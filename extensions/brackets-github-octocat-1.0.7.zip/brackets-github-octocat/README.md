# Brackets Theme - GitHub Octocat

Programing languages applied: `html` `xml` `css` `less` `javascript` `json` `markdown`
