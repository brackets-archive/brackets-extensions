Response for Brackets
=====================

> Responsive design tool for Brackets

Based on @brimelow's [original works](http://www.leebrimelow.com/responsive-brackets-extension-on-github/).

## Usage

A [video](http://www.youtube.com/watch?v=kXTP8XqrSwE) is worth a million words.

### Set Preview URL

If you want to preview with other server URL, e.g. http://localhost:3000/, You can set it under File -> Project Settings

## Demo

You can try it with files from the [original repo](https://github.com/brimelow/Response-for-Brackets/tree/master/demo%20website).

## License

[MIT](http://opensource.org/licenses/MIT) © [Lee Brimelow](http://www.leebrimelow.com/), [Chen-Heng Chang](http://kidwm.net)
