# Brackets BetterCoffee

## Features

* Hide .js files when .coffee & .js filenames match

## TODO

* Update hiding when a new file is created

* Ctrl+J support for CoffeeScript
* Autocompletion suggestions for CoffeeScript
* Better syntax highlighting for CoffeeScript