# brackets-chrome
Chrome theme for Brackets, the code editor
