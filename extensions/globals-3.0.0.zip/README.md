brackets-globals
===============

Highlight global variables in a JavaScript project.  Also spots some misspellings of `length` (e.g. `array.lenght`)  Helps you spot spelling mistakes:

![screen shot](http://s3.postimg.org/ak41o10gj/globals.png)
