define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("fortran", {"name":"FORTRAN","mode":"fortran","fileExtensions":["f90","f77"],"lineComment":["!"]});
});