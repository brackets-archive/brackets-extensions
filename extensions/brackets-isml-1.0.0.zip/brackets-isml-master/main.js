define(function (require, exports, module) {
    "use strict";

    var AppInit = brackets.getModule("utils/AppInit"),
        CodeHintManager = brackets.getModule("editor/CodeHintManager"),
        LanguageManager = brackets.getModule("language/LanguageManager"),
        language = LanguageManager.getLanguage("html"),
        ISMLtagHint = require('text!isml-tag.txt');

    var lastLine,
        lastFileName,
        cachedMatches,
        cachedWordList,
        tokenDefinition,
        currentTokenDefinition;

    LanguageManager.defineLanguage("isml", {
        name: "Isml",
        mode: "htmlmixed",
        fileExtensions: ["isml"]
    });

    function ISMLHint() {
        this.lastLine = 0;
        this.lastFileName = "";
        this.cachedMatches = [];
        this.cachedWordList = [];
        this.tokenDefinition = /[a-zA-Z][(_a-zA-Z0-9$,.';_ )].{2,}/g;
        this.currentTokenDefinition = /[a-zA-Z][a-zA-Z0-9_]+$/g;
    }

    ISMLHint.prototype.hasHints = function (editor, implicitChar) {
        this.editor = editor;
        var cursor = this.editor.getCursorPos();
        if (cursor.line != this.lastLine) {
            var rawWordList = ISMLtagHint.match(this.tokenDefinition);
            this.cachedWordList = [];
            for (var i in rawWordList) {
                var word = rawWordList[i];
                if (this.cachedWordList.indexOf(word) == -1) {
                    this.cachedWordList.push(word);
                }
            }
        }
        this.lastLine = cursor.line;
        var lineBeginning = {
            line: cursor.line,
            ch: 0
        };
        var textBeforeCursor = this.editor.document.getRange(lineBeginning, cursor);
        var symbolBeforeCursorArray = textBeforeCursor.match(this.currentTokenDefinition);
        if (symbolBeforeCursorArray) {
            for (var i in this.cachedWordList) {
                if (this.cachedWordList[i].indexOf(symbolBeforeCursorArray[0]) == 0) {
                    return true;
                }
            }
        }


        return false;
    };

    ISMLHint.prototype.getHints = function (implicitChar) {
        var cursor = this.editor.getCursorPos();
        var lineBeginning = {
            line: cursor.line,
            ch: 0
        };
        var textBeforeCursor = this.editor.document.getRange(lineBeginning, cursor);
        var symbolBeforeCursorArray = textBeforeCursor.match(this.currentTokenDefinition);
        var hintList = [];
        for (var i in this.cachedWordList) {
            if (this.cachedWordList[i].indexOf(symbolBeforeCursorArray[0]) == 0) {
                hintList.push(this.cachedWordList[i]);
            }
        }

        return {
            hints: hintList,
            match: symbolBeforeCursorArray[0],
            selectInitial: true,
            handleWideResults: false
        };
    };

    ISMLHint.prototype.insertHint = function (hint) {
        var cursor = this.editor.getCursorPos();
        var lineBeginning = {
            line: cursor.line,
            ch: 0
        };
        var textBeforeCursor = this.editor.document.getRange(lineBeginning, cursor);
        var indexOfTheSymbol = textBeforeCursor.search(this.currentTokenDefinition);
        var replaceStart = {
            line: cursor.line,
            ch: indexOfTheSymbol
        };
        this.editor.document.replaceRange(hint, replaceStart, cursor);


        return false;
    };

    AppInit.appReady(function () {
        var ismlHints = new ISMLHint();
        CodeHintManager.registerHintProvider(ismlHints, ["html"], 10);
    });

});
