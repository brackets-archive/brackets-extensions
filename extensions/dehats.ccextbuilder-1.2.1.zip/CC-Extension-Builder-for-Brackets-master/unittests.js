/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, describe, it, xit, expect, beforeEach, afterEach, waitsFor, runs, $, brackets, waitsForDone */

define(function (require, exports, module) {
    "use strict";

    // Modules from the SpecRunner window
    var SpecRunnerUtils = brackets.getModule("spec/SpecRunnerUtils"),
        XXXX_Extension   = require("main");

    describe("XXXXExtension", function () {
        
        beforeEach(function () {
            // Stuffs to do before tests
        });
        
        afterEach(function () {
            // Stuffs to do after tests            
        });
                
        describe("Do x", function () {
            
            it("should do x", function () {
                //expect(0)).not.toBe(-1);
            });
            
        });
    });
});