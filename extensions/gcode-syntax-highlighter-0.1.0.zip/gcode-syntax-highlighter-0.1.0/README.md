# G-Code Syntax Highlighter
Brackets highlighter extension for CNC G-Code.
