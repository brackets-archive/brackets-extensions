TwosCalc
=================

Target width ratio calculator extension for Adobe Brackets.

오리지널 뷰크기에 비례해서 목표하는 뷰크기에 대한 가로사이즈를 자동으로 계산해서 변환해주는 계산기입니다.
비율에 따른 픽셀 혹은 퍼센트로 쉽게 변환할 수 있습니다.
   
### Usage
Right Toolbar Button, Edit->TwosCalc or Alt-W / Alt-E
