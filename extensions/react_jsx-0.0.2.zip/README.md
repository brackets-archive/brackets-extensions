React.js (.JSX) Language for Brackets IDE
=========================================

Syntax and code highlighting support.

Uses code from:
 * https://code.google.com/p/lite/
 * https://code.google.com/p/lite/source/browse/trunk/Lite/web/doc/codemirror/jsx.js?spec=svn1482&r=1482


