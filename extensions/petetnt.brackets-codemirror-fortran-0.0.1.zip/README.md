# Brackets CodeMirror Fortran
## Fortran Programming Language syntax highlighter
Brings support for Fortran from CodeMirror to Brackets.
