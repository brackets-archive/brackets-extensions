# brackets mucow language support

Brackets Extension to add mucow syntax highlighting, code hints and attribute completion and Grammar Checking on Save (XML validation)

For an overview of the syntax and more information see http://adobe-muse.github.io/MuCowDocs

This is an Open Source project and is MIT licensed so feel free to fork the repo and make changes and send us pull requests to merge them back in to Master.  

Please file any issues in this repository.  

NOTICE  
xmllint.js is licensed under the Creative Commons "CC BY 3.0 licence".
https://creativecommons.org/licenses/by/3.0/

ATTRIBUTION
```
xmllint.js Built by @syssgx and based on xml.js by @kripken
```

For more infomation see the About page at: http://syssgx.github.io/xml.js/
