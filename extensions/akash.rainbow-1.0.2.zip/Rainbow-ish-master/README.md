# Rainbow-ish
A VIBGYOR colored, dark-based theme for Brackets.
Made with :heart:

<h3>Contributions and Issues</h3>
Please fork this repository and help improve this theme

<h3>License</h3>
MIT
