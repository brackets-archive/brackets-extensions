search-with-google
==================

Adds "Search with..." options to the Brackets file menu and context menu.
As of version 0.3.0 options are: google, stakoverflow, php.net, MDN
