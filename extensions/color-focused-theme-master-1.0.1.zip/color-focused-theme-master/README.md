# color-focused-theme

By Jason Poon

**************************************************** Special THANKS TO  *********************************************

    Rolando B Zabala II (https://github.com/rolo298github/first-custom-theme) who contributed the first theme and help me use it as a reference

                and of course MIT

****************************************************** END **********************************************************



Colors in this Theme are selected carefully to give the user a calming effect but also a energetic and focus effect.

The Color skyblue is suppose to represent water that is for calming, white the orange and yellow represent focus.



Skyblue or Cyan - is the color of trust, freedom, peace and relaxation. This color represents a peace, calm and tranquility. It also provide the heals the emotions creating emotional balance and stability from blue and the growth of green and the uplifting cheerfulness of yellow. This is a color can also recharges our spirits during the times of mental stress and tiredness, alleviating any feelings of loneliness.

Orange - provides a sense of warmth and happiness. With a combination of the stimulation of red and the yellow of cheerfulness. This color react to our gut instincts. Orange is so optimistic and uplifting that it will find many ways that it brings spontaneity and a positive outlook on life and is a great color to use during tough economic times, keeping us motivated and helping us to look on the bright side of life. A warm and inviting color, it is both physically and mentally stimulating, so it gets people thinking and talking


More on Colors Here : http://www.empower-yourself-with-color-psychology.com/meaning-of-colors.html

I am using Less which is completely different from Sass

Less runs on javascript while Sass runs on ruby
Less advantage is that it have a guarded mixins instead of using If else statements
Less require an ajax call which is not inconvient since it requires you to make an ajax call
Less als uses the @ instead of the $ from Sass

http://learn.onemonth.com/sass-vs-less

By Jason Poon
