brackets-jsoniq
===============

JSONiq Package for Atom
