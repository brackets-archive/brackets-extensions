"PasteToBin" for Brackets
==============================
Quickly upload fragments of your code into Pastebin from Brackets.

![PasteToBin](https://raw.githubusercontent.com/Worie/brackets-pastetobin/master/demo.gif)

To use, select the text you'd wish to publish and choose _File > PasteToBin_ or via using keyboard shurtcut (Ctrl+Alt+W on Windows or CMD+Alt+W on Mac)

After that the popup will show up in which you can customize your paste details, such as expiration time or format. After accepting your paste details you'll get a notification from your OS that the URL for you Paste has been generated and copied to your Clipboard automatically!

You can also create private pastes, as long as you can also specify credentials for you Pastebin account in the configuration. 
You can access those by selecting _Edit > PasteToBin config_

### Feel free to contribute

### License
MIT-licensed -- see `main.js` for details.
