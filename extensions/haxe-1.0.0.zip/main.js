define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("haxe", {"name":"Haxe","mode":"haxe","fileExtensions":["hx"],"lineComment":["//"],"blockComment":["/*","*/"]});
});