# CodeMonkey


CodeMonkey is a Dark Theme for Brackets!
It has been optimized for Consolas font on Windows (line-height:140%)


# How to install

Visit http://brackets-themes.github.io/ to see the latest install instructions.

# Troubleshooting

1. Things look "weird"
	1. Try hitting F5 (Save changes before doing so!).

# License

* Theme under MIT license [`LICENSE`](LICENSE)

