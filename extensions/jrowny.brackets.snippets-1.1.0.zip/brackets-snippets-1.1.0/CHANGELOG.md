# Changelog

## 1.1.0
* Added new settings panel - [#34](https://github.com/jrowny/brackets-snippets/pull/34)
* Added support for inline snippets - [#15](https://github.com/jrowny/brackets-snippets/issues/15)
* Added support for string parameters - [#10](https://github.com/jrowny/brackets-snippets/issues/10)
* Default snippet shortcut changed to Ctrl-Alt-Space - [#19](https://github.com/jrowny/brackets-snippets/issues/19)
* Snippets now work on the first line - [#28](https://github.com/jrowny/brackets-snippets/issues/28)
