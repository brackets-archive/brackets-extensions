brackets-packetfilter-syntax
============================

OpenBSD PF (Packet Filter) syntax highlighting for Brackets editor
