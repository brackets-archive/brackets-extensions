"use strict";

// eslint-disable-next-line max-len

/* jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
// eslint-disable-next-line no-unused-vars

/* global define, $, brackets, window */

/**
 *  File: Main.js
 *  Author: Chif <nadchif@gmail.com>
 *  Description:  Simple install-and-use code formatter (beautifier) PHP in Brackets. No extra configuration need, no PHP required
 */
define(function (require, exports, module) {
  'use strict';

  var phpFormatter = require('thirdparty/php').formatter;

  var CommandManager = brackets.getModule('command/CommandManager');
  var EditorManager = brackets.getModule('editor/EditorManager');
  var Menus = brackets.getModule('command/Menus');

  var formatCode = function formatCode() {
    var editor = EditorManager.getFocusedEditor();

    if (editor) {
      var unformatted = editor.document.getText();
      var formatted = phpFormatter(unformatted);
      editor.document.setText(formatted);
    }
  };

  CommandManager.register('Format Document (PHP-Beautify)', 'abfwep', formatCode);
  Menus.getContextMenu(Menus.ContextMenuIds.EDITOR_MENU).addMenuItem('abfwep', null, Menus.LAST);
});