# brackets-goto-starttag-endtag
A Brackets extension to place the cursor on the start or end of the current tag

Just place the cursor into a HTML tag and press: Ctrl+Alt+Shift+/
