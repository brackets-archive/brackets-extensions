# brackets-semicenter
ALT+ENTER - > Puts semicolon at current line, creates and indents new line below. <br />ALT+SEMICOLON - > Puts semicolon at current line, goes to the end of current line. <br />Simple, useful.
