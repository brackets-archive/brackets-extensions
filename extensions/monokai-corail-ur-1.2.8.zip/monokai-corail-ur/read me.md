echo "# Monokai-Corail-UR" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/GUAM23/Monokai-corail-ur.git
git push -u origin master