# Material Brackets 

A light theme inspired from Google's Material Design for brackets

## Installation
Use Brackets' extenstion manager to install the theme, just search for "material"

![Screenshot](https://github.com/kmelkon/material-brackets/raw/master/screenshot.png)
