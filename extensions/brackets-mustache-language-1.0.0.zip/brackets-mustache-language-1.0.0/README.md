brackets-mustache-language
==========================

Brackets Mustache language extension.

Adds support for mustache file extensions.

##License
[MIT](http://opensource.org/licenses/MIT)