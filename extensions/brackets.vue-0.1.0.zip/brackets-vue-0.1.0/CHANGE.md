# CHANGES

## v0.1.x

#### v0.1.0

- Supported creating `*.vue` file on Brackets MenuBar;
- Supported Syntax highlighting for single-file Vue.js components file (.vue);