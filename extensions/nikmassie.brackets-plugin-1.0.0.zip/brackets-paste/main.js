/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window, XMLHttpRequest */

define(function (require, exports, module) {
    
    'use strict';
    
    // Brackets modules
    var CommandManager = brackets.getModule('command/CommandManager');
    var Menus = brackets.getModule('command/Menus');
    var EditorManager = brackets.getModule('editor/EditorManager');
    var Dialogs = brackets.getModule('widgets/Dialogs');
    var LanguageManager = brackets.getModule('language/LanguageManager');
    
    var httpReq = new XMLHttpRequest();
    var url = 'http://paste.ee/api';
    
    // Encodes the selection to be sent properly in the POST request
    function encodeSelection(selection) {
        selection = selection.replace(/\+/g, '%2B');
        selection = selection.replace(/&/g, '%26');
        return selection;
    }
    
    // Returns the current highlighted text
    function getSelection() {
        var editor = EditorManager.getCurrentFullEditor();
        var selection = editor.getSelectedText();
        
        if (selection !== '') {
            return encodeSelection(selection);
        } else {
            throw 'NO_SELECTION';
        }
    }
    
    // Changes the extension to the full language name
    function extensionToLang(ext) {
        switch (ext) {
        case 'js':
            return 'javascript';
        case 'css':
            return 'css';
        case 'html':
            return 'html';
        case 'xml':
            return 'xml';
        case 'py':
            return 'python';
        case 'rb':
            return 'ruby';
        default:
            return 'plain';
        }
    }
    
    // Returns the language of the current file
    function getLang() {
        var extension = (EditorManager.getActiveEditor()).document.file.name.split('.').pop();
        var language = extensionToLang(extension);
        
        if (extension !== 'undefined') {
            return language;
        } else {
            throw 'COULD_NOT_GET_LANGUAGE';
        }
    }
    
    function showDialog(pasteLink) {
        Dialogs.showModalDialog(Dialogs.DIALOG_ID_INFO, 'Paste plugin', '');

        var html = "<div style='-webkit-user-select: text;'>" + pasteLink.replace('/r/', '/p/') + "</div>";
        var $dialog = $(".modal.instance");
        
        $(".dialog-message", $dialog).html(html);
    }
    
    // Pastes highlighted text
    function doPaste() {
        var fields;
        
        try {
            
            fields = 'key=public&description=&language=' + getLang() + '&paste=' + getSelection() + '&format=simple';
        
        } catch (e) {
            console.error(e);
            return;
        }
        
        httpReq.open('POST', url, true);
        
        httpReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        
        httpReq.onload = function () {
            console.log('Raw link: ' + httpReq.responseText);
            showDialog(httpReq.responseText); // Show the user the link
        };
        
        httpReq.send(fields);
    }

    // Register a command (a UI-less object associating an id to a handler)
    var commandId = 'brackets-paste.paste';
    CommandManager.register('Upload paste', commandId, doPaste);

    // Create a menu item bound to the command
    var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
    menu.addMenuItem(commandId, 'Ctrl-Shift-P');
});