# brackets_document_statistics
This brackets extension will provides some basic statistics information about the currently open document in a dialog. 
