/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define */
// Extension configuration
define({
    // Auto-strip when the working document is changed?
    'stripOnDocChange': true,
    // Add to menu items?
    'createMenu': true
});
