/*jslint regexp: true, vars:true*/
/*global define, $, brackets, console*/

/* G-Code Syntax Highlighting to increase readability in Brackets
    v1.0 Marti Deans for Fusion CAM by Autodesk
    */

define(function (require, exports, module) {
    'use strict';
    
    // Integrate with Brackets Language Manager
    var LanguageManager = brackets.getModule("language/LanguageManager");
    var CodeMirror = brackets.getModule("thirdparty/CodeMirror2/lib/codemirror");
    
    CodeMirror.defineMode("gcode", function () {
        
        var ExtensionUtils = brackets.getModule("utils/ExtensionUtils");
        ExtensionUtils.loadStyleSheet(module, "styles/styles.css");
        
        return {
            token: function (stream, state) {
            
                // Program Start %
                if (stream.match(/([\/].*)/, false)) {
                    stream.skipToEnd();
                    return 'program_start';
                }
        
                // Program Number
                if (stream.match(/([o][0-9]{1,4})/i)) {
                    stream.skipToEnd();
                    return 'program_number';
                }
        
                // Block Number
                if (stream.match(/([n][0-9]+)/i)) {
                    return 'block_number';
                }
                
                // Comment
                // but you can't call it 'comment' or it's overwritten by the defaults
                if (stream.match(/(\(.+\))/)) {
                    stream.skipToEnd();
                    return 'comment_line';
                }
                
                // G-Code
                if (stream.match(/([g][0-9]{1,3})/i)) {
                    return 'gcode';
                }
                
                // M-Code
                if (stream.match(/([m][0-9]{1,3})/i)) {
                    return 'mcode';
                }
                
                // Spindle Speed
                if (stream.match(/([s][0-9]+)/i)) {
                    return 'speed';
                }
                
                // Feed Rate
                if (stream.match(/([f][0-9]+\.?[0-9]*)/i)) {
                    return 'feed';
                }
                
                // Skip everything else
                stream.eat(/./);
                
            },
            startState: function () {
                return {
                    inComment: false
                };
            }
        };
    });
    
    CodeMirror.defineMIME("text/x-gcode", "gcode");
    
    LanguageManager.defineLanguage("gcode", {
        name: "G-Code",
        mode: "gcode",
        fileExtensions: ["nc", "tap", "mpf", "eia", "hnc", "min", "hd3", "ncc", "ngc", "gcode"],
        blockComment: ["(", ")"],
        lineComment: [";"]
    });
});