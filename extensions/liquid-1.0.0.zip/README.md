liquid-brackets
===============

A syntax highlighting plugin for liquid in brackets
