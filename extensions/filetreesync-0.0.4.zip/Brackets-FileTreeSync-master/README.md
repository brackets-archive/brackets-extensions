Brackets-FileTreeSync
=====================

Link the File Tree with the Editor so that opening a document will automatically expand and select the file in the source tree.


How to use
=====================

Go to the Navigate menu and toggle "File Tree Sync"
