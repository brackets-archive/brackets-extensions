Wordpress Generate Salts
========

This extension for the Brackets code editor generates Wordpress salt keys. Yay!

##Installation
Clone via git  
-or-  
Download and extract zip file into your Brackets extensions folder.

##Usage
Place your cursor or highlight text then `Ctrl-Shift-G` to generate Wordpress salts.