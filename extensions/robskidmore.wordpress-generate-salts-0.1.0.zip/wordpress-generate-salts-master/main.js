define(function(require, exports, module) {
    'use strict';

    // Import from Brackets
    var CommandManager  = brackets.getModule("command/CommandManager"),
        Menus           = brackets.getModule("command/Menus"),
        DocumentManager = brackets.getModule("document/DocumentManager"),
        EditorManager   = brackets.getModule("editor/EditorManager");

    // Extension constants
    var COMMAND_ID      = "robskidmore.wordpress-generate-salts.generateSalts";
    var COMMAND_NAME    = "Generate Wordpress Salts";

    function generateSalts() {

        // Generate Salts
        var xhr         = new XMLHttpRequest();
        xhr.open("GET", "http://api.wordpress.org/secret-key/1.1/salt/", false);
        xhr.send();
        var salts       = xhr.responseText;

        // Get the cursor position
        var currentDoc  = DocumentManager.getCurrentDocument();
        var editor      = EditorManager.getCurrentFullEditor();
        var selected    = editor.getSelection();
        var pos         = editor.getCursorPos();

        // Insert into Editor
        if(selected) {
            currentDoc.replaceRange(salts, selected.start, selected.end);
        } else {
            currentDoc.replaceRange(salts, pos);
        }
    }

    // Add menu item
    CommandManager.register(COMMAND_NAME, COMMAND_ID, generateSalts);

    var menu            = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
    menu.addMenuItem(COMMAND_ID, [{ "key": "Ctrl-Shift-G" }, { "key": "Ctrl-Shift-G", "platform": "mac" }]);

});
