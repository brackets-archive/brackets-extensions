swig-brackets
=============

Well, i am a lazy guy, and i have always seached for the easiest and fastest way to get my job done, when i wanted to learn Express.js i found a problem about templating, ANOTHER THING TO LEARN! (with Jade for example...) but, thanks to [Swig](https://github.com/paularmstrong/swig "Templating engine for Django/Jinja/Tornado lovers"), i feel myself at home.

So, this simple extension will highlight the code when working on templates.
