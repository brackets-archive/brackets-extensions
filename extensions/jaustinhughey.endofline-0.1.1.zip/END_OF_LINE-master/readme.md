# END_OF_LINE

[Brackets](http://brackets.io) plugin to automatically change your plain-text
file line endings whenever you save the document.

Hooks into the ```file.save``` event and then tells brackets, "hey, yo, that line ending?
Don't care what it is, make it \_this\_". Brackets complies, and then when you next save
the file - which should be right then, since this happens *before* the save is carried out
- Brackets automatically converts the line endings to whatever you told it - LF or CRLF.

## Purpose

I built this because I like Brackets but I don't like CRLF. The only other two
tools I could find that had been updated within two years were overkill. One had
something like 60+ commands along with it, and the other one tied you down to
.gitattributes pretty hard, which I don't necessarily want. So I rolled my own.

## Status: Barely functional

Only does hard-forced LF right now, no actual settings to speak of. Only tested
on Windows.

## What's with the name?

Remember [Battlestar Galactica](https://en.wikipedia.org/wiki/Battlestar_Galactica_(2004_TV_series))?
I loved that show. When I thought about naming this
extension, the first thing I remembered was how "the hybrid" is spouting off
metaphysical BS and then nearly always says, "end of line". Perfect fit, right?

# License: MIT

Copyright (c) 2015 J. Austin Hughey

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.