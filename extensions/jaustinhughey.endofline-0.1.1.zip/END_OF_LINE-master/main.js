define(function(require, exports, module) {
  "use strict"; // TODO: wtf is this?
  var CommandManager = brackets.getModule("command/CommandManager"),
      EditorManager = brackets.getModule("editor/EditorManager"),
      DocumentManager = brackets.getModule("document/DocumentManager"),
      FileUtils = brackets.getModule("file/FileUtils"),
      Menus = brackets.getModule("command/Menus");
  
  // Function to strip trailing whitespace in the file for each line
  function strip_trailing_whitespace(doc) {
    // Add a ref so clowns don't eat us
    doc.addRef();
    console.log("Called function strip_trailing_whitespace");
    console.log("TODO: strip_trailing_whitespace");
    // Release ref since we're done
    doc.releaseRef();
  }
  
  function convert_to_eol() {
    try {
      // TODO: better comments to explain this
      
      // Start by telling the file its line endings should be LF.
      // In testing, this actually worked to fool brackets into
      // automatically converting the entire document. Might be
      // pretty hack-tastic, so be on the lookout for breakage.
      var doc = DocumentManager.getCurrentDocument();
      doc._lineEndings = FileUtils.LINE_ENDINGS_LF;
        
      // Update the text in the file by adding a new line at the
      // end of the file. This forces Brackets to see that there's
      // new data and re-generate line endings according to the NEW
      // line ending policy.
      var eolch;
      switch(FileUtils.LINE_ENDINGS_LF) { // TODO: switch on real cond
        case "LF":
          eolch = "\n";
          break;
        default:
          eolch = "\n";
      }
        
      // This just spoofs brackets into thinking the file has changed
      // so it HAS to regenerate line endings according to the new spec.
      doc.setText(doc.getText() + eolch);
      var x = doc.getText();

      // Next, pull that last character out to restore the file to its
      // original condition. Not wanting to append \n's all over the place!
      doc.setText(x.slice(0, x.length -1));

      // TODO: Implement settings file for this to go either way
      // (crlf or lf) based on the file type. Maybe you want
      // .vbs files (VisualBasic, I think?) as CRLF, for example.
      console.log(doc.file._name + " now has line endings of: " +
                  doc._lineEndings); 
    }
    catch(e) {
      console.error("Caught error while trying to set line endings: " + e.message); 
    }    
  }
  
  var CONVERT_CMD = "jah.END_OF_LINE";
  CommandManager.register("Convert line endings to LF", CONVERT_CMD, convert_to_eol);

  var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
  menu.addMenuDivider(); // Separate extension commands from primary
  menu.addMenuItem(CONVERT_CMD);
  
  var fsave = CommandManager.get("file.save");
  CommandManager.on("beforeExecuteCommand", function(evt, cmd) {
    if(cmd.indexOf("file.save") === 0) {
      // It took all day - literally - to find and figure out how to
      // hook into this event. No idea if it's a good idea or not, but
      // whatever. Adobe - for the love of god, write better api docs!
      // Special thanks to @apptoix for his code:
      // https://github.com/apptoix/bracketstoix/blob/master/main.js#L1976
      convert_to_eol();

      // End of LF conversion
      // TODO: Strip trailing whitespace - move to separate extension
    }    
  });
  
});