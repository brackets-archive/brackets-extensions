define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("ecl", {"name":"ECL","mode":"ecl","fileExtensions":["ecl"],"lineComment":["//"],"blockComment":["/*","*/"]});
});