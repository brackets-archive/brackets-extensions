Base 16 Greenscreen Dark Theme for Brackets
============================

Attempting to be as close to [Greenscreen Dark](http://chriskempson.github.io/base16/#greenscreen) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
