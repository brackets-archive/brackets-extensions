# material-theme
Material theme for Brackets inspired by <a href="https://github.com/DaanDD/material-syntax">material-syntax</a> for Atom

#Screenshot

<img src='https://raw.githubusercontent.com/Gamroth/material-theme/master/less.PNG'>
