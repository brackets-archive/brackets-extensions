brackets-open-terminal
======================
