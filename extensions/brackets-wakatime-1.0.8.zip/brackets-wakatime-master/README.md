brackets-wakatime
=================

Quantify your coding inside [Brackets](http://brackets.io/).

Installation
------------

1. Inside Brackets, navigate to `File` -> `Extension Manager...`

2. Search for `WakaTime`, then click `Install`.

3. Enter your [api key](https://wakatime.com/settings#apikey).

4. Use Brackets like you normally do and your time will be tracked for you automatically.

5. Visit https://wakatime.com to see your logged time.

Screen Shots
------------

![Project Overview](https://wakatime.com/static/img/ScreenShots/ScreenShot-2014-10-29.png)
