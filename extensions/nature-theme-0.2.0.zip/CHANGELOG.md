# CHANGELOG Nature

v 0.1.0

* Create a First version

v 0.1.2

* Change Color in .CodeMirror-linenumber
* Change .CodeMirror-cursor 
* Change .CodeMirror-overwrite .CodeMirror-cursor

v 0.1.3

* Remove main.js Brackets 1.0.0

v 0.2.0

* Add Show Whitespace (https://github.com/DennisKehrig/brackets-show-whitespace)
* Add Code Folding (https://github.com/thehogfather/brackets-code-folding) and Brackets 1.3 (Code Folding)