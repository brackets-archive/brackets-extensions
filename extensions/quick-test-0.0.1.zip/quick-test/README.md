# quick-test
Uses Brackets builder to let you quickly test snipets of code.

Must have Brackets builder installed to use.

All tests are saved with there date and time in the 'quick-tests' folder.