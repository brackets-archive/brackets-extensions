# brackets-octave-syntax
An extension to add Octave/MATLAB syntax highlighting to Brackets
