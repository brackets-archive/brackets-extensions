define(function (require, exports, module) {
    "use strict";
    var LanguageManager = brackets.getModule("language/LanguageManager");

    LanguageManager.defineLanguage("octave", {
        name: "Octave/MATLAB",
        mode: "octave",
        fileExtensions: [".m"],
        blockComment: ["%{", "%}"],
        lineComment: ["%"]
    });
});
