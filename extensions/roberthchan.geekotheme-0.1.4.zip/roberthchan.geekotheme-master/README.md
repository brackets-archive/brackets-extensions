# Geekowater
Tema basado en la guía de estilo de Peter Gabriel's Debut Album con un toque Geeko.
![TheDaysColor](http://www.thedayscolor.com/wallpapers/050814_pg1.jpg)
***
Gracias por escoger mi tema, si tienes alguna sugerencia es bienvenida.

![alt text](https://lh4.googleusercontent.com/adoKo76nNeo077PePEP-LBdDjRbODnKb_idm_n2-GUE=w1043-h566 "Ommadawn")

---
El proceso de la proxima entrega: Geekowater 0.1.1

![alt text](https://soundcoloryellow.files.wordpress.com/2015/03/geekowater0-1-1.png)
Actualmente en la version 0.1.4
Gracias!