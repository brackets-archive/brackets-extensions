# Codecademy Brackets Theme
A theme for Brackets based on the Codecademy theme.

![Codepen Brackets Theme Screenshot](https://raw.githubusercontent.com/trvswgnr/codecademy-brackets-theme/master/screenshot.PNG "Codecademyackets Theme Screenshot")