/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function(require, exports, module) {
    "use strict";

    var Dialogs = brackets.getModule("widgets/Dialogs");
    var BaseView = require('BaseView');
    var template = require("text!templates/dialog_about.html");
    var pkg = JSON.parse(require("text!package.json"));

    var View = BaseView.extend({
        template: _.template(template),

        initialize: function() {
            BaseView.prototype.initialize.apply(this, arguments);

            this.templateValues.pkg = pkg;
        }
    });

    function openDialog() {
        var view = new View();
        var dialog = Dialogs.showModalDialogUsingTemplate('<div class="modal relution-modal relution-modal-about"></div>');
        dialog.getElement().html(view.render().el);
        return dialog;
    }

    exports.openDialog = openDialog;
});