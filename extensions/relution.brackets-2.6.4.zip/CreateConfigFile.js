define(function( require, exports, module ) {
    "use strict";

    var Commands = brackets.getModule("command/Commands");
    var CommandManager = brackets.getModule("command/CommandManager");
    var Menus = brackets.getModule("command/Menus");

    var DocumentManager = brackets.getModule("document/DocumentManager");
    var EditorManager = brackets.getModule("editor/EditorManager");
    var ProjectManager = brackets.getModule("project/ProjectManager");
    var InMemoryFile = brackets.getModule("document/InMemoryFile");
    var FileSystem = brackets.getModule("filesystem/FileSystem");

    var nodeBridge = require("./node/nodeBridge");

    var CONST = require("utils/CONST");

    var Strings = require("strings");

    // the secondary click context menu entry for creating the app.rln file
    var menuEntry = null;
    // the jQuery representation of the menu entry DOM representation
    var $menuEntry = null;

    // Menu entry ID
    var ADD_APP_RLN_ID = 'relution-create-app-rln';

    var baseDirEntry = null;

    // secondary click sideabar context menu aka. project menu
    var projectMenu = Menus.getContextMenu(Menus.ContextMenuIds.PROJECT_MENU);

    /**
     * Register the menu entries
     * @private
     */
    function _registerMenus() {
        // register create command
        CommandManager.register(Strings.CREATE_APP_RLN, ADD_APP_RLN_ID, createConfigFile);
        // register menu entry for secondary click on sidebar
        menuEntry = projectMenu.addMenuItem(ADD_APP_RLN_ID);
        // set the DOM Representation
        $menuEntry = $('#' + menuEntry.id);
    }

    /**
     * Returns the basedir entry of the selected file or folder
     * @returns {*}
     * @private
     */
    function _getBaseBaseDirEntry() {
        var baseDirEntry;
        var selected = ProjectManager.getSelectedItem();
        if( (!selected) || (selected instanceof InMemoryFile) ) {
            // TODO
            // WHAT?! getProjectRoot returns an promise... how can this work?
            selected = ProjectManager.getProjectRoot();
        }
        if( selected.isFile ) {
            baseDirEntry = FileSystem.getDirectoryForPath(selected.parentPath);
        }
        return baseDirEntry || selected;
    }


    /**
     * Highlight the new app.rln when the file is registered in the jstree
     * @private
     */
    function _setCurrentFileToConfig(){
        _unlistenFilesystemChange();
        ProjectManager.showInTree(baseDirEntry._path + CONST.APP_RLN);
    }

    /**
     * Stop listening to filesystem changes
     * @private
     */
    function _unlistenFilesystemChange(){
        FileSystem.off('change', _setCurrentFileToConfig);
    }

    /**
     * Listen to filesystem changes
     * @private
     */
    function _listenFilesystemChange(){
        FileSystem.on('change', _setCurrentFileToConfig);
    }

    /**
     * Create the app.rln file
     * @returns {*}
     */
    function createConfigFile() {

        baseDirEntry = _getBaseBaseDirEntry();

        /**
         * Success callback if file doesn't exists
         * @param suggestedName
         * @returns {*}
         */
        function createWithSuggestedName() {
            nodeBridge.createDefaultAppRln({
                dest: baseDirEntry._path,
                templateValues: {
                    name: baseDirEntry.name,
                    package: 'com.company.' + baseDirEntry.name
                }
            }, function(){
                // when the file was created it takes a while till the brackets ui gets an information about that. register a listener if a change was done.
                _listenFilesystemChange();
            });
        }

        /**
         * Error callback if file exists
         * @param error
         */
        function showErrorDialog( error ) {
            console.error(error);
        }

        // check if the file already exits
        return _fileExists(baseDirEntry).then(createWithSuggestedName).fail(showErrorDialog);
    }

    /**
     * Checks if the file already exists in one of the parent folders
     * Defaults:
     * dir: the current selected file or directory of the sidebar
     * @param dir
     * @param baseFileName
     * @param isFolder
     * @returns {promise}
     * @private
     */
    function _fileExists( dir ) {
        // defaults
        dir = dir || _getBaseBaseDirEntry();

        var deferred = $.Deferred();

        // get all app.rln files
        ProjectManager.getAllFiles(function( file ) {
            return file.name === CONST.CONFIG_FILE;
        }, true).then(function( files ) {
            // if there are some app.rln files
            if( files.length > 0 ) {
                _.each(files, function(file){
                    // check if one of app.rln is inside the parent dir
                    if(dir._path.indexOf(file.parentPath) >= 0){
                        // if a parent folder contains the app.rln reject (hide the menu)
                        deferred.reject();
                        // reject and finish the each loop is possible. also its possible to call everytime the resolve. it doesnt matter - does it?
                    }
                });
                // otherwise resolve (show the menu)
                deferred.resolve();
            } else {
                // resolve (show the menu)
                deferred.resolve();
            }
        });
        return deferred.promise();
    }

    /**
     * Hide the menu entry
     * @private
     */
    function _hideMenuEntry() {
        $menuEntry.hide();
    }

    /**
     * Show the menu entry
     * @private
     */
    function _showMenuEntry() {
        $menuEntry.show();
    }

    /**
     * Before the context menu is opened check if the menu entry should be shown.
     * Show the entry menu if there is no app.rln in the current directory. If there is already one in the parent dir then hide the menu entry
     */
    $(projectMenu).on('beforeContextMenuOpen', function() {
        _showMenuEntry();
        _fileExists().then(function() {
            _showMenuEntry();
        }).fail(function() {
            _hideMenuEntry();
        })
    });

    // register events on load
    _registerMenus();

});