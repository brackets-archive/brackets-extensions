/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports ) {

    var ProjectManager = brackets.getModule("project/ProjectManager");
    var DocumentManager = brackets.getModule("document/DocumentManager");
    var CommandManager = brackets.getModule("command/CommandManager");
    var Commands = brackets.getModule("command/Commands");
    var FileSystem = brackets.getModule("filesystem/FileSystem");
    var RelutionProjectManager = require("utils/RelutionProjectManager");

    var panel = require('panel/panel');

    var _ = brackets.getModule("thirdparty/lodash");
    // Strings
    var BracketsStrings = brackets.getModule("strings");
    var Strings = require("strings");

    var projectRoot = null;

    /**
     * Reads the text from the document and pareses it as JSON
     * @param doc The Brackets document to parse
     * @returns {*}
     */
    function parseAppConfig( doc ) {
        try {
            var appConfig = JSON.parse(doc.getText());
            return $.Deferred().resolve(appConfig);
        } catch( e ) {
            return $.Deferred().reject(e);
        }
    }

    /**
     * Resolves the App.rln document file
     * @returns {*}
     * @private
     */
    function _getAppRlnDoc() {
        return RelutionProjectManager.getConfigFile().then(function( file ) {
            projectRoot = file.parentPath;
            return DocumentManager.getDocumentForPath(file._path)
        });
    }

    /**
     * Resolves the App.rln document file as JSON Object
     * @returns {*}
     * @private
     */
    function _getAppJSON() {
        return _getAppRlnDoc().then(function( doc ) {
            if( doc.isDirty ) {
                return CommandManager.execute(Commands.FILE_SAVE_ALL, {
                    doc: doc
                }).then(function() {
                    return parseAppConfig(doc)
                }).fail(function() {
                });
            } else {
                return parseAppConfig(doc);
            }
        });
    }

    /**
     * Updates the given attributes inside the app.rln file and saves the file
     * @param attributes An object with key value pairs that should be updated. No adding of attributes.
     * @returns {*}
     * @public
     */
    function updateAttributes( attributes ) {
        // get the app.rln as json to operate on it
        return _getAppRlnDoc().then(function( doc ) {
            return parseAppConfig(doc).then(function( appConfig ) {
                _.each(attributes, function(value, key){
                    // if the attribute is inside the app.rln update it
                    if( appConfig[key] ) {
                        appConfig[key] = value;
                    }
                });
                // set the text with the new attributes
                doc.setText(formatCode(appConfig));
                // save the file
                return CommandManager.execute(Commands.FILE_SAVE, {doc: doc});
            });
        });
    }

    function _checkFiles( checkFiles, errorObj, parsedObj ) {

        var dfd = $.Deferred();

        var promises = [];

        _.each(checkFiles, function( objProp ) {
            promises.push(_checkExistenceOfFile(objProp.filePath));
        });

        $.when($.when.apply($, promises)).then(function() {

            if( errorObj ) {
                dfd.reject(errorObj);
            } else {
                dfd.resolve(parsedObj);
            }

        }).fail(function( fail ) {
            errorObj = errorObj || {
                errorCode: 6000,
                message: 'invalid app.rln',
                details: []
            };

            errorObj.details.push({
                errorCode: 6600,
                message: fail
            });
            dfd.reject(errorObj);
        });
        return dfd.promise();
    }

    function _checkExistenceOfFile( filePath ) {
        var dfd = $.Deferred();

        if( !filePath ) {
            dfd.reject(Strings.FILE_PATH_IS_MANDATORY);
        }

        var file = FileSystem.getFileForPath(projectRoot + filePath);

        file.exists(function( error, exists ) {
            if( error ) {
                dfd.reject(Strings.ERROR_ON_FILE_EXISTS + ': ' + projectRoot + '' + filePath);
            } else if( !exists ) {
                dfd.reject(Strings.FILE + ' ' + projectRoot + '' + filePath + ' ' + Strings.NOT_EXISTS);
            } else {
                dfd.resolve({
                    path: filePath,
                    projectPath: projectRoot,
                    exists: exists
                });
            }
        });
        return dfd.promise();
    }

    function getAppJSON() {

        return _getAppJSON().then(function( parsedObj ) {
            return _validate(parsedObj);
        });

    }

    function _validate( parsedObj ) {

        // contains all errors
        var errorObj = null;


        // the required fields
        var requiredFields = [
            {
                key: 'name',
                fieldName: Strings.APP_NAME
            },
            {
                key: 'versionCode',
                fieldName: Strings.VERSION_CODE

            },
            {
                key: 'versionName',
                fieldName: Strings.VERSION_NAME
            },
            {
                key: 'package',
                fieldName: Strings.PACKAGE_NAME
            }
        ];

        return _checkJson(requiredFields, parsedObj);
    }

    function _checkJson( requiredFields, parsedObj ) {
        var dfd = $.Deferred();
        var _errorObj = null;
        var _errorDetails = [];

        // contains all files that needs to be inside the root
        var checkFiles = [];
        if( parsedObj.changelog ) {
            checkFiles.push({
                key: 'changelog',
                filePath: parsedObj.changelog,
                fieldName: Strings.CHANGELOG
            });
        }
        if( parsedObj.mainPage ) {
            checkFiles.push({
                key: 'mainPage',
                filePath: parsedObj.mainPage,
                fieldName: Strings.MAIN_PAGE
            });
        }
        if( parsedObj.defaultIcon ) {
            checkFiles.push({
                key: 'defaultIcon',
                filePath: parsedObj.defaultIcon,
                fieldName: Strings.DEFAULT_ICON
            });
        }

        _.each(requiredFields, function( objProp ) {
            if( parsedObj[objProp.key] === undefined ) {

                _errorDetails.push({
                    errorCode: 6300,
                    message: objProp.fieldName + ' ' + Strings.MUST_DEFINED
                });

            }
            if( parsedObj[objProp.key] === null ) {

                _errorDetails.push({
                    errorCode: 6100,
                    message: objProp.fieldName + ' ' + Strings.NOT_NULL
                });

            }
            if( parsedObj[objProp.key] === '' ) {

                _errorDetails.push({
                    errorCode: 6200,
                    message: objProp.fieldName + ' ' + Strings.NOT_EMPTY
                });
            }
        });

        //pattern for identifier
        var pattern = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+[0-9a-z_]$/i;
        var isValidIdentifier = pattern.test(parsedObj.package);

        if( !isValidIdentifier ) {
            _errorDetails.push({
                errorCode: 6300,
                message: 'Invalid Identifier for Package Name'
            });
        }

        // Check for Integer
        if( parsedObj.versionCode % 1 !== 0 ) {
            _errorDetails.push({
                errorCode: 6400,
                message: 'Version Code has to be an integer'
            });
        }
        if( parsedObj.versionCode < 0 ) {
            _errorDetails.push({
                errorCode: 6500,
                message: 'Version Code has to be greater or equal 0'
            });
        }

        if( parsedObj.copyright ) {
            var length = parsedObj.copyright.license.length + parsedObj.copyright.legal.length;
            var maxCopyrightLength = 4000;
            if(length > maxCopyrightLength) {
                _errorDetails.push({
                    errorCode: 9000,
                    message: 'License and Legal have to be less than 4000 characters!'
                });
            }
        }


        //define _errorObj if there are any intems in _errorDetails
        if( _errorDetails.length > 0 ) {
            _errorObj = {
                errorCode: 6000,
                message: 'invalid app.rln',
                details: _errorDetails
            };
        }

        // reject or resolve
        if( checkFiles.length === 0 ) {
            if( _errorObj ) {
                // reject
                dfd.reject(_errorObj);
            } else {
                // resolve
                dfd.resolve(parsedObj);
            }
        } else {
            return _checkFiles(checkFiles, _errorObj, parsedObj);
        }

        return dfd.promise();
    }

    function getMainPagePath() {
        return _getAppJSON().then(function( config ) {
            return RelutionProjectManager.getProjectRoot().then(function( path ) {
                return path + config.mainPage;
            });
        });
    }

    /**
     * Return the version code based on the app.rln file
     * @returns {*}
     */
    function getVersionCode() {
        return _getAppJSON().then(function( config ) {
            return config.versionCode;
        });
    }

    /**
     * Returns an Object with all version informations like the version code or version name that are read from the app.rln file
     * @returns {*}
     */
    function getVersionInformation() {
        return _getAppJSON().then(function( config ) {
            return {
                versionCode: config.versionCode,
                versionName: config.versionName
            };
        });
    }

    /**
     * Formats the given text as nice JSON string
     * @param text
     * @returns {*}
     */
    function formatCode( text ) {
        return JSON.stringify(text, null, 5);
    }

    /**
     * Increases the version number of the given version name.
     * It must be in this format to work: 0.1.0  - the second number gets increased. Result would be 0.2.0
     * -> also working: '0.1.0 beta' -> '0.2.0 beta'
     * With suggestion:
     * versionName: '0.1.0 beta'
     * versionSuggestion: 30
     * result: '0.30.0 beta'
     * @param versionName - the name that should be updated
     * @param versionSuggestion - the content to replace the second part
     * @returns {*}
     * @example
     *
     * getBextVersionName('0.1.0'); // 0.2.0
     * getBextVersionName('0.1.0', 3); // 0.3.0
     *
     */
    function getNextVersionName( versionName, versionSuggestion ) {
        if(versionName){
            var version = versionName.split('.');
            if(version.length && version[1]){
                var next = parseInt(version[1], 10);
                version[1] = versionSuggestion || next + 1;
                return version.join('.');
            }
        }

        return versionName;
    }

    // For unittest only
    exports.parseAppConfig = parseAppConfig;
    exports._validate = _validate;

    // API
    exports.getAppJSON = getAppJSON;
    exports.getMainPagePath = getMainPagePath;
    exports.getVersionCode = getVersionCode;
    exports.getVersionInformation = getVersionInformation;
    exports.updateAttributes = updateAttributes;
    exports.formatCode = formatCode;
    exports.getNextVersionName = getNextVersionName;

});
