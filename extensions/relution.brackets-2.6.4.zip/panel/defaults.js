/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports ) {
    "use strict";

    var licenses = [
        {"type": "Other", "legal": ""},
        {"type": "Apache v2 License", "legal": "http://www.apache.org/licenses/LICENSE-2.0.html"},
        {"type": "GPL v2", "legal": "http://www.gnu.de/documents/gpl-2.0.en.html"},
        {"type": "MIT License", "legal": "http://opensource.org/licenses/MIT"},
        {"type": "Affero GPL", "legal": "http://www.gnu.org/licenses/agpl-3.0.html"},
        {"type": "Artistic License 2.0", "legal": "http://opensource.org/licenses/Artistic-2.0"},
        {"type": "BSD (3-Clause) License", "legal": "http://opensource.org/licenses/BSD-3-Clause"},
        {"type": "BSD 2-Clause license", "legal": "http://opensource.org/licenses/BSD-2-Clause"},
        {"type": "CC0 1.0 Universal", "legal": "http://creativecommons.org/publicdomain/zero/1.0/legalcode"},
        {"type": "Eclipse Public License v1.0", "legal": "https://www.eclipse.org/legal/epl-v10.html"},
        {"type": "GPL v3", "legal": "http://www.gnu.org/copyleft/gpl.html"},
        {"type": "LGPL v2.1", "legal": "https://www.gnu.org/licenses/old-licenses/lgpl-2.1.en.html"},
        {"type": "LGPL v3", "legal": "http://www.gnu.org/licenses/lgpl-3.0.html"},
        {"type": "Mozilla Public License Version 2.0", "legal": "https://www.mozilla.org/MPL/2.0/"},
        {"type": "The Unlicense", "legal": "http://unlicense.org/"}
    ];


    var cordovaGeneralSettings = [
        {
            id: 'ios-AllowInlineMediaPlayback',
            defaultValue: false
        },
        {
            id: 'ios-AutoHideSplashScreen',
            defaultValue: true
        },
        {
            id: 'ios-BackupWebStorage',
            defaultValue: 'cloud'
        },
        {
            id: 'ios-DisallowOverscroll',
            defaultValue: false
        },
        {
            id: 'ios-EnableViewportScale',
            defaultValue: false
        },
        {
            id: 'ios-FadeSplashScreen',
            defaultValue: true
        },
        {
            id: 'ios-FadeSplashScreenDuration',
            defaultValue: '.25'
        },
        {

            id: 'ios-KeyboardDisplayRequiresUserAction',
            defaultValue: true
        },
        {
            id: 'ios-MediaPlaybackRequiresUserAction',
            defaultValue: false
        },
        {
            id: 'ios-ShowSplashScreenSpinner',
            defaultValue: true
        },
        {
            id: 'ios-SuppressesIncrementalRendering',
            defaultValue: false
        },
        {
            id: 'ios-TopActivityIndicator',
            defaultValue: 'gray'
        },
        {
            id: 'ios-GapBetweenPages',
            defaultValue: 0
        },
        {
            id: 'ios-PageLength',
            defaultValue: 0
        },
        {
            id: 'ios-PaginationBreakingMode',
            defaultValue: 'page'
        },
        {
            id: 'ios-PaginationMode',
            defaultValue: 'unpaginated'
        }

    ];

    var cordovaAndroidSettings =  [
        {
            id: "android-DisallowOverscroll",
            defaultValue: false
        },
        {
            id: "android-KeepRunning",
            defaultValue: true
        },
        {
            id: "android-ShowTitle",
            defaultValue: false
        },
        {
            id: "android-SetFullscreen",
            defaultValue: false
        },
        {
            id: "android-SplashScreenDelay",
            defaultValue: 2000
        },
        {
            id: "android-SplashScreen",
            defaultValue: 0
        },
        {
            id: "android-BackgroundColor",
            defaultValue: -16777216
        },
        {
            id: "android-LoadDialog",
            defaultValue: "null"
        },
        {
            id: "android-LoadingPageDialog",
            defaultValue: "null"
        },
        {
            id: "android-ErrorUrl",
            defaultValue: "null"
        },
        {
            id: "android-LoadUrlTimeoutValue",
            defaultValue: 20000
        },
        {
            id: "android-InAppBrowserStorageEnabled",
            defaultValue: true
        },
        {
            id: "android-LogLevel",
            defaultValue: "DEBUG"
        }

    ];

    var statusBarSettings = [
        {
            id: 'StatusBarOverlaysWebView',
            defaultValue: true
        },
        {
            id: 'StatusBarBackgroundColor',
            defaultValue: '#000000'
        }
    ];

    var plugins = [
        "LocalStorage",
        "Device",
        "StatusBar",
        "Geolocation"
    ];



    // API
    exports.plugins = plugins;
    exports.statusBarSettings = statusBarSettings;
    exports.cordovaAndroidSettings = cordovaAndroidSettings;
    exports.cordovaGeneralSettings = cordovaGeneralSettings;
    exports.licenses = licenses;

});
