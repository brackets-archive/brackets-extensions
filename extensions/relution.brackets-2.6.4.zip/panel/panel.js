/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports ) {
    "use strict"

    var PanelManager = brackets.getModule("view/PanelManager");
    var MainViewManager = brackets.getModule("view/MainViewManager");
    var WorkspaceManager = brackets.getModule("view/WorkspaceManager");
    var CommandManager = brackets.getModule("command/CommandManager");
    var Commands = brackets.getModule("command/Commands");
    var AppInit = brackets.getModule("utils/AppInit");
    var LanguageManager = brackets.getModule("language/LanguageManager");
    var FileViewController = brackets.getModule("project/FileViewController");
    var EditorManager = brackets.getModule("editor/EditorManager");
    var DocumentManager = brackets.getModule("document/DocumentManager");
    var FileSystem = brackets.getModule("filesystem/FileSystem");
    var ProjectManager = brackets.getModule("project/ProjectManager");

    var PanelMarkup = require("text!panel/html/panel.html");
    var BaseView = require('BaseView');
    var select2 = require('select2');
    var jsonHolderTemplate = require("text!templates/json-holder.html");
    var CONST = require("utils/CONST");
    var RelutionProjectManager = require("utils/RelutionProjectManager");

    // Strings
    var BracketsStrings = brackets.getModule("strings");
    var Strings = require("../strings");
    var weinre = require('weinre/weinre');
    var validateJson = require('validateJson');

    var debuggerScript = '';

    require('parsley');

    // the current editor
    var _currentEditor = null;
    // the current document (contains the json text)
    var _currentDocument = null;

    // the backbone view
    var editorView = null;

    var projectPath = null;

    // render the panel
    var $panel = $(Mustache.render(PanelMarkup, Strings));
    // create the panel
    var bottomPanel = WorkspaceManager.createBottomPanel("testName", $panel);

    // To prevent loops: chaning a form updates the file -> updating the file fires change -> change will update the form
    var ignoreInputOnFormChange = false;

    var defaults = require('panel/defaults');

    // initialize default settings
    var licenses = defaults.licenses;
    var cordovaGeneralSettings = defaults.cordovaGeneralSettings;
    var cordovaAndroidSettings =  defaults.cordovaAndroidSettings;
    var statusBarSettings =  defaults.statusBarSettings;
    var plugins =  defaults.plugins;

    // bind events //

    // bind the close button of the panel
    $panel.on("click", ".close", function() {
        _hide();
    });

    /**
     * Backbone View to display form representation of the json/rln file
     * @type {*}
     */
    var EditorView = BaseView.extend({

        className: 'relution-json-form',

        lastSelectedTab: Strings.APP_INFO,

        events: {
            // click on one tab
            'click .relution-json-footer .relution-button-group button': 'switchToTab',
            // change on an form element
            'keyup .relution-json-content input': 'updateDocument',
            'keyup .relution-json-content textarea': 'updateDocument',
            'change .relution-json-content input': 'updateDocument',
            'blur .select2-container input': 'updateDocument',
            'click [data-action="selectIconFile"]': 'selectIconFile',
            'click [data-action="selectChangelogFile"]': 'selectChangelogFile',
            'click [data-action="selectMainPage"]': 'selectMainPage',
            'change .licenses select': 'changeLicense',
            'change #relution-jsonviewer-cordova-settings': 'changeCordovaSettings',
            'change #relution-jsonviewer-cordova-android-settings': 'changeCordovaAndroidSettings',
            'click .remove-tag': 'removeTag',
            'change #relution-jsonviewer-debugger': 'render',
            'change #relution-jsonviewer-debugger-script': 'changeDebuggerScript'
        },

        template: _.template(jsonHolderTemplate),

        changeDebuggerScript: function(){
            debuggerScript = this.binding.debugScript;
            weinre.setClientUrl(debuggerScript);
        },

        removeTag: function(ev){
            var id = $(ev.target).attr('data-id');
            var parent = $(ev.target).attr('data-select-identifier');
            var selector = "#" +parent +  " li.select2-search-choice div:contains('" + id + "')";

            $(selector).parent().find('a.select2-search-choice-close').click();
        },

        updateDocumentAndRender: function(){
            this.updateDocument();
            this.render();
        },

        changeStatusBarSettings: function(ev){
            if( ev.added ) {
                this.binding[ev.added.id] = ev.added.element[0].getAttribute('data-default');
            } else if( ev.removed ) {
                this.binding[ev.removed.id] = '';
            }
            this.updateDocumentAndRender();
        },

        changeCordovaSettings: function( ev ) {
            if( ev.added ) {
                this.binding[ev.added.id] = ev.added.element[0].getAttribute('data-default');
            } else if( ev.removed ) {
                this.binding[ev.removed.id] = '';
            }
            this.updateDocumentAndRender();
        },

        changeCordovaAndroidSettings: function( ev ){
            if( ev.added ) {
                this.binding[ev.added.id] = ev.added.element[0].getAttribute('data-default');
            } else if( ev.removed ) {
                this.binding[ev.removed.id] = '';
            }
            this.updateDocumentAndRender();
        },

        changeLicense: function( ev ) {
            var license = licenses[$(ev.target).val()];
            this.binding.licenseLegal = license.legal;
            this.binding.licenseType = license.type;
            this.updateDocumentAndRender();
        },

        selectIconFile: function( e ) {
            e.preventDefault();
            e.stopPropagation();

            var path = this.projectPath + '' + this.binding.defaultIcon.split('/').slice(0, -1).join('/');
            FileSystem.showOpenDialog(false, false, BracketsStrings.OPEN_FILE, path, null, function( error, files ) {
                if( files && files[0] ) {
                    this.binding.defaultIcon = files[0].replace(this.projectPath, '');
                    this.updateDocument();
                    if( _isInRoot(this.binding.defaultIcon) ) {
                        this.render();
                    }
                }
            }.bind(this));
        },

        selectChangelogFile: function( e ) {
            e.preventDefault();
            e.stopPropagation();

            FileSystem.showOpenDialog(false, false, BracketsStrings.OPEN_FILE, this.projectPath + '' + this.binding.changelog, null, function( error, files ) {
                if( files && files[0] ) {
                    this.binding.changelog = files[0].replace(this.projectPath, '');
                    this.updateDocument();
                }
            }.bind(this));
        },

        selectMainPage: function( e ) {
            e.preventDefault();
            e.stopPropagation();

            FileSystem.showOpenDialog(false, false, BracketsStrings.OPEN_FILE, this.projectPath + '' + this.binding.mainPage, null, function( error, files ) {
                if( files && files[0] ) {
                    this.binding.mainPage = files[0].replace(this.projectPath, '');
                    this.updateDocument();
                }
            }.bind(this));
        },

        initialize: function() {
            // call super
            BaseView.prototype.initialize.apply(this, arguments);
            // add relution strings to the template values
            this.templateValues.Strings = Strings;
            // add brackets strings to the template values
            this.templateValues.BracketsStrings = BracketsStrings;
            this.projectPath = projectPath;

            this.templateValues.utils = {};

            this.customValidator();
        },

        /**
         * gets called if one of the tab buttons is pressed
         * @param ev
         */
        switchToTab: function( ev ) {
            // get a jquery representation of the clicked element ...
            var $el = $(ev.target);
            // ... and store the current tab
            // display the correct content
            this.setActiveTab($el.attr('data-tab'));
        },

        preRender: function() {
            // add the JSON text to the template values
            this.templateValues.rln = _getParsedDocumentText();
            var licenseSelection = 0;
            _.find(licenses, function( l, i ) {
                if( (this.binding && this.binding.licenseType === l.type) || (this.templateValues && this.templateValues.rln && this.templateValues.rln.copyright && l.type === this.templateValues.rln.copyright.license) ) {
                    licenseSelection = i;
                    return true;
                }
            }, this);

            this.templateValues.utils.icon = this.projectPath + this.templateValues.rln.defaultIcon;
            this.templateValues.utils.licenses = licenses;
            this.templateValues.utils.licenseSelection = licenseSelection;
            this.templateValues.utils.cordovaGeneralSettings = cordovaGeneralSettings;
            this.templateValues.utils.cordovaAndroidSettings = cordovaAndroidSettings;

            _.each(this.templateValues.utils.cordovaGeneralSettings, function( value, id ) {
                if( this.templateValues.rln.preferences && typeof this.templateValues.rln.preferences[value.id.replace('ios-','')] !== 'undefined' ) {
                    value.value = this.templateValues.rln.preferences[value.id.replace('ios-','')];
                } else {
                    delete value.value;
                }
            }, this);

            _.each(this.templateValues.utils.cordovaAndroidSettings, function( value, id ) {

                if( this.templateValues.rln.preferencesAndroid && typeof this.templateValues.rln.preferencesAndroid[value.id.replace('android-','')] !== 'undefined' ) {
                    value.value = this.templateValues.rln.preferencesAndroid[value.id.replace('android-','')];
                } else {
                    delete value.value;
                }
            }, this);


            this.templateValues.utils.statusBarSettings = statusBarSettings;
            _.each(this.templateValues.utils.statusBarSettings, function( value, id ) {
                if( this.templateValues.rln.preferences && typeof this.templateValues.rln.preferences[value.id] !== 'undefined' ) {
                    value.value = this.templateValues.rln.preferences[value.id];
                } else {
                    delete value.value;
                }
            }, this);
        },

        postRender: function() {
            // display the correct content
            this.setActiveTab();
            this.$el.find('#relution-jsonviewer-keywords').select2({
                tags: []
            });
            this.$el.find('.licenses select').select2();
            var settings = [];
            _.each(this.templateValues.utils.cordovaGeneralSettings, function( value, id ) {
                if(this.templateValues.rln.preferences && typeof this.templateValues.rln.preferences[value.id.replace('ios-','')] !== 'undefined'){
                    settings.push(value.id);
                    this.binding['ios-' + value.id] = value.value;
                }
            },this);

            var androidSettings = [];
            _.each(this.templateValues.utils.cordovaAndroidSettings, function( value, id ) {
                if(this.templateValues.rln.preferencesAndroid && typeof this.templateValues.rln.preferencesAndroid[value.id.replace('android-','')] !== 'undefined'){
                    androidSettings.push(value.id);
                    this.binding['android-' + value.id] = value.value;
                }
            },this);

            var statusBarSettings = [];
            _.each(this.templateValues.utils.statusBarSettings, function( value, id ) {
                if(this.templateValues.rln.preferences && typeof this.templateValues.rln.preferences[value.id] !== 'undefined'){
                    statusBarSettings.push(value.id);
                    this.binding[value.id] = value.value;
                }
            },this);

            this.binding.debugScript =  debuggerScript || weinre.getClientUrl();


            this.$el.find('#relution-jsonviewer-cordova-settings').val(settings).select2();
            this.$el.find('#relution-jsonviewer-statusbar-settings').val(statusBarSettings).select2();
            this.$el.find('#relution-jsonviewer-cordova-android-settings').val(androidSettings).select2();

            this.$el.find('#s2id_relution-jsonviewer-cordova-settings').addClass('placeholder').find('input').attr('placeholder', Strings.PLEASE_SELECT_SETTING);
            this.$el.find('#s2id_relution-jsonviewer-statusbar-settings').addClass('placeholder').find('input').attr('placeholder', Strings.PLEASE_SELECT_STATUSBAR_SETTING);
            this.$el.find('#s2id_relution-jsonviewer-cordova-android-settings').addClass('placeholder').find('input').attr('placeholder', Strings.PLEASE_SELECT_SETTING);
        },

        /**
         * Set the active tab and update the button group
         * @param tab
         */
        setActiveTab: function( tab ) {
            var _tab = tab || this.lastSelectedTab;
            this.lastSelectedTab = _tab;
            // hide all tab contents - all tabs are under each other
            this.$el.find('.tab').hide();
            // and display the one that matchs with the content of the button
            this.$el.find('div[data-tab="' + _tab + '"]').show();
            // remove all active states
            this.$el.find('.relution-json-footer .relution-button-group button').removeClass('active').removeClass('primary');
            this.$el.find('button[data-tab="' + _tab + '"]').addClass('active').addClass('primary');
        },

        /**
         * Builds the JSON based on the form elements
         * @returns {*}
         */
        formToText: function() {
            var data = JSON.parse(JSON.stringify(this.binding.get()));
            data = _.defaults(data, this.templateValues.rln);
            data.developer = {};
            data.developer.name = data.developerName;
            data.developer.company = data.developerCompany;
            data.developer.email = data.developerMail;
            data.developer.web = data.developerWeb;
            data.copyright = {};
            data.copyright.license = data.licenseType;
            data.copyright.legal = data.licenseLegal;
            data.versionCode = parseInt(data.versionCode, 10);
            data.defaultIcon = data.defaultIcon.replace(this.projectPath, '')
            data.keywords = data.keywords.split(',').filter(function( el ) {
                return el.length != 0
            });

            data.preferences = {};

            var convertToDataType = function(valueToConvert){
                // convert boolean string to real boolean value
                if(valueToConvert === 'false'){
                    valueToConvert = false;
                } else if(valueToConvert === 'true'){
                    valueToConvert = true;
                } else if(!(isNaN(parseInt(valueToConvert, 10)))){
                    // convert Integer string to real integer value
                    valueToConvert = parseInt(valueToConvert, 10);
                }
                return valueToConvert;
            };

            _.each(this.templateValues.utils.cordovaGeneralSettings, function( value, id ) {
                if( data[value.id] !== '' ) {
                    var newKey = value.id.replace('ios-','');
                    data.preferences[newKey] = data[value.id];
                    data.preferences[newKey] = convertToDataType(data.preferences[newKey]);
                }
                delete data[value.id];
            }, this);

            _.each(this.templateValues.utils.statusBarSettings, function( value, id ) {
                if( data[value.id] !== '' ) {
                    data.preferences[value.id] = data[value.id];
                    data.preferences[value.id] = convertToDataType(data.preferences[value.id]);
                }
                delete data[value.id];
            }, this);

            if( Object.keys(data.preferences).length === 0 ) {
                delete data.preferences;
            }

            data.preferencesAndroid = {};

            _.each(this.templateValues.utils.cordovaAndroidSettings, function( value, id ) {
                if( data[value.id] !== '' ) {
                    var newKey = value.id.replace('android-','');
                    data.preferencesAndroid[newKey] = data[value.id];
                    data.preferencesAndroid[newKey] = convertToDataType(data.preferencesAndroid[newKey]);
                }
                delete data[value.id];
            }, this);

            if( Object.keys(data.preferencesAndroid).length === 0 ) {
                delete data.preferencesAndroid;
            }

            //data.plugins = data.plugins.split(',');

            if( data.mainPage === '' ) {
                delete data.mainPage;
            }

            if( data.changelog === '' ) {
                delete data.changelog;
            }

            if( data.defaultIcon === '' ) {
                delete data.defaultIcon;
            }

            if( data.description === '' ) {
                delete data.description;
            }

            if( !data.plugins ) {
                delete data.plugins;
            }

            delete data.developerName;
            delete data.developerCompany;
            delete data.licenseType;
            delete data.licenseLegal;
            delete data.developerMail;
            delete data.developerWeb;
            delete data.debugScript;


            // developer
            if( data.developer.name === '' ) {
                delete data.developer.name;
            }

            if( data.developer.company === '' ) {
                delete data.developer.company;
            }

            if( data.developer.email === '' ) {
                delete data.developer.email;
            }

            if( data.developer.web === '' ) {
                delete data.developer.web;
            }

            if( Object.keys(data.developer).length < 1 ) {
                delete data.developer;
            }


            // copyright
            if( data.copyright.license === '' ) {
                delete data.copyright.license;
            }

            if( data.copyright.legal === '' ) {
                delete data.copyright.legal;
            }

            if( Object.keys(data.copyright).length < 1 ) {
                delete data.copyright;
            }

            if( !data.versionCode || isNaN(data.versionCode) ) {
                data.versionCode = 0;
            }

            return validateJson.formatCode(data);
        },

        /**
         * Updates the document file
         * @param ev
         */
        updateDocument: function( ev ) {
            //validate form
            this.$el.find('form').parsley().validate();

            // ignore the form change rerender
            ignoreInputOnFormChange = true;
            // set the text as current json file
            _currentDocument.setText(this.formToText());
        },

        /**
         * define costum validators for the fields 'appname' and 'package'
         */
        customValidator: function() {
            window.ParsleyValidator.addValidator('fileinproject', _isInRoot, 33).addMessage('en', 'package', this.Strings.NEEDS_TO_BE_INSIDE_PROJECT);

            window.ParsleyValidator.addValidator('package', function( value ) {
                var pattern = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+[0-9a-z_]$/i;
                return pattern.test(value);
            }, 32).addMessage('en', 'package', this.Strings.INVALID_IDENTIFIER);
        }
    });

    function _isInRoot( value ) {
        return value.indexOf('/') !== 0
    }

    /**
     * Return the current documents text
     * @returns {*}
     * @private
     */
    function _getCurrentDocumentText() {
        return _currentDocument.getText();
    }

    /**
     * Return a valid JSON JS Object based on the documents file - if it isn't valid an empty object is returned
     * @param text
     * @returns {*}
     * @private
     */
    function _parseDocumentText( text ) {
        try {
            // if its a valid json return a js parsed object
            return JSON.parse(text);
        } catch( e ) {
            // TODO: raise error!
            // otherwise return an empty object
            return {};
        }
    }

    /**
     * Returns an JS Object based on the documents text - if it's not valid an emtpy object is returned
     * @returns {*}
     * @private
     */
    function _getParsedDocumentText() {

        var text = _getCurrentDocumentText();

        //https://github.com/douglascrockford/JSON-js/blob/master/json2.js
        //line 450
        //by douglascrockford
        if( /^[\],:{}\s]*$/.test(text.replace(/\\["\\\/bfnrtu]/g, '@').replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']').replace(/(?:^|:|,)(?:\s*\[)+/g, '')) ) {
            //the json is ok
            return _parseDocumentText(text);
        } else {
            console.error('Invalid JSON - Syntax Error');
            return {};
            //the json is not ok
        }
    }

    /**
     * Returns the active editor
     * @returns {*}
     * @private
     */
    function _getActiveEditor() {
        return EditorManager.getActiveEditor();
    }

    /**
     * Open the panel
     * @param fileName
     * @param editor
     * @private
     */
    function _openPanel( fileName, editor ) {
        // set the current editor
        _currentEditor = editor || _getActiveEditor();
        // set the current document
        _currentDocument = _currentEditor.document;
        // clear previous change event bindings
        $(_currentDocument).off('change', documentChange);
        // set change event
        $(_currentDocument).on('change', documentChange);
        // show the panel
        show();
    }

    /**
     * Update the panel content
     * @param event
     * @param document
     */
    function documentChange( event, document ) {
        try {
            // check if the content is valid
            JSON.parse(document.getText());
            // if change is through the text editor not the form
            if( !ignoreInputOnFormChange ) {
                // update the backbone view
                editorView.render();
            }

        } catch( e ) {
            // TODO: raise error if file is not valid
        }
        // set ignore to default value
        ignoreInputOnFormChange = false;
    }

    /**
     * Open the pannel if the given filename is app.rln otherwise hide it
     * @param fileName
     * @param editor
     * @private
     */
    function _handleFileName( fileName, editor ) {
        if( fileName === CONST.CONFIG_FILE ) {
            _openPanel(fileName, editor);
        } else {
            _hide();
        }
    }

    /**
     * Show the panel
     * @param text
     * @returns {*}
     */
    function show( text ) {
        if(!projectPath){
            return;
        }
        // create a new backbone view
        editorView = new EditorView();
        // add the view to the DOM
        $('#relution-json-editor .relution-json-container').html(editorView.render().el);
        // show the panel
        bottomPanel.show();
        // return this for chaining
        return this;
    }

    /**
     * Internal hide
     * @returns {*}
     * @private
     */
    function _hide() {
        hide();
        // return this for chaining
        return this;
    }

    /**
     * Hide the panel
     * @returns {*}
     */
    function hide() {
        // hide the panel
        bottomPanel.hide();
        // return this for chaining
        return this;
    }

    /**
     * Toggle the panel
     * @param settings
     * @returns {*}
     */
    function toggle( settings ) {
        if( bottomPanel.isVisible() ) {
            hide();
            if( settings && typeof settings.on === 'function' ) {
                settings.on();
            }
        } else {
            show();
            if( settings && typeof settings.off === 'function' ) {
                settings.off();
            }

        }
        // return this for chaining
        return this;
    }

    function _setProject() {
        return RelutionProjectManager.getProjectRoot().then(function( path ) {
            projectPath = path || ProjectManager.getProjectRoot().fullPath;
            if( editorView ) {
                editorView.projectPath = projectPath;
            }
        }).fail(function() {
            console.error('did not find', CONST.CONFIG_FILE);
        });
    }

    AppInit.appReady(function() {
        // set the current editor
        _currentEditor = _getActiveEditor();
        _setProject();

        $(MainViewManager).on("currentFileChange", function () {
            if(DocumentManager.getCurrentDocument()) {
                _handleFileName(DocumentManager.getCurrentDocument().file.name);
            }

        });
    });

    $(ProjectManager).on('projectOpen', function( ev, doc ) {
        _setProject();
        if(DocumentManager.getCurrentDocument()) {
            _handleFileName(DocumentManager.getCurrentDocument().file.name);
        } else {
            //if the currentDocument isn't immediately available, give him some time
            setTimeout(function() {
                if(DocumentManager.getCurrentDocument()) {
                    _handleFileName(DocumentManager.getCurrentDocument().file.name);
                }
            }, 2000);
        }
    });

    // when a file changes determine if the panel should be visible or not
    $(EditorManager).on('activeEditorChange', function( event, editor ) {
        // if no editor is passed - then we can be sure it is not an app.rln
        if( editor ) {
            // first set the project path and then check for the file to open
            // project path is needed to set the icon and file inputs
            _setProject().then(function() {
                // proceed - could be an app.rln
                _handleFileName(editor.document.file.name, editor);
            })

        } else {
            // no app.rln so hide the panel
            hide();
        }
    });


    // API
    exports.show = show;
    exports.hide = hide;
    exports.toggle = toggle;

});
