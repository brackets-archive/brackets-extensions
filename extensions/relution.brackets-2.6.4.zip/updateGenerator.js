/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function(require, exports, module) {
    "use strict";

    // Brackets modules
    var Dialogs = brackets.getModule("widgets/Dialogs");
    var FileUtils = brackets.getModule("file/FileUtils");

    var BracketsStrings = brackets.getModule("strings");
    var Strings = require("strings");

    var nodeBridge = require("./node/nodeBridge");

    var moduleDirectoryPath = FileUtils.getNativeModuleDirectoryPath(module);

    var BaseView = require('BaseView');
    var template = require("text!templates/dialog_generatorUpdate.html");


    var View = BaseView.extend({
        template: _.template(template),

        initialize: function() {
            BaseView.prototype.initialize.apply(this, arguments);
        }

    });

    function openDialog() {
        var view = new View();
        var dialog = Dialogs.showModalDialogUsingTemplate('<div class="modal relution-modal"></div>');
        dialog.getElement().html(view.render().el);
        return dialog;
    }

    function filesExists(callback) {
        var fs = appshell.fs;
        var mcapGeneratorPath = moduleDirectoryPath + '/node_modules/mcap-generator-ionic/package.json';
        fs.stat(mcapGeneratorPath, function(errorCode) {
            if (errorCode === appshell.fs.NO_ERROR) {
                callback(true);
            } else {
                callback(false);
            }
        });

    }

    function _update(cb) {

        nodeBridge.updateGenerator({
                "updateVersionURL": 'http://mwaydev.nerds.mway.io/relution-brackets-plugin-update/new/package.json',
                "extractPath": moduleDirectoryPath + '/node_modules/',
                "port": 80,
                "log": false
            },
            function(err) {
                if (!err) {
                    $('.uploading .status').html('done');
                    Dialogs.cancelModalDialogIfOpen('relution-modal');
                } else {
                    $('.uploading .status').html('something went wrong');
                    Dialogs.cancelModalDialogIfOpen('relution-modal');
                }
                if (cb && typeof cb === 'function') cb(err);
            });
    }

    function update(cb) {
        //shows the dialog only if file not exists
        filesExists(function(exists) {
            if (exists) {
                if (cb && typeof cb === 'function') cb();
                _update();
            } else {
                openDialog();
                _update(cb);
            }
        });
    }

    exports.update = update;
});
