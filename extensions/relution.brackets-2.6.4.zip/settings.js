/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */


define(function(require, exports, module) {
    "use strict";

    var ProjectManager = brackets.getModule("project/ProjectManager"); //u
    var Dialogs = brackets.getModule("widgets/Dialogs");
    var DefaultDialogs = brackets.getModule("widgets/DefaultDialogs");
    var Strings = require("strings");
    var BaseView = require('BaseView');
    var template = require("text!templates/settings.html");
    var PreferencesManager = brackets.getModule("preferences/PreferencesManager");
    require('parsley');

    var relutionSettings = null;

    var View = BaseView.extend({

        events: {
            'click #relution-settings-testconnection': 'testConnection',
            'click #relution-settings-save': 'saveSettings',
        },

        template: _.template(template),

        initialize: function() {
            BaseView.prototype.initialize.apply(this, arguments);

            relutionSettings = PreferencesManager.get('upload-settings');

            if (!relutionSettings || !relutionSettings.server) {
                //defaultsettings
                relutionSettings = {
                    'server': 'https://live.relution.io',
                    'user': '',
                    'orga': '',
                    'password': ''
                };
            }
            this.templateValues.settings = relutionSettings;
        },

        postRender: function() {
            this.$el.find('form').parsley();
            return this;
        },

        validate: function() {
            return this.$el.find('form').parsley().validate();
        },

        getServerUrl: function() {
            var serverStr = this.binding.server.replace(/\/$/, "");
            return serverStr + '/';
        },

        //////////////////////////////////////////
        // Events

        testConnection: function(e) {
            e.preventDefault();
            e.stopPropagation();

            if (this.validate()) {
                $('#responseContainer').html('<div class="spinner spin"> </div>');

                var server = this.getServerUrl();
                var loginData = {
                    j_username: this.binding.user,
                    j_organization: this.binding.orga,
                    j_password: this.binding.password
                };
                var req = server + 'gofer/security-login?j_username=' + encodeURIComponent(loginData.j_username) + '&j_password=' + encodeURIComponent(loginData.j_password) + '&j_organization=' + encodeURIComponent(loginData.j_organization);
                $.ajax({
                    url: req,
                    type: 'GET',
                    success: function(data, status, xhr) {
                        $('#responseContainer').html('<div class="success"><i class="fa fa-check"></i> Connection attempt completed successfully</div>');
                    },
                    error: function(data, status, xhr) {
                        $('#responseContainer').html('<div class="error"><i class="fa fa-bolt"></i> Connection attempt failed</div>');
                    }
                });
            }
        },

        saveSettings: function(e) {
            e.preventDefault();
            e.stopPropagation();

            if (this.validate()) {
                var newSettings = {
                    'server': this.getServerUrl(),
                    'user': this.binding.user,
                    'orga': this.binding.orga,
                    'password': this.binding.password
                };
                /*prefs.setAllValues(newSettings);*/
                PreferencesManager.set('upload-settings', newSettings)
                Dialogs.cancelModalDialogIfOpen('relution-modal-settings', 'ok');
            }
        }

    });


    function openDialog() {
        var view = new View();
        var dialog = Dialogs.showModalDialogUsingTemplate('<div class="modal relution-modal relution-modal-settings"></div>');
        dialog.getElement().html(view.render().el);
        return dialog;
    }

    function showProjectErrorMessage() {
        Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_ERROR, Strings.DIALOG_TITLE_CREATE, Strings.PROJECT_CREATE_ERROR);
    }
    exports.openDialog = openDialog;
});
