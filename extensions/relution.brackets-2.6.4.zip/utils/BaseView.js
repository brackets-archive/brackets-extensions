/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function (require, exports, module) {
    "use strict";

    var BracketsStrings = brackets.getModule("strings");
    var Strings = require("strings");
    var Binding = require("utils/binding");

    var BaseView = Backbone.View.extend({

        templateValues: {},

        initialize: function () {
            this.Strings = Strings;
            this.BracketsStrings = BracketsStrings;
        },

        render: function () {

            var defaults = {
                Strings: this.Strings,
                BracketsStrings: this.BracketsStrings
            }
            _.defaults(this.templateValues, defaults);

            this._preRender();
            this._render();
            this._postRender();
            return this;
        },

        _preRender: function () {
            if (this.preRender) this.preRender();
            return this;
        },

        _render: function () {
            this.$el.html(this.template(this.templateValues));
            return this;
        },

        _postRender: function () {
            this.binding = new Binding(this.$el);
            if (this.postRender) this.postRender();
            return this;
        }
    });

    module.exports = BaseView;
});