/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports, module ) {
    "use strict";

    var ProjectManager = brackets.getModule("project/ProjectManager");
    var CONST = require("utils/CONST");

    var projectRoot = null;

    /**
     * Returns a promise when resolved the file to the CONST.CONFIG_FILE is returned
     * @returns {*}
     */
    function getConfigFile() {
        var dfd = $.Deferred();
        ProjectManager.getAllFiles(function( file ) {
            return file.name === CONST.CONFIG_FILE;
        }, true).then(function( files ) {
            if( files.length > 0 ) {
                dfd.resolve(files[0]);
            } else {
                dfd.reject();
            }
        });
        return dfd.promise();
    }

    /**
     * Returns a promise when resolved all files with the same name as CONST.CONFIG_FILE
     * @returns {*}
     */
    function getConfigFiles() {
        return ProjectManager.getAllFiles(function( file ) {
            return file.name === CONST.CONFIG_FILE;
        }, true);
    }

    /**
     * Returns a promise when resolved the parentPath to the CONST.CONFIG_FILE is returned.
     * If a app.rln file is provided as a parameter the function returns the parentPath to that file
     * @returns {*}
     */
    function getProjectRoot( configFile ) {
        var dfd = $.Deferred();

        if(configFile && typeof configFile.exists === 'function'){
            dfd.resolve(configFile.parentPath);
        } else {
            getConfigFile().then(function( appRln ) {
                projectRoot = appRln.parentPath;
                dfd.resolve(appRln.parentPath);
            }).fail(function() {
                dfd.reject();
            });
        }

        return dfd.promise();
    }

    module.exports.getProjectRoot = getProjectRoot;
    module.exports.getConfigFile = getConfigFile;
    module.exports.getConfigFiles = getConfigFiles;
});