define(function( require, exports, module ) {
    "use strict";

    var _ = brackets.getModule("thirdparty/lodash");

    /**
     * Read a file form the disk
     *
     * @param path
     * @returns {*}
     * @private
     */
    function _readFile( path ) {
        var dfd = $.Deferred();

        appshell.fs.readFile(path, 'utf8', function( err, data ) {
            if( err !== appshell.fs.NO_ERROR  ) {
                return dfd.reject(err);
            }
            dfd.resolve(data);
        });

        return dfd.promise();
    }

    /**
     * Read a json file form the disk
     *
     * @param path
     * @returns {*}
     * @private
     */
    function _readJSONFile( path ) {
        var dfd = $.Deferred();

        _readFile(path).then(function( data ) {
            var result;
            try {
                result = JSON.parse(data);
            } catch( err ) {
                return dfd.reject(err);
            }
            dfd.resolve(result);
        }).fail(function( err ) {
            dfd.reject(err);
        });
        return dfd.promise();
    }

    /**
     * Write a file to the disk
     *
     * @param path
     * @param data
     * @returns {*}
     * @private
     */
    function _writeFile( path, data ) {
        var dfd = $.Deferred();
        appshell.fs.writeFile(path, data, 'utf8', function( err, content ) {
            if( err !== appshell.fs.NO_ERROR  ) {
                return dfd.reject(err);
            }
            dfd.resolve(content);
        });

        return dfd.promise();
    }

    /**
     * Write a json file to the disk
     *
     * @param path
     * @param data
     * @returns {*}
     * @private
     */
    function _writeJSONFile( path, data ) {
        var dfd = $.Deferred();

        try {
            data = JSON.stringify(data);
        } catch( err ) {
            return dfd.reject(err);
        }

        return _writeFile(path, data);
    }

    /**
     * Checks if file exists. Returns true if the file specified by path exists otherwise false.
     * @param path
     * @returns {*}
     */
    function _exist( path ) {
        return _stat(path).then(function() {
            return true;
        }, function( err ) {
            if( err === appshell.fs.ERR_NOT_FOUND) {
                return $.Deferred().resolve(false);
            }
            return new Error(err);
        });
    }

    /**
     * Returns a stats object for the specified path.
     *
     * @param path
     * @returns {*}
     * @private
     */
    function _stat( path ) {
        var dfd = $.Deferred();
        appshell.fs.stat(path, function( err, stat ) {
            if( err === appshell.fs.NO_ERROR ) {
                dfd.resolve(stat);
            } else {
                dfd.reject(err);
            }
        });
        return dfd.promise();
    }

    /**
     * Checks if the given path is a file. Returns true if the given path is from type file otherwise false.
     * @param path
     * @returns {*}
     */
    function _isFile( path ) {
        return _stat(path).then(function(stat) {
            return stat.isFile();
        })
    }

    /**
     * Checks if the given path is a file. Returns true if the given path is from type file otherwise false.
     * @param path
     * @returns {*}
     */
    function _isDirectory( path ) {
        return _stat(path).then(function(stat) {
            return stat.isDirectory();
        })
    }

    /**
     * Create a directory with the given path
     * @param path
     * @returns {*}
     * @private
     */
    function _mkdir(path) {
        var dfd = $.Deferred();
        appshell.fs.makedir(path, parseInt("0777", 8), function(err) {
            if( err === appshell.fs.NO_ERROR ) {
                return dfd.resolve();
            }
            dfd.reject(err);
        });
        return dfd.promise();
    }

    /**
     * Reads the content of the given path
     * @param path
     * @returns {*}
     * @private
     */
    function _readdir(path) {
        var dfd = $.Deferred();
        appshell.fs.readdir(path, function(err, content) {
            if( err === appshell.fs.NO_ERROR ) {
                return dfd.resolve(content);
            }
            dfd.reject(err);
        });
        return dfd.promise();
    }

    /**
     * Truns error code into a string
     *
     * @param errCode
     * @returns {*}
     * @private
     */
    function _translateErrorCode (errCode) {
        var result = null;
        if( _.isNumber(errCode) ) {
            _.each(appshell.fs, function ( code, message ) {
                if( _.isNumber(code) && errCode === code) {
                    result = message;
                }
            });
        }
        return result;
    }

    module.exports = {
        readFile: _readFile,
        readJSONFile: _readJSONFile,
        writeFile: _writeFile,
        writeJSONFile: _writeJSONFile,
        exist: _exist,
        stat: _stat,
        isDirectory: _isDirectory,
        isFile: _isFile,
        mkdir: _mkdir,
        readdir: _readdir,
        translateErrorCode: _translateErrorCode
    };

});
