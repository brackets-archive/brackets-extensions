define(function( require, exports, module ) {
    "use strict";

    exports.SUCCESS = 'success';
    exports.ERROR = 'error';
    exports.NOCONTENT = 'nocontent';
    exports.TYPE_FOLDER = 'folder';
    exports.TYPE_FILE = 'file';
    exports.CREATE = 'create';
    exports.DEFAULT = 'default';
    exports.CONFIG_FILE = 'app.rln';

});