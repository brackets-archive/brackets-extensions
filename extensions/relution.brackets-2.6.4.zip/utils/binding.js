/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports, module ) {
    "use strict";

    module.exports = function( $selector ) {
        var that = this;

        this.attributes = [];

        this.get = function() {
            var obj = {};
            var that = this;
            this.attributes.forEach(function( ind ) {
                obj[ind] = that[ind];
            });
            return obj;
        };

        this.set = function( obj ) {
            if( !obj ) {
                return;
            }
            var that = this;
            Object.keys(obj).forEach(function( ind ) {
                that[ind] = obj[ind];
            });
            return this;
        };

        $selector.addBack().find('[data-binding]').each(function() {
            var $dom = $(this);
            var ident = $(this).attr('data-binding');
//            var propertyChain = ident.split('.');
//            if( propertyChain.length > 1 ) {
//                var value = {};
//                var root = null;
//                _.each(propertyChain, function( level, ind ) {
//                    if( ind === 0 ) {
//                        that[level] = that[level] || {};
//                        value[level] = that[level];
//                        root = that[level];
//                    }
//                    value[level] = value[level] ? _.extend(value[level], {}) : {};
//                    value = value[level];
//                });
//            }

            that.attributes.push(ident);

            var getter = function() {
                return $dom.val();
            };

            var setter = function( val ) {
                return $dom.val(val);
            };

            if( $dom.attr('type') === 'checkbox' ) {
                getter = function() {
                    return $dom.prop('checked');
                };

                setter = function( val ) {
                    return $dom.prop('checked', val);
                }

            }

//            if( $dom[0].tagName === 'IMG' ) {
//                getter = function() {
//                    return $dom.attr('src');
//                };
//
//                setter = function( val ) {
//                    return $dom.attr('src', val);
//                }
//
//            }

            Object.defineProperty(that, ident, {
                get: getter,
                set: setter
            });

        });
    };
});