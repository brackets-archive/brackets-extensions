/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function(require, exports, module) {
    "use strict";

    // Brackets modules
    var AppInit = brackets.getModule("utils/AppInit");
    var PreferencesManager = brackets.getModule("preferences/PreferencesManager");
    var Commands = brackets.getModule("command/Commands");
    var CommandManager = brackets.getModule("command/CommandManager");
    var ExtensionUtils = brackets.getModule("utils/ExtensionUtils");
    var Menus = brackets.getModule("command/Menus");
    var BracketsStrings = brackets.getModule("strings");
    var Strings = require("strings");
    var JsonPanel = require("panel/panel");
    var intro = require("intro/intro");
    var weinre = require("weinre/weinre");

    var CreateAppRln = require("CreateConfigFile");

    var _ = require('underscore');
    _.str = require('underscore.string');
    ExtensionUtils.loadStyleSheet(module, "css/style.css");
    ExtensionUtils.loadStyleSheet(module, "node_modules/select2-browserify/select2/select2.css");
    ExtensionUtils.loadStyleSheet(module, "node_modules/font-awesome/css/font-awesome.min.css");
    ExtensionUtils.loadStyleSheet(module, "intro/intro.css");

    var LanguageManager = brackets.getModule("language/LanguageManager");
    var language = LanguageManager.getLanguage("json");
    language.addFileExtension("rln");

    var createProject = require('createProject');
    var upload = require('upload');
    var settings = require('settings');
    var about = require('about');
    var updateGenerator = require('updateGenerator');


    var _module = module;

    function openSettingsDialog() {
        settings.openDialog();
    }

    function openNewProjectDialog() {
        createProject.openDialog();
    }

    function openUploadDialog() {
        var loginData = PreferencesManager.get('upload-settings');
        if( loginData && loginData.server && loginData.user && loginData.server.length > 0 && loginData.user.length > 0 ) {
            upload.openDialog();
        } else {
            openSettingsDialog();
        }
    }

    function openAboutDialog() {
        about.openDialog();
    }

    function openGeneratorUpdateDialog() {
        about.openDialog();
    }

    function registerMenu() {
        var RELUTION_COMMANDID_CREATE_PROJECT = "relution.createproject";
        var RELUTION_COMMANDID_SETTINGS = "relution.settings";
        var RELUTION_COMMANDID_INTRO = "relution.intro";
        var RELUTION_COMMANDID_UPLOAD = "relution.upload";
        var RELUTION_COMMANDID_ABOUT = "relution.about";

        var RELUTION_MENUID = "relution-menu";

        var fileMenu = Menus.getMenu(Menus.AppMenuBar.FILE_MENU);

        // New WebApp
        CommandManager.register(Strings.MENU_ITEM_CREATE_PROJECT, RELUTION_COMMANDID_CREATE_PROJECT, openNewProjectDialog);
        fileMenu.addMenuItem(RELUTION_COMMANDID_CREATE_PROJECT, null, Menus.AFTER, Commands.FILE_NEW_UNTITLED);

        var relutionMenu = Menus.addMenu(Strings.MENU_LABEL, RELUTION_MENUID, Menus.BEFORE, Menus.AppMenuBar.HELP_MENU);

        // Settings
        CommandManager.register(Strings.MENU_ITEM_SETTINGS, RELUTION_COMMANDID_SETTINGS, openSettingsDialog);
        relutionMenu.addMenuItem(RELUTION_COMMANDID_SETTINGS);

        // Intro
        CommandManager.register(Strings.MENU_ITEM_INTRO, RELUTION_COMMANDID_INTRO, function(){
            intro.show();
        });
        relutionMenu.addMenuItem(RELUTION_COMMANDID_INTRO);

        // Upload
        CommandManager.register(Strings.MENU_ITEM_UPLOAD, RELUTION_COMMANDID_UPLOAD, openUploadDialog);
        relutionMenu.addMenuItem(RELUTION_COMMANDID_UPLOAD, "Cmd-U");

        // About
        CommandManager.register(Strings.MENU_ITEM_ABOUT, RELUTION_COMMANDID_ABOUT, openAboutDialog);
        relutionMenu.addMenuItem(RELUTION_COMMANDID_ABOUT);
    }

    function init() {

        _.mixin(_.str.exports());
        _.str.include('Underscore.string', 'string');

        registerMenu();
    }

    AppInit.appReady(function() {
        weinre.run().always(function(){
            updateGenerator.update(function(err) {
                setTimeout(intro.start, 250);
            });
        });

    });

    init();
});
