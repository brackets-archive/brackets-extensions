# Relution Brackets Plugin
Version: 2.5.0 25.07.2014

Copyright © 2014, M-Way Solutions GmbH

This is the official Relution extension for Brackets. Use in combination of your own Relution instance or use [SaaS Relution Cloud service](http://live.relution.io).

The Relution Enterprise Appstore makes fast, secure and targeted software distribution for mobile devices possible. Enable your employees to always keep their mobile software up to date, as conveniently as possible – with a company-owned app store. For more information please vist [relution.io](http://relution.io).

Licensed under GPLv3 <http://www.gnu.org/licenses/gpl.txt>
