/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */
define(function( require, exports, module ) {
    "use strict";
    var ProjectManager,     // Load from brackets.test
        CommandManager,     // Load from brackets.test
        FileSystem,         // Load from brackets.test
        Dialogs,            // Load from brackets.test
        DefaultDialogs,     // Load from brackets.test
        FileSystemError,    // Load from brackets.test
        FileUtils           = brackets.getModule("file/FileUtils"),
        SpecRunnerUtils     = brackets.getModule("spec/SpecRunnerUtils"),
        DocumentManager,    // Load from brackets.test
        ExtensionLoader     = brackets.getModule("utils/ExtensionLoader"),
        Commands;           // Load from brackets.test

    // require files to test
    var validateJson = null;
    var upload = null;
    var extensionRequire = null;
    var createProject = null;


    describe("Relution-Plugin", function () {

        var testWindow,
            brackets;
        var moduleDirectoryPath = FileUtils.getNativeModuleDirectoryPath(module) + '/unittest-files';

        var prRoot = moduleDirectoryPath + '/rln-testfiles';

        beforeFirst(function () {

            SpecRunnerUtils.createTestWindowAndRun(this, function (w) {
                testWindow = w;

                // Load module instances from brackets.test
                brackets       = testWindow.brackets;
                ProjectManager = testWindow.brackets.test.ProjectManager;
                CommandManager = testWindow.brackets.test.CommandManager;
                FileSystem     = testWindow.brackets.test.FileSystem;
                Dialogs             = testWindow.brackets.test.Dialogs;
                DefaultDialogs      = testWindow.brackets.test.DefaultDialogs;
                Commands            = testWindow.brackets.test.Commands;
                FileSystemError     = testWindow.brackets.test.FileSystemError;
                DocumentManager     = testWindow.brackets.test.DocumentManager;
                ExtensionLoader     = testWindow.brackets.test.ExtensionLoader;
                Commands            = testWindow.brackets.test.Commands;

                SpecRunnerUtils.loadProjectInTestWindow(moduleDirectoryPath);

                extensionRequire = testWindow.brackets.getModule("utils/ExtensionLoader").getRequireContextForExtension("relution.brackets");

                validateJson = extensionRequire('validateJson');
                upload = extensionRequire('upload');
                createProject = extensionRequire('createProject');
            });
        });

        afterLast(function () {
            testWindow     = null;
            brackets       = null;
            ProjectManager = null;
            CommandManager = null;
            SpecRunnerUtils.closeTestWindow();
            SpecRunnerUtils.removeTempDirectory();
        });

        afterEach(function () {
            testWindow.closeAllFiles();
        });

        describe("validateJson", function () {
            var exposedFile   = prRoot + "/app.rln";

            beforeEach(function() {

            });

            it("should be an function", function() {
                expect(validateJson.parseAppConfig).toEqual(jasmine.any(Function));
            });

            it("should exist a app.rln file", function() {
                runs(function() {
                    var promiseFileOpen = CommandManager.execute(Commands.FILE_OPEN, { fullPath: exposedFile });
                    waitsForDone(promiseFileOpen, 'FILE_OPEN');
                });
            });

            it("should return parsed json-object", function () {
                runs(function () {
                    CommandManager.execute(Commands.FILE_OPEN, { fullPath: exposedFile })
                        .then(validateJson.parseAppConfig)
                        .done(function(data) {
                            expect(data).toEqual(jasmine.any(Object));
                        });
                });
            });

            it("should be an function", function() {
                expect(validateJson.getAppJSON).toEqual(jasmine.any(Function));
            });

            it("should return an error | empty name", function() {
                var tempFilePath = prRoot + '/appEmptyName.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6200, message : 'App Name cannot be empty' });
                                })
                            }
                        });

                    waitsForFail(prom, "empty name")
                });
            });

            it("should return an error | no name attr", function() {
                var tempFilePath = prRoot + '/appNoName.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6300, message : 'App Name must be defined' });
                                })
                            }
                        });
                    waitsForFail(prom)
                });
            });


            it("should return an error | no versionCode attr", function() {
                var tempFilePath = prRoot + '/appNoVersion.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6300, message : 'Version Code must be defined' });
                                })
                            }
                        });
                    waitsForFail(prom)
                });
            });

            it("should return an error | empty versionCode", function() {
                var tempFilePath = prRoot + '/appEmptyVersion.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6200, message : 'Version Code cannot be empty' });
                                })

                            }
                        });
                    waitsForFail(prom, "empty name")
                });

            });



            it("should return an error | no versionName attr", function() {
                var tempFilePath = prRoot + '/appNoVersionName.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6300, message : 'Version Name must be defined' });
                                })

                            }
                        });
                    waitsForFail(prom)
                });

            });

            it("should return an error | empty versionName", function() {
                var tempFilePath = prRoot + '/appEmptyVersionName.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6200, message : 'Version Name cannot be empty' });
                                })

                            }
                        });
                    waitsForFail(prom, "empty name")
                });

            });



            it("should return an error | no package attr", function() {
                var tempFilePath = prRoot + '/appNoPackage.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6300, message : 'Pakage Name must be defined' });
                                })

                            }
                        });
                    waitsForFail(prom)
                });

            });

            it("should return an error | empty package", function() {
                var tempFilePath = prRoot + '/appEmptyPackage.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6200, message : 'Pakage Name cannot be empty' });
                                })

                            }
                        });
                    waitsForFail(prom, "empty name")
                });

            });

            it("should return an error | Invalid Identifier", function() {
                var tempFilePath = prRoot + '/appInvalidIdentifier.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6300, message : 'Invalid Identifier for Package Name' });
                                })

                            }
                        });
                    waitsForFail(prom, "empty name")
                });

            });

            it("should return an error | Invalid Identifier", function() {
                var tempFilePath = prRoot + '/appInvalidIdentifier2.rln';
                runs(function () {
                    //get doc with corrupt content #1
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath })
                        .then(validateJson.parseAppConfig)
                        .then(validateJson._validate)
                        .fail(function(errObj) {
                            //expect error

                            if(errObj && errObj.details) {
                                runs(function() {
                                    expect(errObj.details).toContain({ errorCode : 6300, message : 'Invalid Identifier for Package Name' });
                                })

                            }
                        });
                    waitsForFail(prom)
                });

            });

        });


        describe("dialogs", function(){

            beforeEach(function() {

            });

            afterEach(function() {
                DocumentManager.closeAll();
            });

            it("should open and close a upload dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.upload').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                        });

                        waitsForDone(promise);
                    });
                });
            });


            it("should open and close a 'createproject' dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.createproject').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                        });

                        waitsForDone(promise);
                    });
                });
            });


            it("should open and close a 'about' dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.about').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                            Dialogs.cancelModalDialogIfOpen('relution-modal');
                        });

                        waitsForDone(promise);
                    });
                });
            });

            it("should open and close a 'settings' dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.settings').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                            Dialogs.cancelModalDialogIfOpen('relution-modal');
                        });

                        waitsForDone(promise);
                    });
                });
            });


        });

        describe("editor panel", function() {
            it("should open/close the rln editor panel", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var $panel = testWindow.$('#relution-json-editor');
                        expect($panel.length).toBeDefined();
                        $panel.find('.close').click();
                        expect($panel.css('display')).toBe("none");
                    });

                    waitsForDone(prom);
                });
            });

        });



        describe("create project", function() {
            it("should return a translated errorMessage", function() {
                runs(function () {
                    var msg = createProject.translateErrorString('hello');
                    expect(msg).toBe('HELLO');

                    var msg2 = createProject.translateErrorString('hello.');
                    expect(msg2).toBe('HELLO_');

                    var msg3 = createProject.translateErrorString('..');
                    expect(msg3).toBe('__');

                    var msg4 = createProject.translateErrorString('dialog.title_creaTE');
                    expect(msg4).toBe('New WebApp');

                    var msg5 = createProject.translateErrorString('ideNtifIER.deFaULT');
                    expect(msg5).toBe('com.company.MyFirstWebApp');
                });
            });


            it("should return a trimmed DirectoryName", function() {
                runs(function () {
                    var trimmedName = createProject.trimDirectoryName('something with whitespace');
                    expect(trimmedName).toBe('somethingwithwhitespace');

                    var trimmedName2 = createProject.trimDirectoryName('something    . with whi.tes..pac.e');
                    expect(trimmedName2).toBe('somethingwithwhitespace');

                    var trimmedName3 = createProject.trimDirectoryName('/Applications/[Brackets]/mway');
                    expect(trimmedName3).toBe('ApplicationsBracketsmway');

                    var trimmedName4 = createProject.trimDirectoryName('/Applications/[Brackets]/mway');
                    expect(trimmedName4).toBe('ApplicationsBracketsmway');

                    var trimmedName5 = createProject.trimDirectoryName('!"§$%&/())=?=)(/&%$§"');
                    expect(trimmedName5).toBe('');
                });
            });
        });



        describe("dialogs", function(){

            beforeEach(function() {

            });

            afterEach(function() {
                DocumentManager.closeAll();
            });

            it("should open and close a upload dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.upload').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                            Dialogs.cancelModalDialogIfOpen('relution-modal-uploading');

                        });

                        waitsForDone(promise);
                    });
                });
            });


            it("should open and close a 'createproject' dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.createproject').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                            Dialogs.cancelModalDialogIfOpen('relution-modal');
                        });

                        waitsForDone(promise);
                    });
                });
            });


            it("should open and close a 'about' dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.about').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                            Dialogs.cancelModalDialogIfOpen('relution-modal');
                        });

                        waitsForDone(promise);
                    });
                });
            });

            it("should open and close a 'settings' dialog", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var promise = CommandManager.execute('relution.settings').then(function() {
                            expect(testWindow.$('.relution-modal').length).toBeDefined();
                            Dialogs.cancelModalDialogIfOpen('relution-modal');
                        });

                        waitsForDone(promise);
                    });
                });
            });


        });

        describe("editor panel", function() {
            it("should open/close the rln editor panel", function() {
                var tempFilePath = prRoot + '/app.rln';
                runs(function () {
                    var prom = CommandManager.execute(Commands.FILE_OPEN, { fullPath: tempFilePath });
                    prom.done(function() {
                        var $panel = testWindow.$('#relution-json-editor');
                        expect($panel.length).toBeDefined();
                        $panel.find('.close').click();
                        expect($panel.css('display')).toBe("none");
                    });

                    waitsForDone(prom);
                });
            });

        });



        describe("upload", function() {
            it("should return a array with active targets", function() {
                runs(function () {
                    var targets =  {
                        "android" : {
                            'test': 'ing',
                            'ignore': false
                        },
                        "ios" : {
                            'test': 'ing',
                            'ignore': true
                        }
                    };
                    var result = upload.getActiveTargets(targets);
                    expect(result).toEqual(['android']);


                    var targets2 =  {
                        "android" : {
                            'test': 'ing'
                        },
                        "ios" : {
                            'test': 'ing'
                        }
                    };
                    var result = upload.getActiveTargets(targets2);
                    expect(result).toEqual(['android', 'ios']);


                    var targets3 =  {
                        "android" : {
                            'test': 'ing',
                            'ignore': true
                        },
                        "ios" : {
                            'test': 'ing'
                        },
                        "someOther" : {
                            'stuff': 'nothing',
                            'ignore': false
                        }
                    };
                    var result = upload.getActiveTargets(targets3);
                    expect(result).toEqual(['ios']);

                    var targets4 =  {
                        "android" : {
                            'test': 'ing',
                            'ignore': true
                        },
                        "ios" : {
                            'test': 'ing',
                            'ignore': true
                        },
                        "someOther" : {
                            'stuff': 'nothing',
                            'ignore': false
                        }
                    };
                    var result = upload.getActiveTargets(targets4);
                    expect(result).toEqual([]);


                });
            });

        });
    });
});
