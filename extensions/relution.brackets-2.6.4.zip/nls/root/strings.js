/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define({
  /**
   * KEEP IN MIND THAT CHANING MENU ENTRIES WILL AFFECT THE INTRO TEXT AS WELL!
   */
  'MENU_LABEL': 'Relution',

  'MENU_ITEM_SETTINGS': 'Settings …',
  'MENU_ITEM_INTRO': 'Take the Tour …',
  'MENU_ITEM_CREATE_PROJECT': 'New WebApp …',
  'MENU_ITEM_UPLOAD': 'Upload to Relution …',
  'MENU_ITEM_ABOUT': 'About …',

  'CONFIGURE': 'Configure',
  'UPLOAD': 'Upload',
  'CREATE': 'Create',
  'SERVER': 'Server',

  'ERROR_DIALOG_TITLE': 'Error',
  'ERROR_401': 'Login failed',
  'ERROR_404': 'A connection could not be established. Please check your internet connection and try again.',
  'ERROR_503': 'Server temporarily not available. Please try again later.',
  'ERROR_GENERAL': 'Sorry, something went wrong. Please try again.',
  'ERROR_RELUTION_1000': 'Your user isn\'t allowed to perform this action.',

  'ERROR_APPJSON_IS_COORRUPT': 'The app.json file is corrupt. Please fix it and try again.',
  'ERROR_APPJSON_IS_MISSING': 'The app.json file is missing.',
  'ERROR_DIR_IS_NOT_EMPTY': 'The directory \'%s\' is not empty',

  // Create application
  'DIALOG_TITLE_CREATE': 'New WebApp',
  'APP_NAME': 'App Name',
  'APP_NAME_DEFAULT': 'MyFirstWebApp',
  'IDENTIFIER': 'Identifier',
  'IDENTIFIER_DEFAULT': 'com.company.MyFirstWebApp',
  'PROJECT_DIRECTORY': 'Project Folder',
  'CHANGE_BUTTON': 'Select …',

  'INVALID_IDENTIFIER': ' Invalid Identifier.',
  'INVALID_PROJECT_NAME': 'Invalid Project Name',
  'INVALID_PROJECT_NAME_MESSAGE': 'Project names cannot contain the following characters: /?*:;{}<>\\| or use any system reserved words.',
  'ERROR_GENERATOR_DIRECTORY_EXISTS': 'Directory already exists.',

  'NEEDS_TO_BE_INSIDE_PROJECT': 'The file needs to be inside the project.',

  // Upload
  'UPLOAD_MISSIGN_RLN_FILE': 'The app.rln file is missing. Please create a WebApp first "File > New WebApp"',
  'UPLOAD_DIALOG_TITLE': 'Upload to Relution Appstore',

  'RELEASE_STATE_LABEL': 'Upload to',
  'RELEASE_STATE_DEVELOPMENT': 'Development',
  'RELEASE_STATE_REVIEW': 'Review',
  'RELEASE_STATE_ARCHIVE': 'Archive',
  'RELEASE_STATE_RELEASE': 'Release',

  'ARCHIVATION_MODE_LABEL': 'Archivation mode',
  'ARCHIVATION_MODE_VALUE_ARCHIVE': 'Archive current version',
  'ARCHIVATION_MODE_VALUE_OVERRIDE': 'Override current version',

  'INCREASE_VERSION_NUMBER': 'Increase Version Number',
  'NEXT_VERSION_NUMBER': 'Next Version Number',
  'CURRENT': 'Current',

  'UPLOAD_STATUS_UPLOADING': 'Uploading …',
  'UPLOAD_STATUS_VALIDATE': 'Validate files',
  'UPLOAD_STATUS_LOGIN': 'Login',
  'UPLOAD_SUCCESSFUL': 'The upload was successful',
  'OPEN_RELUTION': 'Open Relution',
  'SHOW_ON_STARTUP': 'Show on startup',
  'HIDE_ON_STARTUP': 'Hide on startup',

  'ARCHIVATION_MODE_HELP': 'Archivation mode defines how to handle existing versions of an application that have the same release status as the version being uploaded. Versions with a different release status are never affected during upload. Archive current version means that an existing version will be replaced by the new version and the existing version is moved to the archive. Overwrite current version means that an existing version with the same release status as the one being uploaded will be deleted.',

  //Settings
  'DIALOG_TITLE_SETTINGS': 'Relution Settings',
  'RELUTION_SERVER_PLACEHOLDER': 'https://live.relution.io',
  'USER': 'User',
  'ORGA': 'Organization',
  'PASSWORD': 'Password',
  'TESTCONNECTION': 'Test connection',
  'SIGN_UP': 'Create an Relution.io account',


  //GENERATOR UPDATE
  'DIALOG_TITLE_GENERATOR_UPDATE': 'Relution | Getting the latest updates',
  'DOWNLOAD_DEPENDENCIES': 'Downloading dependencies for Relution-Plugin. Please wait.',

  // JSON EDITOR

  'NAME': 'Name',
  'VERSION': 'Version',
  'PACKAGE': 'Package',
  'EDITOR': 'Relution Application Editor',
  'DESCRIPTION': 'Description',
  'KEYWORDS': 'Keywords',
  'TARGETS': 'Targets',
  'ANDROID': 'Android',
  'IGNORE': 'Ignore',
  'KEY': 'Key',
  'ALIAS': 'Alias',
  'ICONS': 'Icons',
  'SPLASH': 'Splash',
  'SCREENSHOTS': 'Screenshots',
  'IOS': 'iOS',
  'PASSPHRASE': 'Passphrase',
  'PROVISIONING': 'Provisioning',
  'PLUGINS': 'Plugins',
  'DEVELOPER': 'Developer',
  'COMPANY': 'Company',
  'CONTACT': 'Contact',
  'EMAIL': 'E-Mail',
  'PHONE': 'Phone',
  'LICENSE': 'License',
  'TYPE': 'Type',
  'LEGAL': 'Legal',
  'APP_INFO': 'App Info',
  'NATIVE_BUILD': 'Native Build',
  'CORDOVA_SETTINGS': 'Cordova Settings',
  'IOS_CORDOVA': 'iOS Cordova',
  'ANDROID_CORDOVA': 'Android Cordova',
  'CORDOVA_PARAMETERS': 'Cordova Parameters',
  'PACKAGE_NAME': 'Package Name',
  'VERSION_NAME': 'Version Name',
  'VERSION_CODE': 'Version Code',
  'MAIN_PAGE': 'Main Page',
  'DEFAULT_ICON': 'Icon',
  'WEB': 'Website',
  'CHANGELOG': 'Changelog',
  'PATH_TO_CHANGELOG': 'path/to/changelog.txt',
  'PATH_TO_ICON': 'path/to/icon.png',
  'SELECT_ICON': 'Select Icon',
  'MANDATORY': '*',
  'NOT_NULL': 'cannot be null',
  'NOT_EMPTY': 'cannot be empty',
  'MUST_DEFINED': 'must be defined',
  'NOT_EXISTS': 'does not exists',
  'FILE': 'File',
  'ERROR_ON_FILE_EXISTS': 'Error checking file',
  'FILE_PATH_IS_MANDATORY': 'File path is mandatory',
  'GENERAL_SETTINGS': 'General Settings',
  'PLEASE_SELECT_SETTING': 'Please Select a Setting',
  'PLEASE_SELECT_STATUSBAR_SETTING': 'Please Select a StatusBar Setting',

  //About
  'DIALOG_TITLE_ABOUT': 'Mobile Application Lifecycle Management',
  'ABOUT_SUB_TITLE': 'Brackets plugin version',
  'ABOUT_TEXT': 'The Mobile Application & Device Management Platform Relution secures and manages apps, documents & devices for companies and agencies - across operating systems, safely and inexpensively and for all leading mobile OS platforms. For more information please visit <a href="http://relution.io">Relution.io</a>.',
  'ABOUT_LICENSE': 'This plugin contains source code from the Yeoman Project released under the <a href="http://opensource.org/licenses/bsd-license.php">BSD License</a>.',
  'CREATE_APP_RLN': 'Create app.rln',

  'APPLICATION': 'Application',


  // INTRO: RELUTION DESCR
  'WELCOME_TO_RELUTION': 'Welcome to Relution',
  'RELUTION_BENEFIT': 'With the Relution Plugin for Brackets it is easy as Pie to develop mobile applications.',
  'HAVE_AN_ACCOUNT': 'Do you already have an account?',
  'CREATE_ONE': 'Create one',
  'TO_GET_STARTED': 'to get started.',
  'CREATE_ACCOUNT_LINK': 'http://trial.relution.io/#form-header',
  'POWERED_BY': 'powered by',
  'WEINRE_SCRIPT': 'Weinre Script',
  'TOGGLE_WEINRE_DEBUGGER': 'Toggle the Weinre debugger',
  'REMOTE_DEBUGGER': 'Remote Debugger',
  'DEBUG': 'Debug',

  'ios-AllowInlineMediaPlayback': 'AllowInlineMediaPlayback',
  'ios-AutoHideSplashScreen': 'AutoHideSplashScreen',
  'ios-BackupWebStorage': 'BackupWebStorage',
  'ios-DisallowOverscroll': 'DisallowOverscroll',
  'ios-EnableViewportScale': 'EnableViewportScale',
  'ios-FadeSplashScreen': 'FadeSplashScreen',
  'ios-FadeSplashScreenDuration': 'FadeSplashScreenDuration',
  'ios-KeyboardDisplayRequiresUserAction': 'KeyboardDisplayRequiresUserAction',
  'ios-MediaPlaybackRequiresUserAction': 'MediaPlaybackRequiresUserAction',
  'ios-ShowSplashScreenSpinner': 'ShowSplashScreenSpinner',
  'ios-SuppressesIncrementalRendering': 'SuppressesIncrementalRendering',
  'ios-TopActivityIndicator': 'TopActivityIndicator',
  'ios-GapBetweenPages': 'GapBetweenPages',
  'ios-PageLength': 'PageLength',
  'ios-PaginationBreakingMode': 'PaginationBreakingMode',
  'ios-PaginationMode': 'PaginationMode',

  'android-DisallowOverscroll': 'DisallowOverscroll',
  'android-KeepRunning': 'KeepRunning',
  'android-ShowTitle': 'ShowTitle',
  'android-SetFullscreen': 'SetFullscreen',
  'android-SplashScreenDelay': 'SplashScreenDelay',
  'android-SplashScreen': 'SplashScreen',
  'android-BackgroundColor': 'BackgroundColor',
  'android-LoadDialog': 'LoadDialog',
  'android-LoadingPageDialog': 'LoadingPageDialog',
  'android-ErrorUrl': 'ErrorUrl',
  'android-LoadUrlTimeoutValue': 'LoadUrlTimeoutValue',
  'android-InAppBrowserStorageEnabled': 'InAppBrowserStorageEnabled',
  'android-LogLevel': 'LogLevel',


  // INTRO //

  'intro_1': 'Navigate with arrow keys to stop the intro hit ESC. If you don\'t want to show it again press',
  'SETUP_ACCOUNT': 'Setup your account',
  'intro_2': 'The Relution plugin comes with its own Menu. Within this menu you find any kind of preferences and actions about the plugin. Also you can setup your Relution Server and register with your account.',
  'intro_3': 'You can start this tour again by selecting:',
  'intro_4': 'Setup your Relution credentials in the settings dialog.',
  'intro_5': 'To connect to your Relution Server enter the Server-URL into <strong>Server.</strong> You can also use our Relution Cloud Service via <a href="http://live.relution.io/">http://live.relution.io</a>.',
//  'intro_6': 'Then enter credentials for <strong>User</strong>, <strong>Organisation</strong> and <strong>Password</strong>. If you have trouble with those information contact your administrator. <a href="<%= Strings.CREATE_ACCOUNT_LINK %>">If you don\'t have an account create one here.</a>',
  'intro_6': 'Then enter credentials for <strong>User</strong>, <strong>Organisation</strong> and <strong>Password</strong>. If you have trouble with those information contact your administrator. <a href="http://trial.relution.io/#form-header">If you don\'t have an account create one here.</a>',
  'Test_the_connection': 'Test the connection',
//  'intro_7': 'If your setup is ready you can test if everything works fine by hitting the "<%= Strings.TESTCONNECTION %>" button.',
  'intro_7': 'If your setup is ready you can test if everything works fine by hitting the "Test connection" button.',
  'intro_8': 'A message next to the Button will show you the result of the test.',
  'Create_an_application': 'Create an application',
//  'intro_9': 'Open the \'File\' menu and select "<%= Strings.MENU_ITEM_CREATE_PROJECT %>" to create your first Relution application.',
  'intro_9': 'Open the \'File\' menu and select "New WebApp …" to create your first Relution application.',
  'intro_10': 'Every application needs an name. We recommend not to choose one with more than 12 characters.',
  'intro_11': 'Every app has its own unique <strong>Identifier</strong>. In general this is your state followed by your company and your application name. All seperate by a "." without any whitespaces. Finaly select a folder to store your project.',
  'intro_12': 'To see your application in action you can start it by selecting the "<strong>m</strong>" in the right panel. This will start a live preview of your local application.',
  'intro_13': 'With the <strong>app.rln</strong> it is possible to configure your application/project. This file needs to be a valid JSON file.',
//  'intro_14': 'If you are satisfied by your work you can publish your application to the Relution server. Just open the "<strong><%= Strings.MENU_ITEM_UPLOAD %></strong>" dialog from the menu.',
  'intro_14': 'If you are satisfied by your work you can publish your application to the Relution server. Just open the "<strong>Upload to Relution …</strong>" dialog from the menu.',
//  'intro_15': 'The <strong>server</strong> should be the same as in your settings. You can change your settings by pressing the "<strong><%= Strings.CONFIGURE %></strong>" Button.',
  'intro_15': 'The <strong>server</strong> should be the same as in your settings. You can change your settings by pressing the "<strong>Configure</strong>" Button.',
//  'intro_16': '<strong><%= Strings.RELEASE_STATE_LABEL %></strong> indicates the release state of your application.',
  'intro_16': '<strong>Upload to</strong> indicates the release state of your application.',
  'intro_17': 'Finally select what should happen to older versions of your application. If this is the first time you publish your app you can ignore this setting.',
//  'intro_18': 'Press "<strong><%= Strings.UPLOAD %></strong>" Button to publish your app to Relution.',
  'intro_18': 'Press "<strong>Upload</strong>" Button to publish your app to Relution.',
  'intro_19': 'Wait until the application is published …',
//  'intro_20': 'Congratulations your application is now available in the Relution App Store. Visit the app store by pressing the "<strong><%= Strings.OPEN_RELUTION %></strong>" Button.',
  'intro_20': 'Congratulations your application is now available in the Relution App Store. Visit the app store by pressing the "<strong>Open Relution</strong>" Button.',
  'intro_21': 'Your application can be run within the Relution App for <a href="https://play.google.com/store/apps/details?id=com.mwaysolutions.relution">Android</a> and <a href="https://itunes.apple.com/de/app/relution/id699597062?l=en&mt=8">iOS</a>.',
  'Work_with_your_application': 'Work with your application',
  'Publish_your_application': 'Publish your application',
  'See_your_app_in_action': 'See your app in action',

  '': ''
});
