/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define({
  /**
   * KEEP IN MIND THAT CHANING MENU ENTRIES WILL AFFECT THE INTRO TEXT AS WELL!
   */
  'MENU_LABEL': 'Relution',

  'MENU_ITEM_SETTINGS': 'Einstellungen …',
  'MENU_ITEM_INTRO': 'Tour durch Relution …',
  'MENU_ITEM_CREATE_PROJECT': 'Neue WebApp …',
  'MENU_ITEM_UPLOAD': 'Zu Relution hochladen …',
  'MENU_ITEM_ABOUT': 'Über …',

  'CONFIGURE': 'Konfigurieren',
  'UPLOAD': 'Hochladen ',
  'CREATE': 'Erstellen',
  'SERVER': 'Server',

  'ERROR_DIALOG_TITLE': 'Fehler',
  'ERROR_401': 'Anmeldung fehlgeschlagen',
  'ERROR_404': 'Es konnte keine Verbindung hergestellt werden. Überprüfen Sie ihre Internetverbindung und versuchen Sie es erneut.',
  'ERROR_503': 'Der Server ist momentan nicht erreichbar. Versuchen Sie es gegebenenfalls zu einem späteren Zeitpunkt.',
  'ERROR_GENERAL': 'Entschuldigen Sie vielmals, aber ein unbekannter Fehler ist aufgetreten.',
  'ERROR_RELUTION_1000': 'Ihrem Benutzer ist es nicht erlaubt diese Aktion auszuführen.',

  'ERROR_APPJSON_IS_COORRUPT': 'Die app.json Datei ist nicht lesbar. Bitte überprüfen Sie die Datei und versuchen Sie es erneut.',
  'ERROR_APPJSON_IS_MISSING': 'Die app.json Datei existiert nicht.',
  'ERROR_DIR_IS_NOT_EMPTY': '\'%s\' ist kein leerer Ordner.',

  // Create application
  'DIALOG_TITLE_CREATE': 'Neue WebApp',
  'APP_NAME': 'App Name',
  'APP_NAME_DEFAULT': 'MyFirstWebApp',
  'IDENTIFIER': 'Paketname',
  'IDENTIFIER_DEFAULT': 'com.company.MyFirstWebApp',
  'PROJECT_DIRECTORY': 'Stammverzeichnis',
  'CHANGE_BUTTON': 'Auswählen …',

  'INVALID_IDENTIFIER': ' Ungültiges Identifizierungsmerkmal.',
  'INVALID_PROJECT_NAME': 'Ungültiger Projektname',
  'INVALID_PROJECT_NAME_MESSAGE': 'Folgende Zeichen sind für den Projektnamen nicht erlaubt: /?*:;{}<>\\| ebensowenig wie vom System reservierte Worte.',
  'ERROR_GENERATOR_DIRECTORY_EXISTS': 'Pfad existiert schon.',

  'NEEDS_TO_BE_INSIDE_PROJECT': 'Die Datei muss im Project vorhanden sein.',

  // Upload
  'UPLOAD_MISSIGN_RLN_FILE': 'Die Datei app.rln ist nicht vorhanden. Bitte erstellen Sie zuerst ein neue WebApp "Datei > Neue WebApp"',
  'UPLOAD_DIALOG_TITLE': 'Zu Relution Appstore hochladen',

  'RELEASE_STATE_LABEL': 'Hochladen auf',
  'RELEASE_STATE_DEVELOPMENT': 'Entwicklung',
  'RELEASE_STATE_REVIEW': 'Überprüfung',
  'RELEASE_STATE_ARCHIVE': 'Archiv',
  'RELEASE_STATE_RELEASE': 'Freigabe',

  'ARCHIVATION_MODE_LABEL': 'Archivierungsmodus',
  'ARCHIVATION_MODE_VALUE_ARCHIVE': 'Aktuelle Version archivieren',
  'ARCHIVATION_MODE_VALUE_OVERRIDE': 'Aktuelle Version überschreiben',

  'INCREASE_VERSION_NUMBER': 'Versionsnummer hochzählen',
  'NEXT_VERSION_NUMBER': 'Nächste Versionsnummer',
  'CURRENT': 'Aktuell',

  'UPLOAD_STATUS_UPLOADING': 'Hochladen …',
  'UPLOAD_STATUS_VALIDATE': 'Validiere Dateien',
  'UPLOAD_STATUS_LOGIN': 'Anmelden',
  'UPLOAD_SUCCESSFUL': 'Das Hochladen war erfolgreich',
  'OPEN_RELUTION': 'Relution öffnen',
  'SHOW_ON_STARTUP': 'Beim starten zeigen',
  'HIDE_ON_STARTUP': 'Beim starten nicht anzeigen',

  'ARCHIVATION_MODE_HELP': 'Archivation mode defines how to handle existing versions of an application that have the same release status as the version being uploaded. Versions with a different release status are never affected during upload. Archive current version means that an existing version will be replaced by the new version and the existing version is moved to the archive. Overwrite current version means that an existing version with the same release status as the one being uploaded will be deleted.',

  //Settings
  'DIALOG_TITLE_SETTINGS': 'Relution Einstellungen',
  'RELUTION_SERVER_PLACEHOLDER': 'https://live.relution.io',
  'USER': 'Benutzer',
  'ORGA': 'Organisation',
  'PASSWORD': 'Passwort',
  'TESTCONNECTION': 'Verbindungstest',
  'SIGN_UP': 'Relution.io Konto erzeugen',


  //GENERATOR UPDATE
  'DIALOG_TITLE_GENERATOR_UPDATE': 'Relution | Neueste Updates laden',
  'DOWNLOAD_DEPENDENCIES': 'Benötigte Pakete für das Relution-Plugin werden geladen. Bitte warten.',

  // JSON EDITOR

  'NAME': 'Name',
  'VERSION': 'Version',
  'PACKAGE': 'Paketname',
  'EDITOR': 'Relution Anwendungs Editor',
  'DESCRIPTION': 'Beschreibung',
  'KEYWORDS': 'Schlüsselwörter',
  'TARGETS': 'Zielplattformen',
  'ANDROID': 'Android',
  'IGNORE': 'Ignorieren',
  'KEY': 'Schlüssel',
  'ALIAS': 'Alias',
  'ICONS': 'Icon',
  'SPLASH': 'Splash',
  'SCREENSHOTS': 'Bildschirmfoto',
  'IOS': 'iOS',
  'PASSPHRASE': 'Passwort',
  'PROVISIONING': 'Provisioning',
  'PLUGINS': 'Plugins',
  'DEVELOPER': 'Entwickler',
  'COMPANY': 'Firma',
  'CONTACT': 'Kontakt',
  'EMAIL': 'E-Mail',
  'PHONE': 'Telefon',
  'LICENSE': 'Lizenz',
  'TYPE': 'Typ',
  'LEGAL': 'Rechtshinweis',
  'APP_INFO': 'App Info',
  'NATIVE_BUILD': 'Native Build',
  'CORDOVA_SETTINGS': 'Cordova Einstellungen',
  'IOS_CORDOVA': 'iOS Cordova',
  'ANDROID_CORDOVA': 'Android Cordova',
  'CORDOVA_PARAMETERS': 'Cordova Parameter',
  'PACKAGE_NAME': 'Package Name',
  'VERSION_NAME': 'Versions Name',
  'VERSION_CODE': 'Versions Code',
  'MAIN_PAGE': 'Startseite',
  'DEFAULT_ICON': 'Icon',
  'WEB': 'Webseite',
  'CHANGELOG': 'Changelog',
  'PATH_TO_CHANGELOG': 'Pfad/zu/changelog.txt',
  'PATH_TO_ICON': 'Pfad/zu/icon.png',
  'SELECT_ICON': 'Icon auswählen',
  'MANDATORY': '*',
  'NOT_NULL': 'Darf nicht \'null\' sein',
  'NOT_EMPTY': 'Darf nicht leer sein',
  'MUST_DEFINED': 'Muss definiert sein',
  'NOT_EXISTS': 'Existiert nicht',
  'FILE': 'Datei',
  'ERROR_ON_FILE_EXISTS': 'Fehler bei Dateiüberprüfung',
  'FILE_PATH_IS_MANDATORY': 'Dateipfad ist zwingend.',
  'GENERAL_SETTINGS': 'Allgemeine Einstellungen',
  'PLEASE_SELECT_SETTING': 'Bitte wählen Sie eine Einstellung',
  'PLEASE_SELECT_STATUSBAR_SETTING': 'Bitte wählen Sie eine StatusBar Einstellung',

  //About
  'DIALOG_TITLE_ABOUT': 'Mobile Application Lifecycle Management',
  'ABOUT_SUB_TITLE': 'Brackets Plugin Version',
  'ABOUT_TEXT': 'Die Mobile Application & Device Management Plattform Relution schützt und verwaltet Apps, Dokumente & Geräte für Unternehmen und Agenturen – betriebssystemübergreifend, sicher und kostengünstig für alle führenden, mobilen Plattformen. Weiter Informationen unter <a href="http://relution.io">Relution.io</a>',
  'ABOUT_LICENSE': 'Dieses Plugin enthält Quelltext des Yeoman Projekts welches unter <a href="http://opensource.org/licenses/bsd-license.php">BSD License</a> veröffentlicht wurde.',
  'CREATE_APP_RLN': 'app.rln erstellen',

  'APPLICATION': 'Anwendung',


  // INTRO: RELUTION DESCR
  'WELCOME_TO_RELUTION': 'Willkommen zu Relution',
  'RELUTION_BENEFIT': 'Mit dem Relution Plugin für Brackets ist es spielend einfach mobile Anwendungen zu entwickeln.',
  'HAVE_AN_ACCOUNT': 'Haben Sie schon ein Relution-Konto?',
  'CREATE_ONE': 'Erstellen Sie eins',
  'TO_GET_STARTED': 'um loszulegen.',
  'CREATE_ACCOUNT_LINK': 'http://trial.relution.io/#form-header',
  'POWERED_BY': 'powered by',
  'WEINRE_SCRIPT': 'Weinre Script',
  'TOGGLE_WEINRE_DEBUGGER': 'Weinre debugger An-/Ausschalten',
  'REMOTE_DEBUGGER': 'Remote Debugger',
  'DEBUG': 'Debug',

  'ios-AllowInlineMediaPlayback': 'AllowInlineMediaPlayback',
  'ios-AutoHideSplashScreen': 'AutoHideSplashScreen',
  'ios-BackupWebStorage': 'BackupWebStorage',
  'ios-DisallowOverscroll': 'DisallowOverscroll',
  'ios-EnableViewportScale': 'EnableViewportScale',
  'ios-FadeSplashScreen': 'FadeSplashScreen',
  'ios-FadeSplashScreenDuration': 'FadeSplashScreenDuration',
  'ios-KeyboardDisplayRequiresUserAction': 'KeyboardDisplayRequiresUserAction',
  'ios-MediaPlaybackRequiresUserAction': 'MediaPlaybackRequiresUserAction',
  'ios-ShowSplashScreenSpinner': 'ShowSplashScreenSpinner',
  'ios-SuppressesIncrementalRendering': 'SuppressesIncrementalRendering',
  'ios-TopActivityIndicator': 'TopActivityIndicator',
  'ios-GapBetweenPages': 'GapBetweenPages',
  'ios-PageLength': 'PageLength',
  'ios-PaginationBreakingMode': 'PaginationBreakingMode',
  'ios-PaginationMode': 'PaginationMode',

  'android-DisallowOverscroll': 'DisallowOverscroll',
  'android-KeepRunning': 'KeepRunning',
  'android-ShowTitle': 'ShowTitle',
  'android-SetFullscreen': 'SetFullscreen',
  'android-SplashScreenDelay': 'SplashScreenDelay',
  'android-SplashScreen': 'SplashScreen',
  'android-BackgroundColor': 'BackgroundColor',
  'android-LoadDialog': 'LoadDialog',
  'android-LoadingPageDialog': 'LoadingPageDialog',
  'android-ErrorUrl': 'ErrorUrl',
  'android-LoadUrlTimeoutValue': 'LoadUrlTimeoutValue',
  'android-InAppBrowserStorageEnabled': 'InAppBrowserStorageEnabled',
  'android-LogLevel': 'LogLevel',


  // INTRO //

  'intro_1': 'Es ist möglich mit den Pfeiltasten zu navigieren. Zum verlassen des Intros ESC drücken. Soll das Intro nichtmehr angezeigt werden drücken Sie',
  'SETUP_ACCOUNT': 'Konto erstellen',
  'intro_2': 'Das Relution Plugin hat ein eigenen Menüeintrag in dem Sie jegliche Einstellungen finden, wie die Einstellungen um das Plugin mit einem Relution-Server zu verbinden.',
  'intro_3': 'Sie können diese Tour jederzeit neustarten:',
  'intro_4': 'Tragen Sie ihre Benutzerdaten im Einstellungsdialog ein.',
  'intro_5': 'Um sich mit einem Relution-Server zu verbinden muss die Addresse des <strong>Server</strong> in das entsprechende Feld eingetragen werden. Ebenfalls steht ein Relution Cloud-Dienst unter <a href="http://live.relution.io/">http://live.relution.io</a> zur Verfügung.',
  'intro_6': 'Tragen sie ihre Benutzerdaten für <strong>Benutzer</strong>, <strong>Organisation</strong> and <strong>Passwort</strong> ein. Bei eventuellen Fragen wenden Sie sich am besten an ihren Systemadministrator. <a href="http://trial.relution.io/#form-header">Falls sie noch keinen Account haben, können Sie hier einen erstellen.</a>',
  'Test_the_connection': 'Verbindungstest',
  'intro_7': 'Um die Benutzereinstellungen zu überprüfen drücken Sie den "Verbindungstest".',
  'intro_8': 'Anschließend wird das Ergebnis neben dem Knopf angezeigt.',
  'Create_an_application': 'Anwendung erzeugen',
  'intro_9': 'Wählen sie im \'Datei\' Menü "Neue WebApp …" aus um eine Relution Anwendung zu entwickeln.',
  'intro_10': 'Jede Anwednung hat einen Namen. Hierbei empfiehlt sich ein Name der nicht aus mehr als 12 Buschstaben besteht.',
  'intro_11': 'Jede Anwednung hat einen eindeutigen <strong>Paketname</strong>. Generell gilt hierbei das Länderkürzel, gefolgt eines Firmennamens und des Anwendungsnamen. Jedes Element wird durch einen "." getrennt. Es dürfen keine Leerzeichen enthalten sein. Zum Schluss den Pfad in dem die Anwednung gespeichert werden soll auswählen.',
  'intro_12': 'Um Ihre Anwendung im Entwicklungsmodus zu starten, drücken Sie das "<strong>m</strong>" in der rechten Spalte. Hierdurch wird die Echtzeit-Vorschau gestartet.',
  'intro_13': 'Mit der <strong>app.rln</strong> Datei ist es möglich Anwednungen/Projekte zu konfigurieren, wobei die Datei valides JSON enthalten muss.',
  'intro_14': 'Wenn Sie mit Ihrer Arbeit zufrieden sind, können sie die Anwendung auf den Relution Server hochladen. Hierzu den Menüpunkt "<strong>Zu Relution hochladen …</strong>" auswählen.',
  'intro_15': 'Der <strong>Server</strong> sollte der gleiche wie in den Einstellungen sein. Falls Sie die Einstellungen ändern möchten, drücken sie auf "<strong>Konfigurieren</strong>".',
  'intro_16': '<strong>Hochladen auf</strong> gibt den Release-Zustand der Anwendung an.',
  'intro_17': 'Wählen Sie danach aus was mit der aktuellen Version der Anwendung passieren soll. Falls dies die erste Version der Anwendung ist, können Sie diesen Menüpunkt ignorieren.',
  'intro_18': 'Drücken Sie den "<strong>Hochladen</strong>" Knopf um die Anwendung auf Relution zu veröffentlichen.',
  'intro_19': 'Warten Sie bis die Anwendung veröffentlicht wurde.',
  'intro_20': 'Herzlichen Glückwunsch. Ihre Anwendung steht nun im Relution App Store zur Verfügung. Öffnen Sie den Relution App Store über "<strong>Relution öffnen</strong>".',
  'intro_21': 'Ihre Anwendung kann in der Relution App für <a href="https://play.google.com/store/apps/details?id=com.mwaysolutions.relution">Android</a> und <a href="https://itunes.apple.com/de/app/relution/id699597062?l=en&mt=8">iOS</a> gestartet werden.',
  'Work_with_your_application': 'Anwendung bearbeiten',
  'Publish_your_application': 'Anwendung veröffentlichen',
  'See_your_app_in_action': 'Probieren Sie ihre Anwendung aus',

  '': ''
});
