/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports, module ) {
    "use strict";
    var FileUtils = brackets.getModule("file/FileUtils");
    var PreferencesManager = brackets.getModule("preferences/PreferencesManager");
    var BaseView = require('BaseView');
    var Strings = require("strings");
    var template = require("text!intro/intro.html");

    var rootPath = FileUtils.getNativeModuleDirectoryPath(module);

    var relutionIntroId = 'relution-intro';
    var activeClass = 'active';
    var toLeftClass = 'to-left';
    var toRightClass = 'to-right';

    var first = true;
    var currentView = null;


    var View = BaseView.extend({
        template: _.template(template),

        events: {
            'click [data-action="close"]': 'close',
            'click [data-action="next"]': 'next',
            'click [data-action="prev"]': 'prev',
            'click [data-action="toggleOnStartup"]': 'toggleOnStartup'
        },

        toggleOnStartup: function( force ) {
            var startup = PreferencesManager.get('hide-relution-intro');
            var newVal = typeof force === 'boolean' ? force : !!!startup;
            PreferencesManager.set('hide-relution-intro', newVal);
            this.updateToggleStateUi(newVal);
        },

        updateToggleStateUi: function( val ) {
            if( val ) {
                this.$toggleShowOnStartup.addClass('on');
                this.$toggleShowOnStartup.html(Strings.SHOW_ON_STARTUP);
            } else {
                this.$toggleShowOnStartup.removeClass('on');
                this.$toggleShowOnStartup.html(Strings.HIDE_ON_STARTUP);
            }
        },

        prev: function() {
            var $active = this.$el.find('section.active');
            var id = this.getPrevInd($active);
            if(id > -1) {
              $active.removeClass(activeClass);
              this.$contentSections.eq(id).addClass(activeClass);
              this.$footerSections.eq(id).addClass(activeClass);
              this.updateIndicator(id);
            }
        },

        next: function() {
            var $active = this.$el.find('section.active');
            var id = this.getNextInd($active);
            if(id != 0) {
              $active.removeClass(activeClass);
              this.$contentSections.eq(id).addClass(activeClass);
              this.$footerSections.eq(id).addClass(activeClass);
              this.updateIndicator(id);
            }
        },

        updateIndicator: function( id ) {
            this.$indicatorCurrent.html(++id);
            this.$progress.val(id);
        },

        getNextInd: function( $active ) {
            $active = $active || this.$el.find('.mway-brackets-intro-content section.active');
            var ind = $active.index();
            if( this.$contentSections.length - 1 <= ind ) {
                return 0;
            } else {
                return ++ind;
            }
        },

        getPrevInd: function( $active ) {
            $active = $active || this.$el.find('.mway-brackets-intro-content section.active');
            var ind = $active.index();
            var length = this.$contentSections.length - 1;
            if( length <= 0 ) {
                return length;
            } else {
                return --ind;
            }
        },

        close: function() {
            hide();
        },

        preRender: function(){
            this.templateValues.imagePath = rootPath + '/images/';
        },

        postRender: function() {
            var that = this;
            this.$contentSections = this.$el.find('.mway-brackets-intro-content section');
            this.$footerSections = this.$el.find('.mway-brackets-intro-footer section');


            this.$indicatorCurrent = this.$el.find('.mway-brackets-intro-indicator-current');
            this.$indicatorTotal = this.$el.find('.mway-brackets-intro-indicator-total');
            this.$progress = this.$el.find('progress');

            this.$indicatorCurrent.html(1);
            this.$indicatorTotal.html(this.$contentSections.length);
            this.$progress.attr('max', this.$contentSections.length);

            this.$toggleShowOnStartup = this.$el.find('.show-on-startup');

            this.updateToggleStateUi(this.opt.showOnStartup);

            if(!this.opt.showOnStartup){
                this.toggleOnStartup();
            }

            setTimeout(function() {
                that.$el.find('.mway-brackets-intro-footer-wrapper').addClass('show');
            }, 0);
        },

        className: 'mway-brackets-intro',

        initialize: function( opt ) {
            this.$contentSections = null;
            this.$footerSections = null;
            this.$toggleShowOnStartup = null;
            this.opt = opt;
            BaseView.prototype.initialize.apply(this, arguments);
        }
    });

    function show( opt ) {
        opt = opt || {};
        var id = opt.id || relutionIntroId;
        if( $('#' + id).length < 1 ) {
            currentView = new View({
                showOnStartup: opt.showOnStartup || PreferencesManager.get('hide-relution-intro')
            });
            $('body').append('<div id="' + id + '"></div>');
            $('#' + id).html(currentView.render().$el);
        }

        $(document).off('keyup', onKeyUp);
        $(document).on('keyup', onKeyUp);
    }

    function onKeyUp(ev){
        if(ev.keyCode === 39){
            currentView.next();
        } else if(ev.keyCode === 37){
            currentView.prev();
        } else if(ev.keyCode === 27){
            currentView.close();
        }
    }

    function hide( id ) {
        id = id || relutionIntroId;
        $('#' + id).remove();
    }

    function start() {
        var hide = PreferencesManager.get('hide-relution-intro');
        if( !hide ) {
            show({
                showOnStartup: hide
            });
        }
    }

    exports.start = start;
    exports.show = show;
    exports.hide = hide;
});
