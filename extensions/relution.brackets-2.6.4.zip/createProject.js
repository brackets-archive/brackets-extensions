/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports, module ) {
    "use strict";

    var ProjectManager = brackets.getModule("project/ProjectManager");
    var Dialogs = brackets.getModule("widgets/Dialogs");
    var DefaultDialogs = brackets.getModule("widgets/DefaultDialogs");
    var Strings = require("strings");
    var BaseView = require('BaseView');
    require('parsley');
    var template = require("text!templates/dialog_application_create.html");
    var PreferencesManager = brackets.getModule("preferences/PreferencesManager");
    var FileSystem = brackets.getModule("filesystem/FileSystem");
    var nodeBridge = require("./node/nodeBridge");
    var _ = require('underscore');
    var fs = require('utils/fs');
    var createAppDefaultPathId = 'relutions.create.app.root.folder.path';

    var projectDirectory = PreferencesManager.get(createAppDefaultPathId);
    var defaultHomeDir = brackets.app.getUserDocumentsDirectory();

    var View = BaseView.extend({

        events: {
            'click .btn.primary': 'saveProject',
            'click #relution-change-project-directory': 'changeProjectDirectory',
            'keyup #relution-createproject-name': 'updateNameHandler',
            'keyup #relution-project-directory': 'updateProjectPathHandler'
        },

        template: _.template(template),

        initialize: function() {
            BaseView.prototype.initialize.apply(this, arguments);

            projectDirectory = projectDirectory || defaultHomeDir;

            this.templateValues = {
                PROJECT_DIRECTORY: projectDirectory,
                defaults: {
                    identifier: this.Strings.IDENTIFIER_DEFAULT
                }
            };

            this.customValidator();
        },

        postRender: function() {
            this.$el.find('form').parsley();
            return this;
        },

        customValidator: function() {
            window.ParsleyValidator.addValidator('identifier',function( value ) {
                var pattern = /^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+[0-9a-z_]$/i;
                return pattern.test(value);
            }, 32).addMessage('en', 'identifier', this.Strings.INVALID_IDENTIFIER);

            window.ParsleyValidator.addValidator('appname',function( value ) {
                // Validate file name
                // Checks for valid Windows filenames:
                // See http://msdn.microsoft.com/en-us/library/windows/desktop/aa365247(v=vs.85).aspx
                var pattern = /[\/?*:;\{\}<>\\|]+/;
                var _illegalFilenamesRegEx = /^(\.+|com[1-9]|lpt[1-9]|nul|con|prn|aux)$/i;
                return !pattern.test(value) && (value.match(_illegalFilenamesRegEx).length === null);
            }, 33).addMessage('en', 'appname', this.Strings.INVALID_PROJECT_NAME_MESSAGE);
        },

        //////////////////////////////////////////
        // Events

        saveProject: function( e ) {
            e.preventDefault();
            e.stopPropagation();

            this.validate(function() {
                return fs.mkdir(this.binding.projectDirectory).then(function () {
                    var generatorOptions = {
                        template: 'helloworld',
                        cwd: this.binding.projectDirectory,
                        templateValues: {
                            name: this.binding.name,
                            package: this.binding.identifier
                        }
                    };
                    this.$el.find('.spinner-container').show();
                    nodeBridge.generator(generatorOptions, function( err ) {
                        this.$el.find('.spinner-container').hide();
                        if( err ) {
                            if(typeof err === 'string' ) {
                                err = translateErrorString(err);
                            }
                            showProjectErrorMessage(err);
                            return;
                        }
                        Dialogs.cancelModalDialogIfOpen('relution-modal', 'ok');
                        ProjectManager.openProject(this.binding.projectDirectory);
                    }.bind(this));
                }.bind(this));
            }.bind(this));
        },

        changeProjectDirectory: function( e ) {
            e.preventDefault();
            e.stopPropagation();

            FileSystem.showOpenDialog(false, true, this.BracketsStrings.CHOOSE_FOLDER, this.binding.projectDirectory, null, function( error, files ) {
                if( !error && files && files.length > 0 && files[0].length > 0 ) {
                    var newProjectFolder = files[0];
                    this.templateValues.PROJECT_DIRECTORY = newProjectFolder;
                    this.binding.projectDirectory = newProjectFolder;
                    this.appendProjectNameToPath();
                    projectDirectory = newProjectFolder;
                    PreferencesManager.set("newProjectsFolder", this.binding.projectDirectory);
                    PreferencesManager.set(createAppDefaultPathId, this.binding.projectDirectory);
                }
            }.bind(this));
        },

        updateNameHandler: function() {
            this.generateIdentifier();
            this.appendProjectNameToPath();
            this.validateProjectPath();
        },

        updateProjectPathHandler: function() {
            this.validateProjectPath();
        },
        generateIdentifier: function() {

            var name = _.camelize(this.binding.name.replace(/[^a-zA-Z0-9 ]/g, ""));
            var defaultIdentifier = this.templateValues.defaults.identifier;
            var identifier = this.binding.identifier;

            if( identifier === '' ) {
                identifier = defaultIdentifier;
            }

            // Replace last entry with the new appname
            var list = identifier.split('.');
            list[list.length - 1] = name;

            this.$('#relution-createproject-identifier').val(list.join('.'));
        },

        validate: function ( cb ) {
            this.validateProjectPath().always(function () {
                if( this.$el.find('form').parsley().validate() ) {
                    if( cb ) {
                        cb();
                    }
                }
            }.bind(this));
        },

        appendProjectNameToPath: function() {
            var projectName = this.binding.name;

            // fix projects folder name
            projectName = projectName.replace(/ä/g,"ae").replace(/ö/g,"oe").replace(/ü/g,"ue").replace(/Ä/g,"Ae").replace(/Ö/g,"Oe").replace(/Ü/g,"Ue").replace(/ß/g,"ss");
            projectName = projectName.replace(/[^a-zA-Z0-9_\-]/g, '');

            // Append folder to path
            var path = this.templateValues.PROJECT_DIRECTORY;
            if(projectName) {
                path += '/' + projectName;
            }

            this.binding.projectDirectory = path;
            PreferencesManager.set("newProjectsFolder", path);
        },

        validateProjectPath: function () {
            this.$('.error').html('');
            return fs.readdir(this.binding.projectDirectory).then(function ( content ) {
                if( content.length > 0 ) {
                    this.$('.error').html(Strings.ERROR_DIR_IS_NOT_EMPTY.replace('%s', this.binding.projectDirectory));
                }
            }.bind(this)).fail(function ( err ) {
                if( err !== appshell.fs.ERR_NOT_FOUND ) {
                    this.$('.error').html(err);
                }
            });
        }

    });

    function openDialog() {

        var view = new View();

        var dialog = Dialogs.showModalDialogUsingTemplate('<div class="modal relution-modal"></div>');
        dialog.getElement().html(view.render().el);

        return dialog;
    }

    function showProjectErrorMessage(message) {
        Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_ERROR, Strings.DIALOG_TITLE_CREATE, message);
    }

    /**
     * Trims the given directory name
     * @returns {string}
     */
    function trimDirectoryName (name) {
        return name.replace(/\s/g, '').replace(/[^a-zA-Z0-9 ]/g, "");
    }

    function translateErrorString( errorMessage ) {
        var key = errorMessage.toUpperCase().replace(/\./g, '_');
        var msg = Strings[key];
        if( !msg ) {
            msg = key;
        }
        return msg;
    }

    function convertUnixPathToWindowsPath(path) {
        if (brackets.platform === 'win') {
            path = path.replace(new RegExp(/\//g), '\\');
        }
        return path;
    }

    //For unit-testing only
    exports.trimDirectoryName = trimDirectoryName;
    exports.translateErrorString = translateErrorString;


    exports.openDialog = openDialog;

});
