/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */
(function() {
    "use strict";

    function updateGenerator( options, cb ) {
        var updateManager = require("../node_modules/update-manager/update-manager");

        options.error = function( e ) {
            cb(e);
        };

        options.success = function( data ) {
            cb(null, data);
        };

        updateManager.update(options);
    }

    function generator( appOptions, cb ) {

        var IonicGenerator = require("../node_modules/mcap-generator-ionic/lib/ionic-generator");
        process.chdir(appOptions.cwd);
        delete appOptions.cwd;

        var gen = new IonicGenerator();
        gen.createApp(appOptions, function( err ) {
            if( err ) {
                return cb(err);
            }
            cb();
        });
    }

    function startWeinre( options, cb ) {
        var dns = require('dns');
        var os = require('os');
        // use dns lookup to determine IP addr
        dns.lookup(os.hostname(), function( err, ip, fam ) {
            if( !err ) {
                _runWeinre(ip, cb);
                return;
            } else {
                // if the dns lookup failed
                var ip = null;
                var ifaces = os.networkInterfaces();
                // try a network interface
                for( var dev in ifaces ) {
                    var alias = 0;
                    ifaces[dev].forEach(function( details ) {
                        if( details.family == 'IPv4' ) {
                            // take the latest available network interface
                            ip = details.address;
                            ++alias;
                        }
                    });
                }
                if( ip ) {
                    // if a ip was determined with with a network interface start weinre
                    _runWeinre(ip, cb);
                    return;
                }
                // otherwise raise an error
                cb('no ip')
                return;
            }
            cb(err);
        });
    };

    function _runWeinre( ip, cb ) {
        try{
            require('../node_modules/weinre/node_modules/coffee-script');
            var weinre = require('../node_modules/weinre/lib/weinre');
            weinre.run({httpPort: 8087,
                boundHost:    ip || 'localhost',
                verbose:      false,
                debug:        false,
                readTimeout:  5,
                deathTimeout: 3 * 5
            });
            cb(null, {
                ip: ip
            });
        } catch(e){
            cb(e);
        }

    }


    function createDefaultAppRln( appOptions, cb ) {
        var IonicGenerator = require("../node_modules/mcap-generator-ionic/lib/ionic-generator");
        var gen = new IonicGenerator();
        gen.createDefaultAppRln(appOptions, function( err ) {
            if( err ) {
                return cb(err);
            }
            cb();
        });
    }

    function upload( options, cb ) {
        var fileUpload = require("../node_modules/relution-file-upload/lib/mcap-file-upload");
        fileUpload.upload(options).then(function( appId ) {
            cb(null, appId);
        }).fail(function( err ) {
            cb(err);
        });
    };

    /**
     * Initializes the test domain with several test commands.
     * @param {DomainManager} DomainManager The DomainManager for the server
     */
    function init( DomainManager ) {
        if( !DomainManager.hasDomain("generator") ) {
            DomainManager.registerDomain("generator", {major: 0, minor: 1});
        }

        DomainManager.registerCommand("relution", "updateGenerator", updateGenerator, true, "", [], []);

        DomainManager.registerCommand("relution", "generator", generator, true, "", [], []);

        DomainManager.registerCommand("relution", "upload", upload, true, "", [], []);

        DomainManager.registerCommand("relution", "createDefaultAppRln", createDefaultAppRln, true, "", [], []);

        DomainManager.registerCommand("relution", "startWeinre", startWeinre, true, "", [], []);
    }

    exports.init = init;

}());
