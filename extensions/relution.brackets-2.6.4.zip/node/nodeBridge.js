/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports, module ) {
    "use strict";

    // Load Brackets modules
    var NodeConnection = brackets.getModule("utils/NodeConnection");
    var ExtensionUtils = brackets.getModule("utils/ExtensionUtils");

    var nodeConnection = null;

    function updateGenerator( options, cb ) {
        runNode(function() {

            var promise = nodeConnection.domains.relution.updateGenerator(options);
            promise.fail(function( err ) {
                cb(err);
            });
            promise.done(function() {
                cb(null, 'done');
            });
            return promise;
        });
    };

    function generator( options, cb ) {
        runNode(function() {

          var promise = nodeConnection.domains.relution.generator(options);
            promise.fail(function( err ) {
                cb(err);
            });
            promise.done(function() {
                cb();
            });
            return promise;
        });
    };

    function upload( options, cb ) {
        runNode(function() {

          var promise = nodeConnection.domains.relution.upload(options);
            promise.fail(function( err ) {
                cb(err);
            });
            promise.done(function(appId) {
                cb(null, appId);
            });
            return promise;
        });
    };

    function startWeinre( options) {
        var dfd = $.Deferred();
        runNode(function() {
            var promise = nodeConnection.domains.relution.startWeinre(options);
            promise.fail(function( err ) {
                dfd.reject(err);
            });
            promise.done(function(data) {
                dfd.resolve(data);
            });
            return promise;
        });
        return dfd.promise();
    };

    function createDefaultAppRln( options, cb ) {
        runNode(function() {

            var promise = nodeConnection.domains.relution.createDefaultAppRln(options);
            promise.fail(function( err ) {
                cb(err);
            });
            promise.done(function(appId) {
                cb(null, appId);
            });
            return promise;
        });
    };

    function runNode( nodeFunc ) {

        nodeConnection = new NodeConnection();

        function connect() {
            var promise = nodeConnection.connect(true);
            promise.fail(function( err ) {
                console.log("[brackets-node] Failed to connect to node. Error:", err);
            });
            return promise;
        };

        function loadDomain() {
            var path = ExtensionUtils.getModulePath(module, "./node");
            var promise = nodeConnection.loadDomains([path], true);
            promise.fail(function( err ) {
                console.log("[brackets-node] Failed to load domain. Error:", err);
            });
            return promise;
        };

        var chain = function() {
            var functions = Array.prototype.slice.call(arguments, 0);
            if( functions.length > 0 ) {
                var firstFunction = functions.shift();
                var firstPromise = firstFunction.call();
                firstPromise.done(function() {
                    chain.apply(null, functions);
                });
            }
        };

        chain(connect, loadDomain, nodeFunc);
    };

    exports.updateGenerator = updateGenerator;
    exports.generator = generator;
    exports.upload = upload;
    exports.createDefaultAppRln = createDefaultAppRln;
    exports.startWeinre = startWeinre;
});