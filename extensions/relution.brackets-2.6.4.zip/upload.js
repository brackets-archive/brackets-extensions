/**
 * Relution.io Brackets Plugin
 *
 * @copyright 2014, M-Way Solutions GmbH
 * @license GPLv3 <http://www.gnu.org/licenses/gpl.txt>
 */

define(function( require, exports, module ) {
    "use strict";

    var ProjectManager = brackets.getModule("project/ProjectManager");
    var Dialogs = brackets.getModule("widgets/Dialogs");
    var DefaultDialogs = brackets.getModule("widgets/DefaultDialogs");
    var DocumentManager = brackets.getModule("document/DocumentManager");
    var Commands = brackets.getModule('command/Commands');
    var CommandManager = brackets.getModule('command/CommandManager');
    var Strings = require("strings");
    var BracketsStrings = brackets.getModule("strings");
    var BaseView = require('BaseView');
    var template = require("text!templates/dialog_upload.html");
    var templateUploading = require("text!templates/dialog_uploading.html");
    var templateUploaded = require("text!templates/dialog_uploaded.html");
    var PreferencesManager = brackets.getModule("preferences/PreferencesManager");
    var nodeBridge = require("./node/nodeBridge");
    var settings = require("./settings");
    var validateJson = require("validateJson");
    var RelutionProjectManager = require("utils/RelutionProjectManager");
    var socketIO = require('socketIO');
    var socket = null;

    var ERROR_APPLICATION_DO_NOT_EXIST = 1003;
    var ARCHIVATION_ARCHIVE = 'archive';
    var ARCHIVATION_OVERRIDE = 'override';

    var uploadSettings = null;
    var appConfig = null;
    var rlnFiles = null;

    var mainPageText = null;
    var mainPageDoc = null;

    var cordMainPageText = null;
    var cordMainPageDoc = null;

    var DEVELOPMENT = 'DEVELOPMENT';
    var weinre = require('weinre/weinre');

    /**
     * The Upload View contains the form to setup the upload
     */
    var UploadView = BaseView.extend({

        events: {
            // click on the uplpoad button
            'click .btn.primary': 'upload',
            // checkbox to toggle increase version number option
            'change #relution-upload-increase-version': 'toggleIncreaseVersionNumber',
            // increase version number should increase version text
            'change #relution-upload-next-version': 'updateVersionName',
            // open the settings
            'click .btn.configure': 'openSettings'
        },

        template: _.template(template),

        initialize: function() {
            BaseView.prototype.initialize.apply(this, arguments);
        },

        preRender: function() {
            this.templateValues.releaseStates = this.getReleaseStates();
            this.templateValues.credentials = this.getCredentials();
            this.templateValues.archivationModes = this.getArchivationModes();
            this.templateValues.increaseVersion = this.getIncreaseVersion();
            // add the version name and version code to the template values
            this.templateValues.currentVersionCode = this.currentVersionCode;
            this.templateValues.currentVersionName = this.currentVersionName;
            if( this.templateValues.increaseVersion ) {
                this.templateValues.nextVersionCode = parseInt(this.currentVersionCode, 10) + 1;
                this.templateValues.nextVersionName = validateJson.getNextVersionName(this.currentVersionName);
            } else {
                this.templateValues.nextVersionCode = this.currentVersionCode;
                this.templateValues.nextVersionName = this.currentVersionName;
            }

            // all config files
            this.templateValues.rlnFiles = rlnFiles;
        },

        postRender: function() {
            this.addTooltip();
            return this;
        },

        getReleaseStates: function() {
            return [
                {
                    label: Strings.RELEASE_STATE_DEVELOPMENT,
                    value: DEVELOPMENT,
                    selected: true
                },
                {
                    label: Strings.RELEASE_STATE_REVIEW,
                    value: 'REVIEW'
                },
                {
                    label: Strings.RELEASE_STATE_ARCHIVE,
                    value: 'ARCHIVE'
                },
                {
                    label: Strings.RELEASE_STATE_RELEASE,
                    value: 'RELEASE'
                }
            ];
        },

        getArchivationModes: function() {
            return [
                {
                    label: Strings.ARCHIVATION_MODE_VALUE_ARCHIVE,
                    value: ARCHIVATION_ARCHIVE,
                    selected: true
                },
                {
                    label: Strings.ARCHIVATION_MODE_VALUE_OVERRIDE,
                    value: ARCHIVATION_OVERRIDE
                }
            ];
        },

        validate: function() {
            return this.$el.find('form').parsley().validate();
        },

        getCredentials: function() {
            var loginData = PreferencesManager.get('upload-settings');

            if( loginData && loginData.server ) {
                loginData.server = loginData.server.replace(/.*?:\/\//g, "");
            }

            if( loginData && loginData.server && loginData.user && loginData.server.length > 0 && loginData.user.length > 0 ) {
                return loginData.user + '@' + loginData.server;
            }
            return null;
        },

        addTooltip: function() {

            // Configure the twipsy
            var options = {
                placement: "above",
                trigger: "hover",
                title: function() {
                    return Strings.ARCHIVATION_MODE_HELP;
                }
            };

            // Show the twipsy with the explanation
            this.$('.archivation .help-btn').twipsy(options);
        },

        //////////////////////////////////////////
        // Events

        /**
         * setup the upload options - not really the upload! The next step on the upload is called via the openDialog callback
         * @param e
         */
        upload: function( e ) {
            if( !this.validate() ) {
                e.stopPropagation();
                e.preventDefault();
                return;
            }

            uploadSettings = {
                releasestate: this.binding.releasestate,
                archivation: this.binding.archivation
            };

            // if there are more than one config file
            if( this.templateValues.rlnFiles.length > 1 ) {
                // get the config file by selected id
                var configFile = _.find(this.templateValues.rlnFiles, function( rln ) {
                    // compare the available ids from the template with the selected one. If there was only one config file the this.binding is empty.
                    return rln._id.toString() === this.binding.rlnFileId.toString();
                }, this);

                // and add the config file to the settings
                if( configFile ) {
                    uploadSettings.configFile = configFile;
                }
            }
        },

        openSettings: function( e ) {
            var that = this;
            e.stopPropagation();
            e.preventDefault();
            settings.openDialog().done(function() {
                that.render();
            });
        },

        toggleIncreaseVersionNumber: function() {
            this.render();
        },

        updateVersionName: function(){
            this.binding.versionName = validateJson.getNextVersionName(this.binding.versionName, this.binding.versionCode);
        },

        getIncreaseVersion: function() {
            if( this.binding && typeof this.binding.increaseVersion !== 'undefined' ) {
                return this.binding.increaseVersion;
            }

            return true;
        },

        setVersionCode: function( versionCode ) {
            this.currentVersionCode = versionCode;
        },

        setVersionName: function( versionName ) {
            this.currentVersionName = versionName;
        }
    });

    var UploadingView = BaseView.extend({

        template: _.template(templateUploading),

        initialize: function( options ) {
            BaseView.prototype.initialize.apply(this, arguments);
            this.options = options;
        },

        _postRender: function() {
            var that = this;
            that.validateAppJSON().then(function( parsedObj ) {
                appConfig = parsedObj;
                return that.login();

            }).then(function() {
                return that.uploadZip();

            }).then(function( appId ) {
                showSuccessDialog(appId);
            }).fail(function( err ) {
                var errorMessage = '';
                if( typeof err === 'string' ) {
                    try {
                        err = JSON.parse(err).errors;
                        var errorCode = Object.keys(err)[0];
                        errorMessage = Strings['ERROR_RELUTION_' + errorCode];
                    } catch(e) {
                        errorMessage = err;
                    }
                } else if( err.errors ) {
                    errorMessage = err.erros[Object.keys(err.erros)[0]];
                } else if( err.status ) {
                    errorMessage = Strings['ERROR_' + err.status];
                } else if( err.errorCode ) {
                    if( err.errorCode === 6000 && err.details ) {
                        //Validation Error
                        $.each(err.details, function( key, val ) {
                            console.log(val.errorCode + ' ' + val.message);
                            errorMessage += val.errorCode + ' ' + val.message + '</br>';
                        });
                    } else {

                    }
                    //errorMessage = Strings['ERROR_' + err.errorCode];
                }
                if( !errorMessage && err.message ) {
                    errorMessage = err.message;
                }


                showErrorDialog(errorMessage);
            });
        },

        updateStatus: function( msg ) {
            this.$('.status').html(msg);
        },

        login: function() {
            this.updateStatus(Strings.UPLOAD_STATUS_LOGIN);

            var loginData = PreferencesManager.get('upload-settings');

            var req = loginData.server + 'gofer/security-login?j_username=' + encodeURIComponent(loginData.user) + '&j_password=' + encodeURIComponent(loginData.password) + '&j_organization=' + encodeURIComponent(loginData.orga);
            return $.get(req);
        },

        validateAppJSON: function() {
            this.updateStatus(Strings.UPLOAD_STATUS_VALIDATE);
            return validateJson.getAppJSON();
        },

        uploadZip: function() {
            var dfd = $.Deferred();
            var that = this;

            this.updateStatus(Strings.UPLOAD_STATUS_UPLOADING);

            var loginData = PreferencesManager.get('upload-settings');


            var targets = getActiveTargets(appConfig.targets);

            var uploadOptions = {
                url: loginData.server,
                platforms: targets,
                releaseStatus: this.options.releasestate,
                archivationMode: this.options.archivation,
                auth: {
                    'user': loginData.user + ':' + loginData.orga,
                    'pass': loginData.password
                },
                zip:{
                    rootFolder: ''
                },
                log: false
            };

            // if a config file was set in the initialize process - use that config file as project root and upload that application
            var configFile = null;
            if( this.options && this.options.configFile ) {
                configFile = this.options.configFile;
            }

            // adds a debug script to the main page
            var addDebugScript = function( mainPage, cb ) {
                // get the main page
                DocumentManager.getDocumentForPath(mainPage).then(function( doc ) {
                    // cache the document
                    mainPageDoc = doc;
                    // cache the current text to resstatustore it
                    mainPageText = doc.getText();
                    // add the script tag before the body
                    var text = mainPageText.replace('</body>', '<script src="' + weinre.getClientUrl() + '"></script></body>');
                    // update the main page
                    mainPageDoc.setText(text);
                    // save the main page
                    CommandManager.execute(Commands.FILE_SAVE, {doc: mainPageDoc}).then(function() {
                        cb();
                    });
                });
            };
            function addCordovaScript(mainPage) {
                // get the main page
                DocumentManager.getDocumentForPath(mainPage).then(function( doc ) {
                    // cache the document
                    cordMainPageDoc = doc;
                    // cache the current text to resstatustore it
                    cordMainPageText = doc.getText();
                    var text = cordMainPageText;

                    // this string will be replace the </body> tag of the script
                    var scriptTags = '';
                    // the source path of cordova and ng-cordova files included by the developer
                    var cordovaSourcePath = [];
                    // parse the html page
                    var dom = $(text);
                    dom.each(function(){
                        // find all the scripts
                        if(this.tagName === 'SCRIPT'){
                            /*
                                This regex will match:
                                    cordova.js
                                    fgg/fsdf-/cordova.js
                                    asdf/cordova.js
                                    /node.io/asdf/f-f/cordova.js
                                    ./cordova.js
                                But not:
                                     my-cordova.js
                                     asdf/my-cordova.js
                                     fgg/fsdf-/mycordova.js
                                     /node.io/asdf/f-f/your.cordova.js
                                     min.cordova.js
                             */
                            if(this.src.toString().match(/(.*\/cordova\.js|^cordova\.js)/)){
                                cordovaSourcePath.push(this.getAttribute('src'));
                            }
                            if(this.src.toString().match(/(.*\/ng-cordova\.js|^ng-cordova\.js)/)){
                                cordovaSourcePath.push(this.getAttribute('src'));
                            }
                        }
                    });

                    // if cordova or ng-cordova scripts were found replace remove the src attribute
                    cordovaSourcePath.forEach(function(path){
                        text = text.replace(' src="' + path + '"', '');
                        text = text.replace(' src=\'' + path + '\'', '');
                    });
                    // replace empty script tags
                    text = text.replace(/<script[\s]*>[\s]*<\/script>/gi, '');
                    // append the scripts
                    scriptTags += '<script src="ng-cordova.js"></script>';
                    scriptTags += '<script src="cordova.js"></script>';
                    scriptTags += '</body>';
                    // add the script tag before the body
                    text = text.replace('</body>', scriptTags);
                    // update the main page
                    cordMainPageDoc.setText(text);
                    // save the main page
                    CommandManager.execute(Commands.FILE_SAVE, {doc: cordMainPageDoc});
                });
            }

            function removeCordovaScript() {
                cordMainPageDoc.setText(cordMainPageText);
                CommandManager.execute(Commands.FILE_SAVE, {doc: cordMainPageDoc});
            }

            // Removes the previously set debug script from the main page
            var removeDebugScript = function( cb ) {
                mainPageDoc.setText(mainPageText);
                CommandManager.execute(Commands.FILE_SAVE, {doc: mainPageDoc}).then(function() {
                    cb();
                });
            };

            var doUpload = function() {

                if (!socket) {
                    socket = socketIO.connect('http://localhost:8089');
                    socket.on('uploadProgress', function (percent) {
                        that.updateStatus(percent + ' %');
                    });
                }

                return nodeBridge.upload(uploadOptions, function( err, appId ) {
                    if( err ) {
                        if( typeof err === 'object' ) {
                            var errorCode = parseInt(Object.keys(err)[0], 10);
                            var errorMessage = err[errorCode];
                            err = {
                                errorCode: errorCode,
                                message: errorMessage
                            };

                            dfd.reject(err);
                        } else if( typeof err === 'string' ) {
                            dfd.reject(err);
                        } else {
                            dfd.reject(Strings.ERROR_GENERAL);
                        }
                    }
                    // Inject a debug script tag if its a development version
                    if( appConfig.debug ) {
                        removeDebugScript(function() {
                            dfd.resolve(appId);
                        });
                    } else {
                        dfd.resolve(appId);
                    }
                    removeCordovaScript();
                });
            };

            // get the project root of the config file if there is one. otherwise determine the CONST.config root path
            RelutionProjectManager.getProjectRoot(configFile).then(function( projectRoot ) {
                var upload = null;
                uploadOptions.path = projectRoot;
                addCordovaScript(projectRoot + appConfig.mainPage);
                if( appConfig.debug ) {
                    addDebugScript(projectRoot + appConfig.mainPage, doUpload);
                } else {
                    upload = doUpload();
                }


            }).fail(function( err ) {
                dfd.reject(err);
            });

            return dfd.promise();
        }
    });

    function getActiveTargets( targets ) {
        var allowedTargets = ['android', 'ios'];

        var result = [];
        _.each(targets, function( item, key ) {
            if( !item.ignore && allowedTargets.indexOf(key) >= 0 ) {
                result.push(key);
            }
        });
        return result;
    }

    function openBackboneDialog( view ) {
        var dialog = Dialogs.showModalDialogUsingTemplate('<div class="modal relution-modal relution-modal-uploading"></div>');
        dialog.getElement().html(view.render().el);
        view.$el.find('.dialog-button.primary').focus();
        return dialog;
    }

    function openDialog() {
        RelutionProjectManager.getConfigFiles().then(function( configFiles ) {
            rlnFiles = configFiles;
            validateJson.getVersionInformation().then(function( versionInformation ) {
                var view = new UploadView();
                view.setVersionCode(versionInformation.versionCode);
                view.setVersionName(versionInformation.versionName);
                openBackboneDialog(view).done(function( buttonId ) {
                    if( buttonId === 'ok' ) {
                        if( view.binding.increaseVersion ) {
                            validateJson.updateAttributes({
                                versionCode: view.binding.versionCode,
                                versionName: view.binding.versionName
                            }).then(function() {
                                openBackboneDialog(new UploadingView(uploadSettings));
                            });
                        } else {
                            openBackboneDialog(new UploadingView(uploadSettings));
                        }
                    }
                });
            }).fail(function() {
                Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_ERROR, Strings.ERROR_DIALOG_TITLE, Strings.UPLOAD_MISSIGN_RLN_FILE);
            });
        });
    }

    function showErrorDialog( message ) {
        if( !message ) {
            message = Strings.ERROR_GENERAL;
        }
        Dialogs.cancelModalDialogIfOpen('relution-modal-uploading');
        Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_ERROR, Strings.ERROR_DIALOG_TITLE, message);
    }

    function showSuccessDialog( appId ) {

        var previewLink = PreferencesManager.get('upload-settings').server + 'relution/portal/#/apps/' + appId + '/information';

        var context = {
            BracketsStrings: BracketsStrings,
            Strings: Strings,
            PREVIEW_LINK: previewLink
        };
        Dialogs.cancelModalDialogIfOpen('relution-modal-uploading');

        var dialog = Dialogs.showModalDialogUsingTemplate(Mustache.render(templateUploaded, context));


    }

    // For unittests only
    exports.getActiveTargets = getActiveTargets;


    exports.openDialog = openDialog;

});
