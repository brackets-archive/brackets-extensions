define(function( require, exports, module ) {
    "use strict";

    var Inspector = brackets.getModule("LiveDevelopment/Inspector/Inspector");

    var Strings = require("strings");
    var node = require("node/nodeBridge");
    var viewTemplate = require("text!weinre/html/weinre.html");
    var EditorPanel = require('weinre/panel');
    EditorPanel.unfocus();
    var FileUtils = brackets.getModule('file/FileUtils');
    var moduleDirectoryPath = FileUtils.getNativeModuleDirectoryPath(module);

    // the maintoolbar from brackets
    var $mainToolbar = $('#main-toolbar .buttons');
    // the maintoolbar button markup
    var mainToolbarButtonBarMarkup = '<a id="mcap-toggle-weinre" title="' + Strings.TOGGLE_WEINRE_DEBUGGER + '" href="#"><i class="fa fa-bug"></i></a>';
    // DOM Cache for the maintoolbar button
    var $togglePanelButton = null;

    var weinreServer = null;
    var weinreClient = null;

    // Toggle indicator
    var visible = false;

    var WEINRE_PANEL_ID = 'weinre-panel-id';

    /**
     * Init the panel. Register the menu and their events.
     * @private
     */
    function _initialize( options ) {
        if(!options){
            return;
        }
        _registerMenuEntry();
        weinreServer = 'http://' + options.ip + ':8087/client/#anonymous';
        // http://localhost:8081/target/target-script-min.js#anonymous
        weinreClient = 'http://' + options.ip + ':8087/target/target-script-min.js#anonymous';
        $(EditorPanel).on('close', function( ev, id ) {
            if( WEINRE_PANEL_ID === id ) {
                _onClose();
            }
        });
    }

    /**
     * Register the panel in the maintoolbar sidebar
     * @private
     */
    function _registerMenuEntry() {

        $mainToolbar.append(mainToolbarButtonBarMarkup);
        $togglePanelButton = $mainToolbar.find('#mcap-toggle-weinre');
        $togglePanelButton.on('click', function() {
            toggle();
        });
    }

    /**
     * Show the panel
     */
    function show() {

        // open the editor panel
        EditorPanel.display(WEINRE_PANEL_ID, Mustache.render(viewTemplate, {
            SERVER: weinreServer
            //        }), Strings.WEINRE_SCRIPT + ':', '<input class="full" value="\<script\>' + weinreClient + '\</script\>">');
        }), Strings.REMOTE_DEBUGGER);

        // get the iframe
        var $iframe = $('#relution-panel iframe');
        // if weinre isn't started the $iframe.load is called multiple times
        var firstLoad = 0;
        // when it's load
        $iframe.load(function() {
            // if its the first time
            if(firstLoad === 0){
                firstLoad += 1;
                // add the css
                _injectCss($iframe);
            } else if(firstLoad === 1){
                // if there was an error starting weinre
                firstLoad += 1;
                // start it again
                node.startWeinre().then(function(){
                    // reload the window
                    $iframe[0].contentWindow.location.reload(true);
                    // add add againg the css
                    $iframe.load(function() {
                        _injectCss($iframe);
                    });
                });
            }
        });

        // call the "callback"
        _onOpen();
    }

    function _injectCss($iframe){
        var $head = $iframe.contents().find("head");
        $head.append($('<link/>', { rel: 'stylesheet', href: 'file://' + moduleDirectoryPath + '/css/weinre.css', type: 'text/css' }));
    }

    /**
     * Hide the panel
     */
    function hide() {
        EditorPanel.hide();
        _onClose();
    }

    /**
     * Callback when the panel gets closed
     * @private
     */
    function _onClose() {
        $togglePanelButton.removeClass('active');
        visible = false;
    }

    /**
     * Callback when the panel gets closed. This can be with several buttons like the 'x' button in the panel or the menu button on the brackets maintoolbar sidebar
     * @private
     */
    function _onOpen() {
        $togglePanelButton.addClass('active');
        visible = true;
    }

    /**
     * Toggle the visibility of the panel
     */
    function toggle() {
        if( visible ) {
            hide();
        } else {
            show();
        }
    }

    /**
     * run
     */
    function run() {
        return node.startWeinre().then(function( data ) {
            _initialize(data);
        }).fail(function(){
            _initialize();
        });
    }

    function _onConnect() {
        // Insert weinre script here. You can't insert it from the local fs. it needs to be loaded from the weinre server!
        //TODO
        //        Inspector.Page.addScriptToEvaluateOnLoad().always(function(){
        //            console.log(arguments);
        //        });
    }

    function getClientUrl() {
        return weinreClient;
    }

    function setClientUrl( url ) {
        return weinreClient = url;
    }

    $(Inspector).one("connect", _onConnect);

    exports.run = run;
    exports.hide = hide;
    exports.show = show;
    exports.toggle = toggle;
    exports.getClientUrl = getClientUrl;
    exports.setClientUrl = setClientUrl;

});