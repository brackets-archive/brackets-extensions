define(function( require, exports ) {

    var WorkspaceManager = brackets.getModule("view/WorkspaceManager");
    var PanelMarkup = require("text!weinre/html/panel.html");
    var Strings = require("../strings");

    var $panel = $(Mustache.render(PanelMarkup, Strings));
    var bottomPanel = WorkspaceManager.createBottomPanel("mcap.editors.panel", $panel);

    var $panelContent = null;
    var $menubar = null;

    var panelId = null;

    $panel.on("click", ".close", function() {
        _hide();
        $(exports).trigger('close', panelId);
    });

    function setHeadline( text ) {
        text = text || '';
        $panel.find('.status').html(text);
        return this;
    }

    function show( text ) {
        bottomPanel.show();
        $panelContent = $panel.find('.container');
        $menubar = $panel.find('.menubar');
        return this;
    }

    function _hide() {
        hide();
        return this;
    }

    function hide() {
        bottomPanel.hide();
        return this;
    }

    function toggle( settings ) {
        if( bottomPanel.isVisible() ) {
            hide();
            if( settings && typeof settings.on === 'function' ) {
                settings.on();
            }
        } else {
            show();
            if( settings && typeof settings.off === 'function' ) {
                settings.off();
            }

        }
        return this;
    }


    /**
     * It is possible to set an identifier as first parameter. This identifier is send with every trigger command.
     * If the first parameter is a DOM node no identifier is set and every argument will shift one to the left.
     * @param id - Id that will be send on every event trigger
     * @param content - the content to be displayed
     * @param text - the header text
     * @param menubar - the menu bar view
     * @returns {display}
     */
    function display( id, content, text, menubar) {
        var _content, _text, _menubar = null;
        if(typeof id === 'object' && id.hasOwnProperty('nodeType')){
            panelId = null;
            _content = id;
            _text = content;
            _menubar = text;
        } else {
            panelId = id;
            _content = content;
            _text = text;
            _menubar = menubar;
        }
        show();
        setHeadline(_text || '');
        $panelContent.html(_content);
        $menubar.html(_menubar || '');
        return this;
    };

    function unfocus() {
        $panel.removeClass('no-focus');
        return this;
    };

    exports.show = show;
    exports.setHeadline = setHeadline;
    exports.hide = hide;
    exports.display = display;
    exports.toggle = toggle;
    exports.unfocus = unfocus;

});
