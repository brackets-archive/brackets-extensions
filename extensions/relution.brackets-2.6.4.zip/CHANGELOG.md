#Changelog

## 2.6.4 - 2014-11-04
- Fix typos

## 2.6.3 - 2014-11-03
- Replace deprecated API with supported API

## 2.6.2 - 2014-10-27
- Handle error when user role doesn't match

## 2.6.1 - 2014-09-08
- Validate if cordova.js and ng-cordova is already insde mainPage

## 2.6.0 - 2014-09-08
- add ng-cordova.js script to mainPage on upload

## 2.5.0 - 2014-07-25
- Several bugfixes
- Improved performance
- Tested for Brackets Sprint 42
- Usability improvements
- Enhanced dependency-management

## 1.1.0 - 2014-05-12
- Add weinre as dev tool
- Inject a debug script tag if its a development version.
- Hide intro after shown on next start
- Add Android support for app.rln

## 1.0.0 - 2014-05-09
- First stable release
- Android support
- Add Brackets Intro
- Performance improvements

## 0.3.0 - 2014-04-11
- Create a app.rln file
    - seconary click on the sidebar -> select create app.rln
    - Is only available if no app.rln is in the same or a parent folder

## 0.2.0 - 2014-04-11
- Add app.rln Cordova support for Relution 2.5 and Cordova 3.4.0

## 0.2.0 - 2014-04-11
- Add app.rln Cordova support for Relution 2.5 and Cordova 3.4.0

## 0.1.1 - 2014-04-01
- Root of the relution project is defined by the app.rln config file

## 0.1.1 - 2014-03-17
- Ignore disabled targes from app.rln

## 0.1.0 - 2014-03-17
- Implement "New WebApp" dialog
- Implement settings dialog with "Test connection" option
- Implement upload dialog with options for archivation and release state
