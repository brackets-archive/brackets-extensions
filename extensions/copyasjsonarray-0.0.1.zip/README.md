# copyAsJsonArray

A brackets plugin to enable developers to copy the multiple selection as escaped json array elements.

![](https://i.imgur.com/BphBIE6.gif)

## How to Install

 - Open brackets and go to File -> Extension Manager
 - Search for `CopyAsJsonArray` in the search box.
 - Select install button on the right

## Usage

### Using pointer,

 - Select multiple words or lines in editor
 - Press `Ctrl-Shift-C`
 - Paste it anywhere!
