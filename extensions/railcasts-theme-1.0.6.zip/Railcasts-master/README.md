![Brackets Themes Logo](https://github.com/brackets-themes/railcasts/raw/master/bracket-themes-icon-100x99.png) Railcasts Theme for Brackets
=========

Dark theme for Brackets

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)

![railcasts php](https://github.com/brackets-themes/railcasts/raw/master/railcasts_php.PNG)
![railcasts js](https://github.com/brackets-themes/railcasts/raw/master/railcasts_js.PNG)
