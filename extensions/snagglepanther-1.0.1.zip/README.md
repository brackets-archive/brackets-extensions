Snagglepanther Theme for Brackets
=================================

Pink and minimal. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/Snagglepanther/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/Snagglepanther/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/Snagglepanther/blob/master/screenshots/js.png)
