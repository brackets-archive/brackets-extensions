/**
 * Empty file
 * Needed only to allow the theme to be uploaded in the extension registry
 */
