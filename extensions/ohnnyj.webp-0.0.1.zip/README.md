#Brackets WebP#

Adds webp as supported image format.