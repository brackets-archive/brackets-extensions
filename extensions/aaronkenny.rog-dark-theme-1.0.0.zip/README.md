ROG Dark Theme for Brackets
============================

Minimal theme for Brackets.

## HTML
![alt text](https://raw.githubusercontent.com/aaronmkenny7/ROG-Dark-Theme/master/screenshots/html.jpg "ROG Dark Theme HTML")
## CSS
![alt text](https://raw.githubusercontent.com/aaronmkenny7/ROG-Dark-Theme/master/screenshots/css.jpg "ROG Dark Theme CSS")
## JavaScript
![alt text](https://raw.githubusercontent.com/aaronmkenny7/ROG-Dark-Theme/master/screenshots/javascript.jpg "ROG Dark Theme JavaScript")