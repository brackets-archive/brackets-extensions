# Gherkin syntax highlighting

This is an extension to the code editor [Brackets][1], and adds syntax highlighting for Gherkin files with the extension `.feature`.

## Install from URL

1. Open the the Extension Manager from the File menu.
2. Search for `gherkin` and press install.

  [1]: http://brackets.io/ "Brackets — Open source code editor built with the web for the web"