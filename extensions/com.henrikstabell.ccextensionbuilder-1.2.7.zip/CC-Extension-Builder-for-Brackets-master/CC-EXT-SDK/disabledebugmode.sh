#!/bin/bash
/usr/libexec/PlistBuddy -c "Delete:PlayerDebugMode" ~/Library/Preferences/com.adobe.CSXS.7.plist
