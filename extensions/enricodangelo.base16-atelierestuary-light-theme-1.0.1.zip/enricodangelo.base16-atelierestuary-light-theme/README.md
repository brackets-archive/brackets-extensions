Base 16 Atelierestuary Light Theme for Brackets
============================

Attempting to be as close to [Atelierestuary Light](http://chriskempson.github.io/base16/#atelierestuary) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
