# Visual Studio Code Dark theme for Brackets
Based on Visual Studio Code Dark theme (as of May/5/2018).

Screenshot
![Visual Studio Code Dark theme](screenshot.png) 
