Mata theme for Brackets 
==========================

How to Install
==============
Go to Last Edit is an extension for [Brackets](https://github.com/adobe/brackets/), a new open-source code editor for the web.

To install extensions:

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for this extension
3. Click _Install_!

### HTML
![HTML Screenshot](https://github.com/tnthao10/Mata-theme-brackets/blob/master/screenshot/html.png)
![HTML Screenshot](https://github.com/tnthao10/Mata-theme-brackets/blob/master/screenshot/css.png)
![HTML Screenshot](https://github.com/tnthao10/Mata-theme-brackets/blob/master/screenshot/js.png)

 
### Compatibility
Brackets Sprint 16 or newer (or Adobe Edge Code Preview 2 or newer).

