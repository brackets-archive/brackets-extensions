Brackets Theme: Monokromatik-green
===

This theme is based on the monochrome color scheme found on old monitors from the 1960's-1980's.

Screenshots
---

### HTML
![HTML](screenshots/html.png)

### CSS
![HTML](screenshots/css.png)

### JavaScript
![HTML](screenshots/js.png)

Installation
---

This extension requires Brackets Release 1.0 or newer.

1. Open Brackets
2. Open the Extension Manager
3. Switch to "Themes" tab
4. Search for "Monokromatik-green"
5. Click "Install"

License
---

The MIT License. Read [LICENSE](LICENSE) for further information.