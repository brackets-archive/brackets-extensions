Brackets cut line
===========================================

version 0.2
- fixes for mac key bindings
- using proper pasting mechanism in Windows

This extension adds the ability to ctrl/cmd-X or ctrl/cmd-C
an empty selection. Thus; cutting/copying the whole line.
This is similar behaviour to Visual Studio.