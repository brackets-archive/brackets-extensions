# Voductivity _<sub>for Brackets</sub>_
This extension allows you to use videos and images as a background for the Brackets code editor.

![Watch videos while you code](https://github.com/web-hype/wh-assets/raw/master/voductivity-brackets-demo-clip-2x.gif "Watch \"Tears of Steel\" while you code")
*Watch [Tears of Steel](https://en.wikipedia.org/wiki/Tears_of_Steel) while you code*
