# 0.1.0
 * Filter .meteor directory (avoid error message from brackets).
 * Add run and debug command.
 * Support custom argument for meteor.
 * Allow to set the path of meteor in the configuration.
