# Finess

## Info
###### Artline__ (Me)

[Website](http://www.officialartline.com/)
[Twitter](https://twitter.com/Artline__)

===

[Atom version](https://github.com/OfficialArtline/atom-finess-syntax)

## Installation

## Screenshots
#### HTML
![alt text](https://raw.githubusercontent.com/OfficialArtline/brackets-finess/master/git_img/html.png)
#### CSS
![alt text](https://raw.githubusercontent.com/OfficialArtline/brackets-finess/master/git_img/css.png)
#### JS
![alt text](https://raw.githubusercontent.com/OfficialArtline/brackets-finess/master/git_img/js.png)
