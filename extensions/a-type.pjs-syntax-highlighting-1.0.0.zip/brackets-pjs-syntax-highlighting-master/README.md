brackets-pjs-syntax-highlighting
================================

An extremely simple plugin to highlight all .pjs files as JavaScript syntax
