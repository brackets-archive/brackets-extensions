// McPherran software is acknowledged.

/*jslint maxerr: 10, indent: 2 */
/*global define, brackets */

define(function(require, exports, module)
{
   var cm = brackets.getModule("thirdparty/CodeMirror/lib/codemirror");

   cm.defineSimpleMode
   ("cmd",
      {
         start:
         [
            // { regex: /S/, token: "meta", sol: true, push: "StateTest" },

            // Comments
            { regex: /Rem.*/, token: "comment", sol: true },

            // Directives
            { regex: /(@Echo)(\s)(On|Off)/, token: ["meta", null, "attribute"], sol: true },

            // Labels
            { regex: /:\w+/, token: "tag", sol: true },
            { regex: /:\w+/, token: "tag", sol: true },

            // Catch invalid cases of keywords followed by only whitespace.
            { regex: /(If|If not|Else|Goto|Call|Set|Echo)\s*$/i, token: "error" },

            // Catch invalid cases of keywords followed by no whitespace.
            { regex: /(If|If not|Else|Goto|Call|Set)[^ ].*$/i, token: "error" },

            // Catch Echo keyword followed by neither whitespace nor dot.
            { regex: /Echo[^ \.].*$/i, token: "error" },

            // Catch invalid cases of keywords followed by two or more whitespaces.
            { regex: /(If|If not|Else|Goto|Call|Set|Echo.?|Exit)\s{2,}.*$/i, token: "error" },

            { regex: /(If|If not)( )([\?\|\(\)].*)?(==|EQU|NEQ|LSS|LEQ|GTR|GEQ).*$/i, token: ["error", null, "error", "error"] },
            { regex: /(If|If not)( )/i, token: ["keyword", null] },

            { regex: /\s{2,}Else.*$/i, token: "error" },
            { regex: /[^ ]Else.*$/i, token: "error" },
            { regex: /Else /i, token: "keyword" },

            // Goto
            { regex: /(Goto )(:EOF)$/i, token: ["keyword", "tag"], pop: true },
            { regex: /(Goto )(\w+)$/i, token: ["keyword", "tag"], pop: true },

            // Call
            { regex: /(Call )(:\w+\s*$)/i, token: ["keyword", "tag"] },
            { regex: /(Call )(:\w+)/i, token: ["keyword", "tag"] },
            { regex: /(Call )(:.*$)/i, token: ["keyword", "error"] },
            { regex: /Call /i, token: "keyword", push: "Filepath" },
            // { regex: /(Call )(\w+\.cmd)/i, token: ["keyword", "tag"] },

            { regex: /Exit$/, token: "keyword", sol: true },
            { regex: /(Exit )(\/b)$/, token: ["keyword", "attribute"], sol: true },
            { regex: /(Exit )(\/b )?(\d|%~?\d|%[A-Za-z]\w*%)$/, token: ["keyword", "attribute", "variable"], sol: true },

            // Invalid as data for Set: ?|<>
            { regex: /(Set )(\w+)(=\s*)$/i, token: ["keyword", "variable", "operator"] },
            // { regex: /(Set )(\w+)(=)(.*[\?\|<>].*)$/i, token: ["keyword", "variable", "operator", "error"] },
            { regex: /(Set )(\w+)(=)(")/i, token: ["keyword", "variable", "operator", "string"], push: "QuotedString" },
            { regex: /(Set )(\w+)(=)/i, token: ["keyword", "variable", "operator"], push: "String" },
            { regex: /(Set \/a )(\w+)(=)/i, token: ["keyword", "variable", "operator"] }, // push: "NumericExpression" },

            // Echo
            { regex: /Echo\.$/i, token: "keyword" }, // Echo\.\s*\)
            { regex: /Echo\. [^>].*$/i, token: "error" },
            { regex: /Echo\. $/i, token: "error" },
            { regex: /Echo\. /i, token: "keyword" },
            { regex: /Echo\s*>.*$/i, token: "error" },
            { regex: /Echo /i, token: "keyword", push: "String" },

            // { regex: /[^"%=]+$/, token: "string", pop: true },
            // { regex: /[^"%=]+/, token: "string" },

            { regex: /"[^"]*$/, token: "error", pop: true },
            { regex: /"[^%"]*"/, token: "string" },
            { regex: /"/, token: "string", push: "QuotedString" },

            { regex: /%(~?\d|[A-Za-z]\w*%)/, token: "variable" },

            { regex: /[A-Za-z]:\\?/, token: "link", push: "Path" },
            { regex: /[^\\\s\?\|<>:]*\\/, token: "link", push: "Path" },

            // { regex: /%/, token: "string" },

            // Redirection
            { regex: />>?\s{2,}.*$/i, token: "error" },
            { regex: />>? $/i, token: "error" },
            { regex: />>? /i, token: "operator", push: "Filepath" },

            // Punctuation
            { regex: /[\(\)]/, token: "punctuation" },

            // Operators
            { regex: /(==|EQU|NEQ|LSS|LEQ|GTR|GEQ)\s*$/i, token: "error" },
            { regex: /(==)([^\w"%].*)$/i, token: ["operator", "error"] },
            { regex: /(==)(\w+)/i, token: ["operator", "string"] },
            { regex: /EQU|NEQ|LSS|LEQ|GTR|GEQ/i, token: "operator" }

            // All other text on the line is error.
            // { regex: /.*$/, token: "error" }
         ],

         Path:
         [
            { regex: /[^\\\s%\?\|<>:]+$/, token: "link", pop: true },
            { regex: /[^\\\s%\?\|<>:]+/, token: "link" },

            { regex: /(%~?\d|%[A-Za-z]\w*%)$/, token: ["variable"], pop: true },
            { regex: /(%~?\d|%[A-Za-z]\w*%)/, token: ["variable"] },

            { regex: /%/, token: "link" },

            { regex: /[\?\|<>:]+/, token: "error", pop: true },
            { regex: /\s/, token: null, pop: true },
            { regex: /\\/, token: "link" },
            { pop: true }
         ],

         Filepath:
         [
            { regex: /([A-Za-z]:)$/, token: "error", pop: true },
            { regex: /([A-Za-z]:\s+.*)$/, token: "error", pop: true },

            { regex: /([A-Za-z]:)/, token: "link", next: "Filepath2" },
            { next: "Filepath2" }

            // All other text on the line is error.
            // { regex: /.*$/, token: "error", pop: true }
            // { pop: true }
         ],

         Filepath2:
         [
            // Disallowed in path: ?|%<>:"
            // Spaces not allowed immediately after \

            // { regex: /test$/, token: "link", pop: true },
            // { regex: /test/, token: "link" },

            { regex: /\\\s+.*$/, token: "error", pop: true },

            { regex: /\\?[^\s%\\\?\|<>:]+$/, token: "link", pop: true },
            { regex: /\\?[^\s%\\\?\|<>:]+/, token: "link" },

            { regex: /(\\?)(%~?\d|%[A-Za-z]\w*%)$/, token: ["link", "variable"], pop: true },
            { regex: /(\\?)(%~?\d|%[A-Za-z]\w*%)/, token: ["link", "variable"] },

            { regex: /\\?%/, token: "link" },

            // All other text on the line is error.
            { regex: /.*$/, token: "error", pop: true }
            // { pop: true }
         ],

         // Strings and variables
         // Quotes are not needed and are taken as literal part of string.
         String:
         [
            { regex: /[^%\(\)>]+$/, token: "string", pop: true },
            { regex: /[^%\(\)>]+/, token: "string" },

            { regex: /%(~?\d|[A-Za-z]\w*%)$/, token: "variable", pop: true },
            { regex: /%(~?\d|[A-Za-z]\w*%)/, token: "variable" },

            { regex: /%/, token: "string" },
            { regex: /%$/, token: "string", pop: true },

            { regex: /[\(\)]/, token: "punctuation", pop: true },

//            { regex: /.*[\?\|<].*$/, token: "error", pop: true },

            // Must be '>'
            { pop: true }

            // All other text on the line is error.
            // { regex: /.*$/, token: "error", pop: true }
         ],

         // Text and variables followed by a closing double-quote char.
         QuotedString:
         [
            { regex: /%(~?\d|[A-Za-z]\w*%)/, token: "variable" },
            { regex: /[^"]+/, token: "string" },
            { regex: /"/, token: "string", pop: true }
         ],

         // Numeric Expression:
         //    Consists of integers, variables, and operators.
         //    Spaces are not allowed between numerics and variables
         //    Operators are allowed only after a numeric and/or variable and
         //    operators cannot be at the end of the line.
         // NumericExpression:
         // [
         //    { regex: /[0-9]+$/, token: "number", pop: true },
         //    { regex: /([0-9]+)( [<>\*\/%\+\-&\^\|]\s+)$/, token: ["number", "error"], pop: true },
         //    { regex: /([0-9]+)( [<>\*\/%\+\-&\^\|] )/, token: ["number", "operator"] },
         //    { regex: /[0-9]+/, token: "number" },

         //    { regex: /(%~?\d|%[A-Za-z]\w*%)$/, token: "variable", pop: true },
         //    { regex: /(%~?\d|%[A-Za-z]\w*%)( [<>\*\/%\+\-&\^\|]\s+)$/, token: ["variable", "error"], pop: true },
         //    { regex: /(%~?\d|%[A-Za-z]\w*%)( [<>\*\/%\+\-&\^\|] )/, token: ["variable", "operator"] },
         //    { regex: /(%~?\d|%[A-Za-z]\w*%)/, token: "variable" },

         //    { regex: /.+$/, token: "error", pop: true }
         // ],

         StateTest:
         [
            { regex: /x+/, token: "tag" },
            { regex: /y+/, token: "meta" },
            { pop: true }

            // A rule that consists of only a "pop" will run if the current line
            // has unprocessed text.
            // E.g. In a state that contains only the two following rules, the
            // pop will not run because all line text is consumed by the .*
            // { regex: /.*/, token: "error" },
            // { pop: true }
         ]

         // meta: { lineComment: "#" }
      }
   );
});
