// McPherran software is acknowledged.

/*jslint maxerr: 10, indent: 2 */
/*global define, brackets */

// defineLanguage(), define[Simple]Mode(): First arg, i.e. id/name, must be
// lowercase.

define(function(require, exports, module)
{
  require("cmdMode");

  var lm = brackets.getModule("language/LanguageManager");

  lm.defineLanguage("cmd", {
    name: "Cmd",
    mode: "cmd",
    fileExtensions: ["cmd", "bat"]
  });

});
