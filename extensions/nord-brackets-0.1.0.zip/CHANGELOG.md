<p align="center"><img src="https://cdn.rawgit.com/arcticicestudio/nord-brackets/develop/assets/nord-brackets-banner.svg"/></p>

<p align="center"><img src="https://assets-cdn.github.com/favicon.ico" width=24 height=24/> <a href="https://github.com/arcticicestudio/nord-brackets/releases/latest"><img src="https://img.shields.io/github/release/arcticicestudio/nord-brackets.svg"/></a> <a href="https://github.com/arcticicestudio/nord/releases/tag/v0.2.0"><img src="https://img.shields.io/badge/Nord-v0.2.0-88C0D0.svg"/></a></p>

---

# 0.1.0
*2017-04-15*
**Initial Brackets Extension Registry release version!**

## Features
Detailed information about features, languages, supported extensions and install instructions can be found in the [README](https://github.com/arcticicestudio/nord-brackets/blob/develop/README.md#installation) and in the [project wiki](https://github.com/arcticicestudio/nord-brackets/wiki).

❯ Initial LESSCSS theme implementation (@arcticicestudio, #1, 6db3243a)

<p align="center"><img src="https://raw.githubusercontent.com/arcticicestudio/nord-brackets/develop/assets/scrot-top.png"/></p>

# 0.0.0
*2017-04-15*
**Project Initialization**
