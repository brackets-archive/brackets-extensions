define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("toml", {"name":"toml","mode":"toml","fileExtensions":["toml"]});
});