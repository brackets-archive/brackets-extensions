define({
    ZIP_TITLE: "Comprimi in \u2026",
    UNZIP_TITLE: "Estrai in \u2026",
    FILE_EXISTING: "<code>{0}</code> è già presente: verrà sovrascritto. Vuoi proseguire?",
    NOT_EMPTY: "<code>{0}</code> non è vuota: alcuni file potrebbero essere sovrascritti. Vuoi proseguire?",
    CMD_ZIP: "Comprimi",
    CMD_UNZIP: "Decomprimi"
});