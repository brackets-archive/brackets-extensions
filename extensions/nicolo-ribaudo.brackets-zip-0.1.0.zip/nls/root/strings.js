define({
    ZIP_TITLE: "Compress to \u2026",
    UNZIP_TITLE: "Extract to \u2026",
    FILE_EXISTING: "<code>{0}</code> already exists: it will be overwritten. Do you want to continue?",
    NOT_EMPTY: "<code>{0}</code> isn't empty: some files may be overwritten. Do you want to continue?",
    CMD_ZIP: "Compress",
    CMD_UNZIP: "Uncompress"
});