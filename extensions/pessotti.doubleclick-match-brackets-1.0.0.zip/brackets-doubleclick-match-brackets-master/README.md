# brackets-doubleclick-match-brackets

Brackets extension to select the block inside matching brackets by double clicking a bracket