# base-16-ocean-dark-brackets
A theme for brackets.io editor based on base-16 ocean dark with a couple extra tweaks.

Preview :

![Theme Preview](https://raw.githubusercontent.com/Yantrio/base-16-ocean-dark-brackets/master/Preview.png)
