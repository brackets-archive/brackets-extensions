Neon Minimap Brackets Extension - 1.0.1
=========

## NOTICE: This extension is no longer going to be updated. If the Neon theme updates you'll have to update the theme file manually. Also, this extension can really use any Brackets theme file, not just Neon's, so feel free to re-upload this extension with your own theme.

Screenshots are from Neon version 1.1.4

## MiniMap
![MiniMap](https://github.com/dustindowell22/neon-minimap-brackets-extension/blob/master/preview/minimap.png)

## Themed Extensions
+ [MiniMap by zorgzerg](https://github.com/zorgzerg/brackets-minimap)
