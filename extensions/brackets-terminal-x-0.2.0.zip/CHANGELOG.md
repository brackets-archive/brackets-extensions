## v0.2.0 (2017-03-11)

Add ability to pass arguments upon terminal creation (untested).

Add translation support.

Upgrade deps.

### Breaking changes

Renamed preferences.


## v0.1.0 (2017-02-25)

Add a terminal integrated in Brackets editor.
