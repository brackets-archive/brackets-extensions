define(function (require, exports, module) {
    "use strict";

    module.exports = require("i18n!src/nls/strings");
});
