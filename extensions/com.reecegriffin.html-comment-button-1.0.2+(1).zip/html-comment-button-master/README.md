This is an extension for the Brackets editor that is sponsored by Adobe.  Inspired by Dreamweaver's code editor, this extension provides a button that allows you to add/remove a HTML comment to/from the currently selected text without touching your keyboard (e.g. just using your mouse).. 

This can be helpful when you're just performing minor tweaks to your code & you're too lazy to move your hand from the mouse to the keyboard and back.
