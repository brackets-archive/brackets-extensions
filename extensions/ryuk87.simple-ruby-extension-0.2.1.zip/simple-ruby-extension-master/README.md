Simple Ruby Extension
=====================

A simple Brackets extension that adds:
* comments to Ruby files, 
* syntax highlight for specific Rails files (Gemfile, Rakefile, Guardfile),
* html highlight for ERB and HAML files

