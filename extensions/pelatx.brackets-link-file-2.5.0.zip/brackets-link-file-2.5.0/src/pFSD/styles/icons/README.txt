Icons from http://ionicons.com/
