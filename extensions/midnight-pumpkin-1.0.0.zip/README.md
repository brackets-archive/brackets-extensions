Midnight Pumpkin Theme for Brackets
===================================

Dark theme. Black, white, orange and yellow. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/MidnightPumpkin/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/MidnightPumpkin/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/MidnightPumpkin/blob/master/screenshots/js.png)
