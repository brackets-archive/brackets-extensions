define(function(require, exports, module){
    var ExtensionUtils = brackets.getModule('utils/ExtensionUtils');

    ExtensionUtils.loadStyleSheet(module, './main.css');

    require('./online').init();
});
