Bigger Extensions Panel
=======================

*An extension for Brackets IDE*

![example](https://raw.githubusercontent.com/dnbard/brackets-bigger-extensions/master/screenshots/2014-09-17_1017.png)