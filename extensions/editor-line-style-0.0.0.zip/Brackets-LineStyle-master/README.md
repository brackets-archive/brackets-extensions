# Brackets-LineStyle
Editor line Style


Simply add to your `brackets.json` the size of the line height you want.

### Example

```
{
  "brackets-line-style.height": "1.25"
}
```

The value you specify will be used as is so that you can use percentages, ems... Or whatever you want.  However, using unitless ems based values seem to work best.
