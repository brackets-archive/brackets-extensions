brackets-wordhint
=================

Hint with words in current document. Add autocomplete for PHP, Python, Perl etc.
Also a good example for CodeHintManager. 

Next Step: order autocomplete results by distance to cursor.