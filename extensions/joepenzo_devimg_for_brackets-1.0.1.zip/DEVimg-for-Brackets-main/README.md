DEVimg for Brackets
===================

DEVimg for Brackets provides an easy way to add placeholder images to your project. It adds a DEVimg.com icon to Brackets and a option in the Edit menu inside Brackets. This allows you to place an img html element or just a url to the image into the editor at the place where your cursor is.

Currently the extension doesn't support the themes that DEVimg has to offer. But ofcourse you can always add those yourself and the end of the url, see http://devimg.com for more information about this.


Credits: http://devimg.com