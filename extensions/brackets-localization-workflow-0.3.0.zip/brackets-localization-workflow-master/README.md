brackets-localization-workflow
==============================

A Brackets extension for a better localization workflow

![Screenshot](assets/screenshot.png)
