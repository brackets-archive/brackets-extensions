Rhode Island Red Theme for Brackets
===============================

Silky, dark, maroon based theme to give your code a touch of class. Brackets original.

## HTML
![HTML Screenshot](https://raw.githubusercontent.com/SteveMcArthur/rhode-island-red-theme/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://raw.githubusercontent.com/SteveMcArthur/rhode-island-red-theme/master/screenshots/css.png)

## JS
![JS Screenshot](https://raw.githubusercontent.com/SteveMcArthur/rhode-island-red-theme/master/screenshots/js.png)
