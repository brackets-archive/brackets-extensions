
Brackets Cirru Package
------

Syntax highlight for Cirru in Brackets.

Forked from https://github.com/Cirru/cirru-mode


### License

MIT