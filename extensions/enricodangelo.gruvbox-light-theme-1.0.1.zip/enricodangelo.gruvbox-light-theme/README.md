Gruvbox Light Theme for Brackets
============================

Attempting to be as close to [Gruvbox](https://github.com/morhetz/gruvbox) light mode as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Pavel Pertsev](https://github.com/morhetz).
