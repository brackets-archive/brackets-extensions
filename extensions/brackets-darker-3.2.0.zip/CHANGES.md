# Changelog

## 3.2.0

 * Prefer Fira Sans as interface fonts
 * Prefer Fira Mono as editor fonts
 * Fix editor holder background

## 3.1.1

 * Fix dark ui issues

## 3.1.0

 * Adapted to dark ui changes in brackets 0.43

## 3.0.0

* Complete rewrite of base16 themes
* Uses brackets theme manager introduced in 0.42

## 2.x.x

* Added more themes
* Added menu to select themes

## 1.x.x

* Initial release
* Uses base16-default codemirror theme
