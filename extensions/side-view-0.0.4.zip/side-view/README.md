# side-view
Brackets extension that replaces the scrollbar with a code preview similar to the one found in Sublime Text.

![alt tag](https://raw.githubusercontent.com/Fraser-Greenlee/side-view/master/sample.png)
