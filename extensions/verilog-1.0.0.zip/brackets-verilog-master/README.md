# Verilog Syntax Highlighting for Brackets

This plugin provides syntax highlight for verilog via a CodeMirror mode for Brackets.

## Installation

1. Open the the Extension Manager from the Brackets File menu
2. In the search bar, type verilog
3. Press the Install button next to Verilog Syntax Highlighting
4. OR Copy and paste the URL of the github repo or zip file