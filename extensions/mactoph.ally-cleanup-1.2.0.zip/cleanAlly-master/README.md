Clean Ally HTML
===
Brackets extension that replaces certain tags (&lt;figure&gt;, &lt;style&gt;) to cleanup the HTML produced from the Blackboard Ally tool
  
Usage
===
Open an HTML file produced from Blackboard Ally

Click File > Clean Ally

Known Issues
===

None 
