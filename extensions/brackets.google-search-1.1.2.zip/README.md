Serach Google, Wikipedia, Youtube, and Stackoverflow From Brackets 
================

This extension adds the ability to search highlighted keywords from brackets in Google, Wikipedia, Youtube, and Stackoverflow.

--
Install
-------
It is available via the Brackets Extension Registry. Click on the Extension Manager Icon in Brackets and search for Brackets Google Search.

Using
------
Simply, highlight text, right click and select Google it, Wikipedia it, Youtube it, or Stackoverflow it.  

Releases
--------
June 5, 2015: 1.1.0 Release