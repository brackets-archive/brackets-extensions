/*
System Strings
 */
define(function (require, exports, module) {
    'use strict';
    return {
        RIGHT_CLICK_SEARCH_TITLE_GOOGLE: "Google",
        RIGHT_CLICK_SEARCH_TITLE_WIKI: "Wikipedia",
        RIGHT_CLICK_SEARCH_TITLE_YOUTUBE: "YouTube",
        RIGHT_CLICK_SEARCH_TITLE_STACKOVERFLOW: "Stackoverflow",

    }
});