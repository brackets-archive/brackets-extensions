# brackets-ooc

ooc language support for the [Brackets editor](http://brackets.io/) (.moon files).

## Installation

Search for 'ooc syntax' in Brackets' Extension Manager, hit Install, you're done.

## Authors

  * Amos Wenger aka [@nddrylliog](https://github.com/nddrylliog)

## Links

  * [ooc language](http://ooc-lang.org/)
  * [Brackets text editor](http://brackets.io)

## License

MIT

