### Touch Me
This extension has been created to fix some issues and improve overall experience of using Brakets on the touchscreen devices.

### Installation
You may download and install this extension in many ways following the instructions from the 
[Brackets Wiki page](https://github.com/adobe/brackets/wiki/Brackets-Extensions)

### Did it help you?
If **yes** and you feel like throwing money at the screen [![Donate! :3](https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=C7QYVKM5NJEVC)