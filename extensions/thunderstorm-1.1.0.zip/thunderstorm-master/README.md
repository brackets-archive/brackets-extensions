Thunderstorm
=====================
A dark theme for Brackets based off [Zamiere Dark](https://github.com/Brackets-Themes/Zamiere)


Screenshots
======

### HTML
![HTML](screenshots/html.png)

### CSS
![HTML](screenshots/css.png)

### JavaScript
![HTML](screenshots/js.png)