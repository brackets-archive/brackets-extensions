# "Line Breaks" Tests

Note:  
In any case, a _'soft'_ line break is ok (_'flowing'_ text within a width-limited container is not a breach).  
Hence, only _'hard'_ line breaks e.g. `<br />` are considered here.

## Markdown text with simple line breaks

**TEST: the preview should never break the text when `adaptive width` is ON.**

**TEST: the preview should break the text when `adaptive width` is OFF and `GFM` is ON.**

**TEST: the preview should NOT break the text when `adaptive width` is OFF and `GFM` is OFF.**

Ex varias cillum nam doctrina, nam quem voluptate. Qui sunt familiaritatem. Eu 
aut multos enim quis, qui summis e varias est iudicem malis varias do fugiat, 
quo id illum incurreret e velit do eu quem ingeniis, a eu distinguantur ea 
ingeniis ex summis, sed de distinguantur. Expetendis si esse deserunt, ubi sint.

## Markdown text without line breaks

**TEST: the preview should never break the text**

Ex varias cillum nam doctrina, nam quem voluptate. Qui sunt familiaritatem. Eu aut multos enim quis, qui summis e varias est iudicem malis varias do fugiat, quo id illum incurreret e velit do eu quem ingeniis, a eu distinguantur ea ingeniis ex summis, sed de distinguantur. Expetendis si esse deserunt, ubi sint.

## Markdown text with "double space" line breaks

**TEST: the preview should always break the text when a line is terminated by a double space, regardless of the `adaptive width` and `GFM` settings.**

Ex varias cillum nam doctrina, nam quem voluptate. Qui sunt familiaritatem. Eu  
aut multos enim quis, qui summis e varias est iudicem malis varias do fugiat,  
quo id illum incurreret e velit do eu quem ingeniis, a eu distinguantur ea  
ingeniis ex summis, sed de distinguantur. Expetendis si esse deserunt, ubi sint.
