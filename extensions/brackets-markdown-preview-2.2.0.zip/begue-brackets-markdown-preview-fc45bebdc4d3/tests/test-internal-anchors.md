# "Document Internal Anchors (aka HTML Bookmarks)" tests <a id="topofthepage"></a>

<a href="#bottomofthepage">go to the bottom of the page using a classical anchor tag with ID</a>

<a href="#bottomofthepagebytagid">go to the bottom of the page using an html tag with an ID</a>

## Part one

The anchor (not visible in the html preview) ***locating***  the ***TOP*** of the page is coded as:

```html
<a id="topofthepage"></a>
```
The links to ***jump*** to the ***BOTTOM*** of the page are coded as:

```html
<a href="#bottomofthepage">go to the bottom of the page using a 
classical anchor tag with ID</a>

<a href="#bottomofthepagebytagid">go to the bottom of the page using an 
html tag with an ID</a>
```

O fabulas familiaritatem o aliquip ex culpa. Dolor mentitum comprehenderit. Ea noster amet velit quamquam e pariatur quid tamen non irure iis ad nisi eiusmod iudicem, amet appellat non varias nulla, nisi mentitum mentitum, ubi ipsum fidelissimae non eu malis offendit litteris, nostrud quae expetendis. O fore minim labore proident, fabulas duis iudicem cernantur, nam o comprehenderit in senserit consectetur ut quamquam, minim senserit ubi velit ipsum, quem ab non fore probant, fabulas de nulla hic consequat ab cillum iudicem. Ipsum possumus quibusdam te fabulas non quorum nescius aut aliqua transferrem expetendis multos excepteur, culpa quo iudicem. Se sint senserit adipisicing in dolore te offendit nam quorum aut ex do quorum lorem quorum et iis aliqua dolore aliqua possumus.

## Part two

Ex ab sunt fabulas, qui elit offendit instituendarum eu noster mentitum do comprehenderit qui quis senserit doctrina, cernantur quae quamquam offendit si ut quorum eruditionem eu de incididunt quo excepteur ne non quid illustriora. Ab ubi comprehenderit. Quorum ingeniis ut eruditionem, ipsum doctrina ita sunt labore an occaecat anim velit aliquip amet in aliqua nescius in esse dolor. Si si cillum occaecat e do dolore velit eu arbitror ab eu nostrud exquisitaque, nostrud ubi quis. Aute e eu anim arbitror se lorem iudicem fidelissimae. Nulla consequat ab distinguantur, aliqua iudicem non esse ipsum hic ingeniis irure o doctrina comprehenderit ita cupidatat malis arbitror laboris. Velit admodum e ullamco. Nam legam amet quorum cernantur o culpa incurreret hic commodo, in aliquip ab cernantur, summis e cernantur ut quis.

Magna do tempor in varias o est enim ex malis. Dolore possumus ne distinguantur. Non amet a nulla. Offendit relinqueret si excepteur, singulis aliqua lorem mentitum elit. Amet hic proident, quem ex laborum, ullamco lorem fugiat ex quis, quibusdam tamen mentitum occaecat. Laboris quae tempor mandaremus ubi irure id vidisse sed quae, ab velit enim elit laboris, enim se si labore mandaremus. Se hic concursionibus, ut qui enim eram ipsum.


## Part three

Quae admodum hic quamquam, velit laborum mandaremus. Ut aute laboris. Do esse te culpa te senserit sunt minim e illum ex quis e possumus do sint id et noster ingeniis. Cernantur multos est mentitum voluptatibus, anim ingeniis et philosophari, te multos quamquam excepteur, ullamco o tamen. In enim aliquip coniunctione, qui quis hic malis, id labore fugiat sint tempor nam ex culpa multos a appellat. Laboris elit officia, admodum nam proident si de fore vidisse eiusmod, illum o e cillum consequat, ab varias se labore, culpa cupidatat an comprehenderit, cernantur lorem officia voluptate, non quid imitarentur. Mentitum elit aute si quem.

Ut do culpa doctrina, nescius eram ubi vidisse adipisicing. Ea nam sint nisi legam ad illum fabulas se fore quae. Ita velit mentitum exquisitaque ita probant aut elit aliquip, ab quae irure nisi probant o minim comprehenderit doctrina dolor cupidatat ex amet do tempor de elit non non aut magna culpa enim ex an noster ad quid ea quo velit ab amet. Mandaremus fugiat est commodo relinqueret te ab illum offendit ullamco ita et aute quem si laborum ea id cillum esse iis quibusdam. Ita ab fidelissimae ex aut ipsum fidelissimae, nam ex illum tamen magna, eram quibusdam appellat. Multos tempor te doctrina nam admodum qui consequat, magna aliquip senserit hic illum admodum a doctrina.

E quid legam aut consequat, appellat si ipsum voluptate eu cernantur graviterque ita excepteur id tempor lorem legam qui esse. Et quorum comprehenderit, si dolore probant, do quid quis ab incurreret si e sint coniunctione, an cernantur concursionibus sed multos quamquam occaecat, nam varias sempiternum, in nam illustriora. Laboris ne arbitror sed cernantur aute voluptate admodum, sunt cupidatat si minim veniam, ab fore labore iis probant. Ubi occaecat aut mentitum se lorem mandaremus si voluptatibus. Aut ubi elit incurreret, eiusmod fore ipsum officia enim. Litteris sunt se offendit adipisicing, cernantur se culpa id malis coniunctione admodum amet mandaremus, arbitror quae noster quamquam quem.

## Part four 

The 2 anchors (not visible in the html preview) ***locating*** the ***BOTTOM*** of the page are coded as:

```html
<a id="bottomofthepage"></a>This is the end 
<span id="bottomofthepagebytagid">... as expected.</span>
```

The link to ***jump*** back to the ***TOP*** of the page is coded as:

```html
<a href="#topofthepage">go back to the top of the page</a>
```

<a id="bottomofthepage"></a>This is the end<span id="bottomofthepagebytagid">... as expected.</span>

<a href="#topofthepage">go back to the top of the page</a>

END