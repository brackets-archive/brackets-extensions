# "Checkboxes" Tests

## List items starting with "`-`"

- [] item 1
- [ ] item 2
- [x] item 3
  - [] item 3.1
  - [ ] item 3.2
  - [x] item 3.3
  - [X] item 3.4
- [X] item 4
  
## List items starting with "`*`"   

* [] item 5
* [ ] item 6
* [x] item 7
  * [] item 7.1
  * [ ] item 7.2
  * [x] item 7.3
  * [X] item 7.4
* [X] item 8


## Numbered list items

1. [] item 9
1. [ ] item 10
1. [x] item 11
  1. [] item 11.1
  1. [ ] item 11.2
  1. [x] item 11.3
  1. [X] item 11.4
1. [X] item 12

## mixed mode with/without paragraphs and line breaks

- [] item 13  
this line belongs to item 13  
this line belongs to it as well
- [ ] item 14
- [x] item 15
  * [] item 15.1
  * [ ] item 15.2  
  this line belongs to item 15.2  
  this line belongs to it as well
  * [x] item 15.3
    1. [ ] item 15.3.1  
    this line belongs to item 15.3.1
    1. [ ] item 15.3.2  
    1. [ ] item 15.3.3
  * [X] item 15.4
* [X] item 16

- [] item 17

- [ ] item 18

- [x] item 19

  1. [] item 19.1
  
  1. [ ] item 19.2  
  this line belongs to item 19.2  
  this line belongs to item 19.2 as well
  
  1. [x] item 19.3
  
  1. [X] item 19.4
    
- [X] item 20

END
