# Features and improvements roadmap

## Roadmap

- [ ] finalization of the refactoring efforts (Part II: markdown document preview engine)
- [ ] run 'self tests' of the extension modules (output to the console) when the extension is re-loaded/installed (ruled by a user preference/setting)
- [ ] description of the extension structure (modules, interfaces...)
- [ ] custom/user css theme files
- [ ] implement a 'save preview to file' feature (standalone file export)
- [ ] implement a 'save preview to file' feature (partial html code export)
- [ ] auto-insert a Table-of-Content (list of all headers) at beginning of the document (using a header named 'ToC' or similar...)
- [ ] support the GitHub floavoured "*anchor style*" e.g. ```[](id=id-of-the-anchor)``` (not part of standard markdown, though)

## Version 2.2.0

- [x] option to set the character encoding (default to 'utf-8') of the html output (preview)
- [x] additional "detached" preview panel to display the preview independently from the main brackets window
- [x] enhanced the graphical checkbox to better display, regardless of the selected theme (including fixing the github theme)

## Version 2.1.0

- [x] option to automatically activate the markdown preview when brackets is started (or when the extensions are reloaded e.g. using `F5`)
- [x] the keyboard shortcut `Ctrl-Alt-M` activates/deactivates the preview the preview panel (see menu item `View -> Markdown Preview`)
- [x] improved user settings dialog to better display on narrowed preview panel, now using tabs to group settings
- [x] the user settings dialog now respects the design theme selected for brackets itself (see menu item `View -> Designs...`)

## Version 2.0.0

- [x] highlighting is now applied by the extension directly: the link to the highlight.js script has been removed from the html preview document (thin preview/client)
- [x] DEV: the extension has been _REFACTORED_ (Part I: using separate modules for preview panel, preferences, Brackets commands, core utilities)
- [x] DEV: the extension now uses ES6 (ES2015) extensively
- [x] DEV: the linting of the JavaScript files of this extension is now configured to use ESLint instead of JSLint.
- [x] DEV: diverse code optimization e.g. recycling/reusing already created objects, dialogs, panels... instead of recreating them everytime

## Version 1.3.1

- [x] set/enforce the color of the preview background (different formats are supported: hex values, names...)

## Version 1.3

- [x] syntax highlighting for code blocks (making usage of the '_highlight.js_'library)

## Version 1.2.1

- [x] enhanced html '_preview_' template
- [x] new CSS theme `github`: the minimal amount of CSS to replicate the GitHub Markdown style
- [x] enhancement of the preference declarations for this extension (descriptions and values used while editing the brackets preference file)

## Version 1.2

- [x] option to sanitize some anchors (`<a ...></a>`) to better conform with HTML5 standard

## Version 1.1

- [x] graphical checkbox (task) list

## Version 1.0

- [x] enhance .gitignore
- [x] add some more themes like `Markdown5`, `Screen`, `Markdown7`
- [x] implement an adaptive preview width
- [x] allow preview of markdown files with alternative file extensions

END