/**
 * @module      ExtPreviewContent
 * @file        Functions and classes generating the HTML content of the preview
 * @author      Loïs Bégué
 * @license     MIT license (MIT)
 * @copyright   Copyright (c) 2017 Loïs Bégué
 */

// NOTE: WORK FOR FUTURE IMPROVEMENT ONGOING

/*global define, brackets, window */

define(function (require, exports, module) {
    "use strict";

    // Register Brackets modules
    var WorkspaceManager    = brackets.getModule("view/WorkspaceManager");
    var PopUpManager        = brackets.getModule("widgets/PopUpManager");
    var EditorManager       = brackets.getModule("editor/EditorManager");

    // Register local 3rd party modules
    var marked          = require("lib/marked");
    var tinycolor       = require("lib/tinycolor/tinycolor-min");

    // Module variables
    var _previewContentGenerator;
    var _previewContentTemplate;
    var _source;
    var _content;

    var _detectYamlRegEx = /^-{3}([\w\W]+?)(-{3})/;
    var _replaceLinkHTMLRegEx = /(<a [^>]+)\/>/gmi;
    var _replaceLinkNameRegEx = /(<(?:input|select|table|a)\b(?:\s+(?!name\b)[A-Za-z][\w\-:.]*(?:\s*=\s*(?:"[^"]*"| \'[^\']*\'| [\w\-:.]+))?)*)\s+name\s*=\s*("[^"]*"| \'[^\']*\'| [\w\-:.]+)/gmi;

    function _prepareSource(){

        // Remove Yaml header (if any)
        let yamlHeader = _detectYamlRegEx.exec(_source);
        if (yamlHeader) {
            _source = _source.substr(yamlHeader[0].length);
        }

        // Sanitize Anchors in wrong format replacing "<a ... />" by "<a ... ></a>" (HTML5)
        _source = _source.replace( _replaceLinkHTMLRegEx, "$1></a>");

        // Sanitize Anchors in wrong format, replacing "NAME" attribute by "ID" attribute (HTML5)
        _source = _source.replace(_replaceLinkNameRegEx, "$1 id=$2");

    }

    function _generateContent(){
        // Parse markdown into HTML
        _content = marked(_source);
    }

    function _reworkContent(){

    }

    function _createContent(sourceDocumentContent){
        _source = sourceDocumentContent;
        _content = "";

        _prepareSource();
        _generateContent();
        _reworkContent();

        return _content;

    }

    function _updateContent(sourceDocumentContent){
        //_currentSource = sourceDocumentContent;
        _content = "";

    }

    function _createPreviewContentGenerator(contentTemplate){
        if (!_previewContentGenerator){
            // Load templates as text
            _previewContentTemplate = contentTemplate;

            _previewContentGenerator.createContent = _createContent;
            _previewContentGenerator.updateContent = _updateContent;
        }
        return _previewContentGenerator;
    }

    exports.createPreviewContentGenerator = _createPreviewContentGenerator;
});
