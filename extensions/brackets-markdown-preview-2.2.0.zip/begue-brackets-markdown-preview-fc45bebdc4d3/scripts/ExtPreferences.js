/**
 * @module      ExtPreferences
 * @file        Functions and classes to handle with the user preferences as stored within Brackets
 * @author      Loïs Bégué
 * @license     MIT license (MIT)
 * @copyright   Copyright (c) 2017 Loïs Bégué
 */

/*global define, brackets, window */

define(function (require, exports, module) {
    "use strict";

    /****************************************************************
     * Modules and Variables
    ****************************************************************/

    var ExtLoggingUtils     = require("scripts/ExtLoggingUtils");

    var _preferencesManager;
    var _extensionPreferencesID;
    var _internalPreviewPreferences;
    var _PreviewPreferences;

    /****************************************************************
     * Helper functions
    ****************************************************************/

    function _definePropertyForPreference(propertyName){
        Object.defineProperty(_PreviewPreferences, propertyName, {
            __proto__: null,
            configurable: false,
            enumerable: true,
            get: function() { return _internalPreviewPreferences.get(propertyName); },
            set: function(value) { _internalPreviewPreferences.set(propertyName, value); }
        });
    }

    function _defineHelperPropertiesForPreferences(){
        Object.defineProperty(_PreviewPreferences, "keys", {
            __proto__: null,
            configurable: false,
            enumerable: false,
            get: function() {
                return Object.keys(_PreviewPreferences);
            }
        });

        Object.defineProperty(_PreviewPreferences, "fullKeys", {
            __proto__: null,
            configurable: false,
            enumerable: false,
            get: function() {
                return Object.keys(_PreviewPreferences).map(function(aKey){ return _extensionPreferencesID + "." + aKey; });
            }
        });

        Object.defineProperty(_PreviewPreferences, "descriptions", {
            __proto__: null,
            configurable: false,
            enumerable: false,
            get: function() {
                return Object.keys(_PreviewPreferences).map(function(aKey){ return _internalPreviewPreferences.getPreference(aKey).description; });
            }
        });

        Object.defineProperty(_PreviewPreferences, "names", {
            __proto__: null,
            configurable: false,
            enumerable: false,
            get: function() {
                return Object.keys(_PreviewPreferences).map(function(aKey){ return _internalPreviewPreferences.getPreference(aKey).name; });
            }
        });

        Object.defineProperty(_PreviewPreferences, "prefs", {
            __proto__: null,
            configurable: false,
            enumerable: false,
            get: function() {
                var theList = {};
                Object.keys(_PreviewPreferences).forEach(
                    function(aKey){
                        var thePref = {};
                        thePref["name"] = _internalPreviewPreferences.getPreference(aKey).name;
                        thePref["description"] = _internalPreviewPreferences.getPreference(aKey).description;
                        thePref["fullKey"] = _extensionPreferencesID + "." + aKey;
                        theList[aKey] = thePref;
                    }
                );
                return theList;
            }
        });
    }

    /**
     * Self test function to check the module functionality (also suitable as usage example)
     * @author Loïs Bégué
     */    
    function selfTest(){
        let test = ExtLoggingUtils.createLogCase("Self Test of the module 'ExtPreferences'", true, false);
        test.start();
        test.log("PREFERENCES: KEYS");
        test.log(_PreviewPreferences.keys);
        test.log("PREFERENCES: FULL KEYS");
        test.log(_PreviewPreferences.fullKeys);
        test.log("PREFERENCES: FULL DESCRIPTIONS");
        test.log(_PreviewPreferences.descriptions);
        test.log("PREFERENCES: NAMES");
        test.log(_PreviewPreferences.names);
        test.log("PREFERENCES: FULL PREFS");
        test.log(_PreviewPreferences.prefs);
        test.log("PREFERENCES: SINGLE PREF - SAMPLE - HIGHLIGHT THEME");
        test.log(_PreviewPreferences.highlightTheme);
        test.end();

    }

    /****************************************************************
     * Preferences initializations and declarations
    ****************************************************************/

    _preferencesManager          = brackets.getModule("preferences/PreferencesManager");
    _extensionPreferencesID     = "brackets-markdown-preview";
    _internalPreviewPreferences = _preferencesManager.getExtensionPrefs(_extensionPreferencesID);
    _PreviewPreferences         = {};

    //========== brackets-markdown-preview.useGFM ==========
    _internalPreviewPreferences.definePreference("useGFM", "boolean", false,
        {
            name: "Markdown format",
            description: "Defines the format used to render markdown. 'false' = standard makrdown, 'true' = GitHub-Flavored (GFM)."
        });
    _definePropertyForPreference("useGFM");

    //========== brackets-markdown-preview.theme ==========
    _internalPreviewPreferences.definePreference("theme", "string", "clean",
        {
            name: "Preview theme",
            description: "There are five CSS preview themes available: 'clean', 'dark', 'serif', 'markdown5', 'screen' and 'markdown7'",
            values: ["clean", "dark", "serif", "markdown5", "screen", "markdown7", "github"]
        });
    _definePropertyForPreference("theme");

    //========== brackets-markdown-preview.syncScroll ==========
    _internalPreviewPreferences.definePreference("syncScroll", "boolean", true,
        {
            name: "Sync scroll position",
            description: "When 'true', scrolling in the editor scrolls the preview to roughly the same location."
        });
    _definePropertyForPreference("syncScroll");

    //========== brackets-markdown-preview.adaptiveWidth ==========
    _internalPreviewPreferences.definePreference("adaptiveWidth", "boolean", false,
        {
            name: "Adaptive preview width",
            description: "When this option is 'true', the preview should enlarge to 90% of the preview panel width."
        });
    _definePropertyForPreference("adaptiveWidth");

    //========== brackets-markdown-preview.graphicalCheckboxList ==========
    _internalPreviewPreferences.definePreference("graphicalCheckboxList", "boolean", true,
        {
            name: "Graphical checkbox list",
            description: "When this option is set to 'true', the textual representation of checkboxes  (`[ ]`, `[x]`) within (task) lists is replaced by a graphical one."
        });
    _definePropertyForPreference("graphicalCheckboxList");

    //========== brackets-markdown-preview.markdownSanitizeAnchors ==========
    _internalPreviewPreferences.definePreference("markdownSanitizeAnchors", "boolean", true,
        {
            name: "Sanitize anchors (HTML5)",
            description: "When set to 'true', this option sanitize anchors like '<a name=thename/>' to '<a id=thename></a>' to conform with HTML5 recommandations."
        });
    _definePropertyForPreference("markdownSanitizeAnchors");

    //========== brackets-markdown-preview.highlightTheme ==========
    _internalPreviewPreferences.definePreference("highlightTheme", "string", "default",
        {
            name: "Highlight theme",
            description: "There are 77 code highlighting themes available...",
            values: ["agate", "androidstudio", "arduino-light", "arta", "ascetic", "atelier-cave-dark", "atelier-cave-light",
                "atelier-dune-dark", "atelier-dune-light", "atelier-estuary-dark", "atelier-estuary-light", "atelier-forest-dark",
                "atelier-forest-light", "atelier-heath-dark", "atelier-heath-light", "atelier-lakeside-dark", "atelier-lakeside-light",
                "atelier-plateau-dark", "atelier-plateau-light", "atelier-savanna-dark", "atelier-savanna-light", "atelier-seaside-dark",
                "atelier-seaside-light", "atelier-sulphurpool-dark", "atelier-sulphurpool-light", "atom-one-dark", "atom-one-light",
                "brown-paper", "codepen-embed", "color-brewer", "darcula", "dark", "darkula", "default", "docco", "dracula", "far",
                "foundation", "github-gist", "github", "googlecode", "grayscale", "gruvbox-dark", "gruvbox-light", "hopscotch",
                "hybrid", "idea", "ir-black", "kimbie.dark", "kimbie.light", "magula", "mono-blue", "monokai-sublime", "monokai",
                "obsidian", "ocean", "paraiso-dark", "paraiso-light", "pojoaque", "purebasic", "qtcreator_dark", "qtcreator_light",
                "railscasts", "rainbow", "school-book", "solarized-dark", "solarized-light", "sunburst", "tomorrow-night-blue",
                "tomorrow-night-bright", "tomorrow-night-eighties", "tomorrow-night", "tomorrow", "vs", "xcode", "xt256", "zenburn"]
        });
    _definePropertyForPreference("highlightTheme");

    //========== brackets-markdown-preview.highlightActive ==========
    _internalPreviewPreferences.definePreference("highlightActive", "boolean", true,
        {
            name: "Active highlighting",
            description: "When 'true', highlighting of code blocks is activated. This could slow down the preview when the markdown document is big, though."
        });
    _definePropertyForPreference("highlightActive");

    //========== brackets-markdown-preview.backgroundColor ==========
    _internalPreviewPreferences.definePreference("backgroundColor", "string", "",
        {
            name: "Background color",
            description: "When set to a color value, the background color of the preview should be overridden with this color."
        });
    _definePropertyForPreference("backgroundColor");

    //========== brackets-markdown-preview.activatePreviewOnStart ==========
    _internalPreviewPreferences.definePreference("activatePreviewOnStart", "boolean", false,
        {
            name: "Should the preview be active when brackets starts/reloads the extension?",
            description: "When set to 'true', the preview will be activated everytime brackets starts/reloads the extension. When set to 'false' (default), the preview is deactivated when brackets starts/reloads the extension."
        });
    _definePropertyForPreference("activatePreviewOnStart");

    _internalPreviewPreferences.definePreference("outputCharacterEncoding", "string", "utf-8",
        {
            name: "Output Character Encoding",
            description: "When set (see standard predefined values), a meta element with a corresponding charset is added to the html output  document."
        });
    _definePropertyForPreference("outputCharacterEncoding");

    _defineHelperPropertiesForPreferences();

    exports.Preferences = _PreviewPreferences;
    exports.selfTest    = selfTest;
});
