/**
 * @module      ExtCommander
 * @file        Functions and classes interfacing between extension and brackets (menu, icon, command...)
 * @author      Loïs Bégué
 * @license     MIT license (MIT)
 * @copyright   Copyright (c) 2017 Loïs Bégué
 */

/*global define, $, brackets, window */

define(function (require, exports, module) {
    "use strict";

    var CommandManager      = brackets.getModule("command/CommandManager");
    var Menus               = brackets.getModule("command/Menus");

    /**************************************************
     * Toolbar Icon
    **************************************************/
    var _toolbarIcons = {};

    /**
     * Let the icon be visible
     * @author Loïs Bégué
     * @this
     */
    function showIcon(){
        this.css({display: "block"});
    }

    /**
     * make the icon invisible
     * @author Loïs Bégué
     * @this
     */
    function hideIcon(){
        this.css({display: "none"});
    }

    /**
     * Let the icon be 'active' by assigning the corresponding class
     * @author Loïs Bégué
     * @this
     */
    function activateIcon(){
        this.toggleClass("active", true);
    }

    /**
     * Make the icon 'inactive' by removing the corresponding class
     * @author Loïs Bégué
     * @this
     */
    function deactivateIcon(){
        this.toggleClass("active", false);
    }

    /**
     * Creates an icon and register it into the icon list (to avoid multiple icons with the same ID...)
     * @author Loïs Bégué
     * @param   {string} iconID         The ID of the icon . The ID is used to identify the anchor and to register the icon.
     * @param   {function} iconClickCallback The callback function that should be attached to the icon click event.
     * @returns {object} The JQuery object implementing the icon is returned: it is enhanced by some extra functionality to ease manipulation of its state and visibility.
     */
    function createToolbarIcon(iconID, iconClickCallback){
        if (!(iconID in _toolbarIcons)){
            let newtoolbarIcon = $("<a>").attr({id: iconID, href: "#"}).css({display: "none"}).click(iconClickCallback).appendTo($("#main-toolbar .buttons"));
            newtoolbarIcon.showIcon = showIcon;
            newtoolbarIcon.hideIcon = hideIcon;
            newtoolbarIcon.activate = activateIcon;
            newtoolbarIcon.deactivate = deactivateIcon;
            newtoolbarIcon.iconID = iconID;
            _toolbarIcons[iconID] = newtoolbarIcon;
        }
        return _toolbarIcons[iconID];
    }

    exports.createToolbarIcon = createToolbarIcon;

    /**************************************************
     * Menu Item
    **************************************************/
    var _menuItems = {};

    /*
    var KeyBindingManager   = brackets.getModule("command/KeyBindingManager");
    // not available as long as 'KeyBindingManager.normalizeKeyDescriptorString(...)' is not made public in brackets
    function _keyBindingAlreadyAssigned(keyBinding){
        //TODO: move the function "_keyBindingAlreadyAssigned(...)" to ExtUtils.js
        let normalizedKeyBinding = KeyBindingManager.normalizeKeyDescriptorString(keyBinding);
        let km = KeyBindingManager.getKeymap();
        if (km[normalizedKeyBinding] !== undefined){
            console.log(`The shortcut [${normalizedKeyBinding}] is already assigned to ${JSON.stringify(km[normalizedKeyBinding])}`);
            return true;
        }
        console.log(`The shortcut [${normalizedKeyBinding}] is available for assignment`);
        return false;
    }
    */

    /**
     * Creates a menu item and attach it within the brackets "view" menu.
     * The menu item is also registered into the list of menu items to avoid multiple items with the same ID...
     * @author Loïs Bégué
     * @param   {string} menuItemLabel    The text to be displayed in the menu
     * @param   {string} menuItemID       The ID of the menu item. The ID is used to identify the item and to register it in the list.
     * @param   {function} menuItemCallback The callback function that should be attached to the menu item "selection"
     *                                      event ("click", "Enter", "shortcut"...).
     * @returns {object} The Brackets object representing the menu item.
     */
    function createMenuItemInViewMenu(menuItemLabel, menuItemID, menuItemCallback){
        if (!(menuItemID in _menuItems)){
            let viewMenu = Menus.getMenu(Menus.AppMenuBar.VIEW_MENU);
            let newMenuItem = CommandManager.register(menuItemLabel, menuItemID, menuItemCallback);
            let kb = { key : "Ctrl-Alt-M" };
            /*
            // not available as long as 'KeyBindingManager.normalizeKeyDescriptorString(...)' is not made public in brackets
            _keyBindingAlreadyAssigned(kb.key);
            */
            viewMenu.addMenuItem(newMenuItem, kb);
            newMenuItem.setChecked(false);
            newMenuItem.setEnabled(false);
            _menuItems[menuItemID]=newMenuItem;

        }
        return _menuItems[menuItemID];
    }

    exports.createMenuItem = createMenuItemInViewMenu;
});
