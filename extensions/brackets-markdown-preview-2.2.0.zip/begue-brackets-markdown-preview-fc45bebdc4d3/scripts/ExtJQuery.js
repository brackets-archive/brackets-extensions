/**
 * @module      ExtJQuery
 * @file        Plugin to extend JQuery functionality
 * @author      Loïs Bégué
 * @license     MIT license (MIT)
 * @copyright   Copyright (c) 2017 Loïs Bégué
 */

/*global define, $, window */

define(function (require, exports, module) {
    "use strict";
    /****************************************************************
     * JQUERY PLUGIN FOR VISIBILITY TEST
     *  => $(...).isVisible()
     * as a much faster replacement for $(...).is(":visible")
     * source: https://jsperf.com/jquery-visibility-test/2
    ****************************************************************/
    $.fn.isVisible = function() {
        //console.log("VISIBLE?");
        return $.expr.filters.visible(this[0]);
    };

});
