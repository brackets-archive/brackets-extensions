# Zurb-Apps-Extension
A Brackets code hinting extension for the Zurb Foundation for Apps Framework

##Install

1. Install Brackets 1.0 or later.
2. In Brackets, click the menu item File > Extension Manager...
3. Go to the "Available" tab of the dialog that appears.
4. Type "Zurb Apps code hinter" in the search box.
5. Click the "Install" button in the search result for Zurb Foundation for Apps Code Hinter.
