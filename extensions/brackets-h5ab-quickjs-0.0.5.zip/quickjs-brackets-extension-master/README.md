# quickjs-brackets-extension
Quickly Add jQuery and JavaScript Snippets

Find more about this extension as well as web development articles and WordPress plugins at [HTML5andBeyond](https://www.html5andbeyond.com/quickjs-brackets-extension-fast-js-jquery-commands/)
