# Brackets.io Join Lines

Join Lines for Brackets (with and without inserting a SPACE between the joined lines)
