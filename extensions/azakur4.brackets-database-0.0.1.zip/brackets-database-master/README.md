brackets-database
====================

The focus of this extension is create a simple client to connect different databases like mysql, mssql and oracle.

Actually this is working only for mysql and the idea is that u can make sql querys inside of brackets connecting to a database.

this is a first version the layout not is so good but im focusing in the functionality first.


How Use
====================
To enter to the extension go to view menu and pick the option database client, after that u can fill the fields and click in connect.