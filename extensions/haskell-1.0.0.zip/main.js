define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("haskell", {"name":"Haskell","mode":"haskell","fileExtensions":["hs"],"lineComment":["--"]});
});