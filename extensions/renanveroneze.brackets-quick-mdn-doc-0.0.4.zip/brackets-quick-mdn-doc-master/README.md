brackets-quick-mdn-doc
======================

This is a brackets extension, for helping searches from developers.
Is a shortcut to MDN(Mozilla Developer Network), best location to search.


## Video
http://youtu.be/EOnvAbngHw0
