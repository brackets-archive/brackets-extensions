# Brackets-Epic-Night-Theme
A dark theme for Adobe Brackets.
#Install
1. Open Brackets
2. Open the Extension Manager
3. Navigate to the "Themes" tab
4. Search, "Epic Night"
5. Click install on the theme titled, "Epic Night"
6. Go to View > Themes and select the Epic Night theme.

#HTML
<a href="http://imgur.com/DCB6ygm"><img src="http://i.imgur.com/DCB6ygm.png" title="source: imgur.com" /></a>
#CSS
<a href="http://imgur.com/PiUqCCB"><img src="http://i.imgur.com/PiUqCCB.png" title="source: imgur.com" /></a>
#JavaScript
<a href="http://imgur.com/Cr6HNNi"><img src="http://i.imgur.com/Cr6HNNi.png" title="source: imgur.com" /></a>

