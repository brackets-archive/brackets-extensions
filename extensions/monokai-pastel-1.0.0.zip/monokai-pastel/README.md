# monokai-pastel
Dark pastel theme for Brackets. Based on the Dark Soda and Monokai color schemes.

![Screenshot](https://github.com/rnarrkus/monokai-pastel/blob/master/Screenshot01.png)

![Screenshot](https://github.com/rnarrkus/monokai-pastel/blob/master/Screenshot02.png)
