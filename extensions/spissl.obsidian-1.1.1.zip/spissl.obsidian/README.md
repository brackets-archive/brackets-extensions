Obsidian Brackets theme
=======

Slightly customised Obsidian Theme - Based on the Obsidian theme here "http://eclipsecolorthemes.org/?view=theme&id=21" & Obsidian for Komodo by Gizmoh.

## HTML
![HTML Screenshot](/screenshots/html.png)

## CSS
![CSS Screenshot](/screenshots/css.png)

## JS
![JS Screenshot](/screenshots/js.png)

## PHP
![PHP Screenshot](/screenshots/php.png)

## JAVA
![JAVA Screenshot](/screenshots/java.png)