# Space-Theme
Space Theme For Bracket Text Editor

#Screenshots

HTML

![alt tag](http://uupload.ir/files/nik7_html.png)

CSS

![alt tag](http://uupload.ir/files/ass1_css.png)

JS

![alt tag](http://uupload.ir/files/ja8v_js.png)

PHP

![alt tag](http://uupload.ir/files/xtle_php.png)
