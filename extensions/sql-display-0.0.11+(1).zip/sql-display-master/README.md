SQL-DISPLAy
====================

This is a simple Brackets extention for having a view of content of a MySQL table.

How to use
====================

First install the extension
then go to 'view' on the editor menu and click on 'sql-display-panel'

Enter your connection settings (ip adress of server, port, username, password, and name of database)
click on connect, and select below a name of table to display it.

To do
====================
- [x] display table content
- [ ] add a quick button to delete a row on table
- [ ] add a button to execute any SQL command
- [ ] find a way to keep table head when scrolling
- [ ] use it to connect on more database engine, like MongoDb perhaps...
