# Brackets.Color.Keeper
ColorKeeper is an extension for Brackets that is based on Soenke Tenckhoff's "ColorPal".
Here is his webpage http://www.pixelhoch2.de/ and extension http://brackets.dnbard.com/extension/color.pal

It allows you to add colors to a palette and then insert them into your code from there.

Simple yet useful.

![Alt text](images/screenshot.jpg?raw=true "Screenshot")
