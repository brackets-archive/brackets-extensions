# Jaggeryjs Brackets Extension

===============================

A syntax highlighting plugin for [WSO2 Jaggery](http://jaggeryjs.org/) in the [Brackets editor](http://brackets.io/).

After installation you will get mixed syntax highlightning for html and jaggery in .jag files.

## Installing

The easiest way to install this extension is to use the [Extension Manager](github.com/adobe/brackets/wiki/Brackets-Extensions) in Brackets.

If you want the cutting-edge version you can always clone this repo and manually install it into the brackets extension folder (you can find it in your system by going to Help > Show Extensions Folder in Brackets).

## License

MIT, Version 2.0 ([LICENSE](LICENSE)), You may not use this file except in compliance with the License.
