Machiato Theme for Brackets
===========================

My attempt to translate my trusted favorite Espresso Libre from Sublime Text.

![HTML Screenshot](https://github.com/cpeddecord/machiato/blob/master/screenshots/html.jpg)
![CSS Screenshot](https://github.com/cpeddecord/machiato/blob/master/screenshots/css.jpg)
![JS Screenshot](https://github.com/cpeddecord/machiato/blob/master/screenshots/js.jpg)