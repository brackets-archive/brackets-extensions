var test  // Warning: missing ";"

test = 'Hello';

console.log(test.toUpperCase(); // Fatal: missing ")"
