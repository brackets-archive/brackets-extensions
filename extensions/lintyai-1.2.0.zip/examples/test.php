<?
$test = 'Hello';

echo strtoupper($test; // Parse error: missing ")"
