local test;

test = 'Hello';

print(test:upper(); -- Missing ")"
