![cd node && npm install](https://raw.github.com/wiki/lexazloy/brackets-compilyai/CO.png)
