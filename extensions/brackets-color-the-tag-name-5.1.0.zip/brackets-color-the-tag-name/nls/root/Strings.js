define( {
	PATH: "Directory Path: ",
	BROWSE: "Browse...",
	MESSAGE: "Please set the directory to save your original CSS(LESS) file."
} );