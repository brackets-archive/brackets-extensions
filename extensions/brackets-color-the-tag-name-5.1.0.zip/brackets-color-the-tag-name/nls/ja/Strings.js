define( {
	PATH: "保存先フォルダのパス：",
	BROWSE: "参照...",
	MESSAGE: "オリジナルCSSの保存先フォルダを設定してください。"
} );