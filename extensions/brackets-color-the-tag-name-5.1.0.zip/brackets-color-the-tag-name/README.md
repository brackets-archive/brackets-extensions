# color the tag name
This extension colors the tag name.
like this...!
![screen shot](https://user-images.githubusercontent.com/26040158/32030162-276aae24-ba34-11e7-8bd3-727f378cdea4.jpg "screen shot")
## Your Original CSS(LESS)
You can customize tag colors with your original CSS(LESS), From 'View' -> 'Customize Tag Colors'.

## そして私は無職ではなくなりました。
私はフロントエンドエンジニアとして職を得ることができました。