# Fonts

This is an extension for the code editor [Brackets](http://brackets.io/). The extension allows you to change the font of the editor by choosing from a selection of fonts from Google Fonts.