# brackets-R-syntax
Does nothing more than expose the R programming language mode from CodeMirror to Brackets.
