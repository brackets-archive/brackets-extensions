Daugther of Obsidian Brackets theme
=======

Customised Obsidian Theme - Based on the Obsidian theme from LegibleEel which can be found here: https://github.com/LegibleEel/Obsidian

### JS
![JS](/screenshots/js.png)

### HTML
![HTML](/screenshots/html.png)

### CSS
![CSS](/screenshots/css.png)

### Python
![Python](/screenshots/python.png)
