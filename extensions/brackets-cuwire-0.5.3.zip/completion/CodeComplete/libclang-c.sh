#!/bin/sh
DYLD_LIBRARY_PATH=$DYLD_LIBRARY_PATH:./ ./CodeComplete samples/sample2_l6c9.cc 6 9
