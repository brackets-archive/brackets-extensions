#!/bin/sh
NODE_PATH=/Users/apla/work/mcu/brackets-cuwire/node/node_modules node walker.js
