# Minify (more) for [Brackets](https://github.com/adobe/brackets)

*Originally created by Alfred Xing. This version attempts a deeper minification, using "SIMPLE_OPTIMIZATIONS" instead of simply removing the whitespaces. Minifies JavaScript and CSS files in Brackets and saves to `{filename}.min.{ext}` using Google's Closure Compiler (for JavaScript) and YUI (for CSS). Also fixes a couple of extra issues.*

## Installation

1. Run Brackets
2. Select *File > Install Extension...*
3. Enter `https://github.com/Fornace/minify-more/archive/master.zip` as Extension URL.
3. Click Install to begin downloading and installing the extension.

#### Alternative method
Clone this repository into `~/Library/Application Support/Brackets/extensions/user/` and restart Brackets.

## Usage
To minify a file, use the keyboard shortcut `Cmd/Ctrl+M`. You can also minify files on save by checking the corresponding item in the *Edit* menu.

## A warning
Do never include a single quote (') inside a comment. Breaks things badly.


## Version

`Version 0.2.0`

## ORIGINAL LICENSE

Copyright (C) MMXIV Fornace
See Alfred Xing original license.

Copyright (C) MMXIII Alfred Xing

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, and/or sublicense copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
