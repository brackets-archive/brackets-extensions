brackets-toc
===========

[Toc](http://www.wowwiki.com/TOC_File) syntax Highlighting for Brackets.

## How to Install

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for this extension
3. Click _Install_!


## License

Distributed under the MIT license.