/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, brackets, CodeMirror */

define(function () 
{
    "use strict";
    
    var LanguageManager = brackets.getModule("language/LanguageManager");
    
    CodeMirror.defineMode("toc", function() 
    {
        return {
            token: function(stream)
            {
                if (stream.match(new RegExp("^##\\s[a-zA-Z]+(-[a-zA-Z]+)*:")))
                {
                    return "keyword";
                }
                else if (stream.match(new RegExp("^#.+$")))
                {
                    return "comment";
                }
                else if (stream.match(new RegExp("^.+\\.(xml|lua)$")))
                {
                    return "string";
                }
                else 
                {
                    stream.next();
                    return null;
                }
            }
        };
    });
    
    LanguageManager.defineLanguage("toc", 
    {
        name: "Toc",
        mode: "toc",
        fileExtensions: ["toc"],
        lineComment: ["#"]
    });
});
