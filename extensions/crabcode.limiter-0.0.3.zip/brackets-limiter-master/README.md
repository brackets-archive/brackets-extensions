Line Limiter
============
Adds a button to the toolbar that allows you to limit the width of the code lines, making it more convenient to work on bigger text chunks.

![Screenshot](http://hannes-flor.de/uploads/media/limiter.png)

### How to Install
Line Limiter is an extension for [Brackets](https://github.com/adobe/brackets/).

To install extensions:

1. Choose _File > Extension Manager_ and select the _Available_ tab.
2. Search for this extension.
3. Click _Install_.

### License
MIT-licensed -- see `main.js` for details.