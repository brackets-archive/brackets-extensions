/*
* Copyright (c) 2014 CrabCode
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"),
* to deal in the Software without restriction, including without limitation
* the rights to use, copy, modify, merge, publish, distribute, sublicense,
* and/or sell copies of the Software, and to permit persons to whom the
* Software is furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
* DEALINGS IN THE SOFTWARE.
*/

/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window */
define(function (require, exports, module) {
    "use strict";
    
    var CommandManager  = brackets.getModule("command/CommandManager"),
        Commands        = brackets.getModule("command/Commands"),
        DocumentManager = brackets.getModule("document/DocumentManager"),
        EditorManager   = brackets.getModule("editor/EditorManager"),
        ExtensionUtils  = brackets.getModule("utils/ExtensionUtils"),
        Preferences     = brackets.getModule("preferences/PreferencesManager"),
        prefs           = Preferences.getExtensionPrefs("crabcode.limiter");
    
    var _wrapChange = false;
    
    ExtensionUtils.loadStyleSheet(module, "styles.css");
    
    function updateLimit() {
        if (prefs.get("enabled")) {
            $(".CodeMirror-lines").addClass("enabled");
            $("#limiter-toolbar-icon").addClass("enabled");
			$(".CodeMirror-lines.enabled").css("width", prefs.get("width") + "px");
            
            if ($(".CodeMirror-wrap").length === 0) {
                CommandManager.execute(Commands.TOGGLE_WORD_WRAP);
                _wrapChange = true;
            }
        } else {
            $(".CodeMirror-lines").removeClass("enabled");
            $("#limiter-toolbar-icon").removeClass("enabled");
            
            if (_wrapChange) {
                CommandManager.execute(Commands.TOGGLE_WORD_WRAP);
                _wrapChange = false;
            }
        }
        
        var activeEditor = EditorManager.getActiveEditor();
        
        if (activeEditor !== null) {
            activeEditor.refresh();
        }
    }
    
    function toggleLimiter() {
        prefs.set("enabled", !prefs.get("enabled"));
        prefs.save();
        updateLimit();
    }
    
    $(document.createElement("a"))
        .attr("id", "limiter-toolbar-icon")
        .attr("href", "#")
        .attr("title", "Toggle Limiter")
        .on("click", toggleLimiter)
        .appendTo($("#main-toolbar .buttons"));
    
    if (typeof prefs.get("enabled") !== "boolean") {
        prefs.definePreference("enabled", "boolean", false);
        prefs.set("enabled", false);
        prefs.save();
    }
    
    if (typeof prefs.get("width") !== "number") {
        prefs.definePreference("width", "number", false);
        prefs.set("width", 640);
        prefs.save();
    }
    
    if (prefs.get("enabled")) {
        $(".CodeMirror-lines").addClass("enabled");
        $("#limiter-toolbar-icon").addClass("enabled");
		$(".CodeMirror-lines.enabled").css("width", prefs.get("width") + "px");
    }
    
    $(DocumentManager).on("currentDocumentChange.bracketsCodeLimiter", updateLimit);
});
