/*global define */

define(function (require, exports, module) {
    'use strict';

    module.exports = {
        root: true,
        el: true,
        it: true,
        es: true,
        fr: true
    };
});
