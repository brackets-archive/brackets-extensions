# The Greyhound theme for Brackets

A dark theme, created for speed coding, sporting a modern user interface.

## Installation

* Open the Extension Manager in Brackets
* Switch to "Themes" tab
* Search for "The Greyhound"
* Click "Install"

## Changelog

= 1.1.2 =

* UPDATE: Added keywords
* UPDATE: Updated compatibility with latest version of Adobe Brackets

= 1.1.1 =

* UPDATE: Added changelog
* UPDATE: Updated the Brackets registry for version consistency

= 1.1.0 =

* UI: Fixed sidebar background colour
* UI: Improved editing pane background colour
