![PixzlEyerisTheme](pixzleyeristheme-logo.png)

[![license](https://img.shields.io/github/license/mashape/apistatus.svg?maxAge=2592000)](LICENSE)


Beautiful UI Theme for Brackets.

## Screenshot
![Screenshot](screenshot.png)
