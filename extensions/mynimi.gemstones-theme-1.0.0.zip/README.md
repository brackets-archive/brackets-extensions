#Gemstones Theme

After trying out multiple themes but always ending up not liking things, I decided to make my own.
Gemstones is dark, but does not have too extreme contrasts so it doesn't hurt your eyes.

###Installation
* Open Brackets
* Open the Extension Manager
* Switch to "Themes" tab
* Search for "Gemstones Theme"
* Click "Install"

##Screenshots

### HTML
[![HTML](https://raw.githubusercontent.com/mynimi/gemstones-brackets-theme/master/screenshots/html.png)](https://raw.githubusercontent.com/mynimi/gemstones-brackets-theme/master/screenshots/html.png)
### SCSS
[![SCSS](https://raw.githubusercontent.com/mynimi/gemstones-brackets-theme/master/screenshots/scss.png)](https://raw.githubusercontent.com/mynimi/gemstones-brackets-theme/master/screenshots/scss.png)
### JavaScript
[![JS](https://raw.githubusercontent.com/mynimi/gemstones-brackets-theme/master/screenshots/js.png)](https://raw.githubusercontent.com/mynimi/gemstones-brackets-theme/master/screenshots/js.png)