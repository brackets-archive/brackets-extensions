Brackets-Groovy
=============

This Brackets Extension adds in support for Groovy's GSP view engines.
(Likely be adding more features over time ...)

Install
-------
You can install this via the extenion manager (Brackets -> Extention Manager), install from URL. The URL for the extention is https://github.com/marlon407/Brackets-Groovy
