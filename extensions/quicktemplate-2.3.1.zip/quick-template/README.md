## What is Quick Template?

[![Quick Template](http://api.bddevwork.net/youtube_thumb.png)](https://www.youtube.com/watch?v=-iyPdkEqJ9o "Quick Template")

Quick Template is a html template provider for Brackers.io Editor. That add html template to your brackers editor. when you want to create a new web project you need loots of starting code. this extention make it easy to add html code to yor project.

## Installation

Open Brackets Extention manager then search "quicktemplate". then click install. or download the git as zip then open Extention Manager then drug the zip to Extention Drap place.

## Uses

After Install. click The Q Icon Right site Toolbar to Start Working.

## Tests

This Extention Tested with Brackets 1.8 and 1.9 in Windows, Linux nad Mac. Don't rename the files you find there in order to keep the extension working.

## License

license (MIT)
