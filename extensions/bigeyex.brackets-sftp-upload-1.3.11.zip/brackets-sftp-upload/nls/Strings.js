define( function ( require, exports, module ) {
	'use strict';
	
	module.exports = {
		root: true,
		de: true,
		sv: true,
		zh: true,
		it: true
	};
} );