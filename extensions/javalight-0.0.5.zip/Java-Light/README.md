<b>Java-Light</b>
==========

Awesome Java-Light flavoured theme for Brackets, stay cool in day time!

<br>
<hr>
<b>Screenshots </b>
<br>
<b>HTML</b>
<img src="screenshot/screenshot1.jpg"><br>
<hr>
<br>
