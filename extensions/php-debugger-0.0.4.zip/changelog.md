## Version 0.0.4 (2015-06-01)
 * Fixed bug where it wouldn't open files properly on Linux. Patch contributed by Sven Kuegler.
 * Fixed bug where directories with spaces would cause issues. Patch contributed by Jakob Strande Langgaard.

## Version 0.0.3 (2015-04-23)
 * Fixed bug where gutter markers for breakpoints wouldn't be properly removed on inactive editors.
 * Fixed bug where the default inner panel size would be incorrect and make it hard to scroll to the very bottom.

## Version 0.0.2 (2015-04-10)
 * Fixed bug where multiple requests would cancel current debugging session.

## Version 0.0.1 (2015-04-08)
 * First public release.
