/*jslint regexp: true, vars: true*/
/*global define, $, brackets, console */

define(function (require, exports, module) {
    'use strict';

    // For integration with Brackets' LanguageManager
    var LanguageManager = brackets.getModule("language/LanguageManager");
    var CodeMirror = brackets.getModule("thirdparty/CodeMirror2/lib/codemirror");
	
CodeMirror.defineMode("rapid", function(conf, parserConf) {
    var ERRORCLASS = 'error';

    function wordRegexp(words) {
        return new RegExp("^((" + words.join(")|(") + "))\\b", "i");
    }

    var singleOperators = new RegExp("^[\\+\\-\\*/%&\\\\|\\^~<>!]");
    var singleDelimiters = new RegExp('^[\\(\\)\\[\\]\\{\\}@,:`=;\\.]');
    var doubleOperators = new RegExp("^((==)|(<>)|(<=)|(>=)|(<>)|(<<)|(>>)|(//)|(\\*\\*))");
    var doubleDelimiters = new RegExp("^((\\+=)|(\\-=)|(\\*=)|(%=)|(/=)|(&=)|(\\|=)|(\\^=))");
    var tripleDelimiters = new RegExp("^((//=)|(>>=)|(<<=)|(\\*\\*=))");
    var identifiers = new RegExp("^[_A-Za-z][_A-Za-z0-9]*");
	
    var openingKeywords = ['proc','func','record','module','if','while','for','test'];
    var middleKeywords = ['else', 'elseif','case'];
    var endKeywords = ['endproc','endfunc','endrecord','endmodule','endif','endwhile','endfor','endtest'];

    var operatorKeywords = ['not','or','xor','and','stop'];
    var wordOperators = wordRegexp(operatorKeywords);
    var commonKeywords = ['then','const','pers','var','true','false','inout','local','trynext','raise','retry','error','task','return','false','true','from','to','do','goto'];
    var commontypes = ['aiotrigg','bool','btnres','busstate','buttondata','byte','clock','confdata','corrdescr','datapos','dionum','dir','dnum','errdomain','errnum','errstr','errtype','event_type','exec_level','extjoint','handler_type','icondata','identno','intnum','iodev','iounit_state','jointtarget','listitem','loaddata','loadidnum','loadsession','mecunit','motsetdata','num','opcalc','opnum','orient','paridnum','paridvalidnum','pathrecid','pos','pose','progdisp','rawbytes','restartdata','rmqheader','rmqmessage','rmqslot','robjoint','robtarget','shapedata','signalxx','socketdev','socketstatus','speeddata','stoppointdata','string','stringdig','switch','symnum','syncident','taskid','tasks','testsignal','tooldata','tpnum','trapdata','triggdata','triggios','triggiosdnum','triggstrgo','tunetype','uishownum','wobjdata','wzstationary','wztemporary','zonedata'];

    var keywords = wordRegexp(commonKeywords);
    var types = wordRegexp(commontypes);
    var stringPrefixes = '"';

    var opening = wordRegexp(openingKeywords);
    var middle = wordRegexp(middleKeywords);
    var closing = wordRegexp(endKeywords);

    var indentInfo = null;

    CodeMirror.registerHelper("hintWords", "vb", openingKeywords.concat(middleKeywords).concat(endKeywords)
                                .concat(operatorKeywords).concat(commonKeywords).concat(commontypes));

    function indent(_stream, state) {
      state.currentIndent++;
    }

    function dedent(_stream, state) {
      state.currentIndent--;
    }
    // tokenizers
    function tokenBase(stream, state) {
        if (stream.eatSpace()) {
            return null;
        }

        var ch = stream.peek();

        // Handle Comments
        if (ch === "!") {
            stream.skipToEnd();
            return 'comment';
        }

        // Handle Strings
        if (stream.match(stringPrefixes)) {
            state.tokenize = tokenStringFactory(stream.current());
            return state.tokenize(stream, state);
        }

        // Handle operators and Delimiters
        if (stream.match(tripleDelimiters) || stream.match(doubleDelimiters)) {
            return null;
        }
        if (stream.match(doubleOperators)
            || stream.match(singleOperators)
            || stream.match(wordOperators)) {
            return 'operator';
        }
        if (stream.match(singleDelimiters)) {
            return null;
        }
        if (stream.match(opening)) {
            if (! state.doInCurrentLine)
              indent(stream,state);
            else
              state.doInCurrentLine = false;
            return 'keyword';
        }
        if (stream.match(middle)) {
            return 'keyword';
        }

        if (stream.match(closing)) {
            dedent(stream,state);
            return 'keyword';
        }

        if (stream.match(types)) {
            return 'def';
        }

        if (stream.match(keywords)) {
            return 'keyword';
        }

        if (stream.match(identifiers)) {
            return 'variable';
        }

		// Handle numbers
        if (/\d/.test(ch)) {
            stream.eatWhile(/[\w\.]/);
        if (stream.eat(/eE/)) { stream.eat(/\+\-/); stream.eatWhile(/\d/); }
            return "number";
        }
		
        // Handle non-detected items
        stream.next();
        return ERRORCLASS;
    }

    function tokenStringFactory(delimiter) {
        var singleline = delimiter.length == 1;
        var OUTCLASS = 'string';

        return function(stream, state) {
            while (!stream.eol()) {
                stream.eatWhile(/[^'"]/);
                if (stream.match(delimiter)) {
                    state.tokenize = tokenBase;
                    return OUTCLASS;
                } else {
                    stream.eat(/['"]/);
                }
            }
            if (singleline) {
                if (parserConf.singleLineStringErrors) {
                    return ERRORCLASS;
                } else {
                    state.tokenize = tokenBase;
                }
            }
            return OUTCLASS;
        };
    }


    function tokenLexer(stream, state) {
        var style = state.tokenize(stream, state);
        var current = stream.current();

        // Handle '.' connected identifiers
        if (current === '.') {
            style = state.tokenize(stream, state);
            current = stream.current();
            if (style === 'variable') {
                return 'variable';
            } else {
                return ERRORCLASS;
            }
        }


        var delimiter_index = '[({'.indexOf(current);
        if (delimiter_index !== -1) {
            indent(stream, state );
        }
        if (indentInfo === 'dedent') {
            if (dedent(stream, state)) {
                return ERRORCLASS;
            }
        }
        delimiter_index = '])}'.indexOf(current);
        if (delimiter_index !== -1) {
            if (dedent(stream, state)) {
                return ERRORCLASS;
            }
        }

        return style;
    }

    var external = {
        electricChars:"dDpPtTfFeE ",
        startState: function() {
            return {
              tokenize: tokenBase,
              lastToken: null,
              currentIndent: 0,
              nextLineIndent: 0,
              doInCurrentLine: false


          };
        },

        token: function(stream, state) {
            if (stream.sol()) {
              state.currentIndent += state.nextLineIndent;
              state.nextLineIndent = 0;
              state.doInCurrentLine = 0;
            }
            var style = tokenLexer(stream, state);

            state.lastToken = {style:style, content: stream.current()};



            return style;
        },

        indent: function(state, textAfter) {
            var trueText = textAfter.replace(/^\s+|\s+$/g, '') ;
            if (trueText.match(closing) || trueText.match(middle)) return conf.indentUnit*(state.currentIndent-1);
            if(state.currentIndent < 0) return 0;
            return state.currentIndent * conf.indentUnit;
        },

        lineComment: "!"
    };
    return external;
});

CodeMirror.defineMIME("text/x-rapid", "rapid");

	// Register with Brackets
    LanguageManager.defineLanguage("rapid", {
        name: "RAPID",
        mode: "rapid",
        fileExtensions: ["prg", "mod", "sys"],
        lineComment: ["!"]
    });
    console.log("ABB RAPID syntax highlighting extension loaded");
	
});
