define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("eiffel", {"name":"Eiffel","mode":"eiffel","fileExtensions":["e","eiff"],"lineComment":["--"]});
});