# brackets-wallpaper
Extension for [Brackets Code Editor](https://github.com/adobe/brackets).
Wallpaper for your coding.

## Configuration
Basic config: `View -> Wallpaper Configuration`  
Enable / Disable: `View -> Enable/Disable Wallpaper`
