[Brackets](https://github.com/adobe/brackets) is an open-source code editor built with the web for the web.

This extension will help you to maintain favourite files. So you can access your favourite files across various projects.

##### How to favourite a file?
Right-click on "Working Files" list. You can see "Add to Favourites" menu.

##### How to view favourite files?
You can acess your favourite files by clicking View -> Show Favourite Files Panel Or by using short a cut key Ctrl/Cmd + Alt + F.

Please post issues and feature changes/requests. I will try to improve this extension.