brackets-working-files
======================
Brackets extension to remove the max-height rule on Working Files.
