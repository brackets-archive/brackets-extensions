/*jslint vars: true */
/*global define, $, brackets, window, console */

define(function (require, exports, module) {
  'use strict';
  
  var packageString = 'cdnSuggestions.'
  
  exports.USE_HTTPS = packageString + 'useHTTPS';
});