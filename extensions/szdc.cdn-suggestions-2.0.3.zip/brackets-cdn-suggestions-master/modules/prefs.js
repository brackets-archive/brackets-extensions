/*jslint vars: true */
/*global define, $, brackets, window, console */

define(function (require, exports, module) {
  'use strict';
  
  exports.USE_HTTPS = {
    id:      'useHTTPS',
    type:    'boolean',
    initial: false
  };
});