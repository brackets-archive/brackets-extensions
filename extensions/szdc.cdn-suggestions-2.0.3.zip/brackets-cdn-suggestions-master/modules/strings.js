/*jslint vars: true */
/*global define, $, brackets, window, console */

define(function (require, exports, module) {
  'use strict';
  
  exports.CONSOLE_PREFIX = '[cdn-suggestions]: ';
  exports.CMD_USE_HTTPS  = 'Use HTTPS for CDNs';
});