define(function (require, exports, module) {
    "use strict";

    var keyBoardShortCutGetTemplate = "Alt-1";

    

    var CommandManager = brackets.getModule("command/CommandManager");
    var kbManager = brackets.getModule("command/KeyBindingManager");
    var edManager = brackets.getModule("editor/EditorManager");


//append phpCode to current editor
    function getTemplateDirectory(){
        
        var phpCode = '<?php echo get_template_directory_uri();?>/';
        
        var editor = edManager.getCurrentFullEditor();
        if(editor){
            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(phpCode, insertionPos);
        }        
    }



    var COMMAND_ID_BCXS1 = "keystrap.getColXS1";

    
    
// PHP : GET TEMPLATE DIRECTORY URI
    
    CommandManager.register("GetTemplate", COMMAND_ID_BCXS1, getTemplateDirectory);
    kbManager.addBinding(COMMAND_ID_BCXS1, keyBoardShortCutGetTemplate);
    
});