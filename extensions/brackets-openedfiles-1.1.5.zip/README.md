#brackets-openedfiles

two feature:

1. Automatically close all opened files on project change
2. File menu item `Open Document Folder` to open containing folder of active file
