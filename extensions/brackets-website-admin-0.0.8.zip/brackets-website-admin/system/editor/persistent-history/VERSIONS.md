###Versions
## 0.0.1
* First version with basic functionality
  * Saving history, loading history, caching and rebuilding history on cases where a file has been modified outside of Brackets