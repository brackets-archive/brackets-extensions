Draggable Modals
================

Now modal windows in Brackets can be dragged through the screen!

*Note: only modals with `.modal-header` will be draggable.*