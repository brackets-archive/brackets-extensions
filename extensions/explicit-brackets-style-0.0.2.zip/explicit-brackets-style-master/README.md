# Explicit

This is a Brackets editor theme based on [Brackets Dark](https://github.com/adobe/brackets/tree/master/src/extensions/default/DarkTheme).
The main change is that the colors are more [in-your-face](http://www.merriam-webster.com/dictionary/in-your-face) than the original ones.

Some samples:

![Screenshot of Explicit theme with a LESS file opened.](screenshots/less.PNG)

![Screenshot of Explicit theme with a JSON file opened.](screenshots/json.PNG)