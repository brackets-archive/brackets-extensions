# Hide Project files panel
A very simple extension for [Brackets](https://github.com/adobe/brackets/) to allow you to hide Project file panel.

