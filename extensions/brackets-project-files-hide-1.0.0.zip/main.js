/*jslint vars: true, plusplus: true, devel: true, regexp: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, brackets, $ */

define(function (require, exports, module) {
    var ExtensionUtils = brackets.getModule('utils/ExtensionUtils')
    ExtensionUtils.loadStyleSheet(module, 'styles/main.css');
});
