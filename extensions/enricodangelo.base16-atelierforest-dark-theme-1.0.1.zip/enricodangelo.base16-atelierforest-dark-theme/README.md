Base 16 Atelierforest Dark Theme for Brackets
============================

Attempting to be as close to [Atelierforest Dark](http://chriskempson.github.io/base16/#atelierforest) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
