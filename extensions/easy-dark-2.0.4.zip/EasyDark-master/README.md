EasyDark
========

Dark theme that's just easy on your eyes.

This is a rendition of https://github.com/chriskempson/tomorrow-theme<br>
Using https://github.com/chriskempson/tomorrow-theme/tree/master/Brackets as a starting point<br>
Thank you folks!

![easydark ss](https://github.com/brackets-themes/easydark/raw/master/screenshot.png)
