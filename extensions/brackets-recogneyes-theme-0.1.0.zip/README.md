
#RecognEyes
This is a best effort to port the Eclipse's RecognEyes theme to Brackets

http://eclipsecolorthemes.org/?view=theme&id=30

https://github.com/ytyukhnin/brackets-recogneyes-theme
