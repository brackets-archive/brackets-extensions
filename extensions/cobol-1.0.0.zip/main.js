define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("cobol", {"name":"COBOL","mode":"cobol","fileExtensions":["cbl"]});
});