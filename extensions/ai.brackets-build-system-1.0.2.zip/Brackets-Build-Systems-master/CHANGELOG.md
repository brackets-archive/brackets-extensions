v0.0.1 :

  - initial release ('beta\incomplete' still in dev)

v1.0.0 :

  - first release
  - organized files\folders
  - improved status indicator
  - added save all on build
  - added seperator property
  - added $FILE_PATH special variable
  - build\run\debug menu items will be disabled if not specified (build\run\debug cmd)
  
v1.0.1 :

  - minor code fixes
  - improved theme support
  - build\run buttons in toolbar will be disabled if not specified (build\run cmd)

v1.0.2 :

  - minor code fixes
