#Brackets-Doxygen Extension
##Install from URL

1. Open the the Extension Manager from the File menu
2. Copy paste the URL of the github repo or zip file

##Install from file system

1. Download this extension using the ZIP button above and unzip it.
2. Copy it in Brackets' `/extensions/user` folder by selecting `Help > Show Extension Folder` in the menu. 
3. Reload Brackets.

##Instructions

By pressing this hot keys you get:
    
    * Alt + D , a doxygen type comment.
    * Alt + S , a simple line comment.
    * Alt + M , a simple multiline comment.
    * Alt + V , a simple comment to document a variable.
    
Note: If you have selected a text, and press Alt + S hot key, Doxygen Extension will comment all the lines with //.

Thanks to:
    * Eric J https://github.com/wormeyman for find the first error of this plugin.

