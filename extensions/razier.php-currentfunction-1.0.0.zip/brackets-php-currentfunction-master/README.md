Brackets PHP Current Function
=======================
shows the current php function that you are currently in on the status bar:

![screenshot](https://razier.com/code/brackets-php-currentfunction/screenshot.png)


How to Install
==============
Brackets PHP Current Function is an extension for [Brackets](https://github.com/adobe/brackets/).

To install extensions:

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for PHP Current Function
3. Click Install!


### License
MIT-licensed