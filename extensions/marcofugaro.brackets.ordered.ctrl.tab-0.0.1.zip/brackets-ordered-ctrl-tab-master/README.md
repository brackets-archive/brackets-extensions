Ordered Ctrl+TAB Navigation for Brackets
========================================
Navigate through open tabs with the Ctrl+(Shift)+TAB shortcut in the list order, not in the default MRU way.

It remaps the keys to the command used with the CTRL+PageUp/PageDown shortcut.

### Compatibility
Brackets 1.4 or newer