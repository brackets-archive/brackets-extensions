# brackets-resizable-bottom-working-files

Brackets extension to reposition Working Files in sidebar and make it resizable
(Toggle it in View Menu)