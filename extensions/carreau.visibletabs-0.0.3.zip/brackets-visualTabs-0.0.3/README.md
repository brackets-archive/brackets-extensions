## VisibleTabs

Make tabs visible in CodeMirror with a discreet gray dots..

![screenshot](screenshot.png)

use to be with arrows but was judge too annoying: 

![screenshot](screenshot_legacy.png)

The legacy css is include but no clue how to make a config option to swith
PR welcomed. 


