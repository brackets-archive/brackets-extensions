# brackets-html5_generator
Extension for Brackets to create a new HTML5 document.

A new menu item will appear on File, named New HTML5 File.
CTRL + ALT + N can be used as a shortcut.
