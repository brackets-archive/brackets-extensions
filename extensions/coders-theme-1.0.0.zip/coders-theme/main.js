/*
    Name        : coders-theme
    Title       : Coders Theme
    Description : Theme for coders!
    Version     : 1.0.0
    Author      : Ahmedur Rahman Shovon <shovon.sylhet@gmail.com> (http://datamate.ws/)
	Homepage    : https://github.com/arsho/coders-theme
*/

/*
	This file is intentionally left blank.
*/