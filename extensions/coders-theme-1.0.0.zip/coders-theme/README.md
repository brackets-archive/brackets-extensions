Coders Theme
============
Coders theme for [Brackets](http://brackets.io) editor. 

<h3>
	<a id="information" class="anchor" href="#information" aria-hidden="true"><span class="octicon octicon-link"></span></a>Theme Information
</h3>

<table>
	<tr>
		<td><strong>Name</strong></td>
		<td>coders-theme</td>
	</tr>
	<tr>
		<td><strong>Title</strong></td>
		<td>Coders Theme</td>
	</tr>
	<tr>
		<td><strong>Description</strong></td>
		<td>Theme for coders!</td>
	</tr>
	<tr>
		<td><strong>Version</strong></td>
		<td>1.0.0</td>
	</tr>
	<tr>
		<td><strong>Author</strong></td>
		<td>Ahmedur Rahman Shovon </td>
	</tr>
</table>

### HTML
![HTML Screenshot](https://github.com/arsho/coders-theme/blob/master/screenshot/html.png)

### CSS
![CSS Screenshot](https://github.com/arsho/coders-theme/blob/master/screenshot/css.png)

### Javascript
![Javascript Screenshot](https://github.com/arsho/coders-theme/blob/master/screenshot/javascript.png)

### PHP
![PHP Screenshot](https://github.com/arsho/coders-theme/blob/master/screenshot/php.png)
