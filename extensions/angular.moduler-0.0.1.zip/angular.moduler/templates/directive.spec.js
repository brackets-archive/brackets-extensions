[.directive.spec.js]describe("{{moduleName}}", function(){

	beforeEach(module('{{moduleFullName}}'));

	var $compile,
	$rootScope;

	beforeEach(inject(function(_$compile_, _$rootScope_){
		
		$compile = _$compile_;
		$rootScope = _$rootScope_;

	}));

	it('Replaces the element with the appropriate content', function() {
		
		var element = $compile("<{{moduleBrokenName}}></{{moduleBrokenName}}>")($rootScope);
		
		$rootScope.$digest();
		
		expect(element.html()).toContain("directive contents here");
	});
    
});