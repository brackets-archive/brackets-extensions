[.controller.spec.js]describe("{{controllerName}}Controller", function(){
    beforeEach(module('{{moduleFullName}}'));

    var controller;

    beforeEach(inject(function($controller){

        controller = $controller('{{controllerName}}');

    }));
    
});