[.directive.js](function () {
    'use strict';

    angular
        .module('{{moduleFullName}}')
        .directive('{{moduleName}}', {{moduleName}});

    /* @ngInject */
    function {{moduleName}}() {
        // Usage:
        //
        // Creates:
        //
        var directive = {
            bindToController: true,
            controller: '{{controllerName}}Controller',
            controllerAs: 'vm',
            link: link,
            restrict: 'E',
            scope: {},
            templateUrl: '{{{templateUrl}}}'
        };
        return directive;

        function link(scope, element, attrs, controller) {
            
        }
    }
})();