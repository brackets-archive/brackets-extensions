[.controller.js](function() {
    'use strict';

    angular
        .module('{{moduleFullName}}')
        .controller('{{controllerName}}Controller', {{controllerName}}Controller);

    /* @ngInject */
    function {{controllerName}}Controller(){
        var vm = this;
        vm.property = '{{controllerName}}Controller';
        

        activate();

        ////////////////

        function activate() {
        }
    }
})();