[.module.js](function () {
    'use strict';

    angular
        .module('{{moduleFullName}}', [
            
        ]);
})();