/*
 * Copyright (c) 2014 Torin Pascal. All rights reserved.
 * Copyright (c) 2012 Adobe Systems Incorporated. All rights reserved.
 *  
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"), 
 * to deal in the Software without restriction, including without limitation 
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, 
 * and/or sell copies of the Software, and to permit persons to whom the 
 * Software is furnished to do so, subject to the following conditions:
 *  
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *  
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 * DEALINGS IN THE SOFTWARE.
 * 
 */

/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, brackets, $ */

define(function (require, exports, module) {
    "use strict";

    // Brackets modules
    var AppInit                     = brackets.getModule("utils/AppInit"),
        ProjectManager              = brackets.getModule("project/ProjectManager"),
        FileSystemEntry             = brackets.getModule("filesystem/FileSystemEntry"),
        ProjectModel                = brackets.getModule("project/ProjectModel"),
        ExtensionUtils = brackets.getModule("utils/ExtensionUtils"),
        CommandManager              = brackets.getModule("command/CommandManager"),
        Menus                       = brackets.getModule("command/Menus"),
        FileUtils                   = brackets.getModule("file/FileUtils"),
        DefaultDialogs              = brackets.getModule("widgets/DefaultDialogs"),
        FileSystem              = brackets.getModule("filesystem/FileSystem"),
        Dialogs                     = brackets.getModule("widgets/Dialogs");

    var MODULE_NAME                 = "Create Module";

    var MENU_CMD_CREATE          = "angular.moduler";
    var MENU_ITEM_CREATE         = "Create Module";

    ExtensionUtils.loadStyleSheet(module, "style.css");
    var template = require('text!template.html');
    var templates = {};
    var prefix = "";
    var optionModal = null;
    var location;

    var values = {
        moduleName: "test",
        moduleFullName: "test.full.name"
    };

    var files = [
        '.module.js',
        '.controller.js',
        '.controller.spec.js',
        '.directive.js',
        '.directive.spec.js',
        '.route.js', 
        '.css',
        '.html'
    ];

    fetchTemplates(files);

    function fetchTemplates(files){

        var filenames = [];
        for(var i in files){

            var file = files[i];

            // filenames.push('text!templates/' + file.substring(1));

            require(['text!templates/' + file.substring(1)], function(content){
                var match = content.match(/\[(.*)\]/);
                
                if(!match)
                    match = ["", "file"];

                templates[match[1]] = content.substring(content.indexOf("]") + 1);
                
            }); 


        }

        setTimeout(function(){
            console.log(templates);
        },1000)



        // console.log(new FileSystemEntry("C:/npm-debug.log"));


    }

    function createModule(){

        var dir = ProjectManager.getSelectedItem();

        if(!dir._isDirectory)
            return;

        prefix = dir._path.match(/.*(app\/.*)\//)[1].replace(/\//g, ".");

        if(optionModal == null)
            optionModal = renderTemplate();
        else
            hookEvents(optionModal);

        Dialogs.showModalDialogUsingTemplate(optionModal);

        $(".angular-moduler-options #module-prefix").val(prefix);

        location = dir._path;

        console.log(location);



        var res = Mustache.render(templates, values);

        console.log(res);

    }

    function hookEvents(dialog){
        
        dialog.find("#module-name").on("keyup", function(){

            dialog.find(".filename").html(event.target.value);
            console.log(event.target.value);
            updateModuleName();
        });

        dialog.find("#module-prefix").on("keyup", function(){
            updateModuleName();
        });


        dialog.find("#create-module").on("click", function(){

            Create();

        });
    }

    function renderTemplate(){

        var dialog;

        dialog = $(template);
        var selections = dialog.find(".selections");

        $.each(files, function(i,e){
            console.log(i + ", " + e);
            var label = $("<label></label>");
            label.append("<input type='checkbox' value='"+e+"'/>");
            label.append("<span class='filename'>app<span>");
            label.append(e);

            selections.append(label);
        });

        hookEvents(dialog);

        return dialog;
    }

    function Create(){
        
        var name = $(".angular-moduler-options #module-name").val();
        ProjectManager.createNewItem(location, name, false, true);



        var files = [];

        $(".angular-moduler-options .selections input[type='checkbox']:checked").each(function(i,e){
            
            ProjectManager.createNewItem(location + "/" + name, name + e.value, false, false);
            files.push({
                filename: location + name + "/"  + name + e.value,
                key: e.value
            });
        });


        values.templateUrl = location + name + "/" + name + ".html";
        values.templateUrl = values.templateUrl.replace(/.*(app.*)/, "$1");

        ProjectManager.refreshFileTree()

        var rendered = {};

        $.each(templates, function(i,e){
            rendered[i] = Mustache.render(e, values);
        });

        console.log(rendered);

        setTimeout(function(){    
            
            // console.log(FileUtils);
            
            $.each(files, function(i,e){
                console.log(e.filename + ", " + e.key);    
                var file = FileSystem.getFileForPath(e.filename);//new FileSystemEntry(e.filename);
                // console.log(file);
                file.write(rendered[e.key]);
                // FileUtils.writeText(file, rendered[e.key] );

            });
            // console.log(ProjectModel);
            // ProjectModel.setDirectoryOpen(location + '/' + name);  

        },500);
        
    }


    function updateModuleName(){

        var name = $(".angular-moduler-options #module-name").val();
        var prefix = $(".angular-moduler-options #module-prefix").val();

        name = filterString(name);
        prefix = filterString(prefix);

        $(".angular-moduler-options #module-full-name").html(prefix + "." + name);



        values.moduleName = name;
        values.moduleFullName = prefix + "." + name;
        values.moduleBrokenName = breakCamelCase(name);
        values.controllerName = removePrefix(name);
        values.templateUrl = "";
    }

    function removePrefix(str){
        return str.replace(/^[a-z]*([A-Z].*)/, "$1");
    }

    function filterString(str){

        str = str.charAt(0).toLowerCase() + str.slice(1);
        str = str.replace(/[^a-z0-9A-Z\.]/, "");

        return str;
    }

    function breakCamelCase(str){
        return str.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
    }

    // Initialize extension once shell is finished initializing.
    AppInit.appReady(function () {
        
        // Add to project context menu
        var cmdDuplicate = CommandManager.register(MENU_ITEM_CREATE, MENU_CMD_CREATE, createModule);
        
        var menu = Menus.getContextMenu(Menus.ContextMenuIds.PROJECT_MENU);

        menu.addMenuItem(MENU_CMD_CREATE);

    });
    
});

