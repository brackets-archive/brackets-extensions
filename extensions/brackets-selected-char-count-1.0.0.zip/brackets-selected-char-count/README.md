brackets-selected-char-count
=========================

Shows the number of selected chars (not lines) on the fotter.

By default if more than one line is selected Brackets only shows the number of selected lines, now it will also show the number of selected chars.

## Getting Started ##

1. Open Extension Manager by clicking the building-blocky icon on the right side of Brackets;
2. Search for Selected Char Count;
3. Click Install;
4. Done =)
   
