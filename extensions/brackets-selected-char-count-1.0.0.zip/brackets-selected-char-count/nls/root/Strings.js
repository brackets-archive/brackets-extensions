/*jshint node: true*/
/* globals define*/
define( {
	// EXTENSION.
	EXTENSION_NAME: "Selected Char Counter",

    // $counter selected chars
    FOOTER_LABEL: "selected chars"

} );
