# Color Merge

Brackets extension that finds all colors from the document and let's you choose and merge similar colors.

All selected color values will be set to the last selected color value.

![Color Merge](/images/screenshot.png?raw=true "Color Merge")