# brackets-esnext-highlight

A Brackets extension to enable ECMAScript 6/7 highlighting. To install, place in your ```brackets/src/extensions/user``` folder.

Supported features beyond standard Javascript language highlighting:

  * async/await keywords
