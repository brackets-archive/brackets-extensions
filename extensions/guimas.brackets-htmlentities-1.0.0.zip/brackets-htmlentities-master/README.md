Html Entities Encoder
======

An extension for [Brackets](https://github.com/adobe/brackets/) for encoding special chars for HTML pages.

### How to use Html Entities Encoder
Select the text you want to convert and press Cmd-& (or Ctrl-& in Windows)

**Example:**

    + "Concentração" becomes "Concentra&ccedil;&atilde;o"
    + "§5" becomes "&sect;5"
    
***
Tested on Brackets Sprint 40, OSX 10.9
