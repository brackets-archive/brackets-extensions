# Guacamayo theme
Readable and high-contrast dark theme for brackets.

##Screenshots

###HTML
![HTML Screenshot](screenshots/html.png)
###CSS
![CSS Screenshot](screenshots/css.png)
###JavaScript
![JavaScript Screenshot](screenshots/js.png)
