/*global $, brackets, define, require, exports, module*/

define(function (require, exports, module) {
  "use strict";

  require("src/autocomplete");
  require("src/highlight");
  require("src/snippet");
  require("src/lint");

});
