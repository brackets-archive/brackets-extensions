#### brackets-theme-darktooth

This is a port of the [Darktooth theme for Emacs](https://github.com/emacsfodder/emacs-theme-darktooth), which was
created by [jasonm23](https://github.com/jasonm23).

__Installation:__ The easiest method of installation is via the extension manager, which is built in to Brackets. This
theme can also be installed by placing the brackets-theme-darktooth folder in the extensions folder (Help > Show
Extensions Folder, then open the folder named "user" and paste this folder in that directory).

#### Other information
To see a preview screenshot, please visit the GitHub repository for this theme:
https://github.com/Poorchop/darktooth-theme-ports/tree/master/brackets-theme-darktooth
