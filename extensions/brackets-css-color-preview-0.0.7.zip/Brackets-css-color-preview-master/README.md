Brackets-css-color-preview
==========================

css color preview extension for Brackets
<h3>
<a id="user-content-features" class="anchor" href="#features" aria-hidden="true"><span class="octicon octicon-link"></span></a>Features</h3>
<ol class="task-list">
<li><p>Css color preview whithin css file.</p></li>
<li><p>You can toggle the enabled of this extension from the view menu.</p></li>
</ol>
<p><img src="https://github.com/cmgddd/Brackets-css-color-preview/blob/master/screenshot.png" alt="screenshot"/></p>
<h3>
<a id="user-content-how-to-install" class="anchor" href="#how-to-install" aria-hidden="true"><span class="octicon octicon-link"></span></a>How to install</h3>
<p>Navigate to <strong>Brackets &gt; File &gt; Install Extension</strong> and paste url <a href="https://github.com/cmgddd/Brackets-css-color-preview">https://github.com/cmgddd/Brackets-css-color-preview</a></p>
<h4>
<a id="user-content-or-manually" class="anchor" href="#or-manually" aria-hidden="true"><span class="octicon octicon-link"></span></a>Or manually</h4>
<ol class="task-list">
<li><a href="https://github.com/cmgddd/Brackets-css-color-preview/archive/master.zip">Download</a></li>
<li>Unzip in <strong>user</strong> folder in <strong>Brackets &gt; Help &gt; Show Extensions Folder</strong>
</li>
<li>Restart or Reload Brackets</li>
</ol>
<h2>
<a id="user-content-known-issues" class="anchor" href="#known-issues" aria-hidden="true"><span class="octicon octicon-link"></span></a>Known Issues</h2>
<h3>
<a id="user-content-license" class="anchor" href="#license" aria-hidden="true"><span class="octicon octicon-link"></span></a>License</h3>
<p>MIT-licensed.</p>
