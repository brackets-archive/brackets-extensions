#Brackets Theme - Solarized Dark

The excellent [Solarized Dark](http://ethanschoonover.com/solarized) theme for [Brackets](http://brackets.io/).

<hr>

![Solarized Dark Brackets Theme](screenshot.png)
