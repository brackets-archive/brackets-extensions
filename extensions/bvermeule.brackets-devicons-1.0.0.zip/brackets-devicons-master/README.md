# Brackets Devicons
File tree icons for [Brackets](http://brackets.io) based on [Devicons](https://github.com/vorillaz/devicons) font. Inspired by [Brackets Icons](https://github.com/ivogabe/Brackets-Icons) and [Brackets File Icons](https://github.com/drewbkoch/Brackets-File-Icons).

## Screenshots

![Brackets Devicons](https://raw.githubusercontent.com/bvermeule/brackets-devicons/master/screenshots/screenshot.png)
