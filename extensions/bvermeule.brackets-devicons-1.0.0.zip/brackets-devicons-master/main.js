/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window */

define(function (require, exports, module) {
    "use strict";
    
    var exts = {};
    exts.brackets       = '\ue69d';
    exts.js             = '\ue64e';
    exts.json           = '\ue64e';
    exts.css            = '\ue64a';
    exts.py             = '\ue63c';
    exts.pyc            = '\ue63c';
    exts.pyd            = '\ue63c';
    exts.pyo            = '\ue63c';
    exts.htm            = '\ue636';
    exts.html           = '\ue636';
    exts.php            = '\ue63d';
    exts.phtml          = '\ue63d';
    exts.php3           = '\ue63d';
    exts.php4           = '\ue63d';
    exts.php5           = '\ue63d';
    exts.phps           = '\ue63d';
    exts.gitignore      = '\ue602';
    exts.gitattributes  = '\ue602';
    exts.gitmodules     = '\ue602';
    exts.md             = '\ue63e';
    exts.sass           = '\ue64b';
    exts.scss           = '\ue64b';
    exts.conf           = '\ue696';
    exts.htaccess       = '\ue696';
    exts.htpasswd       = '\ue696';
    exts.project        = '\ue696';
    exts.bat            = '\ue696';
    exts.sh             = '\ue696';
    exts.command        = '\ue696';
    exts.less           = '\ue658';
    exts.sql            = '\ue606';
    exts.java           = '\ue638';
    exts.jar            = '\ue638';
    exts.rb             = '\ue639';
    exts.rbw            = '\ue639';
    exts.coffee         = '\ue651';
    exts.styl           = '\ue659';
    exts.npmignore      = '\ue61e';
    exts.scala          = '\ue637';
    exts.sc             = '\ue637';
    exts.go             = '\ue624';
    exts.bowerrc        = '\ue64d';
    exts.swift          = '\ue655';
    exts.sln            = '\ue60c';
    exts.pl             = '\ue669';
    exts.pm             = '\ue669';
    exts.hs             = '\ue677';
    exts.lhs            = '\ue677';
    exts.psd            = '\ue6b8';
    exts.ai             = '\ue6b4';
    
    var files = {};
    files['gruntfile.js']   = '\ue64c';
    files['package.json']   = '\ue61e';
    files['gemfile']        = '\ue639';
    files['gulpfile.js']    = '\ue663';
    
    var extensionUtils = brackets.getModule('utils/ExtensionUtils');
    var fileUtils = brackets.getModule('file/FileUtils');

    extensionUtils.loadStyleSheet(module, 'css/main.css');

    var iconProvider = function (entry) {

        if (!entry.isFile) {
            return;
        }

        var ext = fileUtils.getSmartFileExtension(entry.fullPath) || entry.name.substr(1);
        var filename = fileUtils.getBaseName(entry.fullPath).toLowerCase();

        var el = $('<span>');
        el.addClass('bd-icon');
        el.text(exts.brackets);

        if (exts[ext]) {
            el.text(exts[ext]);
        }

        if (files[filename]) {
            el.text(files[filename]);
        }

        return el;
    };
    
    var workingSetView = brackets.getModule('project/WorkingSetView');
    var fileTreeView = brackets.getModule('project/FileTreeView');
    
    workingSetView.addIconProvider(iconProvider);
    fileTreeView.addIconProvider(iconProvider);
});