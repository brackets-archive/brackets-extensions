# Cobalt2-brackets Syntax

Cobalt2, Sublime Text theme, ported to brackets

brackets syntax theme based Atom cobalt2 - <https://github.com/wesbos/cobalt2-atom>


![Screenshot](https://github.com/CRY-D/Cobalt2-brackets/raw/master/css.png)
![Screenshot](https://github.com/CRY-D/Cobalt2-brackets/raw/master/html.png)
![Screenshot](https://github.com/CRY-D/Cobalt2-brackets/raw/master/js.png)

Preferences:

1. Go to `Help > Show Extensions Folder` and 
2. Download this repo ` Cobalt2-brackets` and move it to Extensions Folder
3. Go to `View > Themes` and choose Cobalt2 as the syntax theme
