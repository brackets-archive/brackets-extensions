# Change Log
All notable changes to this project will be documented in this file.

## 0.4.0 - 2016-11-11
### Changed
- Update to Brackets 1.8 API


## 0.3.2 - 2015-08-30
### Fixed
- Included missing image in archive


## 0.3.1 - 2015-08-24
### Added
- Names and Descriptions for preferences


## 0.3.0 - 2015-04-06
### Added
- Darker Line for Brackets Dark Theme


## 0.2.0 - 2015-03-17
### Changed
- Update to Brackets 1.2 API


## 0.1.2 - 2015-02-18
### Fixed
- Print Margin is set to the configured value after editor changes (see [#4](https://github.com/Hirse/brackets-print-margin/issues/4))


## 0.1.1 - 2015-02-13
### Added
- Italian Translation, thanks to [__@Denisov21__](https://github.com/Denisov21)
