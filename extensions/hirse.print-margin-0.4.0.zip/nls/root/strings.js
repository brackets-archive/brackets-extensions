define({
    STATUSBAR_LABEL:        "Print Margin:",
    STATUSBAR_NUMBER_TITLE: "Click to change column of print margin",

    PREF_COLUMN_NAME:       "Print Margin - Column Number",
    PREF_COLUMN_DESC:       "Column of the print margin"
});
