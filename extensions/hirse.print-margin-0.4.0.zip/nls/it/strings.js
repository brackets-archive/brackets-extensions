define({
    STATUSBAR_LABEL:        "Margine stamapante:",
    STATUSBAR_NUMBER_TITLE: "Clicca per cambiare la colonna margine stampante"
});

/* Last translated for be56ca66626a11b7c2709ba3107881cab4e09e60 */
