define({
    STATUSBAR_LABEL:        "Print Margin:",
    STATUSBAR_NUMBER_TITLE: "Klicken, um die Spalte des Seitenrandes zu ändern",

    PREF_COLUMN_NAME:       "Print Margin - Spalte",
    PREF_COLUMN_DESC:       "Spalte des Seitenrandes"
});
