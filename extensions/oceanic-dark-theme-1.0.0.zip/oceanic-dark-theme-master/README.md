# Oceanic Dark Theme for Brackets

Inspired by Oceanic Dark Theme on Codepen.

WIP (Javascript Syntax will be made much prettier!)

## Installation

* Open the Extension Manager in Brackets
* Switch to "Themes" tab
* Search for "Oceanic Dark Theme"
* Click "Install"

## Javascript
![JS Screenshot](https://github.com/kaisiemek/oceanic-dark-theme/blob/master/screenshot/js-screenshot.png)
## HTML
![HTML Screenshot](https://github.com/kaisiemek/oceanic-dark-theme/blob/master/screenshot/html-screenshot.png)
## CSS
![CSS Screenshot](https://github.com/kaisiemek/oceanic-dark-theme/blob/master/screenshot/css-screenshot.png)
