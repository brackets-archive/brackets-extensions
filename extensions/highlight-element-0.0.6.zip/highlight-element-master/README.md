# highlight-element

A Brackets extension that highlights variables in your code when selected.

Only woks with Highlight Active Line turned on.

![alt tag](https://raw.githubusercontent.com/Fraser-Greenlee/highlight-element/master/promo.png)
