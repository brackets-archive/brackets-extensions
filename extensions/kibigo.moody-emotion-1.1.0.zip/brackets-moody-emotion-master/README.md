#  Brackets Moody Emotion

by kibigo!

![Screenshot of Brackets Moody Emotion](screenshots/screenshot01.png)
