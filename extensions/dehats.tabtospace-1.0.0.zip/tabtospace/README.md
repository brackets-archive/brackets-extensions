Brackets Tab to space
=================

A brackets extension to convert tab based identation to space based identation and vice versa.

To install, place the ```tabtospace``` folder inside the ```brackets/src/extensions/user``` folder.

**Compatible with Brackets Sprint10**


Usage
=====

Simply open a project in Brackets, and select ```Convert indentation to spaces``` or ```Convert indentation to tabs``` from the ```File``` menu.

This will replace tabs with N spaces, and replace each group of N spaces with a tab (N being the tab length defined in the editor, 4 being the default).
