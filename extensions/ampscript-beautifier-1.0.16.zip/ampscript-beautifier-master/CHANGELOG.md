# AMPscript Beautifier Changelog
All notable changes to this project will be documented in this file.

## 1.0.14 - 08/06/2017
* Fixed bug with additional whitespace being added after commas
* Refactored outputSpacer function for easier understanding

## 1.0.16 - 15/08/2017
* Ignores processing of %%=v()=%%
* Adds space after operators like AND or OR
* Doesn't add a space before a comma anymore