Projects
========

An extension for Brackets IDE to manage projects.

![instructions](http://content.screencast.com/users/dnbard/folders/Jing/media/fcc64935-fea7-4fc3-91e9-feea0507d6a5/2014-10-02_1612.png)

![image](http://content.screencast.com/users/dnbard/folders/Jing/media/e423ab97-7aa3-4760-b380-0c67d82acd67/2014-10-02_1608.png)

## Keyboard Shortcuts

* `alt+p` Opens the projects modal
* When in the modal window, you can use `up` and `down` to select projects
