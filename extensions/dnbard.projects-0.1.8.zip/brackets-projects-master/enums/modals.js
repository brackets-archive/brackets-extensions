define({
    GENERAL: 'modal.general',
    OPTIONS: 'modal.options'
});
