brackets-moonlitglaciertheme
============================

A dark theme with light blue highlights for use with the Brackets Web Editor.

## HTML
![HTML Screenshot](https://github.com/Phantomwalker/brackets-moonlitglaciertheme/blob/master/screenshots/html.png)

## PHP
![PHP Screenshot](https://github.com/Phantomwalker/brackets-moonlitglaciertheme/blob/master/screenshots/php.png)

## CSS
![CSS Screenshot](https://github.com/Phantomwalker/brackets-moonlitglaciertheme/blob/master/screenshots/css.png)

## Javascript
![Javascript Screenshot](https://github.com/Phantomwalker/brackets-moonlitglaciertheme/blob/master/screenshots/javascript.png)
