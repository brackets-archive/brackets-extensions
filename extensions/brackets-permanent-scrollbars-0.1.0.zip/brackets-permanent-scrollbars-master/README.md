# brackets-permanent-scrollbars

Makes the file list scrollbars always visible

Compatible with release 44 and above