###Versions
## 0.0.6
* Small bugfix where {0} replaced with #000 ended up with #0000

## 0.0.5
* Spanish translation
* Added option to change text color

## 0.0.4
* Added optional scope for the project name settings

## 0.0.3
* (Bugfix) Init `namedProjects` with an empty object if it doesn't exits yet

## 0.0.2
* Basic functionality included
  * First public release!
  * Added support for background colors (hex or name) for project names

## 0.0.1
* Basic functionality included
  * Naming Projects
  * Saving names to `brackets.json` via Preferences
  * Localized to English and Finnish
  