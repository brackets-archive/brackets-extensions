define({
    "PROJECT_NAME": "Projektin Nimi",
    "PROJECT_DIALOG_TITLE": "Projektin nimi kohteelle {0}",
    "PROJECT_BACKGROUND_COLOR": "Taustaväri (heksa-, hsl, rgba tai nimiarvo)",
    "PROJECT_TEXT_COLOR": "Tekstinväri (heksa-, hsl, rgba tai nimiarvo)",
    "PROJECT_SETTINGS_SCOPES": {
      "TITLE": "Laajuus:",
      "DEFAULT": "Oletusarvo",
      "USERGLOBAL": "Käyttäjä-globaali",
      "PROJECT": "Projekti-taso"
    }
});