define({
    "PROJECT_NAME": "Project Name",
    "PROJECT_DIALOG_TITLE": "Project Name for {0}",
    "PROJECT_BACKGROUND_COLOR": "Background colour (Hex, hsla, rgb or name)",
    "PROJECT_TEXT_COLOR": "Text colour (Hex, hsla, rgb or name)",
    "PROJECT_SETTINGS_SCOPES": {
      "TITLE": "Scope:",
      "DEFAULT": "Default",
      "USERGLOBAL": "User-global",
      "PROJECT": "Project level"
    }
});