define({
    "PROJECT_NAME": "Nome progetto",
    "PROJECT_DIALOG_TITLE": "Nome progetto per {0}",
    "PROJECT_BACKGROUND_COLOR": "Colore di sfondo (hex, hsla, rgba o nome)",
    "PROJECT_TEXT_COLOR": "Colore del testo (Hex, hsla, rgb o nome)",
    "PROJECT_SETTINGS_SCOPES": {
      "TITLE": "Scope:",
      "DEFAULT": "Default",
      "USERGLOBAL": "User-global",
      "PROJECT": "Project level"
    }
});
