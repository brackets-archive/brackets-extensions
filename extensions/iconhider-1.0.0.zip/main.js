define(function (require, exports, module) {
    "use strict";
    
    $("#toolbar-go-live").css({display: "none"});
    $("#toolbar-extension-manager").css({display: "none"});
});
