Dreamweaver's wombat color scheme for Brackets.
============================

based on Vlad Saling's [Wombatish](https://github.com/vlad-saling/wombatish)

Current applied styles:
HTML, CSS, SCSS, LESS, JS, JSON, PHP. 

## Screenshot

![PHP-js screenshot](https://raw.githubusercontent.com/ignacionelson/dreamweaver-wombat/master/screenshot.png)


## Changelog

v 1.0.2: Tweaked the selected text background color again :)
v 1.0.1: Tweaked the selected text background color
v 1.0.0: Initial commit

## License

The MIT License. Read [LICENSE](LICENSE) for further information.
