# Hazard-Droid-Dark-Theme
* An Awesome Brackets Theme(Dark Version) Created By <a href="http://www.techdudez.tk">Hazard Droid</a>.

# How to install
Visit <a href="http://brackets-themes.github.io/">Here</a> To See The Latest Installation Instructions.

# License
* Theme under MIT license [`LICENSE`](LICENSE)

# Screenshot

### HTML

![HTML Screenshot](https://github.com/YasirRehman2017/Hazard-Droid-Dark/blob/master/html.PNG)

### CSS

![CSS Screenshot](https://github.com/YasirRehman2017/Hazard-Droid-Dark/blob/master/css.PNG)
