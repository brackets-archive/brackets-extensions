Brackets Tabs
===============

Gives you the option to use tabs rather than the sidebar for working files

How to use
=======

To enable the tab interface choose "Show tabs" in the View menu. Choosing it again will disable it.
