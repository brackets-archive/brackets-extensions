![brackets logo](https://cloud.githubusercontent.com/assets/6317005/12852935/6082a77a-cc29-11e5-910d-3947bcd2b535.png)
#Brackets-rightClick 
Although it's ready to use, it's still considered a work in progress. Feel free to jump in, if you think you can contribute!

Issues, suggestions, or anything of the nature [here] (https://github.com/i07/rightClick/issues).
***
To install.

- use brackets Extensions manager ( tip: search for 'copy' )
- or manually through extension manager by URL: https://github.com/i07/rightClick/archive/master.zip

***
It's all basic JS, no dependencies, so light weight and just does the job! :)
