<h3>bluePrint Beta</h3>
<br>
<p>Blueprint is a hierarchic outline view and code minimap extension for brackets.</br>
In the outliner currently only JavaScript, HTML, CSS and python are supported.
</p>
<p>
ideas and suggestions are welcome, please feel free to create an issue.
</p>