# brackets-dockerfile-extension
Dockerfile highlighting support for brackets

This extension add highlighting support for Dockerfiles in the editor Brackets.

##How to install
The extension can be directly installed using the Extension Manager of Brackets.

1. File -> Extension Manager 
2. Search for Dockerfile 
3. Click install on Dockerfile Syntax Highlighter

You can see that the extension has loaded successfully when Dockerfile can be selected in the lower right corner or when opening a Dockerfile.

Maybe Brackets must be reloaded. Happy Dockerizing!

This extension is registered via [Brackets Extension Registry](https://brackets-registry.aboutweb.com).
