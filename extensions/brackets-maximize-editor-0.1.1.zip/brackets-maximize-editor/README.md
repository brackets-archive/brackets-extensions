# Brackets Maximize Editor

To install, search for "Maximize Editor" on Brackets Extention Manager, then click Install.

To toggle active editor, go to View > Maximize Editor or use shortcut Command+Shift+Enter (Mac)/Control+Shift+Enter (Windows).

Have fun coding ;-)
