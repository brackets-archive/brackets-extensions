# Flattark (a Brackets Theme)

### Flattark is a minimal dark Theme for [Brackets](http://brackets.io/)
#### It is based on [Slickrock](https://github.com/NicoM1/Slickrock) with custom colors
## See
*A dark, minimal theme for the Brackets text-editor.*
![JS](./scrot-js.png)
![LESS](./scrot-less.png)
