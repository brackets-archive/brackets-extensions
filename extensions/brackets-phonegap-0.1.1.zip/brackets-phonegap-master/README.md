PhoneGap Extension for Brackets
==============================

Readme content coming very soon...

Notices, terms and conditions pertaining to third party software are located at http://www.adobe.com/go/thirdparty/ and incorporated by reference herein.
