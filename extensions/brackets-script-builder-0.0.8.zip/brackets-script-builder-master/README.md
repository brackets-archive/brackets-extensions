brackets-script-builder
=======================
Brackets Script Builder

Allows to run programs contained in one file (can be used for Scala, Java, Python, Ruby, Node, C++, Bash) from Brackets and display results in panel.
It is possible to create own build systems via 'Edit > Script Builder Configuration' menu item and editing opened JSON file
(you need to restart Brackets afterwards). 

Based on Brackets Builder (http://github.com/Vhornets/brackets-builder). 


Keyboard shortcuts: 
 * F9 to run current file as a script. 
 * F10 to compile current file. 
 * F11 to run compilation result. 
 