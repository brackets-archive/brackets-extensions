An extension for Adobe Brackets editor
# Hide Status Bar

DESCRIPTION: Adds a status bar visibility switch to the View menu

VERSION: Tested in Feb 2021 for Brackets Editor of version 1.14.2 on Windows 10

STORY: I created this because I don’t use it much. It is my second plugin.

FUNCTIONALITY: I don’t know, I mean it contains some event listeners which
watches the preferences and then performs hide/show function of status
bar module.

AUTHOR:
Graphic designer
& amateur fullstack developer

Jiří Dvořák