# brackets-cucumber
Gherkin/Cucumber/Feature files editor for Brackets, with beautify, row inserting in tables...

## Features:
* Syntax highlight
* Beautify/Formater on saving including column realignments in examples
* Line inserting in examples


## TODO:
* Change line insert in examples from Ctrl+P to enter (how to do this with CodeMirror in Brackets?)
* Line deleting
