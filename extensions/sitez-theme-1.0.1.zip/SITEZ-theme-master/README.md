# SITEZ-theme
A nice dark theme with neon colors to keep your eyes interested and focused late at night. For Adobe Brackets.

Feel free to pull an submit any fixes/changes!
