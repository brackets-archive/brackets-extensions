#Epic Light
Have an epic day with the Epic Light theme, an nice and elegant light theme.
#Installation
1. Open Brackets
2. Open the Extension Manager
3. Navigate to the "Themes" tab
4. Search, "Epic Light"
5. Click install on the theme titled, "Epic Light"
6. Go to View > Themes and select the Epic Light theme.

#HTML
<a href="http://imgur.com/2uanxXW"><img src="http://i.imgur.com/2uanxXW.png" title="source: imgur.com" /></a>
#CSS
<a href="http://imgur.com/3MbD3tb"><img src="http://i.imgur.com/3MbD3tb.png" title="source: imgur.com" /></a>
#JavaScript
<a href="http://imgur.com/raEDwg4"><img src="http://i.imgur.com/raEDwg4.png" title="source: imgur.com" /></a>
