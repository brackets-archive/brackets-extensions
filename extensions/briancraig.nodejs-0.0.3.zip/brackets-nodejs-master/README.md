briancraig.nodejs
===============

Esta es una extensión que te permite manejar las aplicaciones de NodeJS directamente desde Brackets

Para iniciar una aplicación, haz click en el ícono de nodejs de la derecha

Atención :  esta extensión esta en una etapa experimental