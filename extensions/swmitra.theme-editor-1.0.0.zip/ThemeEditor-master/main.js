/*
 * Copyright (c) 2015 - present Adobe Systems Incorporated. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, brackets, $*/

define(function (require, exports, module) {
    "use strict";

    require("lib/jquery-ui-1.10.3.custom");
    require("lib/bootstrap-colorpicker/js/bootstrap-colorpicker");

    // Load dependencies.
    var AppInit             = brackets.getModule("utils/AppInit"),
        CodeHintManager     = brackets.getModule("editor/CodeHintManager"),
        PreferencesManager  = brackets.getModule("preferences/PreferencesManager"),
        StringMatch         = brackets.getModule("utils/StringMatch"),
        DocumentManager     = brackets.getModule("document/DocumentManager"),
        ExtensionUtils      = brackets.getModule("utils/ExtensionUtils"),
        EditorManager       = brackets.getModule("editor/EditorManager"),
        LanguageManager     = brackets.getModule("language/LanguageManager"),
        JSONUtils           = brackets.getModule("language/JSONUtils"),
        Strings             = brackets.getModule("strings"),
        ThemeManager        = brackets.getModule("view/ThemeManager"),
        CodeInspection      = brackets.getModule("language/CodeInspection"),
        _                   = brackets.getModule("thirdparty/lodash"),
        languages           = LanguageManager.getLanguages(),
        Commands            = brackets.getModule("command/Commands"),
        CommandManager      = brackets.getModule("command/CommandManager"),
        FileSystem          = brackets.getModule("filesystem/FileSystem"),
        ThemeManager        = brackets.getModule("view/ThemeManager"),
        template            = require("text!themeTemplate.html"),
        packageJSONTxt      = require("text!package-json-template.json");

    var PreferencesManager = brackets.getModule("preferences/PreferencesManager"),
        prefs              = PreferencesManager.getExtensionPrefs("themes");

    var _themeStyleSheet;
    var RGB_REGEX = /rgb\((\d{1,3}), (\d{1,3}), (\d{1,3})\)/;

    var _themeName = "#editor-holder.dwTheme ";

    var beautify_css = require('lib/beautify/beautify-css').css_beautify;

    var config = JSON.parse(require('text!lib/beautify/config/defaults.json'));

    function _getCSSText(rule) {
        var text = rule.selectorText + " { @name : @colorval; }";
        var prop = rule.style[0];
        var propval = rule.style[prop];
        var rgb = RGB_REGEX.exec(propval);

        if (rgb) {
            propval = "#" +
                ("0" + parseInt(rgb[1], 10).toString(16)).slice(-2) +
                ("0" + parseInt(rgb[2], 10).toString(16)).slice(-2) +
                ("0" + parseInt(rgb[3], 10).toString(16)).slice(-2);
        }

        return text.split("@name").join(prop).split("@colorval").join(propval);
    }

    function _beautifyCSSAsText(styleSheet) {
        var styleText = [], i;
        for (i in styleSheet.rules) {
            if (styleSheet.rules[i].cssText) {
                styleText.push(_getCSSText(styleSheet.rules[i]));
            }
        }
        styleText = styleText.join('\n').split(';').join(';\n').split('{').join('\n{\n').split('}').join('\n}\n');
        styleText = styleText.split(_themeName).join("");
        styleText = beautify_css(styleText, config);

        return styleText;
    }

    function _formatCSSAsText(styleSheet) {
        var styleText = [], i;
        for (i in styleSheet.rules) {
            if (styleSheet.rules[i].cssText) {
                styleText.push(styleSheet.rules[i].cssText);
            }
        }

        styleText = styleText.join('');
        styleText = styleText.split("\n").join("");

        return styleText;
    }

    function _createCSSText(context) {
        if (!context.value) {
            return "";
        }

        if ($(context).data("csstemplate")) {
            return $(context).data("csstemplate").split("@color").join(context.value).split("@dwTheme").join(_themeName);
        } else {
            return _themeName + "." + context.id + " { color: " + context.value + "; }";
        }
    }

    function _findThemeStyleSheet() {
        var styleSheets = document.styleSheets;
        var sheetCount, setCount, styleSheet, ruleSets, ruleSet;
        var ref;
        for (sheetCount = 0; sheetCount < styleSheets.length && !ref; sheetCount++) {
            styleSheet = styleSheets[sheetCount];
            if (styleSheet.title === "MyStyleSheet") {
                _themeStyleSheet = styleSheet;
            }
        }
    }

    function _applyRule(ruleName, cssText) {
        var setCount, ruleSets, ruleSet, ref;
        ruleSets = _themeStyleSheet.rules;
        for (setCount = 0; setCount < ruleSets.length && !ref; setCount++) {
            ruleSet = ruleSets[setCount];
            if (ruleSet.selectorText === ruleName) {
                _themeStyleSheet.deleteRule(setCount);
                break;
            }
        }

        if (cssText) {
            _themeStyleSheet.insertRule(cssText, 0);
        }

        var styleText = _formatCSSAsText(_themeStyleSheet);
        _themeStyleSheet.ownerNode.innerText = styleText;
        _findThemeStyleSheet();
    }

    function _highlightSelectors() {
        $("#theme-param-list>li.highlight").removeClass("highlight");
        var classList = $(this).attr('class').trim().split(/\s+/);
        var color = $(this).css("color");
        $.each(classList, function (index, item) {
            $("input#" + item).parent().addClass("highlight");
        });
    }

    function _toggleThemeEditor() {
        if ($(".themed").length === 0) {
            _findThemeStyleSheet();
            $("#editor-holder").addClass("themed");
            $("#editor-holder").addClass("dwTheme");
            $(".CodeMirror:visible .CodeMirror-code").css("pointer-events", "all");
            $(document).on('mousedown', "pre.CodeMirror-line>span>*", _highlightSelectors);
            $("#theme-param-list li input").colorpicker()
                .on('changeColor.colorpicker', function () {
                    $(this).trigger("change");
                });
            $("#codeview-param-list li input").colorpicker()
                .on('changeColor.colorpicker', function () {
                    $(this).trigger("change");
                });
        } else {
            _themeStyleSheet = null;
            $(".themed").removeClass("themed");
            $("#editor-holder").removeClass("dwTheme");
            $(".CodeMirror:visible .CodeMirror-code").css("pointer-events", "none");
            $(document).off('mousedown', "pre.CodeMirror-line>span>*", _highlightSelectors);
        }
    }

    function _resetTheme() {
        _themeStyleSheet.ownerNode.innerText = "";
        $("#theme-param-list li input").val("");
        $("#codeview-param-list li input").val("");
        $("#theme-param-list>li.highlight").removeClass("highlight");
        _findThemeStyleSheet();
    }

    function _copyToEditor() {
        var themeName = $("#theme-name").val().split(/\s/).join(""),
            extensionsDir = brackets.app.getApplicationSupportDirectory() + "/extensions/user/",
            thisExtensionDir = extensionsDir + themeName;

        var dir = FileSystem.getDirectoryForPath(thisExtensionDir);
        dir.create(function () {
            var cssFile = FileSystem.getFileForPath(thisExtensionDir + "/main.less");
            var currentTheme = ThemeManager.getCurrentTheme();
            if (currentTheme && currentTheme.file) {
                currentTheme.file.read(function() {
                    cssFile.write(arguments[1] + "\n" + _beautifyCSSAsText(_themeStyleSheet), {}, function() {
                        ThemeManager.loadFile(thisExtensionDir + "/main.less", JSON.parse(packageJSONTxt.split("{{theme-name}}").join(themeName))).done(function() {
                            _resetTheme();
                            _toggleThemeEditor();
                            prefs.set("theme", themeName);
                        });
                    });
                });
            }
            var jsonFile = FileSystem.getFileForPath(thisExtensionDir + "/package.json");
            jsonFile.write(packageJSONTxt.split("{{theme-name}}").join(themeName), {}, function() {
                //no-op now
            });
        });

        /*CommandManager.execute(Commands.FILE_NEW_UNTITLED);
        setTimeout(function () {
            DocumentManager.getCurrentDocument().setText(_beautifyCSSAsText(_themeStyleSheet));
        }, 200);*/
    }

    $(document).on("click", "#export-theme", _copyToEditor);

    $(document).on("click", "#new-theme", _resetTheme);

    //$(document).on("click", "#th-toggle", _toggleThemeEditor);

    $(document).on('change', "#theme-param-list li input", function () {
        _applyRule(_themeName + "." + this.id, _createCSSText(this));
    });

    $(document).on('change', "#codeview-param-list li input", function () {
        _applyRule($(this).data("selector").split("@dwTheme").join(_themeName), _createCSSText(this));
    });

    AppInit.appReady(function () {
        $("#editor-holder").append(template);
        //$('#first-pane').append("<div id='th-toggle'></div>");

        $(document.createElement("a"))
            .attr("id", "theme-settings-icon")
            .attr("href", "#")
            .attr("title", "Theme editor")
            .on("click", _toggleThemeEditor)
            .appendTo($("#main-toolbar .buttons"));

        ExtensionUtils.loadStyleSheet(module, "lib/jquery-ui-1.10.3.custom.css");
        ExtensionUtils.loadStyleSheet(module, "lib/bootstrap/css/bootstrap.css");
        ExtensionUtils.loadStyleSheet(module, "lib/bootstrap-colorpicker/css/bootstrap-colorpicker.css");
        ExtensionUtils.loadStyleSheet(module, "themes.css");
    });

});
