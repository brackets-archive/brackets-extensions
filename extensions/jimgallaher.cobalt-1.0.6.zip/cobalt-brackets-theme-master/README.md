# Cobalt-bracket-theme

Cobalt for Brackets is based on Sublime Text's and Atom's Cobalt themes.

Author: Jim Gallaher

![screen shot](cobalt_screenshot.png)