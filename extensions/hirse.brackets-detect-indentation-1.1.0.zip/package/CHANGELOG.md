# Change Log
All notable changes to this project will be documented in this file.
This project tries to adhere to [Semantic Versioning](http://semver.org/).


## 1.1.0 - 2019-05-01
### Changed
- Updated `detect-indent` to version 6.0.0

### Fixed
- Use first occurrence for files with equal indentation
