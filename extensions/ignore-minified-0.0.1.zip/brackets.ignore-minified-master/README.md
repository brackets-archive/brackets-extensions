# ignore-minified

Brackets editor's QuickEdit is very good feature. However, it finds codes in minified JS/CSS instead of original file when using QuickEdit and Jump To Definition.

So, I just added min.js/min.css as a binary file to solve this simply.

## Links

* [Brackets text editor](http://brackets.io)

## License

MIT