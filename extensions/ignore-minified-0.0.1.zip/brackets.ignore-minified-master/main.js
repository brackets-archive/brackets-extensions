define(function (require, exports, module) {
  'use strict';
  
  var LanguageManager = brackets.getModule("language/LanguageManager");

  LanguageManager.defineLanguage("minified", {
      name: "Minified file",
      fileExtensions: ["min.js", "min.css"],
      isBinary: true
  });
});