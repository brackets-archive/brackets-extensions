# maaextension
A brackets extension thats saves your time by helping you quickly insert a html file
 with prefilled HTML code.