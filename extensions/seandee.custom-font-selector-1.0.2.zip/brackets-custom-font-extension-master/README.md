# Brackets Custom Font Select


A Simple Font Select of you Choice for [Brackets](https://github.com/adobe/brackets/) very suited with HTML, CSS, PHP, Javascript....


### Installation
1. Select **Brackets > File > Extension Manager...**
2. Search [Font Style Select](https://github.com/seanDeee/brackets-custom-font-extension/).
3. Click on the **Install** button.

**OR**

1. Download the **.zip** file
2. In Brackets, navigate to **Help > Show Extensions Folder > User**
3. Place the **.zip** file in the **User** folder
4. Refresh Brackets and Find **Fonts** from **Menu...**


## Screenshot

## Arial Font Style
![Custom Font Select](https://github.com/seanDeee/brackets-custom-font-extension/blob/master/Screenshot/Arial.png)




## Coming soon...... Updates 1.0.1
...More UI Fonts
