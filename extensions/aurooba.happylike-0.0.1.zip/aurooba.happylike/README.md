Brackets-Theme-Happy-Like
=========================

A Brackets editor theme for happy people who enjoy coding.


![alt tag] (https://raw.githubusercontent.com/aurooba/Brackets-Theme-Happy-Like/master/screenshot.png)
