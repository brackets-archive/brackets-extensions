# lumous
### A Dark Interface With Great Vibrant Colours

A simple but vibrant theme for use with Adobe Brackets. The colour scheme has been completely redone; the colours are more suited to a dark mode environment.