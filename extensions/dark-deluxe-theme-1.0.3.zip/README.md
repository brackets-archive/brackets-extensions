#Dark Deluxe Theme

This theme was inspired by my quest to find the perfect theme for my way to often all-nighters. There are a few great dark themes available but they all lacked in one way or another. So, this was my attempt to creating one of my own. Enjoy!

###Installation
This extension requires Brackets Release 1.1 or newer.

- Open Brackets
- Open the Extension Manager
- Switch to "Themes" tab
- Search for "Dark Deluxe Theme"
- Click "Install"

##Screenshots

###HTML
![HTML Screenshot](https://github.com/ChynoDeluxe/dark-deluxe-theme/blob/master/screenshots/html.png)
###CSS
![CSS Screenshot](https://github.com/ChynoDeluxe/dark-deluxe-theme/blob/master/screenshots/css.png)
###JavaScript
![JavaScript Screenshot](https://github.com/ChynoDeluxe/dark-deluxe-theme/blob/master/screenshots/js.png)
###PHP
![PHP Screenshot](https://github.com/ChynoDeluxe/dark-deluxe-theme/blob/master/screenshots/php.png)

