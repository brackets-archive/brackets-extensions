# Smart-Dark-Theme
* A smart, sophisticated and colored theme for Brackets (dark version).

# How to install
Visit http://brackets-themes.github.io/ to see the latest install instructions.

# License
* Theme under MIT license [`LICENSE`](LICENSE)

# Screenshot

### HTML

![HTML Screenshot](https://github.com/gthibaud/Smart-Dark-Theme/blob/master/html.png)

### CSS

![CSS Screenshot](https://github.com/gthibaud/Smart-Dark-Theme/blob/master/css.png)
