Lion Theme for Brackets
=======================

Dark and minimal. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/Lion/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/Lion/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/Lion/blob/master/screenshots/js.png)
