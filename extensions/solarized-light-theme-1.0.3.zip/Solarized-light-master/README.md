Solarized Light Theme for Brackets
=========

Precision colors for machines and people
developed  by Ethan Schoonover. 
http://ethanschoonover.com/solarized 

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)



![Solarized-Light html](https://github.com/chechnyan/Solarized-light/blob/master/html.PNG)
![Solarized-Light css](https://github.com/chechnyan/Solarized-light/blob/master/css.PNG)
