DS Tools
==============
This extension allows to work with DS tools inside brackets.
Still under experimentation.

Screenshots
--------------
![Screenshot](https://raw.githubusercontent.com/mohanaravind/mohanaravind.brackets.ds-tools/master/screenshots/screenshot1.png)

License
-------
Brackets File Icons is licensed under the [MIT license](http://opensource.org/licenses/MIT). The original Brackets Icons is also licensed under the MIT license.
v1
