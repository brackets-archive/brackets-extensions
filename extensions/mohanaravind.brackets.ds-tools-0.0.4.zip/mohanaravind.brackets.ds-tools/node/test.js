(function() {
	var Executor = require('./utility/executor/executor');

	var echoMessageA = new Executor.Execution('echo', 'A');
	var echoMessageB = new Executor.Execution('echo', 'B');

	var Execution = Executor.Execution;

	var tck_init = new Execution('//file-sim/tools/tck/tck_init.bat', ''),
		tck_profile = new Execution('tck_profile', 'SCMV5'),
		adl_ch_ws = new Execution('adl_ch_ws', '"simExpStudioServer417_zb8_" -image WINDOWS'),
		adl_co = new Execution('adl_co', '"SMAProcExpStudioUI/SMAProcXSUI.mweb/src/xs-player/xs-player.css"'),
		adl_unco = new Execution('adl_unco', '"SMAProcExpStudioUI/SMAProcXSUI.mweb/src/xs-player/xs-player.css"');


	var callback = function (output) {
		console.log('called back a');
		console.log(output);
		console.log('00000');
	};


	//Executor.execute(tck_init).then(callbackA).execute(tck_profile).then().execute(adl_ch_ws).then().execute(adl_co).then().execute(adl_unco);

//	setTimeout(function () {
//		console.log('please');
		Executor.execute(echoMessageA).then().execute(echoMessageB).then(callback);


	//	setTimeout(function () {
	//		console.log('next please');
	//		Executor.execute(adl_co).then().execute(adl_unco);
	//	}, 9000);
	///Changes


//	}, 1000);
	
	
}());
