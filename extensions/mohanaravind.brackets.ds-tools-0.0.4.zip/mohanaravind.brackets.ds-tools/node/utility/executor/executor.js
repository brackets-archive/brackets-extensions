//@author: mohanaravind
//Date: 12/30/2014
module.exports = (function () {	
	'use strict';
	
	var Execution,
		WAIT_TIME = 1000,
		Then,
		isWaiting,
		queue = [],
		EXECUTE_READY = 'EXECUTE_READY',
		execute,
		kill,		
		child_process = require('child_process'),
		child;
	
	Execution = function (command, args) {
		this.command = command;
		this.args = args;
		this.state = Execution.STATE.WAITING;
	};

	Execution.STATE = {
		WAITING: 0,
		EXECUTING: 1,
		COMPLETED: 2
	};

	Then = function (execute, execution) {
		this.then = function (callback) {
			execution.callback = callback;
			return {
				execute: execute
			};
		};
	};

	execute = function (execution) {    
		var then = new Then(execute, execution),
			pastExecution;

		queue.push(execution);

		//If the process is not yet spawned
		if(!child) {
			child = child_process.spawn(__dirname + '/executor.bat', [])

			child.stdin.setEncoding = 'utf-8';

			//Listen to data method
			child.stdout.on('data', function (data) {
				var execution;
					
				console.log(data.toString());

				//Refresh
				isWaiting = false;

				//If its ready
				if (data.toString().search(EXECUTE_READY) > -1) {										
					pastExecution && pastExecution.callback && pastExecution.callback(data.toString());
					
					//If there are execution items in the queue
					if (queue.length) {												
						//Get the first item in the queue
						execution = queue.shift();
						
						//Store it as the past execution
						pastExecution = execution;

						//Do Execution
						execution.state = Execution.STATE.EXECUTING;
												
						setTimeout(function () {
							console.log('Executing: ' + execution.command + ' ' + execution.args);
							child.stdin.write(execution.command + '\n');
							child.stdin.write(execution.args + '\n');														
						}, WAIT_TIME);													
					} else {
						//Allow direct calls
						isWaiting = true;	
					}
				}
			});

			child.stderr.on('data', function (data) {
				console.log('process stderr: ' + data.toString());
			});

			child.on('close', function (code) {
				if (code !== 0) {
					console.log('process exited with code ' + code);
				}  
			});

			child.on('exit', function (code) {
				console.log('exit');
			});						
		}

		if (isWaiting) {
			console.log('Trying to wake up...');
			child.stdin.write('echo' + '\n');
			child.stdin.write('wakeup' + '\n');
			isWaiting = false;
		}

		return {
			then: then.then  
		};
	};
	
	return {
		Execution: Execution,
		execute: execute
	};
	
}());
