//@author: mohanaravind
//Date: 12/30/2014
(function () {
	"use strict";

	var DOMAIN_NAME = 'dsdomain';

	var fs = require("fs");


	var checkPermission = function (file, mask, cb) {
		fs.stat(file, function (error, stats) {
			if (error) {
				cb(error, true);
			} else {
				cb(null, !(mask & parseInt((stats.mode & parseInt("777", 8)).toString(8)[0])));
			}
		});
	};

	var renameFile = function (oldPath, newPath, cb) {
		fs.rename(oldPath, newPath, cb);
	};


	var executeCommand = function (arg, callback) {
		var spawn = require('child_process').spawn;

		var command = __dirname + '/buildtime.bat';

		var ps = spawn(command, ['ara']);

		console.log(__dirname);

		ps.stdout.on('data', function (data) {
			//grep.stdin.write(data);
			console.log(data);
			callback(data);
		});

		ps.stderr.on('data', function (data) {
			console.log('ps stderr: ' + data);
		});

		ps.on('close', function (code) {
			if (code !== 0) {
				console.log('ps process exited with code ' + code);
			}
		});

		ps.on('exit', function (code) {
			console.log('exit');
		});

		//setTimeout(function() {
		//	ps.kill();
		//}, 3000);

	};


	//Start of SCM Commands

	var Executor = require('./utility/executor/executor'),
		Execution = Executor.Execution;

	function scm_init(options, callback) {
		var tck_init = new Execution(options.tck_init.command, options.tck_init.args),
			tck_profile = new Execution(options.tck_profile.command, options.tck_profile.args);

		Executor.execute(tck_init).then().execute(tck_profile).then(function (data) {
			callback(null, data);
		});
	}

	function scm_chws(options, callback) {
		var adl_ch_ws = new Execution(options.adl_ch_ws.command, options.adl_ch_ws.args);

		Executor.execute(adl_ch_ws).then(function (data) {
			callback(null, data);
		});
	}

	function scm_checkin(options, callback) {
		var file = options.file.replace(/\//g, '\\'),
			adl_ci = new Execution('adl_ci', '"' + file + '"');
		Executor.execute(adl_ci).then(function (data) {
			callback(null, data);
		});
	}

	function scm_checkout(options, callback) {
		var file = options.file.replace(/\//g, '\\'),
			adl_co = new Execution('adl_co', '"' + file + '"');
		Executor.execute(adl_co).then(function (data) {
			callback(null, data);
		});
	}

	//End of SCM Commands



	/**
	 * @private
	 * Checks if the file is read only.
	 * @param {boolean} filePath
	 * @return {number} callback
	 */
	function isReadOnly(filePath, callback) {

		checkPermission(filePath, 2, callback);

		return;
	}

	/**
	 * Initializes the test domain with several test commands.
	 * @param {DomainManager} domainManager The DomainManager for the server
	 */
	function init(domainManager) {
		if (!domainManager.hasDomain("dsdomain")) {
			domainManager.registerDomain("dsdomain", {
				major: 0,
				minor: 1
			});
		}

		domainManager.registerCommand(
			'dsdomain',
			'isReadOnly',
			isReadOnly,
			true,
			'Returns if the file is read only or not', [{
					name: 'filePath',
					type: 'string',
					description: 'Path of the file which has to be checked'
				},
				{
					name: 'callback',
					type: 'function',
					description: 'The callback function'
				}]
		);

		domainManager.registerCommand(
			'dsdomain',
			'renameFile',
			renameFile,
			true,
			'Renames the file', [{
					name: 'oldPath',
					type: 'string',
					description: 'Path of the file which has to be renamed'
				},
				{
					name: 'newPath',
					type: 'string',
					description: 'Path of the file to which it has to be renamed to'
				},
				{
					name: 'callback',
					type: 'function',
					description: 'The callback function'
				}]
		);

		domainManager.registerCommand(
			DOMAIN_NAME,
			'scm_init',
			scm_init,
			true,
			'Checks in a file', [{
					name: 'options',
					type: 'object',
					description: 'Path of the file which has to be checked in'
				},
				{
					name: 'callback',
					type: 'function',
					description: 'The callback function'
				}]
		);

		domainManager.registerCommand(
			DOMAIN_NAME,
			'scm_chws',
			scm_chws,
			true,
			'Changes the workspace', [{
					name: 'options',
					type: 'object',
					description: 'Path of the file which has to be checked in'
				},
				{
					name: 'callback',
					type: 'function',
					description: 'The callback function'
				}]
		);

		domainManager.registerCommand(
			DOMAIN_NAME,
			'scm_checkin',
			scm_checkin,
			true,
			'Checks in a file', [{
					name: 'options',
					type: 'object',
					description: 'The options with options.file'
				},
				{
					name: 'callback',
					type: 'function',
					description: 'The callback function'
				}]
		);
		domainManager.registerCommand(
			DOMAIN_NAME,
			'scm_checkout',
			scm_checkout,
			true,
			'Checks out the file', [{
					name: 'options',
					type: 'object',
					description: 'Path of the file which has to be checked out'
				},
				{
					name: 'callback',
					type: 'function',
					description: 'The callback function'
				}]
		);
	}

	exports.init = init;
}());