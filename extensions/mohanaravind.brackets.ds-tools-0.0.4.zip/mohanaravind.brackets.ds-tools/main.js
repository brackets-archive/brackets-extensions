window.define(function (require, exports, module) {
	'use strict';

	function load(moduleName) {
		return brackets.getModule(moduleName);
	}

	var args = arguments,
		AppInit = load("utils/AppInit"),
		ExtensionUtils = load('utils/ExtensionUtils'),
		ProjectManager = load('project/ProjectManager'),
		DEFAULTS;


	DEFAULTS = {
		polymer: 'https://cdnjs.cloudflare.com/ajax/libs/polymer/0.5.2/polymer.js',
		app: 'http://localhost:8080/vulcanized.html'
	};

	//Inserts the app infra
	function appInit() {
		var PreferenceManager = load('preferences/PreferencesManager'),
			preference,
			polymer,
			APP_NAME = 'ds-tools';


		preference = PreferenceManager.get(APP_NAME) || DEFAULTS;

		//Set the preference if not present		
		preference.polymer = preference.polymer || DEFAULTS.polymer;
		preference.app = preference.app || DEFAULTS.app;

		//Save the options
		PreferenceManager.set(APP_NAME, preference);

		polymer = document.createElement('script');
		polymer.setAttribute('src', preference.polymer);
		polymer.addEventListener('load', function () {
			$.get(preference.app, function (content) {
				var container = document.createElement('div');
				container.setAttribute('id', 'ds-tools-container');
				container.setAttribute('class', 'ds-tools-container');


				//Listen to the DS brackets init event				
				container.addEventListener('dsbrinit', function (event) {
					var dsBRMain = document.getElementById('ds-br-main');

					//Initialize with brackets variables					
					dsBRMain.args = args;
				});

				document.body.appendChild(container);

				//Add the main content
				$('#ds-tools-container').html(content + '<ds-br-main id="ds-br-main"></ds-br-main>');
			});
		});

		//Add polymer reference to brackets
		document.head.appendChild(polymer);
	}

	//Insert the style sheet for the tool
	ExtensionUtils.loadStyleSheet(module, 'styles/style.css');

	//When a project is open initialize the app
	ProjectManager.on("projectOpen", appInit);

});