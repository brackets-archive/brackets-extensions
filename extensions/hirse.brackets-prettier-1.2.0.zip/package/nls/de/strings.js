define({
    FORMAT: "Formatiere Datei mit Prettier",
    PARSE_CONFIG_FAILED: "Fehler beim Parsen der Konfigurationsdatei",
    FORMAT_FAILED: "Fehler beim Formatieren der Datei",
});
