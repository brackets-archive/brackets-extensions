define({
    FORMAT: "Format File with Prettier",
    PARSE_CONFIG_FAILED: "Error Parsing Configuration File",
    FORMAT_FAILED: "Error Formatting File",
});
