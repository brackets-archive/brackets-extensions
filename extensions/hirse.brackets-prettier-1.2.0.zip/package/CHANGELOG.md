# Change Log
All notable changes to this project will be documented in this file.
This project tries to adhere to [Semantic Versioning](http://semver.org/).


## 1.2.0 - 2020-12-27
### Added
- Support for PHP with `@prettier/plugin-php`

### Changed
- Updated Prettier to 2.2.1


## 1.1.0 - 2019-07-17
### Changed
- Updated Prettier to 1.18.2
