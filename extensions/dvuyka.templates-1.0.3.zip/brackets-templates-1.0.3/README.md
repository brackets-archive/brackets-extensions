# brackets-templates
Adds template-based project generation to Brackets
