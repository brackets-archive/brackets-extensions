#Apache Syntax for Brackets

This extension adds syntax highlighting for Apache config files to Brackets.

It will activate currently in 2 cases:

* .conf files
* .htaccess files
