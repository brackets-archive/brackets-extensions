# filesize
Shows the file size on saving a document or switching to another document. Displays the size of the file in KB in statusbar. For a new unsaved document, size is not shown.