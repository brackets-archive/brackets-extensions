var order = [
    "display",
    "float",
    "clear",
    "position",
    "top",
    "right",
    "bottom",
    "left",
    "z-index",
    "min-width",
    "max-width",
    "width",
    "min-height",
    "max-height",
    "height",
    "overflow",
    "overflow-wrap",
    "overflow-x",
    "overflow-y",
    "margin",
    "margin-top",
    "margin-right",
    "margin-bottom",
    "margin-left",
    "padding",
    "padding-top",
    "padding-right",
    "padding-bottom",
    "padding-left",
    "border",
    "border-top",
    "border-top-color",
    "border-top-style",
    "border-top-width",
    "border-right",
    "border-right-color",
    "border-right-style",
    "border-right-width",
    "border-bottom",
    "border-bottom-color",
    "border-bottom-style",
    "border-bottom-width",
    "border-left",
    "border-left-color",
    "border-left-style",
    "border-left-width",
    "border-image-source",
    "border-image-slice",
    "border-image-width",
    "border-image-outset",
    "border-image-repeat",
    "border-radius",
    "border-collapse",
    "border-spacing",
    "background",
    "background-image",
    "background-position-x",
    "background-position-y",
    "background-size",
    "background-repeat-x",
    "background-repeat-y",
    "background-attachment",
    "background-origin",
    "background-clip",
    "background-color",
    "color",
    "font",
    "font-size",
    "font-style",
    "font-variant-ligatures",
    "font-variant-caps",
    "font-variant-numeric",
    "font-variant-east-asian",
    "font-weight",
    "line-height",
    "font-stretch",
    "font-family",
    "text-align",
    "text-align-last",
    "vertical-align",
    "line-height",
    "white-space",
    "text-indent",
    "text-decoration",
    "letter-spacing",
    "word-break",
    "word-wrap",
    "list-style",
    "ime-mode",
    "content",
    "cursor",
    "zoom",
    "opacity",
    "filter",
    "transform",
];

function jsonToCss(json) {
    var css = "";

    for (var objCSS of json.css) {
        css += "\n" + objCSS.selector.trim() + " {\n";
        for (var property of objCSS.properties) {
            css += "    " + property.property + ": " + property.value + ";\n";
        }
        css += "}\n";
    }

    return css;
}

function compareProperties(a, b) {
    var indexA = order.indexOf(a.property);
    var indexB = order.indexOf(b.property);
    if(indexA == -1) return 1;
    if(indexB == -1) return -1;
    if(indexA > indexB) return 1;
    if(indexA < indexB) return -1;
    return 0;
}

function removeDuplicate(properties) {
    var unique = [];
    properties.forEach(function (property) {
        var index = unique.findIndex(matchProperty, property.property);
        if (index == -1) {
            unique.push(property);
        } else {
            unique.splice(index, 1, property);
        }
    });
    return unique;
}

function sortProperties(properties) {
    properties = removeDuplicate(properties);
    properties = properties.sort(compareProperties);
    return properties;
}

function matchProperty(property) {
    return this == property.property;
}

function cssToJson(cssToSort) {
    var json = {
        "css": []
    };
    if (cssToSort.indexOf("{") == -1 ||
        cssToSort.indexOf("}") == -1 ||
        cssToSort.replace(/[^}]/g, "").length != cssToSort.replace(/[^{]/g, "").length) return null;

    var maxloop = cssToSort.length;
    var loopTimes = 0;
    while (cssToSort.indexOf("}") != -1 && loopTimes < maxloop) {
        loopTimes++;
        if (loopTimes == maxloop) return null;
        var css = cssToSort.substring(0, cssToSort.indexOf("}") + 1),
            jsonCSS = {
                "selector": null,
                "properties": [],
            };


        jsonCSS.selector = css.substring(0, css.indexOf("{"));
        css = css.substring(css.indexOf("{") + 1).trim();

        var innerLoopTimes = 0;
        while (css.indexOf("}") != 0 && innerLoopTimes < maxloop) {
            innerLoopTimes++;
            if (innerLoopTimes == maxloop) return null;
            var property = css.substring(0, css.indexOf(":"));
            css = css.substring(css.indexOf(":") + 1).trim();
            var value = css.substring(0, css.indexOf(";"));
            css = css.substring(css.indexOf(";") + 1).trim();
            jsonCSS.properties.push({
                "property": property,
                "value": value
            });
        }

        cssToSort = cssToSort.substring(cssToSort.indexOf("}") + 1).trim();
        jsonCSS.properties = sortProperties(jsonCSS.properties);
        json.css.push(jsonCSS);
    }
    return json;
}

function sortCSS(cssToSort) {
    var sortedCSS = "";
    cssToSort = cssToSort.trim();
    var cssJson = cssToJson(cssToSort);
    if (cssJson == null) return null;
    sortedCSS = jsonToCss(cssJson);
    return sortedCSS;
}
