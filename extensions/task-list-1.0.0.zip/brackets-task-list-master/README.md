Brackets Task List
==================

Adobe [Brackets](http://brackets.io/ "Brackets") Extension for managing development tasks. This extension allows you to add tasks for each and every project separately. This extension is inspired by 
[Brackets-Tasks](https://github.com/crot4lus/Brackets-Tasks "Brackets-Tasks")

## Screenshot
![Screenshot](https://cloud.githubusercontent.com/assets/1453745/5527162/e02ad2c0-89fb-11e4-9005-de7760b008b3.png)

## Installation
1. Open Extension Manager and click the `Install from URL...` link at the bottom
2. Enter the following URL: https://github.com/ckip/brackets-task-list
3. Click the `Install` button

##License
MIT license - [http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)
