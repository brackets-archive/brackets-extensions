dogs-for-brackets
=================

Add a dog icon in Brackets, this allows for a random 'placedog.com' image tag to be generated and inserted into the editor.

Credit: http://placedog.com