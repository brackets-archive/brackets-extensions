# Brackets-Plasma-Light-Theme
A cool theme for Brackets code editor.
