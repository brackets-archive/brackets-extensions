# \[Browse...] (or Drag & Drop)
You can open files from [Browse...] with shortcut key.  
And this extension inserts tags automatically (link tag, img tag, script tag, css @import, or php include statement).  
It also be able to open files from a modal window.

## Shortcut Key
### Show an "Open" dialog
#### Root Path
Windows: Ctrl-Shift-.  
Mac: Cmd-Shift-.

#### Relative Path
Windows: Ctrl-Shift-Alt-.  
Mac: Cmd-Shift-Alt-.

### Open The Modal Window (drag and drop zone)
Windows: Ctrl-.  
Mac: Cmd-.

## With right-clicking
You can now insert tags by right-clicking from the file list.
