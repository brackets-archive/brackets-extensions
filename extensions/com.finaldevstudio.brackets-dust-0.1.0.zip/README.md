brackets-dust
=============

[Adobe Brackets](http://brackets.io) [CodeMirror](http://codemirror.net/) mode for the [Dustjs](http://linkedin.github.io/dustjs) templating language.

### Description
It's a really simple fix so that Brackets doesn't get confused on situations like `{<` and screw up all the syntax highlighting and indentation. This is done by treating everything between `{` and `}` as plain text.

### Installation
Search for Dust in the Brackets extension manager :)
