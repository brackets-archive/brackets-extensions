/*global brackets, define, console*/

define(function (require, exports, module) {
    'use strict';

    var CodeMirror = brackets.getModule('thirdparty/CodeMirror2/lib/codemirror');

    CodeMirror.defineMode('dust', function (config) {
        return CodeMirror.multiplexingMode(CodeMirror.getMode(config, 'text/html'), {
            open: '{',
            close: '}',
            mode: CodeMirror.getMode(config, 'text/plain'),
            delimStyle: 'delimit'
        });
    });
});