/*global require, brackets, define, console */


define(function (require, exports, module) {
    'use strict';

    var LanguageManager = brackets.getModule('language/LanguageManager'),
        EjsLang = LanguageManager.getLanguage('ejs'),
        DustMode = require('dust');

    /* Dust has nothing to do with EJS */
    EjsLang.removeFileExtension('dust');

    LanguageManager.defineLanguage('dust', {
        name: 'Dust',
        mode: 'dust',
        fileExtensions: [
            'dust'
        ],
        blockComment: [
            '{!',
            '!}'
        ]
    }).done(function () {
        console.log('Dust module loaded');
    });
});