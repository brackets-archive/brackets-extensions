"use strict";

/**
 *  File: ASCII.js
 *  Author: Arthur Pons <unguestdev@gmail.com> aka unguest on github
 *  Description:  Encodes String --> ASCII Code
 *
 */
define(function (require, exports) {
  var encodeToASCII = function encodeToASCII(text) {
    var asciiArray = [];

    for (var _i = 0, _Array$from = Array.from(text); _i < _Array$from.length; _i++) {
      var _char = _Array$from[_i];
      asciiArray.push(_char.charCodeAt(0));
    }

    return asciiArray.join('');
  };

  var decodeFromASCII = function decodeFromASCII(text) {
    var codes = [];

    for (var i = 0; i < text.length;) {
      var numDigits = text[i] === '1' ? 3 : 2;
      codes.push(text.substr(i, numDigits));
      i += numDigits;
    }

    return String.fromCharCode.apply(String, codes);
  };

  exports.encodeToASCII = encodeToASCII;
  exports.decodeFromASCII = decodeFromASCII;
});