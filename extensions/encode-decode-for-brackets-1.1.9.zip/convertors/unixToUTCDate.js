"use strict";

/**
 *  File: unixToUTCDate.js
 *  Author: Devin Ekadeni <devinekadeni@gmail.com>
 *  Description:  Encodes Unix Timestamp --> UTC Date
 *  UTC Date format: [Day], [Date] [Month] [Year] [Hour]:[Minute]:[Second] GMT
 *  ex: Sun, 21 Jun 2020 22:15:35 GMT
 */
define(function (require, exports) {
  var encodeUnixToUTCDate = function encodeUnixToUTCDate(unixTimestamp) {
    if (!validateTimestamp(unixTimestamp)) throw new Error('Invalid Unix Timestamp');
    var DAYS_ARR = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var MONTHS_ARR = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Nov', 'Dec'];
    var date = new Date(unixTimestamp * 1000); // * 1000 because JS compiles until milliseconds

    var utcYear = date.getUTCFullYear();
    var utcMonth = MONTHS_ARR[date.getUTCMonth()];
    var utcDate = date.getUTCDate();
    var utcDay = DAYS_ARR[date.getUTCDay()];
    var utcHour = date.getUTCHours();
    var utcMinute = date.getUTCMinutes();
    var utcSecond = date.getUTCSeconds();
    var UTCDate = "".concat(utcDay, ", ").concat(utcDate, " ").concat(utcMonth, " ").concat(utcYear, " ").concat(utcHour, ":").concat(utcMinute, ":").concat(utcSecond, " GMT");
    return UTCDate;
  };

  var validateTimestamp = function validateTimestamp(unixTimestamp) {
    return new Date(unixTimestamp * 1000).getTime() > 0;
  };

  exports.encodeUnixToUTCDate = encodeUnixToUTCDate;
});