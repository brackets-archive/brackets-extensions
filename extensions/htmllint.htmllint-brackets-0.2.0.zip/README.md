brackets-htmllint
=================

An Adobe Brackets extension for [htmllint](https://github.com/htmllint/htmllint).

Please note that this is an extension to bring the basic functionality of htmllint to Brackets, and the functionality is currently being used only for testing. Users are encouraged to add the other features of htmllint!

Please take a look at the issues to contribute.

When working on this extension, remember to use npm install!

