# brackets-zen-dark
Minimal dark theme which is soothing to eyes and catchy colors

## sample screen shots
### HTML
![screenshot-html](/screenshots/Screen\ Shot\ HTML.png "HTML Screen Shot")

### CSS
![screenshot-html](/screenshots/Screen\ Shot\ CSS.png "CSS Screen Shot")
