<h2> Get Active File Path </h2>

Utility for getting path of opened file with possibility to copy it. Use 'Ctrl+`' to get File Path
