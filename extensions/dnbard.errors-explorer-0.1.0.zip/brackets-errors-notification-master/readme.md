Errors Explorer
===============

Brackets IDE extension that lets you to see errors that happens inside of IDE without Development Tools. Useful for Brackets Extensions Authors!

Features:
_________
* Icon with errors count  
![icon with errors count](http://content.screencast.com/users/dnbard/folders/Jing/media/d025b4b8-6ff0-4eed-8362-237c6a9783f0/2014-09-10_1235.png)

* Panel to explore errors  
![panel to explore errors](http://content.screencast.com/users/dnbard/folders/Jing/media/07487984-14ec-41f9-886b-f245b77c8df3/2014-09-10_1239.png)