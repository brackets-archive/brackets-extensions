# brackets-dramatic-error-highlighting
Overrides Brackets theme error highliting for optimal visibility of errors.
