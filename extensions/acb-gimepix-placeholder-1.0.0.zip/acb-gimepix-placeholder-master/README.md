ACB GIMEpix Placeholder
=======================

Free images for your projects.

Placeholder images from gimepix.com.

![Screenshot](https://github.com/acbarbosa1964/acb-sample-gifs/blob/master/images/acb-gimepix-demo.gif?raw=true)

## Install

#### Git Clone

1. Under main menu select **Help > Show Extensions Folder**
2. Git clone this repository inside the folder user.

#### Extension Manager

1. Under main menu select **File > Extension Manager...**
2. Search for "ACB GIMEpix Placeholder"
3. Click "Install"

## How to use


## More extensions?

http://brackets.dnbard.com/author/Antonio%20Carlos%20Barbosa



### Changelog

#### V1.0.0

* First version

### Credits
---

- Images provided by http://www.gimepix.com
- Source-code editor used in this project - Brackets - http://www.brackets.io
- OwlCarousel v1.3.4 - Customized Version - OwlFonk - https://github.com/OwlFonk/OwlCarousel

Thank you all!!!

### License
---

[MIT](https://raw.githubusercontent.com/acbarbosa1964/acb-bootstrap-snippets/master/LICENSE) for this project.

Copyright (c) 2015 Antonio Carlos Barbosa
Released under the MIT license
