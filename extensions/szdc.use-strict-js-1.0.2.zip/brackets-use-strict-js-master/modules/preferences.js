/*jslint vars: true */
/*global define, $, brackets, window, console */

define(function (require, exports, module) {
  'use strict';
  
  exports.ENABLE_STRICT_ON_SAVE = {
    id:      'enableStrictOnSave',
    type:    'boolean',
    initial: true
  };
});