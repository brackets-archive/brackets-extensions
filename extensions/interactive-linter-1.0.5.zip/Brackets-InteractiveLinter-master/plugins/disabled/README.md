Place plugins that you don't want Interactive Linter to load in this directory. Anything in this directory will be ignored by git.
