define(function (require, exports, module) {
    var   test    = {};
});
