var c = 0;
if (c = 1) {
}
