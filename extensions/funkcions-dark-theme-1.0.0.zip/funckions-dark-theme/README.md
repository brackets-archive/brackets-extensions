# Funkcions (Dark Theme) for Brackets

## Installation

* Open the Extension Manager in Brackets
* Switch to "Themes" tab
* Search for "Funkcions (Brackets Dark Theme)"
* Click "Install"
* Select "Themes" menu option under the "View" menu
* Select "Funkcions (Dark Theme)"
* Enjoy!