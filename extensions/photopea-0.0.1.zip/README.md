Brackets Photopea
==============

Support of Photopea image editor inside of Brackets IDE.

Fully functional professional photo and image editing software inside Brackets IDE.

Has several issues, but we are trying to solve them.
