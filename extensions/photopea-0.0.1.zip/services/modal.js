define(function(require, exports){
    var Dialogs = brackets.getModule('widgets/Dialogs'),
        ppTemplate = require('text!../templates/modal.html');
	
    exports.showHandler = function(){
        Dialogs.showModalDialogUsingTemplate(ppTemplate)._$dlg;
    };
});
