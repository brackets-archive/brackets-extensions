# Violet Dark Theme [![MIT License](https://img.shields.io/badge/listence-MIT-blue.svg)](https://opensource.org/licenses/MIT)
A dark theme for Brackets.

## Screenshots

### Javascript
![JS](screenshots/js.png)

### PHP / HTML
![php](screenshots/php.png)