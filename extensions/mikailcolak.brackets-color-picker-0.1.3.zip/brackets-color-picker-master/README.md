#Usage:
    1. When you type "color :" or like "background-color:" color picker will be appeared on cursor position.
    2. You can press ' ⌘ CMD/CTRL + ALT + K ' for show color picker.
