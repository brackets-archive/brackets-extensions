![Brackets Themes](https://github.com/PandaDigital/panda-night/blob/master/panda.png) Panda Night Theme
=========

[Phil Reichner's Panda Night](https://github.com/PandaDigital/silent-night) theme for Brackets.

## CSS 
![Panda Night Theme in a CSS file](https://github.com/PandaDigital/panda-night/blob/master/panda-night-css-screenshot.png)

## HTML
![Panda Night Theme in an HTML file](https://github.com/PandaDigital/panda-night/blob/master/panda-night-html-screenshot.png)

## JavaScript
![Panda Night Theme in a JS file](https://github.com/PandaDigital/panda-night/blob/master/panda-night-js-screenshot.png)
