Monokai Redux theme for Brackets
======================

This dark theme is a customized version of the Monokai color scheme.

Screenshots
======================

Coming Soon...