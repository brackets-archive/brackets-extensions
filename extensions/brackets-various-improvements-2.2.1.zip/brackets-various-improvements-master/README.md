Various improvements
=============================

This extension add some small improvements :

- Add some informations on the status bar. (Path and size of the currently edited file)
- Add a toLowerCase and toUpperCase features Ctrl+Alt+U - Ctrl+Alt+L.
- Add a super clipboard features Ctrl+Alt+C to copy and Ctrl+Alt+V to paste. (In this way you can have two separate clipboard)
- Add a close button in the file tree that allows you to close all the opened folders when you are lost in your project.
- Add a files search that allow you to find a file in your project using filter by filename or extension. Ctrl+Alt+F to open the search bottom panel.
