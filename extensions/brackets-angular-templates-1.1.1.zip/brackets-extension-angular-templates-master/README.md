## Brackets Angular.Js templates extension

Brackets extension that will insert a chosen HTML or JS template into the current file.

Templates are based on generic HTML or JS for Angular.Js.

### Usage

Use the custom Angular templates Menu
