/*jslint node:true, vars:true, plusplus:true, devel:true, nomen:true, regexp:true, white:true, indent:2, maxerr:50 */
/*global define, $, brackets, Mustache, window, console */
define(function (require, exports, module) {
	"use strict";
	
	var domain = null;
	var errorFile = null;
	
	exports.domain = domain;
	exports.errorFile = errorFile;
});