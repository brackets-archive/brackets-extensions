![html](http://i.imgur.com/c8d1zvp.png)
![css](http://i.imgur.com/wangVNC.png)
*A dark, minimal theme for the Brackets text-editor.*