Brackets-Thymeleaf and HTML5 CodeHints
=======================
> version of Thymeleaf is 2.1

---

### code hint image

![thymeleaf attributes](https://github.com/orangeeeee/Brackets-Thymeleaf-Code-Hint/wiki/explain01.PNG)

Thanks [coliff](https://github.com/coliff) for inspiration