brackets-builder
================
![Brackets Builder](https://dl.dropboxusercontent.com/u/30258921/brackets-builder.png "Brackets Builder") <br />
Allow to run build programs (such as running Python/Ruby/Node/etc scripts) from Brackets and display results in panel.
It is possible to create own build systems via 'Edit>Edit Builder' menu item and editing opened JSON-file
(you need to restart Brackets). <br />
Press Ctrl(Cmd)-Alt-B to build current file.
