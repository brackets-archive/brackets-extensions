![Brackets Themes](https://github.com/Brackets-Themes/Envy/blob/master/bracket-themes-icon-100x99.png) Envy Theme for Brackets
=========

Dark theme for Brackets - it's kind of greenish... so envy... you see what I did there?

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)



![envy theme js](https://github.com/Brackets-Themes/Envy/blob/master/envy-screenshot-js.png)
