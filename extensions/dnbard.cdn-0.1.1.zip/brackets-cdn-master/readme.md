CDN Finder
==========

Search for javascript libraries, jQuery plugins, fonts, CSS frameworks and anything else you might need.

![example](https://raw.githubusercontent.com/dnbard/brackets-cdn/master/presentation/video.gif)