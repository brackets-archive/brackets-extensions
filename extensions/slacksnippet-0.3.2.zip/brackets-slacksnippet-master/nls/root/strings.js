/*jshint maxlen:false */

define({
    SHOW_SLACK_MANAGER:          "Show Slack Manager",
    SLACK_SETTINGS:          	 "Slack Settings",
	SLACK_TOKEN:				 "slack user token",
	NEW_SLACK:					 "New Slack Snippet",
	CREATE_NEW_SLACK:			 "New Slack Snippet",
	SLACK_CONTENT_HERE:			 "Your snippet",
	SLACK_TITLE_HERE:			 "Snippet title",
	SLACK_TOKEN_HERE:			 "Slack token",
	SLACK_DOWNLOAD:				 "Download Slack Snippet",
});
