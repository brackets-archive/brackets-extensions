# brackets - enhanced-scrollbars

This extension makes the scrollbars look like native OS X scollbars, also removes the scrollbar's empty gutter space.
