#Changelog

## 0.1.1 - ?

### Added

- Highlight ppc64le architecture.
- Highlight all tags by changing from defined list to regex.
- Support ! in macro names.

### Fixed

- Clear control flow state after macros.

## 0.1.0 - 2015-07-20

- Initial Release.