# brackets-rpm-syntax

RPM spec file syntax highlighting for [Brackets](http://brackets.io/). Install via the Extension Manager.

rpm.js is a modified version of the RPM spec file mode in [CodeMirror](http://codemirror.net/).
