# Brackets / Theme / Spring Light
Nice light theme for adobe brackets.

php ![php](https://raw.githubusercontent.com/MerryPanda/brackets-theme-spring-light/master/example/php.png) 
js ![js](https://raw.githubusercontent.com/MerryPanda/brackets-theme-spring-light/master/example/js.png) 
css ![css](https://raw.githubusercontent.com/MerryPanda/brackets-theme-spring-light/master/example/css.png) 
json ![json](https://raw.githubusercontent.com/MerryPanda/brackets-theme-spring-light/master/example/json.png)
html ![html](https://raw.githubusercontent.com/MerryPanda/brackets-theme-spring-light/master/example/html.png)  
