# brackets-go-syntax [![GitHub release](https://img.shields.io/github/release/amller/brackets-go-syntax.svg)](https://github.com/amller/brackets-go-syntax/releases)
A simple extension for [Brackets](http://brackets.io) to enable syntax highlighting for [Go](https://golang.org) via [CodeMirror mode](https://codemirror.net/mode/index.html).  
**Note:** *I will no longer maintain this repo, because [Go will be supported by default in future releases](https://github.com/adobe/brackets/pull/13114).*  

This project is licensed under GPL-3.0. For more information read the [LICENSE](LICENSE).
