##"Copyright" Extension for [Brackets](http://brackets.io)

[Brackets on GitHub](https://github.com/adobe/brackets)

This [Brackets](http://brackets.io) extension provides a quick way to insert a copyright notice at the top of your document.
The copyright text will be inserted using the appropriate comment characters based on type of file you are editing.

### Installation
* Select **File > Extension Manager**
* Click **Install from URL**
* Enter the following GitHub repository URL
* https://github.com/joeireland/brackets-extension-copyright
* Click **Install**

### How To Use
Press the **"Alt+C"** HotKey or select **"Edit > Insert Copyright"** menu item
