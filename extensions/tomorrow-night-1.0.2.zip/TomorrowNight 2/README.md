![Brackets Themes](https://github.com/Brackets-Themes/TomorrowNight/blob/master/bracket-themes-icon-100x99.png) Tomorrow Night Theme for Brackets
=========

[Chris Kempson's Tomorrow Night](https://github.com/chriskempson/tomorrow-theme) theme for Brackets.

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)

## CSS 
![Tomorrow Night Theme in a CSS file](https://github.com/Brackets-Themes/TomorrowNight/blob/master/tomorrow-night-screenshot-css.png)

## HTML
![Tomorrow Night Theme in an HTML file](https://github.com/Brackets-Themes/TomorrowNight/blob/master/tomorrow-night-screenshot-html.png)

## JavaScript
![Tomorrow Night Theme in a JS file](https://github.com/Brackets-Themes/TomorrowNight/blob/master/tomorrow-night-screenshot-js.png)