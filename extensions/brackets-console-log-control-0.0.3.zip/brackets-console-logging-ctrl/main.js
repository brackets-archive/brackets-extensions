/*
* Copyright (c) 2013 Daniele Urania. All rights reserved.
*
* http://www.uXentrik.com
*
*
*
* Permission is hereby granted, free of charge, to any person obtaining a
* copy of this software and associated documentation files (the "Software"), 
* to deal in the Software without restriction, including without limitation 
* the rights to use, copy, modify, merge, publish, distribute, sublicense, 
* and/or sell copies of the Software, and to permit persons to whom the 
* Software is furnished to do so, subject to the following conditions:
*  
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*  
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
* DEALINGS IN THE SOFTWARE.





* Bracket extension that helps to create/delete/comment in/comment in the 
* console.log statements


* HOW TO USE:

* to create a console.log statement for a var: select the var, "Edit > Create var Console.log Line"
* That results in a new line below the var line the contain the console.log statemnt
* as the following example:

var myVar=somevalue; // select myVar and the result of the "Edit > Create var Console.log Line" will be:
console.log('myVar: '+myVar);


* - "Remove Console.log Lines" COMMAND:
* SELECT ALL THE LINES FROM WHICH YOU WANT TO REMOVE THE CONSOLE.LOG LINES 
* and SELECT "Edit > Remove Console.log Lines"
-> result: all the lines that start with Console.log inside the selection will be deleted

* - "Comment Out Console.log Lines" COMMAND:
* SELECT ALL THE LINES FROM WHICH YOU WANT TO COMMENT OUT THE CONSOLE.LOG LINES 
* SELECT ALL Ctrl+A (window) or CMD+A (MAC) to COMMENT OUT ALL THE LINES that 
* CONTAINS "CONSOLE.LOG" LINES and SELECT "Edit > Comment Out Console.log Lines"
-> result: all the lines that start with Console.log inside the selection will be commented out

* - "Comment in Console.log Lines" COMMAND:
* SELECT ALL THE LINES FROM WHICH YOU WANT TO COMMENT IN THE LINE That CONTAINS 
* "//CONSOLE.LOG". 
* SELECT "Edit > Comment In Console.log Lines"
-> result: all the lines that start with //Console.log inside the selection will be commented in


/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window */


define(function (require, exports, module) {
	"use strict";

	var CommandManager = brackets.getModule("command/CommandManager"),
		EditorManager = brackets.getModule("editor/EditorManager"),
		Menus = brackets.getModule("command/Menus"),
		StringUtils = brackets.getModule("utils/StringUtils");

	var outputData = function (text) {
		EditorManager.getFocusedEditor()._codeMirror.replaceSelection(text);
	};


	var inputData = function () {
		return EditorManager.getFocusedEditor().getSelectedText();
	};
	var inputline = function () {
		return EditorManager.getFocusedEditor().getCursor();
	};


	function handleRemoveConsoleLogLines() {
		var string = inputData();
		var lines = string.split("\n");
		var len = lines.length;
		var i;
		var outputLines = new Array();
		for (i = 0; i < len; i++) {
			var n = lines[i].indexOf("console.log");
			if (n === (-1)) {
				outputLines.push(lines[i]);
			}
		}
		var output = outputLines.join("\n");
		outputData(output);
	}

	function handleCommentOutConsoleLogLines() {
		var string = inputData();
		var lines = string.split("\n");
		var len = lines.length;
		var i;
		var outputLines = new Array();
		for (i = 0; i < len; i++) {
			var n = lines[i].indexOf("console.log");
			if (n !== (-1)) {
				lines[i] = "//" + lines[i];
			}
			outputLines.push(lines[i]);
		}
		var output = outputLines.join("\n");
		outputData(output);
	}

	function handleCommentInConsoleLogLines() {
		var string = inputData();
		var lines = string.split("\n");
		var len = lines.length;
		var i;
		var outputLines = new Array();
		for (i = 0; i < len; i++) {
			var n = lines[i].indexOf("//console.log");
			if (n !== (-1)) {

				lines[i] = lines[i].replace("//console.log", "console.log");
			}
			outputLines.push(lines[i]);
		}
		var output = outputLines.join("\n");
		outputData(output);
	}


	function CreateVarConsoleLogs() {
		var doc = EditorManager.getFocusedEditor()._codeMirror;
		var newVar = EditorManager.getFocusedEditor()._codeMirror.getSelection();
		var selLineStart = doc.getCursor("anchor").line;
		var selLineEnd = doc.getCursor("head").line;

		var lines = doc.getValue();
		var line = lines.split("\n");
		var outputLines = new Array();
		var emptyLine = "";
		var consoleStat = "console.log('" + newVar + ": '+" + newVar + ");";


		outputLines.push(consoleStat);
		outputLines.push(emptyLine);
		var string = inputData();

		doc.setCursor(selLineStart + 1);
		var output = outputLines.join("\n");
		outputData(output);

	}
	function CreateVarAlert() {
		var doc = EditorManager.getFocusedEditor()._codeMirror;
		var newVar = EditorManager.getFocusedEditor()._codeMirror.getSelection();
		var selLineStart = doc.getCursor("anchor").line;
		var selLineEnd = doc.getCursor("head").line;

		var lines = doc.getValue();
		var line = lines.split("\n");
		var outputLines = new Array();
		var emptyLine = "";
		var alertStat = "alert('" + newVar + ": '+" + newVar + ");";


		outputLines.push(alertStat);
		outputLines.push(emptyLine);
		var string = inputData();

		doc.setCursor(selLineStart + 1);
		var output = outputLines.join("\n");
		outputData(output);

	}

	var CREARE_VAR_CONSOLE_LOGS = "com.uxentrik.CreateVarConsoleLogs";
	var CREARE_VAR_ALERT = "com.uxentrik.CreateVarAlert";
	var REMOVE_CONSOLE_LOGS = "com.uxentrik.removeConsoleLogLines";
	var COMMENT_OUT_CONSOLE_LOGS = "com.uxentrik.CommentOutConsoleLogLines";
	var COMMENT_IN_CONSOLE_LOGS = "com.uxentrik.CommentInConsoleLogLines";

	CommandManager.register("Create var Console.log Line", CREARE_VAR_CONSOLE_LOGS, CreateVarConsoleLogs);
	CommandManager.register("Create var Alert Line", CREARE_VAR_ALERT, CreateVarAlert);
	CommandManager.register("Remove Console.log Lines", REMOVE_CONSOLE_LOGS, handleRemoveConsoleLogLines);
	CommandManager.register("Comment Out Console.log Lines", COMMENT_OUT_CONSOLE_LOGS, handleCommentOutConsoleLogLines);
	CommandManager.register("Comment In Console.log Lines", COMMENT_IN_CONSOLE_LOGS, handleCommentInConsoleLogLines);

	var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
	var CreateVarWindowsCommand = {
        key: "Ctrl-Alt-C",
        platform: "win"
    };

    var CreateVarMacCommand = {
        key: "Cmd-Alt-C",
        platform: "mac"
    };

    var CreateVarCommand = [CreateVarWindowsCommand, CreateVarMacCommand];
	
	
	var CreateVarAlertWindowsCommand = {
        key: "Ctrl-Alt-A",
        platform: "win"
    };

    var CreateVarAlertMacCommand = {
        key: "Cmd-Alt-A",
        platform: "mac"
    };

    var CreateVarAlertCommand = [CreateVarAlertWindowsCommand, CreateVarAlertMacCommand];
	
	
	var RemoveConsoleLogWindowsCommand = {
        key: "Ctrl-Shift-C",
        platform: "win"
    };

    var RemoveConsoleLogMacCommand = {
        key: "Cmd-Shift-C",
        platform: "mac"
    };

    var RemoveConsoleCommand = [RemoveConsoleLogWindowsCommand, RemoveConsoleLogMacCommand];
	
	var CommentOutConsoleLogWindowsCommand = {
        key: "Alt-Shift-C",
        platform: "win"
    };

    var CommentOutConsoleLogMacCommand = {
        key: "Ctrl-Shift-C",
        platform: "mac"
    };

    var CommentOutConsoleCommand = [CommentOutConsoleLogWindowsCommand, CommentOutConsoleLogMacCommand];
	
	var CommentInConsoleLogWindowsCommand = {
        key: "Alt-Shift-Ctrl-C",
        platform: "win"
    };

    var CommentInConsoleLogMacCommand = {
        key: "Ctrl-Cmd-C",
        platform: "mac"
    };

    var CommentInConsoleCommand = [CommentInConsoleLogWindowsCommand, CommentInConsoleLogMacCommand];

	
	menu.addMenuDivider();
	menu.addMenuItem(CREARE_VAR_CONSOLE_LOGS,CreateVarCommand);
	menu.addMenuItem(CREARE_VAR_ALERT,CreateVarAlertCommand);
	menu.addMenuItem(REMOVE_CONSOLE_LOGS,RemoveConsoleCommand);
	menu.addMenuItem(COMMENT_OUT_CONSOLE_LOGS,CommentOutConsoleCommand);
	menu.addMenuItem(COMMENT_IN_CONSOLE_LOGS,CommentInConsoleCommand);
	menu.addMenuDivider();

	exports.CreateVarConsoleLogs = CreateVarConsoleLogs;
	exports.CreateVarAlert = CreateVarAlert;
	exports.handleRemoveConsoleLogLines = handleRemoveConsoleLogLines;
	exports.handleCommentOutConsoleLogLines = handleCommentOutConsoleLogLines;
	exports.handleCommentInConsoleLogLines = handleCommentInConsoleLogLines;
});