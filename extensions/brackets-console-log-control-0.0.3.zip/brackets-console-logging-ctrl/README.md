brackets-console-logging-ctrl
=============================

* Bracket extension that helps to create/delete/comment-in/comment-out the 
* console.log statements and now the alert statement has been added as well. 

* HOW TO USE:

* to create a console.log statement for a var: select the var, "Edit > Create var Console.log Line"
* That results in a new line below the var line the contain the console.log statemnt
* as the following example:

* to create a alert statement for a var: select the var, "Edit > Create var alert Line"
* That results in a new line below the var line the contain the alert statemnt
* as the following example:
var myVar=somevalue; // select myVar and the result of the "Edit > Create var alert Line" will be:
alert('myVar: '+myVar); 


* - "Remove Console.log Lines" COMMAND:
* SELECT ALL THE LINES FROM WHICH YOU WANT TO REMOVE THE CONSOLE.LOG LINES 
* and SELECT "Edit > Remove Console.log Lines"
-> result: all the lines that start with Console.log inside the selection will be deleted

* - "Comment Out Console.log Lines" COMMAND:
* SELECT ALL THE LINES FROM WHICH YOU WANT TO COMMENT OUT THE CONSOLE.LOG LINES 
* SELECT ALL Ctrl+A (window) or CMD+A (MAC) to COMMENT OUT ALL THE LINES that 
* CONTAINS "CONSOLE.LOG" LINES and SELECT "Edit > Comment Out Console.log Lines"
-> result: all the lines that start with Console.log inside the selection will be commented out

* - "Comment in Console.log Lines" COMMAND:
* SELECT ALL THE LINES FROM WHICH YOU WANT TO COMMENT IN THE LINE That CONTAINS 
* "//CONSOLE.LOG". 
* SELECT "Edit > Comment In Console.log Lines"
-> result: all the lines that start with //Console.log inside the selection will be commented in
