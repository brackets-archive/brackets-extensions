define(function (require, exports, module) {
    'use strict';

    brackets.getModule("utils/ExtensionUtils").loadStyleSheet(module, "ubuntu.css");

});
