Brackets Ubuntu
========

Makes Brackets more Ubuntu friendly by appliying the Ubuntu font family to the UI, excluding CodeMirror. It also adjusts font weight and shadow for improved readability.

![preview](https://raw.githubusercontent.com/FinalDevStudio/brackets-ubuntu/master/preview.png)

Based on [Bolder Menu Fonts](https://github.com/Mark-Simulacrum/Brackets-Bolder-Menu-Font) by [Mark Simulacrum](https://github.com/Mark-Simulacrum).
