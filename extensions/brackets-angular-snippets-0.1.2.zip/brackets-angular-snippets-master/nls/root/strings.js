// English - root strings
define({
    'COMMAND_NAME': 'Enable Angular Snippets',
    'COMMAND_DOCS': 'Angular Snippets Docs',
	'EXTENSION_NAME': 'Angular Snippets',
    'DOCS_PANEL_TITLE': 'Angular Snippets Docs'
});