/*jshint maxlen:false */
/*global define */

define({
    BUTTON_CANCEL:                      "Abbrechen",
    BUTTON_DEFAULTS:                    "Standard wiederherstellen",
    BUTTON_SAVE:                        "Speichern"
});
