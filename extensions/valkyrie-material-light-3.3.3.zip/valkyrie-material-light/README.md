# brackets-valkyrie-material-light
Valkyrie is a light theme for all lover of Material Design. Valkyrie respect the principle of colors and hazmonization of Material Design

====================================================================

PHP ![php](https://raw.githubusercontent.com/Dr-Chaos/images/master/php.png) 
JavaScript ![js](https://raw.githubusercontent.com/Dr-Chaos/images/master/js.png) 
CSS ![css](https://raw.githubusercontent.com/Dr-Chaos/images/master/css.png) 
HTML ![html](https://raw.githubusercontent.com/Dr-Chaos/images/master/html.png)
