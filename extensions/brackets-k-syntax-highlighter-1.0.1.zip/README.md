# K framework for Brackets

K framework is an open source project and you can view the source code here: https://github.com/kframework

## Features

K Syntax highlighting support for Brackets, made with CodeMirror
K code snippets

## Install

Install it using Brackets Install Manager

## Syntax Highlighter Example
