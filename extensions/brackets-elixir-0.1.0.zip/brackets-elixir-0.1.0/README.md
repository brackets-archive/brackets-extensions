# Brackets Elixir

Provides primitive highlighting for [Elixir](http://elixir-lang.org). It's at least a step up from telling Brackets you're using Ruby.

This extension is nothing more than glue between [halohalospecial](https://github.com/halohalospecial)'s [codemirror-elixir-mode](https://github.com/halohalospecial/codemirror-elixir-mode) and [BigBlueHat](https://github.com/BigBlueHat)'s [brackets-langman](https://github.com/BigBlueHat/brackets-langman).

## Contributing

Want Brackets-Elixir improved? Me too! Feel free to open an issue or PR here on github.

## License

[MIT](http://opensource.org/licenses/mit)

Glued together by Matt Enlow ([@novaugust](http://github.com/novaugust) on most parts of the internet)
