Brackets Dark Theme
# Kindfeeling-dark

起動は画像を表示するために少し遅くなります。(Base64デコード処理のためです。)  
Startup is slightly slower to display the image. (This is for Base64 decoding.)

![css](https://user-images.githubusercontent.com/54123288/74583794-352b0f00-500e-11ea-86d0-b672bedff614.png)
![html](https://user-images.githubusercontent.com/54123288/74583795-35c3a580-500e-11ea-8f86-3b7a1a8b6714.png)
![js](https://user-images.githubusercontent.com/54123288/74583796-365c3c00-500e-11ea-928e-407a6b831f14.png)
