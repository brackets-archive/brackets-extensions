# Deep Chill
Cool color scheme for Brackets.

## HTML

![Screenshot](https://github.com/rnarrkus/deepchill/blob/master/screenshot01.png)

## CSS

![Screenshot](https://github.com/rnarrkus/deepchill/blob/master/screenshot02.png)