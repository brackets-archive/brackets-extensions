Lapland Brackets theme
=======

Dark theme, nice colors. That's it.

## HTML
![HTML Screenshot](https://github.com/vtrrsl/lapland/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/vtrrsl/lapland/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/vtrrsl/lapland/blob/master/screenshots/js.png)
