# Dream PHP

A dream theme for [Brackets](http://brackets.io/) that simulates PHP coloring scheme of Dreamweaver.

## PHP
![PHP Screenshot](screenshots/php.png)

## HTML
![HTML Screenshot](screenshots/html.png)

## CSS
![CSS Screenshot](screenshots/css.png)

## JavaScript
![JavaScript Screenshot](screenshots/javascript.png)

## License
Released under the [MIT License](LICENSE).