Brackets Github Theme
=====================
Light Github-like theme for [Brackets](http://brackets.io) editor. 

### HTML
![HTML Screenshot](https://github.com/georapbox/brackets-github-theme/blob/master/screenshots/html.png)

### CSS
![HTML Screenshot](https://github.com/georapbox/brackets-github-theme/blob/master/screenshots/css.png)

### Javascript
![HTML Screenshot](https://github.com/georapbox/brackets-github-theme/blob/master/screenshots/javascript.png)
