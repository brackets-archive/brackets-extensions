/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    "FILTERSET_NOT_FOUND" : "A filter set was not found named {0}",
    "REVIEW_PREFERENCE" : "Review preferences with prefix {0}",
    "PREFERENCES_FILE" : "Preferences: {0}",
    "DISMISS" : "Dismiss"
});
