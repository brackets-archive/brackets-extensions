![Brackets Themes](https://github.com/CMYKpixels/tomorrow-night-nineties/blob/master/bracket-themes-icon-100x99.png?raw=true)
A Tomorrow Night Nineties Theme for Brackets
=========

This theme is itself based on Patrick Fricano's [Patrick Fricano's Tomorrow Night Eighties](https://github.com/patrickfatrick/TomorrowNightEighties) 
this is itself based on Chris Kempson's [Chris Kempson's Tomorrow Night Eighties](https://github.com/chriskempson/tomorrow-theme) theme, adapted for Brackets.


This is itself based on Ryan Stewart's [Tomorrow Night theme for Brackets](https://github.com/Brackets-Themes/TomorrowNight). 

#####For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)

---
####HTML PREVIEW
![HTML](https://github.com/CMYKpixels/tomorrow-night-nineties/blob/master/html.png.jpg?raw=true)

####CSS PREVIEW
![CSS](https://github.com/CMYKpixels/tomorrow-night-nineties/blob/master/JavaScript.png?raw=true)

####JAVASCRIPT PREVIEW
![JAVASCRIPT](https://github.com/CMYKpixels/tomorrow-night-nineties/blob/master/JavaScript.png?raw=true)