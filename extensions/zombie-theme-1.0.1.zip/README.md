Zombie theme for Brackets
=========

Dark zombie theme for Brackets

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)

![zombie screenshot html](https://github.com/RogueVoo/zombie-theme/blob/master/screenshot-html.jpg)
![zombie screenshot css](https://github.com/RogueVoo/zombie-theme/blob/master/screenshot-css.jpg)
![zombie screenshot js](https://github.com/RogueVoo/zombie-theme/blob/master/screenshot-js.jpg)