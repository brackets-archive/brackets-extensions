Zenburn Theme for Brackets
=========

Dark low contrast color themes originally designed for Vim 

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)



![Zenburn php](https://github.com/chechnyan/Zenburn/blob/master/screenshot.PNG)
