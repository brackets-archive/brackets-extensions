# Brackets peacock

Peacock color theme for Brackets editor