# Brackets Magento 2 Hint [![Talk.ai](https://img.shields.io/badge/Release-0.1.0-green.svg)](https://github.com/rafaelstz/brackets-magento-hint/releases)

Ideal for developing Magento 2 themes, get hints of the main functions, classes and methods. This plugin will greatly facilitate the development, mainly on the frontend. He suggests methods, built-in functions and classes Magento quickly and easily, it besides being open has a very simple way of contribution to customize your way.


## Suggestions

If you have something to improve these plugin, please create a [issue](https://github.com/rafaelstz/brackets-magento-hint/issues).

## License

MIT © [Rafael Corrêa Gomes](https://github.com/rafaelstz)
