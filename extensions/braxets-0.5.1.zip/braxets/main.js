/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window */

define(function (require, exports, module) {
    "use strict";
	require(["haxe-brackets"], function (haxebrackets) {
		var	AppInit             = brackets.getModule("utils/AppInit"),
			CodeHintManager     = brackets.getModule("editor/CodeHintManager"),
			NodeDomain          = brackets.getModule("utils/NodeDomain"),
			CommandManager      = brackets.getModule("command/CommandManager"),
			Commands            = brackets.getModule("command/Commands"),
			ExtensionUtils      = brackets.getModule("utils/ExtensionUtils");
		
		var haxeDomain = new NodeDomain("haxecompiler", ExtensionUtils.getModulePath(module, "node/haxecompiler"));
		window.haxeDomain = haxeDomain;
		
		haxebrackets.haxebrackets.autocompletion.Autocompletion.commandManager = CommandManager;
		haxebrackets.haxebrackets.autocompletion.Autocompletion.commands = Commands;
		haxebrackets.haxebrackets.autocompletion.Autocompletion.haxeDomain = haxeDomain;
		
		function HaxeHints() {
		}
		
		
		HaxeHints.prototype.hasHints = 
			haxebrackets.haxebrackets.autocompletion.Autocompletion.hasHint;
		
		HaxeHints.prototype.getHints =
			haxebrackets.haxebrackets.autocompletion.Autocompletion.getHints;
		
		HaxeHints.prototype.insertHint =
			haxebrackets.haxebrackets.autocompletion.Autocompletion.insertHint;
		
		AppInit.appReady(function () {
			// Register code hint providers
			var haxeHints = new HaxeHints();
			CodeHintManager.registerHintProvider(haxeHints, ["hx"], 0);
			
			haxeDomain.exec("getSDKsConfig", "/Users/benjamin.dasnois")
				.done(function (doc) {
				console.log("getSDKsConfig: " + doc);
			})
				.fail(function (err) {
				console.log("getSDKsConfig failed: " + err);
			});
	 
    	});
	});
});