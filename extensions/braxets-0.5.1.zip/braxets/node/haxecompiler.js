var spawn = require("child_process").spawn;
var fs = require('fs');

function getCompletion(projectRoot, file, byteNumber, errback)
{
	var data = "";
    //var process = spawn("haxe", ["-main", "Main", "-cp", "C:\\Users\\Benjamin\\Documents\\HaxeProject", "-js", "something.js", "--display", "C:\\Users\\Benjamin\\Documents\\HaxeProject\\Main.hx@73"]);
	var env = [];
	
	/** Haxe 3.x **/
	//env['HAXE_STD_PATH'] = "/Users/benjamin.dasnois/repo/haxe-3.1.3/std";
	//env['PATH'] = "/Users/benjamin.dasnois/repo/haxe-3.1.3:/Users/benjamin.dasnois/repo/neko-2.0.0/";
	//env['HOME'] = "/Users/benjamin.dasnois";
	
	/** Haxe 2.x **/
	//env['HAXE_LIBRARY_PATH'] = "/Users/benjamin.dasnois/repo/haxe-2.10/std";
	//env['DYLD_LIBRARY_PATH'] = "/Users/benjamin.dasnois/repo/neko-1.8.2";
	//env['PATH'] = "/Users/benjamin.dasnois/repo/haxe-2.10:/Users/benjamin.dasnois/repo/neko-1.8.2/";
	//env['HOME'] = "/Users/benjamin.dasnois";

	var configTxt = fs.readFileSync(projectRoot + "/buildEnv.json");
	var configTemp = JSON.parse(configTxt);
	for (var envVar in configTemp)
	{
		if (configTemp.hasOwnProperty(envVar))
		{
			env[envVar] = configTemp[envVar];
		}
	}
	
    var process = spawn("haxe", ["autocomplete.hxml", "--display", file+"@" + byteNumber],
						{cwd:projectRoot, env:env});
	process.stderr.on("end", function() {
		errback(null, data);
	});
    process.stderr.on("data", function(chunk) {
        data += chunk.toString();
		//errback(null, chunk.toString());
    });
}

function getSDKsConfig(projectRoot, errback)
{
	var fs = require("fs");
	var filePath = projectRoot + "/.haxe-brackets";
	if(!fs.exists(filePath))
	{
		errback("File does not exist", null);
		return;
	}
	var content = fs.readFileSync(filePath);
	errback(null, content);
}

function init(domainManager) {
    if (!domainManager.hasDomain("haxecompiler")) {
        domainManager.registerDomain("haxecompiler", {major: 0, minor: 1});
    }
    domainManager.registerCommand(
        "haxecompiler",       // domain name
        "getCompletion",    // command name
        getCompletion,   // command handler function
        true,          // this command is synchronous in Node
        "Returns the autocompletion from the Haxe compiler using autocomplete.hxml at the project's root.",
        [{name: "projectRoot", // parameters
            type: "string",
            description: "The project's root folder's path. Used to determine location of autocomplete.hxml"}],
        [{name: "file", // return values
            type: "string",
            description: "The path of the file in which autocompletion should occur."}],
        [{name: "byteNumber", // return values
            type: "number",
            description: "The position in the file (in Bytes) where autocompletion should occur."}]
    );
	
	domainManager.registerCommand(
        "haxecompiler",       // domain name
        "getSDKsConfig",    // command name
        getSDKsConfig,   // command handler function
        true,          // this command is synchronous in Node
        "Returns the configuration of Haxe SDKs.",
		[{name: "projectRoot",
		 	type: "string",
		  	description: "well..."
		 }]
    );
}

exports.init = init;