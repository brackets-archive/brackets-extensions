# Animations deactivator
Disable animations for better perfomance