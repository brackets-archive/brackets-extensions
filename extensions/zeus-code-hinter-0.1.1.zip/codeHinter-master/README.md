# codeHinter
It's a Brackets extension that allows you to get code hints for our "loc-acc.json" file for the current interactivity that you are working on.