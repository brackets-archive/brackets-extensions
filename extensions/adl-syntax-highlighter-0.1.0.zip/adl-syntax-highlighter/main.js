
define(function(require, exports, module) {
	'use strict';
	
	var LanguageManager = brackets.getModule('language/LanguageManager');

	require("adl");

	LanguageManager.defineLanguage('adl', {
	  name: 'Adl',
	  mode: 'adl',
	  fileExtensions: ['adl', 'adls', 'adlf'],
	  lineComment: ['--']
	});     
	
	//console.log('Factor syntax highlighting loaded.');
});