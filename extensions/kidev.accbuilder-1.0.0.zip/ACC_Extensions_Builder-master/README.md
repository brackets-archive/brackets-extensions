# ACC Extensions Builder for Brackets [Adobe Creative Cloud Extension Builder]
Support for Adobe CC 2014 / 2018 [CEP 8]

Brackets extension to let you create HTML based extensions for Adobe Creative Cloud applications such as Photoshop, Illustrator, InDesign, After Effects, Prelude and FLASH Pro.

![](http://i.cubeupload.com/QtqXdr.png)
![](http://i.cubeupload.com/jnDCk6.jpg)

# Installation
You don't need to download anything. Just do the following:

### Open Brackets or Edge code
Choose File > Extension Manager and click Install from URL
Paste the URL of this page (https://github.com/KIDevs/ACC_Extensions_Builder) and click Install
No need to relaunch the app, your extension is ready to use.

# Credits
Based on http://davidderaedt.github.io/CC-Extension-Builder-for-Brackets/

