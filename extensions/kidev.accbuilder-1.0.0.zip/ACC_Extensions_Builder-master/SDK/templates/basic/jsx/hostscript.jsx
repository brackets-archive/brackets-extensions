function sayHello(){
    alert("hello from ExtendScript");
}
