# LOIDMAN

A mix of Wayman's Dark and Darkaloid themes for brackets!

Wayman Dark's color palette with a focus colouring and decolouring effect! 
While you keep the mouse over the code area it will be coloured, move your mouse to another place and the color is gone!

Please check out both links below, this project wouldn't have been possible without them!

# LICENSE 
MIT

# CREDIT
Color pallete: Wayman https://github.com/Waymans/Brackets-Themes/tree/master/Dark

Color shifting code: Ismalf https://github.com/Ismalf/darkaloid


