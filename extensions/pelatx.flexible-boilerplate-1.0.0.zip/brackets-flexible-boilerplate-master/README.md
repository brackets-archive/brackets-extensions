# brackets-flexible-boilerplate
A boilerplate extension for Brackets editor that let you copy only desired items of a directory. 

##Install from URL

1. Open the the Extension Manager from the File menu
2. Copy paste the URL of the github repo or zip file


##Install from file system

1. Download this extension using the ZIP button above and unzip it.
2. Copy it in Brackets' `/extensions/user` folder by selecting `Help > Show Extension Folder` in the menu. 
3. Reload Brackets.

##Instructions
