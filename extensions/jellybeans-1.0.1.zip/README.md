Jellybeans Theme for Brackets
=========
This is a port of [nanotech's Jellybeans theme for Vim](https://github.com/nanotech/jellybeans.vim).

To install, in Brackets go to Extension Manager and click the Themes tab. Search for 'jellybeans',
then click 'Install'.

For more themes, see the [Brackets Themes website](http://brackets-themes.github.io/)

## HTML
![Jellybeans Theme in an HTML file](https://github.com/jsbalrog/brackets-jellybeans/blob/master/jellybeans-screenshot-html.png)
