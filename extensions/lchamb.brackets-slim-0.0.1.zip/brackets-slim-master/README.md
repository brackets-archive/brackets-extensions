# Brackets Slim

Syntax highlighting for Slim in Brackets [http://slim-lang.com](http://slim-lang.com).

## Todo

- Add Slim to HTML complier
- Add unit tests
