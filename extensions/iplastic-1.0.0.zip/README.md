iPlastic Theme for Brackets
===========================

iPlastic by Jeroen van der Ham, converted from TextMate theme.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/IPlastic/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/IPlastic/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/IPlastic/blob/master/screenshots/js.png)
