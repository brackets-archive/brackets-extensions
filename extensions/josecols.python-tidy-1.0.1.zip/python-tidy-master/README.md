Python Tidy Brackets Extension
==============================

Compatible with Sprint 24 and above.

Clean up, regularize, and reformat the text of Python scripts by `Edit > Python Tidy` menu or `Cmd-L(Mac) / Ctrl-P(Win)` key or on save (if checked).

Note
----

This extension makes use of PythonTidy.py package (https://pypi.python.org/pypi/PythonTidy/). You need Python for this extension to work.

Installation
------------

Download zip and extract into Brackets extensions folder (you can open this folder by clicking `Help > Show Extensions Folder` menu).


josecolsg@gmail.com