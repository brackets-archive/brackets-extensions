define(function (require, exports, module) {
    'use strict';
    
    document.getElementById('editor-holder').style += '; -webkit-font-smoothing: none !important;';
});
