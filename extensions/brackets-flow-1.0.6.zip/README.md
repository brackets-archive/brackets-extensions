# brackets-flow [![Build Status](https://travis-ci.org/zaggino/brackets-flow.svg?branch=master)](https://travis-ci.org/zaggino/brackets-flow)

Brackets extension which provides support for working with Flow.

## How to install

Use [brackets-npm-registry](https://github.com/zaggino/brackets-npm-registry)

## How to use

Have `.flowconfig` in your project root and `flow-bin` installed in your `node_modules`.
