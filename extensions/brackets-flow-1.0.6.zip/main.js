define(function (require, exports, module) {
  'use strict';

  require('./node_modules/brackets-inspection-gutters/dist/main')();
  require('dist/code-inspection')();

});
