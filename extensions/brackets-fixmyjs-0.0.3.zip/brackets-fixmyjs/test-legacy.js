/* global console */
// This code has issues
'use strict';
// Missing bits
var a = new Object()

// Array constructions
var b = new Array()

// Number constructions
var c = new Number(3)

// JSON constructions
var d = new JSON({})

// Leading decimals
var e = 0.25;

console.log(a,b,c,d,e);
