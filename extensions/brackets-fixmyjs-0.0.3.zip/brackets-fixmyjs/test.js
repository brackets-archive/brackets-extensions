// This code has issues
'use strict';
// Missing bits
var q = Array()
var t = new Object()

// Array literal test
var a = Array();
var ab = [];

// Array constructions
var b = new Array();
var bb = [];

// Literals
var c = Object();
var cb = [];

// Number constructions
var d = new Number(3)

// JSON constructions
var e = new JSON({});

// Leading decimals
var g = .25;

console.log(q,t,a,ab,b,bb,c,cb,d,e,g);
