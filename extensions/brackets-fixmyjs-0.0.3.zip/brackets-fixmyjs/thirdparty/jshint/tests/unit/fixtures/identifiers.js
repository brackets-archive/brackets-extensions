var ascii;
var num1;
var lifé = 42;
var π = 3.1415;
var привет = "hello";
var \u1d44;
var encoded\u1d44;
var \uFF38;  // Lu (third to last)
var \uFF58;  // Ll (third to last)
var \u1FBC;  // Lt (third to last)
var \uFF70;  // Lm (third to last)
var \u4DB3;  // Lo (third to last within a range)
var \u97CA;  // Lo (third to last within a range)
var \uD7A1;  // Lo (third to last within a range)
var \uFFDA;  // Lo (third to last)
var \uA6ED;  // Nl (third to last)
var \u0024;  // $
var \u005F;  // _
var \u0024\uFF38;  // Lu (third to last)
var \u0024\uFF58;  // Ll (third to last)
var \u0024\u1FBC;  // Lt (third to last)
var \u0024\uFF70;  // Lm (third to last)
var \u0024\u4DB3;  // Lo (third to last within a range)
var \u0024\u97CA;  // Lo (third to last within a range)
var \u0024\uD7A1;  // Lo (third to last within a range)
var \u0024\uFFDA;  // Lo (third to last)
var \u0024\uA6ED;  // Nl (third to last)
var \u0024\uFE24;  // Mn (third to last)
var \u0024\uABE9;  // Mc (third to last)
var \u0024\uFF17;  // Nd (third to last)
var \u0024\uFE4E;  // Pc (third to last)
var \u0024\u200C;  // ZERO WIDTH NON-JOINER
var \u0024\u200D;  // ZERO WIDTH JOINER
var \u0024\u0024;  // $
var \u0024\u005F;  // _
