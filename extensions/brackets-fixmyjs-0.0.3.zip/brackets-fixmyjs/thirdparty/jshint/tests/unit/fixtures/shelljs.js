target.foo = function () {};

echo();
exit();
cd();
pwd();
ls();
find();
cp();
rm();
mv();
mkdir();
test();
cat();
sed();
grep();
which();
dirs();
pushd();
popd();
env();
exec();
chmod();
config.hi = 'hi';
error();
tempdir();

// node stuff
require('hi');
module.exports = 'hi';
process.exit();
