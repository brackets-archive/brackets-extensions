/*jshint
undef:false*/
foo();
