/* jshint undef:false */
foo();
