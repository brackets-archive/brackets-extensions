var one = 1, two = 2;

var string = `  ${one} + ${two}
= ${one + two}`;

var unterminated = `${one}