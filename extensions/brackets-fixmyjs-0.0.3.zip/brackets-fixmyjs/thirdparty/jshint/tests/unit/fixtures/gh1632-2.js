/*jshint undef:true*/
/* global blah:true */
var x = blah();
blah = x;
