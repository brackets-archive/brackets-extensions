/* jshint undef: true */

module ng from "angular";
module em from "ember"

ng.controller();

var module = {};
module.exports = "foo";
