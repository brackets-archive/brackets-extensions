(function foo() {
  "use strict";
  return "=";
}());
