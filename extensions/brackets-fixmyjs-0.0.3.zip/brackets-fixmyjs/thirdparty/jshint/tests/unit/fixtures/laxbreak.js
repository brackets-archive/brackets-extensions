var a = [
    'one'
  , 'two'
];

a = [
    'one',
    'two'
];

var b = {
    one: 1
  , two: 2
};

b = {
    one: 1,
    two: 2
};
