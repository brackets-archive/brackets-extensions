function b() {
    "use strict";
    a();
}

function a() { }