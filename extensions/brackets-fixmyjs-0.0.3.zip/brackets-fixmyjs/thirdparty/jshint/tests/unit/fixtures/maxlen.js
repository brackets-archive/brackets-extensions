var a = "test maxlen";
var b = "test maxlen ";
var c = "test maxlen  ";
  //  http://jshint.com/docs/
var someCode; // http://jshint.com/docs/
  // http://jshint.com/docs/ is a good website
  // http://jshint.com/docs/
  /* http://jshint.com/docs/
   */
a = 23;
  /*
   * http://jshint.com/docs/
   */
a = 23;
/*
   http://jshint.com/docs/
 */
