var a = [
  /1/,
  /2/
];

return a;
