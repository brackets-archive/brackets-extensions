# BracketsUML
A Brackets extension that allows you to create PlantUML diagrams from within the editor.

Planned features are:

- Preview the resulting diagram in a panel below the editor
- Basic syntax highlighting for sequence diagrams (to start)
- Ability to save the resulting diagram
- Advanced syntax highlighting (more diagram types; smarter Code Mirror mode/lexer)
