define({
    BEAUTIFY_ON_SAVE: 'Beautify al salvataggio'
});
