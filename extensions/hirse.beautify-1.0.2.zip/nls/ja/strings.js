define({
    BEAUTIFY_ON_SAVE: '保存時に Beautify する'
});
