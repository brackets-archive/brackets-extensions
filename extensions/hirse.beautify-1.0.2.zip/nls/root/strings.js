define({
    BEAUTIFY: 'Beautify',
    BEAUTIFY_ON_SAVE: 'Beautify on save',
    UNSUPPORTED_TITLE: 'Unsupported Language',
    UNSUPPORTED_MESSAGE: 'This language is not supported.\n Supported languages are JavaScript, JSON, HTML, XML, SVG, HTML in PHP, Embedded JavaScript, Handlebars, CSS, SCSS, and LESS.'
});
