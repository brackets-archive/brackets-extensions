define({
    BEAUTIFY_ON_SAVE: 'Beautify beim Speichern',
    UNSUPPORTED_TITLE: 'Sprache nicht unterstützt',
    UNSUPPORTED_MESSAGE: 'Diese Sprache ist nicht unterstützt.\n Verfügbare Sprachen sind JavaScript, JSON, HTML, XML, SVG, HTML in PHP, Embedded JavaScript, Handlebars, CSS, SCSS, und LESS.'
});
