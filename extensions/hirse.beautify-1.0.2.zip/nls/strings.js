define(function (require, exports, module) {
    'use strict';
    module.exports = {
        root: true,
        de: true,
        es: true,
        it: true,
        ja: true
    };
});
