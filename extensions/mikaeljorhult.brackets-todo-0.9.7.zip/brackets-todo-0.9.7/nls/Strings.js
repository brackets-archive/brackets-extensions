define(function (require, exports, module) {
  'use strict';

  module.exports = {
    root: true,
    de: true,
    es: true,
    fi: true,
    fr: true,
    gl: true,
    it: true,
    pt: true,
    ru: true,
    sv: true,
    tr: true,
    uk: true,
    zh: true
  };
});
