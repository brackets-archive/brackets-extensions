CHANGELOG
=========

##1.0.1
- [NEW] Add support for white-space (https://github.com/DennisKehrig/brackets-show-whitespace)
- [NEW] Add support for code-folding (https://github.com/thehogfather/brackets-code-folding)
- [NEW] Add CHANGELOG
- [CHANGE] Update flat colors
- [CHANGE] Require Brackets 1.0.0 or higher
- [DOCS] Update README

##1.0.0
- [NEW] Initital Release