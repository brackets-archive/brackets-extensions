# Blumberry Theme
A lightweight Coda-inspired [Brackets](http://brackets.io/) Theme.

## HTML
![HTML Screenshot](magic/html.png)

## CSS
![CSS Screenshot](magic/css.png)

## JavaScript
![JavaScript Screenshot](magic/javascript.png)

## PHP
![PHP Screenshot](magic/php.png)

## Copyright and License
Copyright (c) 2014 [Increment Web Services](https://incrementwebservices.com/). Released under the [MIT License](LICENSE).
