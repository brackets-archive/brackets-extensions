# jsLint2-for-Brackets
Support last version jsLint for Adobe Brackets, this version support ES6 and many more good parts.
