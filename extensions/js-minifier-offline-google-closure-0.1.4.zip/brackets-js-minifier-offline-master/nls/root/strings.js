// English - root strings

define({
    AppTitle: 'JavaScript Minifier',
    editMenuText: 'Create Minified JavaScript version',
    editMenuTextToggle: 'JavaScript Minifification On Save',
    contextMenuText: 'Create Minified version'
});
