# brackets-js-minifier-offline
Brackets Extension - Minify JavaScript using the offline Google closure compiler

**Options**

* Edit menu will have two new options

1. "Create Minified JavaScript version" this will save a minfied version of the open JavaScript file keyboard shortcut Ctrl-Alt-M.
2. "JavaScript Minifification On Save" (Toggle) When you save a JavaScript file a minified version will be created.

* Additionally you can right click a JavaScript file in the project window and select "Create Minified version".

_Future: Options dialog: optimization level currently defaults to simple._
