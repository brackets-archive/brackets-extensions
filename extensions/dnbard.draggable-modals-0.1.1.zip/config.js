define(function(require, exports, module){
    module.exports = {
        observer: {
            attributes: true,
            childList: true,
            characterData: true
        }
    }
});
