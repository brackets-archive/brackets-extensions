define(function(require, exports, module){
    require('./services/mutation').init();
    require('./services/tracking').init();
});
