/**
 * Need to run brackets from source
 *
 * https://github.com/adobe/brackets/wiki/How-to-Hack-on-Brackets
 *
 * Test commit to dev
 */


define(function (require, exports, module) {
    "use strict";

    var main = require("main");

    /**
     * [[Description]]
     * @param {[[Type]]} "Hello World" [[Description]]
     * @param {[[Type]]} function (    [[Description]]
    describe("Hello World", function () {
        it("should expose a handleHelloWorld method", function () {
            expect(main.helloWorld).toEqual('Hello world!');
        });
    });
	*/
});
