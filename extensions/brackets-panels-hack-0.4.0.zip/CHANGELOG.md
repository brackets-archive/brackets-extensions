## v0.4.0 (2017-05-16)

Changed the heuristic to retrieve the title.

Try to move extension icons from the main toolbar into the tabbar.

Add a note for Usage by other extensions.


## v0.3.0 (2017-05-06)

Move the code hints icon in the tabbar.

Correct the logic to select the active tab.


## v0.2.0 (2017-05-03)

Retrieve the title from the panel, fallback to the id.

Correct style for current tab (add bottom border).

Use the id of the panel for the title of the tab.


## v0.1.0 (2017-05-01)

Created an hack to avoid to see stacked panels.
