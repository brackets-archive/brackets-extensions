# CHANGELOG PHONEGAP SPAIN

v 0.0.1

* Created :)

v 0.0.2

* Change select color and increase version :)