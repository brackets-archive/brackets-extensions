hacker theme for brackets :D

ScreenShot <br />[Hacker Theme](https://raw.githubusercontent.com/GhostThrone/hacker-theme-brackets/master/hacker-theme-screenshot.jpg)