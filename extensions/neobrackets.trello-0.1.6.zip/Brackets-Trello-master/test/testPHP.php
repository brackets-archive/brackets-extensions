<!DOCTYPE html>
<html>
<body>
    
<!-- trello: this is a html trello comment in php file -->
<!--  trello todo: this is a html todo trello comment in php file -->
 
<?php
// trello: this is a trello comment in php file
// trello todo: this is a todo trello comment in php file
#  trello todo: this is a # trello comment
/* trello: this is multiple line trello comment in php file, but not support now */
/*  trello todo: this is multiple line trello todo comment in php file, but not support now */
/* 
 * trello: multiple line trello comment 1 in php file, but not support now
 * trello: multiple line trello comment 2 in php file, but not support now
 * 
 * */
?>
    
</body>
</html>