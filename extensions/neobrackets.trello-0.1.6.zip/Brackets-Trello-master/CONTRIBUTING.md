# Bug

You found a bug? We would like to fix it asap! So please open an issue and follow some simple steps.
Which version of this extension do you use? Are there any logs in the developer console which are related? Post them please.

**Attention** Please delete all your tokens (The token appears at the end of each url)

# Feature Request

We <3 new features. Please open an issue and we will response asap and try to code it :)
If you have some design talent you may want to add screen mockups so we can easily be excited about that feature request!
