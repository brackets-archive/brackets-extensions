## Trello list tab
Idea for new structure:
Recent:

- To Do
	+ Bla bla
	+ askj
	+ foo bar
	+ Baadas
	+ adfa
	+ afasdas
	+ adawjd
- Doing
	+ asdasbdka
	+ askdasd
	+ ajdksda

New idea:

- To Do
	+ test/index.php
		+ Bla bla
		+ askj
	+ test/index.html 
		+ foo bar
		+ Baadas
	+ adfa
	+ afasdas
	+ adawjd
- Doing
	+ asdasbdka
	+ askdasd
	+ ajdksda
	
And we can order by file so the tasks for the current file are at the top.
Maybe show it another color if the current user is a member of the card.