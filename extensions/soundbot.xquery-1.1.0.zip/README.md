### XQuery
This plugin provides XQuery language support and auto-completion in the Brackets editor
### License
MIT, see LICENSE file
