# Black Flat Theme (Brackets theme)

![Theme print](https://raw.githubusercontent.com/MatheusSThomaz/Brackets-BlackFlat-theme/master/screen.png)
