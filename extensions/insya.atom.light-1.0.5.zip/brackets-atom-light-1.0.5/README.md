Brackets Atom Light Theme
========

### Installation
- Method 1: Open the Brackets Extension Manager and search for brackets atom light
- Method 2: Download directly from GitHub using either the latest release and install the contents to extensions/user/brackets.atom.light folder.

![Atom Light](https://github.com/yasinkuyu/brackets-atom-light/raw/master/screenshot.png)

### Contribution
Fork & Pull Request

### License
The MIT License

##### Brackets Tools
https://github.com/yasinkuyu/brackets-tools

#####Brackets Inline Units 
Units Conversion Extension (px to em /em to px etc.)
https://github.com/yasinkuyu/brackets-units

2014 Yasin Kuyu - [@yasinkuyu](https://twitter.com/yasinkuyu)
