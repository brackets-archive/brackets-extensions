ContextMenu Toggle Comment
=========================

Adds the menu item into the context menu of the editor to toggle a comment.

## Change log
* 1.0.0
  * Initial release


## Developed by
* Max Grass

## License
This project is released under [The MIT License](http://www.opensource.org/licenses/mit-license.php).
