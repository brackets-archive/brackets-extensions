Proxy Extension for Brackets
---

Adds a proxy dialog to the Brackets File menu.