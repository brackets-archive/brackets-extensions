var DockerfileLexer = (function (undefined) {
function CDFA_base(){
	this.ss=undefined;
	this.as=undefined;
	this.tt=undefined;
this.stt={};
}
CDFA_base.prototype.reset = function (state) {
	this.cs = state || 	this.ss;
this.bol=false;
};
CDFA_base.prototype.readSymbol = function (c) {
	this.cs = this.nextState(this.cs, c);
};
CDFA_base.prototype.isAccepting = function () {
	var acc = this.as.indexOf(this.cs)>=0;
if((this.stt[this.cs]===-1)&&!this.bol){
acc=false;}
return acc;};
CDFA_base.prototype.isInDeadState = function () {
	return this.cs === undefined || this.cs === 0;
};
CDFA_base.prototype.getCurrentToken = function(){
	var t= this.tt[this.cs];
var s=this.stt[this.cs];
if(s!==undefined){return this.bol?t:s;}
return t;};

function CDFA_DEFAULT(){
	this.ss=1;
	this.as=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,34,35,36,39,45,50,53,58,63,70,74,78,80,87,88,89];
	this.tt=[null,null,61,60,60,0,61,61,61,61,61,61,61,61,61,61,61,61,0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,57,57,57,null,null,57,null,null,null,null,null,57,null,null,null,null,57,null,null,57,null,null,null,null,57,null,null,null,null,57,null,null,null,null,null,null,57,null,null,null,57,null,null,null,57,null,57,null,null,null,null,null,null,57,57,57];
this.stt={};
}
CDFA_DEFAULT.prototype= new CDFA_base();
CDFA_DEFAULT.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "#" || "#" < c)  && (c < "A" || "A" < c)  && (c < "C" || "C" < c)  && (c < "E" || "F" < c)  && (c < "L" || "M" < c)  && (c < "O" || "O" < c)  && (c < "R" || "S" < c)  && (c < "U" || "W" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("#" === c )){
next = 5;
} else if(("A" === c )){
next = 6;
} else if(("C" === c )){
next = 7;
} else if(("E" === c )){
next = 8;
} else if(("F" === c )){
next = 9;
} else if(("L" === c )){
next = 10;
} else if(("M" === c )){
next = 11;
} else if(("O" === c )){
next = 12;
} else if(("R" === c )){
next = 13;
} else if(("S" === c )){
next = 14;
} else if(("U" === c )){
next = 15;
} else if(("V" === c )){
next = 16;
} else if(("W" === c )){
next = 17;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
}
break;
case 5:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 5;
}
break;
case 6:
if(("D" === c )){
next = 19;
} else if(("R" === c )){
next = 20;
}
break;
case 7:
if(("M" === c )){
next = 19;
} else if(("O" === c )){
next = 22;
}
break;
case 8:
if(("N" === c )){
next = 23;
} else if(("X" === c )){
next = 24;
}
break;
case 9:
if(("R" === c )){
next = 25;
}
break;
case 10:
if(("A" === c )){
next = 26;
}
break;
case 11:
if(("A" === c )){
next = 27;
}
break;
case 12:
if(("N" === c )){
next = 28;
}
break;
case 13:
if(("U" === c )){
next = 29;
}
break;
case 14:
if(("T" === c )){
next = 30;
}
break;
case 15:
if(("S" === c )){
next = 31;
}
break;
case 16:
if(("O" === c )){
next = 32;
}
break;
case 17:
if(("O" === c )){
next = 33;
}
break;
case 19:
if(("D" === c )){
next = 34;
}
break;
case 20:
if(("G" === c )){
next = 34;
}
break;
case 22:
if(("P" === c )){
next = 37;
}
break;
case 23:
if(("T" === c )){
next = 38;
} else if(("V" === c )){
next = 34;
}
break;
case 24:
if(("P" === c )){
next = 40;
}
break;
case 25:
if(("O" === c )){
next = 41;
}
break;
case 26:
if(("B" === c )){
next = 42;
}
break;
case 27:
if(("I" === c )){
next = 43;
}
break;
case 28:
if(("B" === c )){
next = 44;
}
break;
case 29:
if(("N" === c )){
next = 34;
}
break;
case 30:
if(("O" === c )){
next = 46;
}
break;
case 31:
if(("E" === c )){
next = 47;
}
break;
case 32:
if(("L" === c )){
next = 48;
}
break;
case 33:
if(("R" === c )){
next = 49;
}
break;
case 37:
if(("Y" === c )){
next = 34;
}
break;
case 38:
if(("R" === c )){
next = 51;
}
break;
case 40:
if(("O" === c )){
next = 52;
}
break;
case 41:
if(("M" === c )){
next = 34;
}
break;
case 42:
if(("E" === c )){
next = 54;
}
break;
case 43:
if(("N" === c )){
next = 55;
}
break;
case 44:
if(("U" === c )){
next = 56;
}
break;
case 46:
if(("P" === c )){
next = 57;
}
break;
case 47:
if(("R" === c )){
next = 34;
}
break;
case 48:
if(("U" === c )){
next = 59;
}
break;
case 49:
if(("K" === c )){
next = 60;
}
break;
case 51:
if(("Y" === c )){
next = 61;
}
break;
case 52:
if(("S" === c )){
next = 62;
}
break;
case 54:
if(("L" === c )){
next = 34;
}
break;
case 55:
if(("T" === c )){
next = 64;
}
break;
case 56:
if(("I" === c )){
next = 65;
}
break;
case 57:
if(("S" === c )){
next = 66;
}
break;
case 59:
if(("M" === c )){
next = 62;
}
break;
case 60:
if(("D" === c )){
next = 68;
}
break;
case 61:
if(("P" === c )){
next = 69;
}
break;
case 62:
if(("E" === c )){
next = 34;
}
break;
case 64:
if(("A" === c )){
next = 71;
}
break;
case 65:
if(("L" === c )){
next = 19;
}
break;
case 66:
if(("I" === c )){
next = 73;
}
break;
case 68:
if(("I" === c )){
next = 47;
}
break;
case 69:
if(("O" === c )){
next = 76;
}
break;
case 71:
if(("I" === c )){
next = 77;
}
break;
case 73:
if(("G" === c )){
next = 79;
}
break;
case 76:
if(("I" === c )){
next = 81;
}
break;
case 77:
if(("N" === c )){
next = 31;
}
break;
case 79:
if(("N" === c )){
next = 83;
}
break;
case 81:
if(("N" === c )){
next = 84;
}
break;
case 83:
if(("A" === c )){
next = 54;
}
break;
case 84:
if(("T" === c )){
next = 34;
}
break;
	}
	return next;
};

function CDFA_STARTQUOTEDSTRING(){
	this.ss=1;
	this.as=[2];
	this.tt=[null,null,1];
this.stt={};
}
CDFA_STARTQUOTEDSTRING.prototype= new CDFA_base();
CDFA_STARTQUOTEDSTRING.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if(("\"" === c ) || ("'" === c )){
next = 2;
}
break;
	}
	return next;
};

function CDFA_QUOTEDSTRING(){
	this.ss=1;
	this.as=[2,3,4,5,6,7];
	this.tt=[null,null,3,3,3,2,3,3];
this.stt={};
}
CDFA_QUOTEDSTRING.prototype= new CDFA_base();
CDFA_QUOTEDSTRING.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < "\"" || "\"" < c)  && (c < "'" || "'" < c)  && (c < "\\" || "\\" < c) ){
next = 2;
} else if(("\n" === c )){
next = 2;
} else if(("\r" === c )){
next = 2;
} else if(("\"" === c ) || ("'" === c )){
next = 5;
} else if(("\\" === c )){
next = 6;
}
break;
case 6:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 2;
}
break;
	}
	return next;
};

function CDFA_UNQUOTEDSTRING(){
	this.ss=1;
	this.as=[2,3,4,5,6];
	this.tt=[null,null,6,4,5,4,6];
this.stt={};
}
CDFA_UNQUOTEDSTRING.prototype= new CDFA_base();
CDFA_UNQUOTEDSTRING.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "#" || "#" < c)  && (c < "\\" || "\\" < c) ){
next = 2;
} else if(("#" === c )){
next = 3;
} else if(("\\" === c )){
next = 4;
}
break;
case 2:
if((c < "#" || "#" < c)  && (c < "\\" || "\\" < c) ){
next = 2;
}
break;
case 3:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 3;
}
break;
case 4:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 6;
}
break;
	}
	return next;
};

function CDFA_UNQUOTEDSTRING2SPACE(){
	this.ss=1;
	this.as=[2,3,4,5,6];
	this.tt=[null,null,9,7,8,7,9];
this.stt={};
}
CDFA_UNQUOTEDSTRING2SPACE.prototype= new CDFA_base();
CDFA_UNQUOTEDSTRING2SPACE.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "#" || "#" < c)  && (c < "\\" || "\\" < c) ){
next = 2;
} else if(("#" === c )){
next = 3;
} else if(("\\" === c )){
next = 4;
}
break;
case 3:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 3;
}
break;
case 4:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 2;
}
break;
	}
	return next;
};

function CDFA_ENV(){
	this.ss=1;
	this.as=[2,3,4,5,6,7,8,9];
	this.tt=[null,null,14,10,10,11,13,11,11,12];
this.stt={};
}
CDFA_ENV.prototype= new CDFA_base();
CDFA_ENV.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "#" || "#" < c)  && (c < "\\" || "\\" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("#" === c )){
next = 5;
} else if(("\\" === c )){
next = 6;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("#" === c )){
next = 5;
}
break;
case 5:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 5;
}
break;
case 6:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 9;
}
break;
	}
	return next;
};

function CDFA_ENVDEF(){
	this.ss=1;
	this.as=[2,3,4];
	this.tt=[null,null,16,15,15];
this.stt={};
}
CDFA_ENVDEF.prototype= new CDFA_base();
CDFA_ENVDEF.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < "0" || "9" < c)  && (c < "A" || "Z" < c)  && (c < "_" || "_" < c)  && (c < "a" || "z" < c) ){
next = 2;
} else if(("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 3;
}
break;
case 3:
if(("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 3;
}
break;
	}
	return next;
};

function CDFA_ENVASSIGN(){
	this.ss=1;
	this.as=[2,3,4,5,6,7];
	this.tt=[null,null,19,18,18,17,17,17];
this.stt={};
}
CDFA_ENVASSIGN.prototype= new CDFA_base();
CDFA_ENVASSIGN.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "=" || "=" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("=" === c )){
next = 5;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("=" === c )){
next = 5;
}
break;
case 5:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 5;
}
break;
	}
	return next;
};

function CDFA_ENVVAL(){
	this.ss=1;
	this.as=[2,3];
	this.tt=[null,null,21,20];
this.stt={};
}
CDFA_ENVVAL.prototype= new CDFA_base();
CDFA_ENVVAL.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\"" || "\"" < c)  && (c < "'" || "'" < c) ){
next = 2;
} else if(("\"" === c ) || ("'" === c )){
next = 3;
}
break;
	}
	return next;
};

function CDFA_ARG(){
	this.ss=1;
	this.as=[2,3,4,5,6,7,8,9];
	this.tt=[null,null,26,22,22,23,25,23,23,24];
this.stt={};
}
CDFA_ARG.prototype= new CDFA_base();
CDFA_ARG.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "#" || "#" < c)  && (c < "\\" || "\\" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("#" === c )){
next = 5;
} else if(("\\" === c )){
next = 6;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("#" === c )){
next = 5;
}
break;
case 5:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 5;
}
break;
case 6:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 9;
}
break;
	}
	return next;
};

function CDFA_ARGDEF(){
	this.ss=1;
	this.as=[2,3,4];
	this.tt=[null,null,28,27,27];
this.stt={};
}
CDFA_ARGDEF.prototype= new CDFA_base();
CDFA_ARGDEF.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < "0" || "9" < c)  && (c < "A" || "Z" < c)  && (c < "_" || "_" < c)  && (c < "a" || "z" < c) ){
next = 2;
} else if(("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 3;
}
break;
case 3:
if(("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 3;
}
break;
	}
	return next;
};

function CDFA_ARGASSIGN(){
	this.ss=1;
	this.as=[2,3,4,5,6,7];
	this.tt=[null,null,31,30,30,29,29,29];
this.stt={};
}
CDFA_ARGASSIGN.prototype= new CDFA_base();
CDFA_ARGASSIGN.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "=" || "=" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("=" === c )){
next = 5;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("=" === c )){
next = 5;
}
break;
case 5:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 5;
}
break;
	}
	return next;
};

function CDFA_ARGVAL(){
	this.ss=1;
	this.as=[2,3];
	this.tt=[null,null,33,32];
this.stt={};
}
CDFA_ARGVAL.prototype= new CDFA_base();
CDFA_ARGVAL.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\"" || "\"" < c)  && (c < "'" || "'" < c) ){
next = 2;
} else if(("\"" === c ) || ("'" === c )){
next = 3;
}
break;
	}
	return next;
};

function CDFA_LABEL(){
	this.ss=1;
	this.as=[2,3,4,5,6,7,8,9];
	this.tt=[null,null,38,34,34,35,37,35,35,36];
this.stt={};
}
CDFA_LABEL.prototype= new CDFA_base();
CDFA_LABEL.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "#" || "#" < c)  && (c < "\\" || "\\" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("#" === c )){
next = 5;
} else if(("\\" === c )){
next = 6;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("#" === c )){
next = 5;
}
break;
case 5:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 5;
}
break;
case 6:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 9;
}
break;
	}
	return next;
};

function CDFA_LABELDEF(){
	this.ss=1;
	this.as=[2,3,4,5];
	this.tt=[null,null,41,40,39,39];
this.stt={};
}
CDFA_LABELDEF.prototype= new CDFA_base();
CDFA_LABELDEF.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < "\"" || "\"" < c)  && (c < "'" || "'" < c)  && (c < "-" || "." < c)  && (c < "0" || "9" < c)  && (c < "A" || "Z" < c)  && (c < "_" || "_" < c)  && (c < "a" || "z" < c) ){
next = 2;
} else if(("\"" === c ) || ("'" === c )){
next = 3;
} else if(("-" <= c && c <= ".")  || ("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 4;
}
break;
case 4:
if(("-" <= c && c <= ".")  || ("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 4;
}
break;
	}
	return next;
};

function CDFA_LABELASSIGN(){
	this.ss=1;
	this.as=[2,3,4,5,6,7];
	this.tt=[null,null,44,43,43,42,42,42];
this.stt={};
}
CDFA_LABELASSIGN.prototype= new CDFA_base();
CDFA_LABELASSIGN.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "=" || "=" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("=" === c )){
next = 5;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("=" === c )){
next = 5;
}
break;
case 5:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 5;
}
break;
	}
	return next;
};

function CDFA_LABELVAL(){
	this.ss=1;
	this.as=[2,3];
	this.tt=[null,null,46,45];
this.stt={};
}
CDFA_LABELVAL.prototype= new CDFA_base();
CDFA_LABELVAL.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\"" || "\"" < c)  && (c < "'" || "'" < c) ){
next = 2;
} else if(("\"" === c ) || ("'" === c )){
next = 3;
}
break;
	}
	return next;
};

function CDFA_EXPOSE(){
	this.ss=1;
	this.as=[2,3,4,5,6,7];
	this.tt=[null,null,49,47,47,48,48,48];
this.stt={};
}
CDFA_EXPOSE.prototype= new CDFA_base();
CDFA_EXPOSE.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "#" || "#" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("#" === c )){
next = 5;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("#" === c )){
next = 5;
}
break;
case 5:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 5;
}
break;
	}
	return next;
};

function CDFA_EXPOSEDEF(){
	this.ss=1;
	this.as=[2,3,4];
	this.tt=[null,null,51,50,50];
this.stt={};
}
CDFA_EXPOSEDEF.prototype= new CDFA_base();
CDFA_EXPOSEDEF.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < "$" || "$" < c)  && (c < "0" || "9" < c)  && (c < "A" || "Z" < c)  && (c < "_" || "_" < c)  && (c < "a" || "{" < c)  && (c < "}" || "}" < c) ){
next = 2;
} else if(("$" === c ) || ("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "{")  || ("}" === c )){
next = 3;
}
break;
case 3:
if(("$" === c ) || ("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "{")  || ("}" === c )){
next = 3;
}
break;
	}
	return next;
};

function CDFA_STOPSIGNAL(){
	this.ss=1;
	this.as=[2,3,4,5,6,7];
	this.tt=[null,null,54,52,52,53,53,53];
this.stt={};
}
CDFA_STOPSIGNAL.prototype= new CDFA_base();
CDFA_STOPSIGNAL.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < "#" || "#" < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
} else if(("#" === c )){
next = 5;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("#" === c )){
next = 5;
}
break;
case 5:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c) ){
next = 5;
}
break;
	}
	return next;
};

function CDFA_STOPSIGNALDEF(){
	this.ss=1;
	this.as=[2,3,4];
	this.tt=[null,null,56,55,55];
this.stt={};
}
CDFA_STOPSIGNALDEF.prototype= new CDFA_base();
CDFA_STOPSIGNALDEF.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\n" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < "0" || "9" < c)  && (c < "A" || "Z" < c)  && (c < "_" || "_" < c)  && (c < "a" || "z" < c) ){
next = 2;
} else if(("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 3;
}
break;
case 3:
if(("0" <= c && c <= "9")  || ("A" <= c && c <= "Z")  || ("_" === c ) || ("a" <= c && c <= "z") ){
next = 3;
}
break;
	}
	return next;
};

function CDFA_DOCKDIR(){
	this.ss=1;
	this.as=[2,3,4];
	this.tt=[null,null,59,58,58];
this.stt={};
}
CDFA_DOCKDIR.prototype= new CDFA_base();
CDFA_DOCKDIR.prototype.nextState = function(state, c){
    var next = 0;
    switch(state){
case 1:
if((c < "\t" || "\n" < c)  && (c < "\r" || "\r" < c)  && (c < " " || " " < c)  && (c < " " || " " < c) ){
next = 2;
} else if(("\t" === c ) || (" " === c ) || (" " === c )){
next = 3;
} else if(("\n" === c ) || ("\r" === c )){
next = 3;
}
break;
case 3:
if(("\t" <= c && c <= "\n")  || ("\r" === c ) || (" " === c ) || (" " === c )){
next = 3;
}
break;
	}
	return next;
};

var EOF={};
function Lexer(){

if(!(this instanceof Lexer)) return new Lexer();

this.pos={line:0,col:0};

this.states={};
this.state = ['DEFAULT'];
this.lastChar = '\n';
this.actions = [function anonymous() {

  return 'COMMENT';

},function anonymous() {

  this.quote = this.jjtext;
  this.popState();
  this.pushState('QUOTEDSTRING');
  return null;

},function anonymous() {

  if (this.jjtext !== this.quote) {
    return (this.stringAs || 'STRING');
  }
  this.quote = null;
  this.stringAs = null;
  this.popState();

  var s = this.getState();
  if (!this.input.more()) {
    if (s.match(/^(ENV|ARG|LABEL)$/)) {
      this.popState();
    }
  }
  return null;

},function anonymous() {

  if (!this.input.more() && this.jjtext != '\\') {
    this.popState();
    //return 'ERROR';
  }
  return (this.stringAs || 'STRING');

},function anonymous() {
 // comment
  this.popState();
  this.stringAs = null;
  var s = this.getState();
  if (s.match(/^(ENV|ARG)$/)) {
    this.popState();
  }
  return 'COMMENT';

},function anonymous() {
  // escaped eol, continue string
  return (this.stringAs || 'STRING');

},function anonymous() {

  var tok = (this.stringAs || 'STRING');
  if (!this.input.more()) {
    this.popState();
    this.stringAs = null;
    var s = this.getState();
    if (s.match(/^(ENV|ARG)$/)) {
      this.popState();
    }
  }
  return tok;

},function anonymous() {
 // comment
  this.popState();
  this.stringAs = null;
  var s = this.getState();
  if (s.match(/^(ENV|ARG)$/)) {
    this.popState();
  }
  return 'COMMENT';

},function anonymous() {
  // escaped eol, continue string
  return (this.stringAs || 'STRING');

},function anonymous() {

  var tok = (this.stringAs || 'STRING');
  if (!this.input.more()) {
    this.popState();
    this.stringAs = null;
    var s = this.getState();
    if (s.match(/^(ENV|ARG)$/)) {
      this.popState();
    }
  }
  if (this.jjtext.match(/^[ \t]$/)) {
    this.less(1);
    this.popState();
    this.stringAs = null;
    var s = this.getState();
  }
  return tok;

},function anonymous() {

  if (this.input.more()) {
    this.pushState('ENVDEF');
  } else {
    this.popState()
  }
  return null;

},function anonymous() {

  this.popState();
  return 'COMMENT';

},function anonymous() {

  this.popState();
  return 'ERROR';

},function anonymous() {

  return null;

},function anonymous() {

  this.less(1);
  if (!this.input.sol()) {
    this.popState();
    return 'ERROR';
  }
  this.pushState('ENVDEF');
  return null;

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('ENVASSIGN');
  } else {
    // pop out of ENV
    this.popState();
  }
  return 'DEF';

},function anonymous() {

  this.less(1);
  this.popState();
  return 'ERROR';

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('ENVVAL');
  } else {
    // pop out of ENV
    this.popState();
  }
  return null;

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('UNQUOTEDSTRING');
  } else {
    // pop out of ENV
    this.popState();
  }
  return null;

},function anonymous() {

  return 'ERROR';

},function anonymous() {

  this.less(1);
  this.popState();
  this.pushState('STARTQUOTEDSTRING');
  return null;

},function anonymous() {

  this.less(1);
  this.popState();
  this.pushState('UNQUOTEDSTRING2SPACE');
  return 'STRING';

},function anonymous() {

  if (this.input.more()) {
    this.pushState('ARGDEF');
  } else {
    this.popState()
  }
  return null;

},function anonymous() {

  this.popState();
  return 'COMMENT';

},function anonymous() {

  this.popState();
  return 'ERROR';

},function anonymous() {

  return null;

},function anonymous() {

  this.less(1);
  if (!this.input.sol()) {
    this.popState();
    return 'ERROR';
  }
  this.pushState('ARGDEF');
  return null;

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('ARGASSIGN');
  } else {
    // pop out of ARG
    this.popState();
  }
  return 'DEF';

},function anonymous() {

  this.less(1);
  this.popState();
  return 'ERROR';

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('ARGVAL');
  } else {
    // pop out of ARG
    this.popState();
  }
  return null;

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('UNQUOTEDSTRING');
  } else {
    // pop out of ARG
    this.popState();
  }
  return null;

},function anonymous() {

  return 'ERROR';

},function anonymous() {

  this.less(1);
  this.popState();
  this.pushState('STARTQUOTEDSTRING');
  return null;

},function anonymous() {

  this.less(1);
  this.popState();
  this.pushState('UNQUOTEDSTRING2SPACE');
  return 'STRING';

},function anonymous() {

  if (this.input.more()) {
    this.pushState('LABELDEF');
  } else {
    this.popState()
  }
  return null;

},function anonymous() {

  this.popState();
  return 'COMMENT';

},function anonymous() {

  this.popState();
  return 'ERROR';

},function anonymous() {

  return null;

},function anonymous() {

  this.less(1);
  if (!this.input.sol()) {
    this.popState();
    return 'ERROR';
  }
  this.pushState('LABELDEF');
  return null;

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('LABELASSIGN');
  } else {
    // pop out of LABEL
    this.popState();
  }
  return 'DEF';

},function anonymous() {

  this.less(1);
  this.stringAs = 'def';
  this.popState();
  this.pushState('LABELASSIGN');
  this.pushState('STARTQUOTEDSTRING');
  return null;

},function anonymous() {

  this.less(1);
  this.popState();
  return 'ERROR';

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('LABELVAL');
  } else {
    // pop out of LABEL
    this.popState();
  }
  return null;

},function anonymous() {

  this.popState();
  if (this.input.more()) {
    this.pushState('UNQUOTEDSTRING');
  } else {
    // pop out of LABEL
    this.popState();
  }
  return null;

},function anonymous() {

  return 'ERROR';

},function anonymous() {

  this.less(1);
  this.popState();
  this.pushState('STARTQUOTEDSTRING');
  return null;

},function anonymous() {

  this.less(1);
  this.popState();
  this.pushState('UNQUOTEDSTRING2SPACE');
  return 'STRING';

},function anonymous() {

  if (this.input.more()) {
    this.pushState('EXPOSEDEF');
  }
  return null;

},function anonymous() {

  this.popState();
  return 'COMMENT';

},function anonymous() {

  this.less(1);
  this.popState();
  return 'ERROR';

},function anonymous() {

  this.popState();
  return 'EXPOSE';

},function anonymous() {

  this.less(1);
  this.popState();
  this.popState();
  return 'ERROR';

},function anonymous() {

  if (this.input.more()) {
    this.pushState('STOPSIGNALDEF');
  }
  return null;

},function anonymous() {

  this.popState();
  return 'COMMENT';

},function anonymous() {

  this.less(1);
  this.popState();
  return 'ERROR';

},function anonymous() {

  this.popState();
  return 'STOPSIGNAL';

},function anonymous() {

  this.less(1);
  this.popState();
  this.popState();
  return 'ERROR';

},function anonymous() {

  var d = this.jjtext.match(/(\w+)/)[1];
  this.jjval = d;

  if (d.match(/RUN|CMD/i)) {
    this.localMode = this.bashMode;
    this.localState = this.bashMode.startState();

  } else if (d.match(/ONBUILD/)) {
    this.popState();

  } else {
    if (d.match(/FROM|MAINTAINER|EXPOSE|STOPSIGNAL/i)) {
      this.stringAs = d.toLowerCase();
    } else {
      this.stringAs = null;
    }
    if (!d.match(/ENV|ARG|LABEL|EXPOSE|STOPSIGNAL/i)) {
      d = 'DOCKDIR';
    }
    this.pushState(d.toUpperCase());
  }
  return 'DOCKDIR';

},function anonymous() {

  this.jjval = this.jjtext.trim();
  this.popState();
  this.pushState('UNQUOTEDSTRING');
  return null;

},function anonymous() {

  return 'ERROR';

},function anonymous() {


},function anonymous() {

  return 'ERROR';

}];
this.states["DEFAULT"] = {};
this.states["DEFAULT"].dfa = new CDFA_DEFAULT();
this.states["STARTQUOTEDSTRING"] = {};
this.states["STARTQUOTEDSTRING"].dfa = new CDFA_STARTQUOTEDSTRING();
this.states["QUOTEDSTRING"] = {};
this.states["QUOTEDSTRING"].dfa = new CDFA_QUOTEDSTRING();
this.states["UNQUOTEDSTRING"] = {};
this.states["UNQUOTEDSTRING"].dfa = new CDFA_UNQUOTEDSTRING();
this.states["UNQUOTEDSTRING2SPACE"] = {};
this.states["UNQUOTEDSTRING2SPACE"].dfa = new CDFA_UNQUOTEDSTRING2SPACE();
this.states["ENV"] = {};
this.states["ENV"].dfa = new CDFA_ENV();
this.states["ENVDEF"] = {};
this.states["ENVDEF"].dfa = new CDFA_ENVDEF();
this.states["ENVASSIGN"] = {};
this.states["ENVASSIGN"].dfa = new CDFA_ENVASSIGN();
this.states["ENVVAL"] = {};
this.states["ENVVAL"].dfa = new CDFA_ENVVAL();
this.states["ARG"] = {};
this.states["ARG"].dfa = new CDFA_ARG();
this.states["ARGDEF"] = {};
this.states["ARGDEF"].dfa = new CDFA_ARGDEF();
this.states["ARGASSIGN"] = {};
this.states["ARGASSIGN"].dfa = new CDFA_ARGASSIGN();
this.states["ARGVAL"] = {};
this.states["ARGVAL"].dfa = new CDFA_ARGVAL();
this.states["LABEL"] = {};
this.states["LABEL"].dfa = new CDFA_LABEL();
this.states["LABELDEF"] = {};
this.states["LABELDEF"].dfa = new CDFA_LABELDEF();
this.states["LABELASSIGN"] = {};
this.states["LABELASSIGN"].dfa = new CDFA_LABELASSIGN();
this.states["LABELVAL"] = {};
this.states["LABELVAL"].dfa = new CDFA_LABELVAL();
this.states["EXPOSE"] = {};
this.states["EXPOSE"].dfa = new CDFA_EXPOSE();
this.states["EXPOSEDEF"] = {};
this.states["EXPOSEDEF"].dfa = new CDFA_EXPOSEDEF();
this.states["STOPSIGNAL"] = {};
this.states["STOPSIGNAL"].dfa = new CDFA_STOPSIGNAL();
this.states["STOPSIGNALDEF"] = {};
this.states["STOPSIGNALDEF"].dfa = new CDFA_STOPSIGNALDEF();
this.states["DOCKDIR"] = {};
this.states["DOCKDIR"].dfa = new CDFA_DOCKDIR();
}
Lexer.prototype.setInput=function (input){
        this.pos={row:0, col:0};
        if(typeof input === 'string')
        {input = new StringReader(input);}
        this.input = input;
        this.state = ['DEFAULT'];
        this.lastChar='\n';
        this.getDFA().reset();
        return this;
    };
Lexer.prototype.nextToken=function () {


        var ret = undefined;
        while(ret === undefined){
            this.resetToken();
            ret = this.more();
        }


        if (ret === EOF) {
            this.current = EOF;
        } else {
            this.current = {};
            this.current.name = ret;
            this.current.value = this.jjval;
            this.current.lexeme = this.jjtext;
            this.current.position = this.jjpos;
            this.current.pos = {col: this.jjcol, line: this.jjline};
        }
        return this.current;
    };
Lexer.prototype.resetToken=function (){
        this.getDFA().reset();
        this.getDFA().bol = (this.lastChar === '\n');
        this.lastValid = undefined;
        this.lastValidPos = -1;
        this.jjtext = '';
        this.remains = '';
        this.buffer = '';
        this.startpos = this.input.getPos();
        this.jjline = this.input.line;
        this.jjcol = this.input.col;
    };
Lexer.prototype.halt=function () {
        if (this.lastValidPos >= 0) {
            var lastValidLength = this.lastValidPos-this.startpos+1;
            this.jjtext = this.buffer.substring(0, lastValidLength);
            this.remains = this.buffer.substring(lastValidLength);
            this.jjval = this.jjtext;
            this.jjpos = this.lastValidPos + 1-this.jjtext.length;
            this.input.rollback(this.remains);
            var action = this.getAction(this.lastValid);
            if (typeof ( action) === 'function') {
                return action.call(this);
            }
            this.resetToken();
        }
        else if(!this.input.more()){//EOF
            var actionid = this.states[this.getState()].eofaction;
            if(actionid){
                action = this.getAction(actionid);
                if (typeof ( action) === 'function') {
                    //Note we don't care of returned token, must return 'EOF'
                    action.call(this);
                }
            }
            return EOF;
        } else {//Unexpected character
            throw new Error('Unexpected char \''+this.input.peek()+'\' at '+this.jjline +':'+this.jjcol);
        }
    };
Lexer.prototype.more=function (){
        var ret;
        while (this.input.more()) {
            var c = this.input.peek();
            this.getDFA().readSymbol(c);
            if (this.getDFA().isInDeadState()) {

                ret = this.halt();
                return ret;

            } else {
                if (this.getDFA().isAccepting()) {
                    this.lastValid = this.getDFA().getCurrentToken();
                    this.lastValidPos = this.input.getPos();

                }
                this.buffer = this.buffer + c;
                this.lastChar = c;
                this.input.next();
            }

        }
        ret = this.halt();
        return ret;
    };
Lexer.prototype.less=function (length){
        this.input.rollback(length);
    };
Lexer.prototype.getDFA=function (){
        return this.states[this.getState()].dfa;
    };
Lexer.prototype.getAction=function (i){
        return this.actions[i];
    };
Lexer.prototype.pushState=function (state){
        this.state.push(state);
        this.getDFA().reset();
    };
Lexer.prototype.popState=function (){
        if(this.state.length>1) {
            this.state.pop();
            this.getDFA().reset();
        }
    };
Lexer.prototype.getState=function (){
        return this.state[this.state.length-1];
    };
Lexer.prototype.restoreLookAhead=function (){
        this.tailLength = this.jjtext.length;
        this.popState();
        this.less(this.tailLength);
        this.jjtext = this.lawhole.substring(0,this.lawhole.length-this.tailLength);


    };
Lexer.prototype.evictTail=function (length){
        this.less(length);
        this.jjtext = this.jjtext.substring(0,this.jjtext.length-length);
    };
Lexer.prototype.isEOF=function (o){
        return o===EOF;
    }
;
function StringReader(str){
        if(!(this instanceof StringReader)) return new StringReader(str);
		this.str = str;
		this.pos = 0;
        this.line = 0;
        this.col = 0;
	}
StringReader.prototype.getPos=function (){
        return this.pos;
    };
StringReader.prototype.peek=function ()
	{
		//TODO: handle EOF
		return this.str.charAt(this.pos);
	};
StringReader.prototype.eat=function (str)
	{
		var istr = this.str.substring(this.pos,this.pos+str.length);
		if(istr===str){
			this.pos+=str.length;
            this.updatePos(str,1);
		} else {
			throw new Error('Expected "'+str+'", got "'+istr+'"!');
		}
	};
StringReader.prototype.updatePos=function (str,delta){
        for(var i=0;i<str.length;i++){
            if(str[i]=='\n'){
                this.col=0;
                this.line+=delta;
            }else{
                this.col+=delta;
            }
        }
    };
StringReader.prototype.rollback=function (str)
    {
        if(typeof str === 'string')
        {
            var istr = this.str.substring(this.pos-str.length,this.pos);
            if(istr===str){
                this.pos-=str.length;
                this.updatePos(str,-1);
            } else {
                throw new Error('Expected "'+str+'", got "'+istr+'"!');
            }
        } else {
            this.pos-=str;
            this.updatePos(str,-1);
        }

    };
StringReader.prototype.next=function ()
	{
		var s = this.str.charAt(this.pos);
		this.pos=this.pos+1;
		this.updatePos(s,1);
		return s;
	};
StringReader.prototype.more=function ()
	{
		return this.pos<this.str.length;
	};
StringReader.prototype.reset=function (){
        this.pos=0;
    };
if (typeof(module) !== 'undefined') { module.exports = Lexer; }
return Lexer;})();