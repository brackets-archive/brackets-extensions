<meta charset="utf-8">
<h2>English</h2>
<h1>Blue Dream</h1>
<h3>Criated by Me(Warnney)</h3>
<h4>This theme was created with the simple intention of offering an even greater variety of topics in order to cater for all tastes .</h4>
<br>
<h2>Português - Brasil</h2>
<h1>Blue Dream</h1>
<h3>Criado por mim(Warnney)</h3>
<h4>Este tema foi criado com a simples intenção de oferecer uma variedade ainda maior de temas, a fim de atender à todos os gostos.</h4><br>
<img src="https://www.mediafire.com/convkey/9571/9rr6spq0wxhkkqr7g.jpg" border="0" alt="Blue Dream Theme For Brackets"/>
