define(function (require, exports, modile)
{
    "use strict";
    
    const EditorManager = brackets.getModule("editor/EditorManager");
    const content = Array.from(document.getElementsByClassName("content")).shift();
    const style = window.getComputedStyle(document.body);
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    context.font = style.font;
    const measure = context.measureText("A");
    const charWidth = measure.width;
    let charHeight, editor, start;
    
    let handleMouseMove = e =>
    {
        if (!editor) { return; }
        
        let nLine = start.line - Math.round((start.y - e.y)/charHeight) + (2 * +!!(e.y >= start.y)),
            nCh = start.ch - Math.round((start.x - e.x)/charWidth),
            arrLen = Math.max(1, Math.abs(start.line - nLine + 1));
        
        editor.setSelections(
            new Array(arrLen).fill(Math.min(start.line, nLine)).map((l,i) =>
            {
                return {
                    start: {
                        line: l+i,
                        ch: Math.min(nCh, start.ch)
                    },
                    end: {
                        line: l+i,
                        ch: Math.max(nCh, start.ch)
                    },
                    primary: l+i == nLine,
                    reversed: nCh < start.ch
                };
            }),
            true,
            0
        );
    };

    content.addEventListener("mousedown", e =>
    {
        if (e.which == 2 || e.button == 4) {
            e.preventDefault();
            editor = EditorManager.getActiveEditor();
            if (!charHeight) {
                charHeight = Array.from(Array.from(document.getElementsByClassName("CodeMirror-code")).shift().children).shift().offsetHeight;
            }
            start = editor.getCursorPos();
            start.x = e.x;
            start.y = e.y;
            
            content.addEventListener("mousemove", handleMouseMove);
            
            return false;
        } else {
            content.removeEventListener("mousemove", handleMouseMove);
        }
    });
    
    content.addEventListener("mouseup", e =>
    {
        content.removeEventListener("mousemove", handleMouseMove);
    });
    
    
});