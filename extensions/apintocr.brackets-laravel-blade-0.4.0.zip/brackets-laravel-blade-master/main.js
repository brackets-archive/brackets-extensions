
define(function (require, exports, module) {
	'use strict';	
	
	//Require
	var BladeSyntaxHighligh  = require('src/bladesyntaxhighligh');
	var BladeCodeHint		 = require('src/bladecodehint');
	
	//Call
	BladeSyntaxHighligh;
	BladeCodeHint;

});
