[<img src="http://img.shields.io/badge/version-0.3.0-green.svg?style=flat-square">](#)
[<img src="http://img.shields.io/badge/Code-Highlight-yellow.svg?style=flat-square">](#)
[<img src="http://img.shields.io/badge/Code-Hints-orange.svg?style=flat-square">](http://laravel.com/)
[<img src="http://img.shields.io/badge/Laravel-Blade-red.svg?style=flat-square">](http://laravel.com/)
[<img src="http://img.shields.io/badge/Brackets-code editor-blue.svg?style=flat-square">](http://brackets.io/)

Laravel Blade
=============
Syntax highlighting and Code Hints for [*Brackets code editor*](http://brackets.io/).

##Supports:
*** NOW Supporting Blade Code Hints! ***
Syntax Highlight for:

* Comments: **{{-- --}}**
* Laravel 4: **{{  }}**
* Laravel 5: **{%  %}**

###**Current State**
Currently this extension supports only basic syntax, I plan to add support for the full Laravel Blade template system.
At this moment it does not support line breaks, I'm still trying to figure how to do that....

***Note:*** *I only have basic .js knowledge (let alone Code Mirror...), so any help you can provide will be greatly apreciatted.*
