# Fira in Brackets
A simple extension that changes the [Brackets](http://brackets.io/) UI fonts to Fira Code.

## Installation
This plugin requires that the fonts are installed locally on your computer. You can download Fira Code here:
* https://github.com/tonsky/FiraCode

To install in Brackets, simply open the Brackets Extension Manager and search for “fira”.

## License
The fonts: [SIL Open Font License](https://github.com/mozilla/Fira/blob/master/LICENSE).<br>
The extension is released under the [MIT License](http://opensource.org/licenses/MIT).
