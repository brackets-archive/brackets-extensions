# 1.1.0
* Added support for "find next" and "find previous" 

# 1.0.0
* Started versioning