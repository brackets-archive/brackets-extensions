# brackets-stencil-language
Adding a language extension to Brackets. 
