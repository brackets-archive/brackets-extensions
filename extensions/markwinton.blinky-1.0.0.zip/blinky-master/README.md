# Blinky

A Brackets theme from the 600 Bazaars

![preview](preview.png)
