Zamiere
=====================
Dark theme for Brackets!

![zamiere ss](https://github.com/brackets-themes/zamiere/raw/master/screenshot.png)

Contributors
======

* Kulcsár Kázmér <zamiere@gmail.com>
* Miguel Castillo <manchagnu@gmail.com>
