# Gherkin Syntax Highlighting for Brackets

This is an extension to the code editor [Brackets][1], and adds syntax
highlighting for Gherkin files with the extension `.feature`.

### How to Install

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for this extension
3. Click _Install_!

### License
MIT-licensed -- see `LICENSE` for details.

  [1]: http://brackets.io/ "Brackets — Open source code editor built with the web for the web"