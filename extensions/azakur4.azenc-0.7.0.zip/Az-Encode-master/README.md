Az-Encode
=========

Brackets extension for encoding files
