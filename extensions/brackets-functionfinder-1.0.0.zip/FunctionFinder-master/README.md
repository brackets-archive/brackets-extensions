FunctionFinder
==============

An extension for the Brackets editor that copies the Eclipse "Open Declaration" functionality
