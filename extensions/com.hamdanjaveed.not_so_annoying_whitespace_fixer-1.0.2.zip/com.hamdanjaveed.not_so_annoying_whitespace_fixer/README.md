Not-So-Annoying-Whitespace-Fixer
================================

A Brackets extension that trims trailing whitespace (except for the line the cursor is currently on).
Also as a bonus it ensures the file has a new line at the end.


Instructions
============

Just save the file and it'll do its thing.

Install within Brackets
=======================

Click the extension manager button within Brackets (in the toolbar to the right) and search for "Not So Annoying Whitespace Fixer". Click install.


Install from URL
================

1. Open the the Extension Manager from the File menu
2. Copy paste the URL of the github repo or zip file


Install from file system
========================

1. Download this extension using the ZIP button above and unzip it.
2. Copy it in Brackets' `/extensions/user` folder by selecting `Help > Show Extension Folder` in the menu.
3. Reload Brackets.
