/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 Matthieu Lassalvy <malas34.github@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */
// English - root strings
/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */
define({

    'IONIC_CREATE_DIALOG_ID':"ionic-dialog-new-project",
    'DOMAIN_NAME':"ionic-cli-nodejs",

    'IONIC_CMD_OPT_DIALOG_ID':"ionic-dialog-cmd-opt",
    
    'DLG_SHOW_ABOUT_ID':"ionic-dialog-show-about",
    'DLG_CMD_OPT_TITLE':"Options ",
    
    'DLG_SHOW_IO_LOGIN_ID':"ionic-dialog-show-io-login",
    'DLG_SHOW_IO_LOGIN_TITLE':"Informations de login pour la platforme Ionic Io",

    'COMMAND_IONIC_TEST_CODE_ID':"ionic-cli.test-code",
    'COMMAND_IONIC_TEST_CODE_TITLE':"Test code",

    'DOMAIN_NAME':"ionic-cli-nodejs",


    'COMMAND_IONIC_PLAY_ID' : "ionic-cli.ionic-play",
    'COMMAND_IONIC_PLAY_TITLE' : "Show Ionic Play",


    'COMMAND_IONIC_NEW_ID' :"ionic-cli.ionic-new",
    'COMMAND_IONIC_NEW_TITLE':"New Projet",

    'COMMAND_IONIC_VERSION_ID':"ionic-cli.ionic-version",
    'COMMAND_IONIC_VERSION_TITLE':"Ionic Infos...",

    'COMMAND_IONIC_SERVE_ID':"ionic-cli.ionic-serve",
    'COMMAND_IONIC_SERVE_TITLE':"Ionic Serve...",

    'COMMAND_IONIC_RUN_ID':"ionic-cli.ionic-run",
    'COMMAND_IONIC_RUN_TITLE':"Ionic run...",
    
    'COMMAND_IONIC_BUILD_ID':"ionic-cli.ionic-build",
    'COMMAND_IONIC_BUILD_TITLE':"Ionic build...",

    'COMMAND_IONIC_IO_ID':"ionic-cli.ionic-io",
    'COMMAND_IONIC_IO_TITLE':"Ionic io...",
    
    'COMMAND_IONIC_IO_INIT_ID':"ionic-cli.ionic-io-init",
    'COMMAND_IONIC_IO_INIT_TITLE':"Ionic io init...",

    'COMMAND_IONIC_LAB_ID':"ionic-cli.ionic-lab",
    'COMMAND_IONIC_LAB_TITLE':"Ionic Lab...",

    'COMMAND_IONIC_RELEASE_ID':"ionic-cli.ionic-release",
    'COMMAND_IONIC_RELEASE_TITLE':"Ionic compile 'Release'",

    'COMMAND_IONIC_UPDATE_ID':"ionic-cli.ionic-update",
    'COMMAND_IONIC_UPDATE_TITLE':"Ionic Update...",

    'COMMAND_IONIC_SIGNED_ID':"ionic-cli.ionic-signed",
    'COMMAND_IONIC_SIGNED_TITLE':"Ionic Appli 'Signed'",


    'COMMAND_IONIC_SETTINGS_ID':"ionic-cli.ionic-settings",
    'COMMAND_IONIC_SETTINGS_TITLE':"Ionic Configurations...",

    'COMMAND_IONIC_ABOUT_ID':"ionic-cli.ionic-about",
    'COMMAND_IONIC_ABOUT_TITLE':"About...",

    'DLG_CREATE_TITLE':"Create new Ionic Project",
    'DLG_SHOW_ABOUT_TITLE':"About Backets-ionic-cli",

    'DLG_TEXT_SHOW_ABOUT':"Bracket - ionic -cli is an extension to assist in development of mobile applications or office with the brilliant framework <a href='http://ionicframework.com'> Ionic . </a> <br> <b style='color:red'>Order to fully use this extension must :</b>  - <b style='color:red'>install</b>: <a href='https://nodejs.org/en/'> nodejs </a> <br> - <b style='color:red'>install</b>: npm install ionic cordova -g < br> This extension from the editor brackets can: ad - Start compiling a draft Ionic <br> - Test the project on a browser Ionic <br> - Start in Ionic lab test his <br> project - Start plaform play.ionic.io <br> code for creating and testing - Start service platform app.ionic.io <br> - Compile a version of ' release' of project ( mandatory JAVA JDK : set JAVA_HOME and ANDROID_HOME ) <br> - Sign version ' release' project (JAVA required JDK : set JAVA_HOME and ANDROID_HOME )<br><b style='color:red'>Next:</b>Ionic package with ui...",

    'DLG_CREATE_TITLE':"Create new Ionic Project",

    'MSG_MUST_BE_IONIC':"The active project must be an Ionic project !!!",
    
    'MENU_NAME':"IonicCli",
    
    'MSG_CREATE_PROJECT_WAITING':"Creating Ionic Project..."
});
