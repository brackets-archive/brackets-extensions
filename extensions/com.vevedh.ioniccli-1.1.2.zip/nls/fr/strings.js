/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 Matthieu Lassalvy <malas34.github@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */
// English - root strings
/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */
define({
    'IONIC_CREATE_DIALOG_ID':"ionic-dialog-new-project",
    'IONIC_CREATE_DIALOG_Title':"Création d'un nouveau projet Ionic",

    'IONIC_CMD_OPT_DIALOG_ID':"ionic-dialog-cmd-opt",
    
    'DLG_SHOW_IO_LOGIN_ID':"ionic-dialog-show-io-login",
    'DLG_SHOW_IO_LOGIN_TITLE':"Informations de login pour la platforme Ionic Io",
    
    'DLG_SHOW_ABOUT_ID':"ionic-dialog-show-about",
    'DLG_CMD_OPT_TITLE':"Options de commande",


    'DOMAIN_NAME':"ionic-cli-nodejs",

    'COMMAND_IONIC_TEST_CODE_ID':"ionic-cli.test-code",
    'COMMAND_IONIC_TEST_CODE_TITLE':"Test code",


    'COMMAND_IONIC_PLAY_ID' : "ionic-cli.ionic-play",
    'COMMAND_IONIC_PLAY_TITLE' : "Lance Ionic Play",


    'COMMAND_IONIC_NEW_ID' :"ionic-cli.ionic-new",
    'COMMAND_IONIC_NEW_TITLE':"Nouveau Projet",

    'COMMAND_IONIC_VERSION_ID':"ionic-cli.ionic-version",
    'COMMAND_IONIC_VERSION_TITLE':"Ionic Infos...",

    'COMMAND_IONIC_SERVE_ID':"ionic-cli.ionic-serve",
    'COMMAND_IONIC_SERVE_TITLE':"Ionic Serve...",

    'COMMAND_IONIC_RUN_ID':"ionic-cli.ionic-run",
    'COMMAND_IONIC_RUN_TITLE':"Ionic run...",
    
    'COMMAND_IONIC_BUILD_ID':"ionic-cli.ionic-build",
    'COMMAND_IONIC_BUILD_TITLE':"Ionic build...",

    'COMMAND_IONIC_IO_ID':"ionic-cli.ionic-io",
    'COMMAND_IONIC_IO_TITLE':"Ionic io...",
    
    'COMMAND_IONIC_IO_INIT_ID':"ionic-cli.ionic-io-init",
    'COMMAND_IONIC_IO_INIT_TITLE':"Ionic io init...",

    'COMMAND_IONIC_LAB_ID':"ionic-cli.ionic-lab",
    'COMMAND_IONIC_LAB_TITLE':"Ionic Lab...",

    'COMMAND_IONIC_RELEASE_ID':"ionic-cli.ionic-release",
    'COMMAND_IONIC_RELEASE_TITLE':"Ionic Appli 'Release'",
    
    'COMMAND_IONIC_UPDATE_ID':"ionic-cli.ionic-update",
    'COMMAND_IONIC_UPDATE_TITLE':"Ionic Update...",

    'COMMAND_IONIC_SIGNED_ID':"ionic-cli.ionic-signed",
    'COMMAND_IONIC_SIGNED_TITLE':"Ionic Appli 'Signed'",

    'COMMAND_IONIC_SETTINGS_ID':"ionic-cli.ionic-settings",
    'COMMAND_IONIC_SETTINGS_TITLE':"Ionic Configurations...",

    'COMMAND_IONIC_ABOUT_ID':"ionic-cli.ionic-about",
    'COMMAND_IONIC_ABOUT_TITLE':"A propos...",

    'DLG_CREATE_TITLE':"Création d'un nouveau projet Ionic",
    'DLG_SHOW_ABOUT_TITLE':"A propos de Backets-ionic-cli",

    'DLG_TEXT_SHOW_ABOUT':"Bracket-ionic-cli est une extension pour aider au developpement d'applications mobiles ou bureau avec le génial framework <a href='http://ionicframework.com'>Ionic.</a><br><b style='color:red'>Afin d'utiliser pleinement cette extension il faut :</b><br><br> -   <b style='color:red'>installer</b> : <a href='https://nodejs.org/en/'>nodejs</a><br> - <b style='color:red'>installer</b> : npm install -g ionic cordova<br><br>Cette extension a partir de l'editeur brackets permet de :<br> - Lancer une compilation d'un projet Ionic<br> - Tester sur un navigateur le projet Ionic<br> - Lancer dans le lab Ionic un test de son projet<br> - Lancer la plaforme play.ionic.io pour creation et test de code<br> - Lancer la platforme de services app.ionic.io<br> - Compiler une version 'Release' du projet(JAVA JDK obligatoire: set JAVA_HOME et ANDROID_HOME)<br> - Signer la version 'Release' du projet (JAVA JDK obligatoire: set JAVA_HOME et ANDROID_HOME)<br><b style='color:red'>Bienôt</b>: ionic package avec interface ...",

    'DLG_CREATE_TITLE':"Création d'un nouveau projet Ionic",

    'MSG_MUST_BE_IONIC':"Le projet actif doit être un projet Ionic!!!",

    'MENU_NAME':"IonicCli",
    'MSG_CREATE_PROJECT_WAITING':"Creation du projet en cours..."
});
