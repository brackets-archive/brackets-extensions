/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets */

/** ionic-cli Extension
    description
*/
define(function (require, exports, module) {
    'use strict';

    extlog("INITIALIZING ionic-cli EXTENSION");

    var CommandManager          = brackets.getModule("command/CommandManager"),
        Commands                = brackets.getModule("command/Commands"),
        Menus                   = brackets.getModule("command/Menus"),
        NativeApp               = brackets.getModule('utils/NativeApp'),
		DocumentManager			= brackets.getModule("document/DocumentManager"),
		MainViewManager			= brackets.getModule("view/MainViewManager"),
		WorkspaceManager		= brackets.getModule("view/WorkspaceManager"),
		FileUtils				= brackets.getModule("file/FileUtils"),
		FileSystem				= brackets.getModule("filesystem/FileSystem"),
		ProjectManager			= brackets.getModule("project/ProjectManager"),
		EditorManager			= brackets.getModule("editor/EditorManager"),
		ExtensionUtils			= brackets.getModule("utils/ExtensionUtils"),
		AppInit					= brackets.getModule("utils/AppInit"),
		CSSUtils				= brackets.getModule("language/CSSUtils"),
		HTMLUtils				= brackets.getModule("language/HTMLUtils"),
		PreferencesManager		= brackets.getModule("preferences/PreferencesManager"),
        NodeDomain              = brackets.getModule("utils/NodeDomain"),
        Dialogs                 = brackets.getModule("widgets/Dialogs"),
        StatusBar               = brackets.getModule("widgets/StatusBar"),
        Strings                 = require('strings'),
        ansi                    = require("./ansi"),
        prefs                   = require("./preferences"),
        scrollEnabled = true;

    var utf8 = require('utf8');
    // execution de commandes externes
    /**
     * Connect to the backend nodejs domain
     */
    var domain = new NodeDomain(Strings.DOMAIN_NAME, ExtensionUtils.getModulePath(module, "node/processDomain"));

    var dlgNew = {
        path:""
    };

    var dlgCmd = {
        options:""
    };

    domain.on("output", function(info, data) {
        Panel.write(data);


        if ( new RegExp("Saved api_key","g").test(data) ) {
            if ( new RegExp("bower install --save-dev ionic-platform-web-client","g").test(ConnectionManager.last.command) ){
                StatusBar.hideBusyIndicator("ionic-new-progress");
                extlog("Check io config");
                if (chkIoConfig) {
                    var pth = "https://apps.ionic.io/login";
                    NativeApp.openLiveBrowser('"' + pth + '"');
                }

            }
        }
    });
    
    domain.on("outputHelp", function(info, data) {
        //Dialog.helpCmd = data;
        StatusBar.hideBusyIndicator("ionic-new-progress");
        extlog("Avant :"+ansi(data));
        $("."+Strings.IONIC_CMD_OPT_DIALOG_ID+" .dialog-message table").prepend("Exemple:\n<label>"+(ansi(data)).replace(/<b>/g,'<br><b>')+"</label>");//('Examples :<br>'+data+'');
    });


    // durant la creation du nouveau projet
    domain.on("Ionic-New-Event-data",function(info,data){
        $(".ionic-cli-waiting-dialog .modal-body").append(ansi(data)+"<br>");
    });
    
    // a la fin de la creation du nouveau projet
    domain.on("Ionic-New-Event-exit",function(info,data){
        StatusBar.hideBusyIndicator("ionic-new-progress");
        Dialogs.cancelModalDialogIfOpen("ionic-cli-waiting-dialog");
        extlog("Creation complete!\n"+dlgNew.path);
        extlog("Creation :"+data);
        setTimeout(function(){
           extlog("Wait a moment..."); 
        },5000);
        ProjectManager.openProject(dlgNew.path).done(function(){
            CommandManager.execute(Commands.CMD_OPEN, {fullPath: dlgNew.path + "/www/index.html"})
        }).fail(function(){});
    });
    
    // en cas d'erreur de creation du nouveau projet
    domain.on("Ionic-New-Event-err",function(info,data){
        StatusBar.hideBusyIndicator("ionic-new-progress");
        Dialogs.cancelModalDialogIfOpen("ionic-cli-waiting-dialog");

        extlog("Creation Error:\n"+data);

    });
    
    
    /*
    domain.on("Ionic-Module-Event",function(){
         StatusBar.hideBusyIndicator("ionic-new-progress");
        //Dialogs.showModalDialogUsingTemplate(Mustache.render(require("text!html/modal-about.html"),{msg:'Vous devez installer:<br>npm install -g ionic-app-lib'}),"test","test titre");
        Dialogs.showModalDialog(
            "ionic-cli.show-msg",
            "Information",
            Mustache.render(require("text!html/modal-message.html"), {msg:"Vous devez installez:<br>&nbsp;&nbsp;npm install -g ionic-app-lib<br><br>La console de tentative d'exécution de la commande s'afficheras en bas.<br>A l'issue de cette installation vous pourrez réessayer la création d'un Nouveau projet Ionic"}),//;require("text!html/modal-about.html"),
              [
                  {
                      className: Dialogs.DIALOG_BTN_CLASS_PRIMARY,
                      id: Dialogs.DIALOG_BTN_OK,
                      text: "OK"
                    }
              ]
          ).done(function(id){
                if (id=="ok") {

                   ConnectionManager.initNpm();
                }
          });
        //StatusBar.hideBusyIndicator("ionic-new-progress");
        //extlog("Creation complete!"+dlgNew.path);
        //ProjectManager.openProject(dlgNew.path);
    })
    */
    
    
    /**
     * ConnectionManager aide à construire et executer une requete cote server node.js
     */
    var ConnectionManager = {

        last: {
            command: null,
            cwd: null
        },

        envIo:null,
        /**
         * Creates a new EventSource
         *
         * @param (optional): Command
         * @param (optional): Current working directory to use
         */
        // This need to be inside quotes since new is a reserved word
        "doCmdExec": function (command, cwd) {
            // If no cwd is specified use the current file's directory
            // if available else fallback to the project directory
            var doc = DocumentManager.getCurrentDocument(),
                dir;
            if (cwd) {
                dir = cwd;
            } else {
                dir = ProjectManager.getProjectRoot().fullPath;
            }


            ConnectionManager.exit();
            Panel.show(command);
            Panel.clear();
            
            
            
            
            extlog("Commande à exécuter :"+command+" path:"+dir);
            domain.exec("startProcess", command, dir)
                .done(function(exitCode) {
                    Panel.write("Sortie : " + exitCode + ".\n");
                     StatusBar.hideBusyIndicator("ionic-new-progress");
                }).fail(function(err) {
                    Panel.write("Erreur ionic-cli-nodejs' processes : \n" + err);
                     StatusBar.hideBusyIndicator("ionic-new-progress");
                });

            // Store the last command and cwd
            this.last.command = command;
            this.last.cwd = dir;

        },

        "ionicNewPrj": function(vName,vpName,vTemplate,vPath) {
            domain.exec("startNew",vName,vpName,vTemplate,vPath);
        },
        runCmd: function(sndcmd) {
            domain.exec("sendCmd",sndcmd);
        },
        
        initNpm: function() {
            this.doCmdExec("npm install -g ionic-app-lib",ProjectManager.getProjectRoot().fullPath)
        },
        getEnv: function() {
            
            var result = domain.exec("getEnv");
            result.done(function(envList){
             extlog(envList.join(","));
            }).fail(function(err){
                 extlog(err);
            });
            //extlog(envList)
        },
        getEnvIo: function() {
            
            var result = domain.exec("getEnvIo");
            
            result.done(function(envIoList){
                if ( (envIoList[0]==undefined) || (envIoList[1]==undefined) ) {
                    extlog("Variables d'environnement inexistantes");
                    if ("IONIC_EMAIL" in localStorage) {
                        envIoList[0]=localStorage["IONIC_EMAIL"];
                    }
                    if ("IONIC_PASSWORD" in localStorage) {
                        envIoList[1]=localStorage["IONIC_PASSWORD"];
                    }
                    Dialog.showIoLogin(envIoList);
                }
                
            }).fail(function(err){
                 extlog(err);
            });
            
        },
        rerun: function () {

            var last = this.last;
            if(last.command === null) return;

            this.doCmdExec(last.command, last.cwd);

        },

        /**
         * Close the current connection if server is started
         */
        exit: function () {
            domain.exec("stopProcess");
        }
    };

    /**
     * Panel alias terminal
     */
    $(".content").append(require("text!html/panel.html"));
    var Panel = {

        id: "ionic-cli-panel",
        panel: null,
        commandTitle: null,
        height: 201,

        get: function (qs) {
            return this.panel.querySelector(qs);
        },

        /**
         * Basic functionality
         */
        show: function (command) {
            this.panel.style.display = "block";
            this.commandTitle.textContent = command;
            WorkspaceManager.recomputeLayout();
        },
        hide: function () {
            this.panel.style.display = "none";
            WorkspaceManager.recomputeLayout();
        },
        clear: function () {
            this.pre.innerHTML = null;
        },

        /**
         * Prints a string into the terminal
         * It will be colored and then escape to prohibit XSS (Yes, inside an editor!)
         *
         * @param: String to be output
         */
        write: function (str) {
            var e = document.createElement("span");
            e.innerHTML = ansi(str.replace(/</g, "&lt;").replace(/>/g, "&gt;"));

            var scroll = false;
            if (this.pre.parentNode.scrollTop === 0 || this.pre.parentNode.scrollTop === this.pre.parentNode.scrollHeight || this.pre.parentNode.scrollHeight - this.pre.parentNode.scrollTop === this.pre.parentNode.clientHeight) {
                scroll = true;
            }

            this.pre.appendChild(e);

            if (scroll && scrollEnabled) {
                this.pre.parentNode.scrollTop = this.pre.parentNode.scrollHeight;
            }
        },

        /**
         * Used to enable resizing the panel
         */
        mousemove: function (e) {

            var h = Panel.height + (Panel.y - e.pageY);
            Panel.panel.style.height = h + "px";
            WorkspaceManager.recomputeLayout();

        },
        mouseup: function (e) {

            document.removeEventListener("mousemove", Panel.mousemove);
            document.removeEventListener("mouseup", Panel.mouseup);

            Panel.height = Panel.height + (Panel.y - e.pageY);

        },
        y: 0
    };

    // Still resizing
    Panel.panel = document.getElementById(Panel.id);
    Panel.commandTitle = Panel.get(".cmd");
    Panel.pre = Panel.get(".table-container pre");
    Panel.get(".resize").addEventListener("mousedown", function (e) {

        Panel.y = e.pageY;

        document.addEventListener("mousemove", Panel.mousemove);
        document.addEventListener("mouseup", Panel.mouseup);

    });

    /**
     * Terminal buttons
     */
    Panel.get(".action-close").addEventListener("click", function () {
        
        if ( new RegExp(/serve/gi).test($("#ionic-cli-panel .cmd").html()) ) {
         ConnectionManager.runCmd("q\n");
        }
        ConnectionManager.exit();
        Panel.hide();
    });
    Panel.get(".action-terminate").addEventListener("click", function () {
        
        if ( new RegExp(/serve/gi).test($("#ionic-cli-panel .cmd").html()) ) {
         ConnectionManager.runCmd("q\n");
        }
        ConnectionManager.exit();
    });
    Panel.get(".action-rerun").addEventListener("click", function () {
        if ( new RegExp(/serve/gi).test($("#ionic-cli-panel .cmd").html()) ) {
         ConnectionManager.runCmd("r\n");
        } else {
          ConnectionManager.rerun();  
        }
        
    });

    Panel.get(".action-quit").addEventListener("click", function () { //document.getElementById("ionic-cli-panel")
        ConnectionManager.runCmd("q\n");
        ConnectionManager.exit();
        Panel.hide();
    });


    var Dialog = {

        
        helpCmd: null,
        showCmd: function(cmd) {

          Dialogs.showModalDialog(
            Strings.IONIC_CMD_OPT_DIALOG_ID,
            Strings.DLG_CMD_OPT_TITLE,
            Mustache.render(require("text!html/modal-cmd-options.html"),{cmdval:cmd}),
              [
                  {
                      className: Dialogs.DIALOG_BTN_CLASS_PRIMARY,
                      id: Dialogs.DIALOG_BTN_OK,
                      text: "OK"
                    }
              ]
          ).done(function(id){
                if (id=="ok") {
                    dlgCmd.options = ionicOptions.value;
                    ConnectionManager.doCmdExec(cmd+" "+ionicOptions.value,ProjectManager.getProjectRoot().fullPath);
                }
          });

          var ionicOptions = document.querySelector("."+Strings.IONIC_CMD_OPT_DIALOG_ID+" .ionic-app-cmd-opt");
          if ( new RegExp(/serve/gi).test(cmd) ) {
              
              
             domain.exec("getHelpCmd", "ionic help serve")
                .done(function(exitCode) {
                    extlog("Sortie : " + exitCode + ".\n");
                }).fail(function(err) {
                   extlog("Erreur ionic-cli-nodejs' processes : \n" + err);
                });

            this.last.command = cmd;
          }
          if ( new RegExp(/build/gi).test(cmd) ) {
             domain.exec("getHelpCmd", "ionic help build")
                .done(function(exitCode) {
                    extlog("Sortie : " + exitCode + ".\n");
                }).fail(function(err) {
                   extlog("Erreur ionic-cli-nodejs' processes : \n" + err);
                });

            // Store the last command and cwd
            this.last.command = cmd;
          }
          if ( new RegExp(/run/gi).test(cmd) ) {
             domain.exec("getHelpCmd", "ionic help run")
                .done(function(exitCode) {
                    extlog("Sortie : " + exitCode + ".\n");
                }).fail(function(err) {
                   extlog("Erreur ionic-cli-nodejs' processes : \n" + err);
                });

            // Store the last command and cwd
            this.last.command = cmd;
          }
            if ( new RegExp(/package/gi).test(cmd) ) {
             domain.exec("getHelpCmd", "ionic help package")
                .done(function(exitCode) {
                    extlog("Sortie : " + exitCode + ".\n");
                }).fail(function(err) {
                   extlog("Erreur ionic-cli-nodejs' processes : \n" + err);
                });
            this.last.command = cmd;
          }


        },
        
        showMsg: function (msgtxt) {
            Dialogs.showModalDialog(
            "ionic-cli.show-msg",
            "Information",
            Mustache.render(require("text!html/modal-message.html"), {msg:msgtxt}),//;require("text!html/modal-about.html"),
              [
                  {
                      className: Dialogs.DIALOG_BTN_CLASS_PRIMARY,
                      id: Dialogs.DIALOG_BTN_OK,
                      text: "OK"
                    }
              ]
          ).done(function(id){
                if (id=="ok") {

                 StatusBar.hideBusyIndicator("ionic-new-progress");
                }
          });
        },
        showAbout: function() {

          Dialogs.showModalDialog(
            Strings.DLG_SHOW_ABOUT_ID,
            Strings.DLG_SHOW_ABOUT_TITLE,
            Mustache.render(require("text!html/modal-about.html"), {info:Strings.DLG_TEXT_SHOW_ABOUT}),//;require("text!html/modal-about.html"),
              [
                  {
                      className: Dialogs.DIALOG_BTN_CLASS_PRIMARY,
                      id: Dialogs.DIALOG_BTN_OK,
                      text: "OK"
                    }
              ]
          ).done(function(id){
                if (id=="ok") {
                   StatusBar.hideBusyIndicator("ionic-new-progress");
                }
          });



        },
        showIoLogin: function(envioar) {

          Dialogs.showModalDialog(
            Strings.DLG_SHOW_IO_LOGIN_ID,
            Strings.DLG_SHOW_IO_LOGIN_TITLE,
            Mustache.render(require("text!html/modal-io-login.html"), {infoIoUser:envioar[0],infoIoPass:envioar[1]}),//;require("text!html/modal-about.html"),
              [
                  {
                      className: Dialogs.DIALOG_BTN_CLASS_PRIMARY,
                      id: Dialogs.DIALOG_BTN_OK,
                      text: "OK"
                    }
              ]
          ).done(function(id){
                StatusBar.hideBusyIndicator("ionic-new-progress");
                if (id=="ok") {
                    var valIoUser = formIoUser.value,
                        valIoPass = formIoPass.value;
                    extlog("Nous allons memoriser "+valIoUser+":"+valIoPass);
                    localStorage.setItem("IONIC_EMAIL",valIoUser);
                    localStorage.setItem("IONIC_PASSWORD",valIoPass);
                    //domain.exec("setEnvIo",valIoUser,valIoPass);
                    ConnectionManager.doCmdExec("bower install --save-dev ionic-platform-web-client && ionic login --email "+valIoUser+" --password "+valIoPass+" && ionic io init",ProjectManager.getProjectRoot().fullPath);
                    
                    
                }
          });
           
          var formIoUser = document.querySelector("."+Strings.DLG_SHOW_IO_LOGIN_ID+" .ionic-cli-iouser"),
            formIoPass = document.querySelector("."+Strings.DLG_SHOW_IO_LOGIN_ID+" .ionic-cli-iopass");


        },

        /**
         *
         * HTML : html/modal-create-new.html
         */
        "create": {

            /**
             * HTML put inside the dialog
             */
            html: require("text!html/modal-create-new.html"),

            ionicPath:null,
            ionicName:null,
            ionicModel:null,
            ionicPName:null,
            /**
             * Opens up the modal
             */
            show: function () {
                Dialogs.showModalDialog(
                    Strings.IONIC_CREATE_DIALOG_ID, // ID the specify the dialog
                    Strings.DLG_CREATE_TITLE, // Title
                    this.html, // HTML-Content
                    [ // Buttons
                        {
                            className: Dialogs.DIALOG_BTN_CLASS_PRIMARY,
                            id: Dialogs.DIALOG_BTN_OK,
                            text: "Creer"
                        }, {
                            className: Dialogs.DIALOG_BTN_CLASS_NORMAL,
                            id: Dialogs.DIALOG_BTN_CANCEL,
                            text: "Annuler"
                        }
                    ]
                ).done(function (id) {

                    // Only saving
                    if (id == "ok") {

                        var name = ionicName.value,
                            dir = ionicDir.value,
                            model = ionicModel.value,
                            pname = ionicPkgName.value;
                        this.ionicName = name;
                        this.ionicPath = dir;
                        this.ionicModel = model;
                        this.ionicPName = pname;

                        dlgNew.path = dir+"/"+name;

                        extlog("Infos " + name + ":"+dir+":"+model+":"+pname);
                        StatusBar.showBusyIndicator("ionic-new-progress");
                        Dialogs.showModalDialogUsingTemplate(Mustache.render(require("text!html/modal-waiting.html"), {msg:Strings.MSG_CREATE_PROJECT_WAITING}),false);
                      
                        ConnectionManager.ionicNewPrj(name,pname,model,dir+"/"+name);

                    }
                });

                // It's important to get the elements after the modal is rendered but before the done event
                var ionicName = document.querySelector("." + Strings.IONIC_CREATE_DIALOG_ID + " .ionic-app-name"),
                    ionicDir = document.querySelector("." + Strings.IONIC_CREATE_DIALOG_ID + " .ionic-app-dir"),
                    ionicModel = document.querySelector("." + Strings.IONIC_CREATE_DIALOG_ID + " .ionic-app-model"),
                    ionicPkgName = document.querySelector("." + Strings.IONIC_CREATE_DIALOG_ID + " .ionic-app-pname");


                //var btnBrowser =  document.querySelector("." + IONIC_CREATE_DIALOG_ID + " .ionic-btn-browse");
                document.querySelector("." + Strings.IONIC_CREATE_DIALOG_ID +" #ionic-btn-browse").addEventListener("click",function () {
                     extlog("test click");
                     FileSystem.showOpenDialog(false, true, "Choix d'un fichier", null, [],function (error, dir) {
                                if (!error && dir ) {
                                    ionicDir.value=dir;
                                } else {
                                    ionicDir.value="";
                                }
                            });

                });



            }


        }
    };


    /*

        var templateVars = {
                 ionicDir: ionicSettings.ionicDirectory,
                 projectName: ionicSettings.projectName
        };
        //
        Dialogs.showModalDialogUsingTemplate(Mustache.render(newprjdlg,templateVars),false);
        Dialogs.cancelModalDialogIfOpen();


        function showModalDialog(dlgClass, title, message, buttons, autoDismiss) {
            var templateVars = {
                dlgClass: dlgClass,
                title:    title   || "",
                message:  message || "",
                buttons:  buttons || [{ className: DIALOG_BTN_CLASS_PRIMARY, id: DIALOG_BTN_OK, text: Strings.OK }]
            };
            var template = Mustache.render(DialogTemplate, templateVars);

            return showModalDialogUsingTemplate(template, autoDismiss);
        }

    */


    // execute une commande normale
    var doMyCommand = function() {
        extlog("Executing Command Panel.show");
        //Dialog.create.show();

        //var pth = "http://play.ionic.io/";
        //NativeApp.openLiveBrowser('"' + pth + '"');
       // Dialog.showAbout();
       
        //ConnectionManager.getEnvIo();
        //extlog(ConnectionManager.envIo);
        //if ( (ConnectionManager.envIo.split(",")[0]=="") && (ConnectionManager.envIo.split(",")[1]=="") ) {
            
         //   ConnectionManager.showIoLogin();
        //};
        //ConnectionManager.getEnv();
        
        //var pth = "http://play.ionic.io/";

        //NativeApp.openLiveBrowser('"' + pth + '"');
         //Dialogs.showModalDialogUsingTemplate(Mustache.render(require("text!html/modal-waiting.html"), {msg:"creation en cours du projet..."}),false);
        

    }

    var doIonicNew = function() {
        extlog("Executing Command Panel.show");
        
        Dialog.create.show();

    }

    // execute une commande normale
    var doIonicVersion=function () {
        
        StatusBar.showBusyIndicator("ionic-new-progress");
        extlog("Executing Command : ionic info");
        ConnectionManager.doCmdExec("ionic info");

    }

    // execute ionic lab
    var  doIonicLab = function() {
        
        extlog("Executing Command : ionic -v");
        var check = chkType();
        if (check==true) {
            StatusBar.showBusyIndicator("ionic-new-progress");
            ConnectionManager.doCmdExec("ionic serve --lab");
        }
    }

    var doIonicServe = function() {
        
        var check = chkType();
        if (check==true) {
            StatusBar.showBusyIndicator("ionic-new-progress");
            Dialog.showCmd("ionic serve");
        }
    }

    
    var doIonicBuild = function() {
        var check = chkType();
        if (check==true) {
            StatusBar.showBusyIndicator("ionic-new-progress");
            Dialog.showCmd("ionic build");
        }
    }
    
    
    var doIonicRun = function() {
        var check = chkType();
        if (check==true) {
            StatusBar.showBusyIndicator("ionic-new-progress");
            Dialog.showCmd("ionic run");
        }
    }


    var doIonicAbout = function() {
        StatusBar.showBusyIndicator("ionic-new-progress");
        Dialog.showAbout();
    }

    
    var doIonicPlay = function() {
        var pth = "http://play.ionic.io/";
        NativeApp.openLiveBrowser('"' + pth + '"');      
    }

    
    
    var doIonicUpdate = function() {
        StatusBar.showBusyIndicator("ionic-new-progress");
        ConnectionManager.doCmdExec("npm install -g ionic");

    }
    
    var doIonicIoInit = function() {
         var check = chkType();
        if (check==true) {
            StatusBar.showBusyIndicator("ionic-new-progress");
            ConnectionManager.getEnvIo();
            //ConnectionManager.doCmdExec("ionic login ionic io init");
        }
    } 
    
    
    var doCloseWaiting =function(){
        Dialogs.cancelModalDialogIfOpen("ionic-cli-waiting-dialog");
    }
   
    var doOpenWithFileBrowser = function() {
        NativeApp.openURLInDefaultBrowser(ProjectManager.getProjectRoot().fullPath);
    }

    
    // enregistrer les commandes


    // commande to Init ionic io
    CommandManager.register(Strings.COMMAND_IONIC_IO_INIT_TITLE,Strings.COMMAND_IONIC_IO_INIT_ID,doIonicIoInit);

    // commande nouveau projet ionic
    CommandManager.register(Strings.COMMAND_IONIC_NEW_TITLE, Strings.COMMAND_IONIC_NEW_ID, doIonicNew);
    // commande info version
    CommandManager.register(Strings.COMMAND_IONIC_VERSION_TITLE, Strings.COMMAND_IONIC_VERSION_ID, doIonicVersion); //doIonicVersion
    // commande excecute ionic --lab ouvrant le navigateur par defaut
    CommandManager.register(Strings.COMMAND_IONIC_LAB_TITLE, Strings.COMMAND_IONIC_LAB_ID, doIonicLab);
    // commande execute ionic serve
    CommandManager.register(Strings.COMMAND_IONIC_SERVE_TITLE, Strings.COMMAND_IONIC_SERVE_ID, doIonicServe);

    // commande affiche a propos
    CommandManager.register(Strings.COMMAND_IONIC_ABOUT_TITLE, Strings.COMMAND_IONIC_ABOUT_ID, doIonicAbout);
    
    // commande ionic play
    CommandManager.register(Strings.COMMAND_IONIC_PLAY_TITLE,Strings.COMMAND_IONIC_PLAY_ID, doIonicPlay);
    
    // commande to run
    CommandManager.register(Strings.COMMAND_IONIC_RUN_TITLE,Strings.COMMAND_IONIC_RUN_ID, doIonicRun);
    
    // commande to build
    CommandManager.register(Strings.COMMAND_IONIC_BUILD_TITLE,Strings.COMMAND_IONIC_BUILD_ID, doIonicBuild);
    
    // commande to update
    //CommandManager.register(Strings.COMMAND_IONIC_UPDATE_TITLE,Strings.COMMAND_IONIC_UPDATE_ID, doIonicUpdate);
    


 


    //CommandManager.register(Strings.COMMAND_IONIC_TEST_CODE_TITLE,Strings.COMMAND_IONIC_TEST_CODE_ID, doOpenWithFileBrowser);
    

   // CommandManager.register("close","ionic-cli.close-cmd",doCloseWaiting);


    // ajouter les commandes au menu
    var menu = Menus.addMenu(Strings.MENU_NAME,"menu-ionic-cli");//Menus.getMenu(Menus.AppMenuBar.FILE_MENU);
    menu.addMenuItem(Strings.COMMAND_IONIC_NEW_ID);
    menu.addMenuDivider();
    menu.addMenuItem(Strings.COMMAND_IONIC_IO_INIT_ID);
    menu.addMenuDivider();
    menu.addMenuItem(Strings.COMMAND_IONIC_SERVE_ID);
    menu.addMenuItem(Strings.COMMAND_IONIC_LAB_ID);
    menu.addMenuItem(Strings.COMMAND_IONIC_VERSION_ID);
    menu.addMenuItem(Strings.COMMAND_IONIC_PLAY_ID);
    menu.addMenuDivider();
    menu.addMenuItem(Strings.COMMAND_IONIC_RUN_ID);
    menu.addMenuItem(Strings.COMMAND_IONIC_BUILD_ID);
    menu.addMenuDivider();
    //menu.addMenuItem(Strings.COMMAND_IONIC_UPDATE_ID);
    menu.addMenuItem(Strings.COMMAND_IONIC_ABOUT_ID);
    
    
    //menu.addMenuItem(Strings.COMMAND_IONIC_TEST_CODE_ID);
    //menu.addMenuItem("ionic-cli.close-cmd");



    var chkIoEnv = function() {
        return ConnectionManager.getEnvIo();
    }

    var chkType = function() {
        var result = false;
        
        FileSystem.resolve(ProjectManager.getProjectRoot().fullPath+"ionic.project",function(err,stat){
            
            if (!err) {
               // extlog("Infos fichier"+stat);
                extlog("Le projet est de type ionic");
                result = true;
            } else {
                Dialog.showMsg(Strings.MSG_MUST_BE_IONIC);
            }
            
        });
        return result;
    }
    
    var chkIoConfig = function() {
        var result = false;
        
        FileSystem.resolve(ProjectManager.getProjectRoot().fullPath+".io-config.json",function(err,stat){
            
            if (!err) {
               // extlog("Infos fichier"+stat);
                extlog("Le projet est de type ionic io");
                result = true;
            } 
            
        });
        return result;
    }
    
    
    


    //  log generique permet de voir dans les logs
    function extlog(s) {
        console.log("%c[ionic-cli] %c"+s,"color:blue;font-size:large","font-weight:bold;font-size:large");
    }


    // Initialize extension
    AppInit.appReady(function () {
        ExtensionUtils.loadStyleSheet(module, "styles/styles.css");
         extlog(prefs.get("version"));
       // ConnectionManager.initNpm();
        //$(ProjectManager).on("projectOpen", chkType);
        //$(ProjectManager).on("beforeProjectClose", add);
    });

});
