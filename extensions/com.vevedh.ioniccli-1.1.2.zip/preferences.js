define(function main(require, exports, module) {
    var PreferencesManager = brackets.getModule("preferences/PreferencesManager"),
        Strings            = require('strings'),
        prefs = PreferencesManager.getExtensionPrefs("brackets-ionic-cli");

    // Default settings

    prefs.definePreference("version", "string", "1.1.2");



    // Conversion from the old localstorage
    if ("version" in localStorage) {
        prefs.set("version", localStorage["version"]);
        localStorage.removeItem("version");
    }


    prefs.save();

    module.exports = prefs;
});
