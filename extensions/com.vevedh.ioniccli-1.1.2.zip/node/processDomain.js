(function () {
    "use strict";

    var treekill = require("treekill"),
        exec = require("child_process").exec,
        domain = null,
        child = null,
        DOMAIN_NAME = "ionic-cli-nodejs";



    /*var ionicAppLib = require('ionic-app-lib'),
        cordova = ionicAppLib.cordova,
        serve = ionicAppLib.serve,
        start = ionicAppLib.start;
    */


    function getEnvIonic() {
        
        var envList=[];
        envList.push(process.env.ANDROID_HOME);
        envList.push(process.env.JAVA_HOME);
        return envList;
        
    }
    
    function getEnvIo() {
        
        var envIoList=[];
        envIoList.push(process.env.IONIC_EMAIL);
        envIoList.push(process.env.IONIC_PASSWORD);
        return envIoList;
        
    }
    
    function setEnvIo(mail,pass) {
        process.env.IONIC_EMAIL = mail;
        process.env.IONIC_PASSWORD = pass;
    }
    
    

    function cmdStartNew(pvName, pvPname, pvTemplate, pvPath) {
        //console.log("run ionic");
        var options = {
          appDirectory: pvName,
          appName: pvName,
          packageName: pvPname,
          isCordovaProject: true,
          template: pvTemplate,
          targetPath: pvPath
        };
        
        child = exec("ionic start --id "+pvPname+" --appname "+pvName+ " "+pvPath+ " -t " +pvTemplate,{silent:true});
        
        
        var send = function(data) {

            console.log(data);
            // Support for ansi colors and text decorations
            data = data.toString().replace(/\x1B\[/g, "\\x1B[");
            //outstr = outstr + data;
            domain.emitEvent(DOMAIN_NAME, "Ionic-New-Event-data",data);
            
        };

        child.stdout.on("data", send);
        child.stderr.on("data", send);
        
        child.on("exit", function(code) {
            
            domain.emitEvent(DOMAIN_NAME, "Ionic-New-Event-exit", code);
           
        });

        child.on("error", function(err) {
             domain.emitEvent(DOMAIN_NAME, "Ionic-New-Event-err", err);
        });

          /* exec("ionic start --id "+pvPname+" --appname "+pvName+ " "+pvPath+ " -t " +pvTemplate,function(err, stdout, stderr) {
               if (!err) {
                domain.emitEvent(DOMAIN_NAME, "Ionic-New-Event",stdout);
               }
            });
            */

    }

    
    function cmdSend(cmddata) {
        if (child !== null) {
            child.stdin.write(cmddata);
        }
    }
    
    function cmdGetHelpCmd(command,cb) {
        if (child !== null) {
            treekill(child.pid);
        }

        child = exec(command, {
            silent: true
        });
        
        var outstr="";
        // Send data to the client
        var send = function(data) {

            console.log(data);
            // Support for ansi colors and text decorations
            data = data.toString().replace(/\x1B\[/g, "\\x1B[");
            outstr = outstr + data;
            
        };

        child.stdout.on("data", send);
        child.stderr.on("data", send);

        child.on("exit", function(code) {
            
            domain.emitEvent(DOMAIN_NAME, "outputHelp", outstr);
            cb(null, code);
        });

        child.on("error", function(err) {
            cb(err);
        });
    }

    function cmdStartProcess(command, cwd, cb) {
        if (child !== null) {
            treekill(child.pid);
        }

        child = exec(command, {
            cwd: cwd,
            silent: true
        });

        // Send data to the client
        var send = function(data) {

            console.log(data);
            // Support for ansi colors and text decorations
            data = data.toString().replace(/\x1B\[/g, "\\x1B[");

            domain.emitEvent(DOMAIN_NAME, "output", data);
        };

        child.stdout.on("data", send);
        child.stderr.on("data", send);

        child.on("exit", function(code) {
            cb(null, code);
        });

        child.on("error", function(err) {
            cb(err);
        });
    }

    function cmdStopProcess() {
        if(child !== null) {
            treekill(child.pid);
        }
    }

    function init(domainManager) {
        domain = domainManager;

        if (!domainManager.hasDomain(DOMAIN_NAME)) {
            domainManager.registerDomain(DOMAIN_NAME, {
                major: 0,
                minor: 0
            });
        }

        domainManager.registerCommand(
            DOMAIN_NAME,
            "getEnv",
            getEnvIonic,
            false,
            "Get values of environment vars",
            [],
            [
              { 
                name: "envList",
                type: "array"
              }
            ] 
        );
        
        
        domainManager.registerCommand(
            DOMAIN_NAME,
            "getEnvIo",
            getEnvIo,
            false,
            "Get values of environment vars",
            [],
            [
              { 
                name: "envIoList",
                type: "array"
              }
            ] 
        );
        
        
        domainManager.registerCommand(
            DOMAIN_NAME,
            "setEnvIo",
            getEnvIo,
            false,
            "Get values of environment vars",
            [{
                name:"mail",
                type:"string"
            },{
                name:"pass",
                type:"password"
            }]
        );
        
        domainManager.registerCommand(
            DOMAIN_NAME,
            "sendCmd",
            cmdSend,
            true,
            "Send command to current process",
            [
                {
                    name: "cmddata",
                    type: "string"
                }
            ]
        );
        
        domainManager.registerCommand(
            DOMAIN_NAME,
            "startNew",
            cmdStartNew,
            true,
            "Starts the process using the supplied command",
            [
                {
                    name: "pvName",
                    type: "string"
                },
                {
                    name: "pvPname",
                    type: "string"
                },
                {
                    name: "pvTemplate",
                    type: "string"
                },
                {
                    name: "pvPath",
                    type: "string"
                }
            ]
        );

        domainManager.registerCommand(
            DOMAIN_NAME,
            "startProcess",
            cmdStartProcess,
            true,
            "Starts the process using the supplied command",
            [
                {
                    name: "command",
                    type: "string"
                },
                {
                    name: "cwd",
                    type: "string"
                }
            ]
        );
        
        domainManager.registerCommand(
            DOMAIN_NAME,
            "getHelpCmd",
            cmdGetHelpCmd,
            true,
            "start help commande",
            [
               {
                    name: "command",
                    type: "string"
                } 
            ]
        )

        domainManager.registerCommand(
            DOMAIN_NAME,
            "stopProcess",
            cmdStopProcess,
            false,
            "Stops the process if one is already started",
            []
        );

        domainManager.registerEvent(
            DOMAIN_NAME,
            "output",
            [
                {
                    name: "output",
                    type: "string"
                }
            ]
        );
        
        domainManager.registerEvent(
            DOMAIN_NAME,
            "outputHelp",
            [
                {
                    name: "outputhelp",
                    type: "string"
                }
            ]
        );
        
        domainManager.registerEvent(
            DOMAIN_NAME,
            "Ionic-New-Event-data",
            [{
                name: "stdout",
                type: "string"
                }]
        );
        
        domainManager.registerEvent(
            DOMAIN_NAME,
            "Ionic-New-Event-exit",
            [{
                name: "code",
                type: "string"
                }]
        );
        
        domainManager.registerEvent(
            DOMAIN_NAME,
            "Ionic-New-Event-err",
            [{
                name: "err",
                type: "string"
                }]
        );
        
        domainManager.registerEvent(
            DOMAIN_NAME,
            "Ionic-Module-Event",
            []
        );
    }

    exports.init = init;

}());
