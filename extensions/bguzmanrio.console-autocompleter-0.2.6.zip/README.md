# Console Autocompleter
* Allows you to console.log a var with just pressing Ctrl-Alt-V
* Allows you to console.info a var with just pressing Ctrl-Alt-X
* Now you can change the text for the console (log || info) with a dialog box in the edit submenu
