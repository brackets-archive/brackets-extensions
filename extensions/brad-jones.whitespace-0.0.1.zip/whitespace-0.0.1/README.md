Whitespace My Way
================================================================================
Out of all the whitespace normalizers I couldn't find
one that fitted my needs so I made my own.

> This plugin was forked from:
> https://github.com/MiguelCastillo/Brackets-wsSanitizer

I wanted something that would santize on file open as well as on file save.
This way when I open a file that is indented differently than how I like it,
for the most part I don't even notice anymore.

Installation
--------------------------------------------------------------------------------
Search for "Whitespace My Way" in the brackets
[Extension Manager](https://github.com/adobe/brackets/wiki/Brackets-Extensions),
then click on the Install button.

It uses the Indentation settings already set by Brackets.

There are no prefrences or things to enable and disable.
It starts working the second you install it.

--------------------------------------------------------------------------------
Developed by Brad Jones - brad@bjc.id.au
