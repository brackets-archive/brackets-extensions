brackets-csslint
================

[CSSLint](http://csslint.net/) extension for Brackets.

![CSSLint](http://f.cl.ly/items/3E0y2m1R3i331u361M2k/Screen%20Shot%202013-09-12%20at%203.48.51%20PM.png "CSSLint")
