Base 16 Bright Light Theme for Brackets
============================

Attempting to be as close to [Bright Light](http://chriskempson.github.io/base16/#bright) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
