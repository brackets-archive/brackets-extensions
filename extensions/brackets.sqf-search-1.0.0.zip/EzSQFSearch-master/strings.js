define(function (require, exports, module) {
    'use strict';
    return {
        RIGHT_CLICK_SEARCH_TITLE_BISWIKI: "BIS Wiki",
    }
});