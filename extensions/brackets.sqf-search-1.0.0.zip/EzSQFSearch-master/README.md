Use this extension with Brackets to easily search ANY ArmA scripting (SQF) command from BIS wiki.

Usage: Highlight the keyword, right click, choose "BIS Wiki" and a new browser tab/window will open
in your default browser.