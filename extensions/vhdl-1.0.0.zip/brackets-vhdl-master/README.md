# vhdl Syntax Highlighting for Brackets

This plugin provides syntax highlight for vhdl via a CodeMirror mode for Brackets.

## Installation

1. Open the the Extension Manager from the Brackets File menu
2. In the search bar, type vhdl
3. Press the Install button next to vhdl Syntax Highlighting
4. OR Copy and paste the URL of the github repo or zip file