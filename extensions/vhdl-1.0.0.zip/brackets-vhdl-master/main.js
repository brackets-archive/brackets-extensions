define(function (require, exports, module) {
  "use strict";

  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("vhdl", {"name":"VHDL","mode":"vhdl","fileExtensions":["vhd"],"lineComment":["--"]});
      
});