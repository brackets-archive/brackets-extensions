Dieter Bamz Theme for Brackets
==============================

Inspired by Dieter Rams's Snow White's Coffin. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/DieterBamz/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/DieterBamz/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/DieterBamz/blob/master/screenshots/js.png)
