LB4B
====

Laravel's Blade for Brackets is an extensions which adds Blade specific features to Brackets language modes.

0.0.1  
-extends html mode to support Blade files  
-uses {{-- --}} for block comment  


To Do:  
-move from HTML extension to overlay (syntax highlighting)  
-accept EchoData and EchoDataEscape coloring  
-improved comment support  
-add text-based tagging

