var ckConfig = {
	height: '600px', 
	width: '100%', 
	allowedContent: true,
	toolbar: 'Basic'
}
