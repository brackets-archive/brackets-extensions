/**
* Transliteration for Brackets
* @author Slobodan Marković <sloba.markovic@gmail.com>
*/

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */

/*global define, $, brackets */

define(function (require, exports, module) {
    "use strict";

    // Include Brackets modules
    var _ = brackets.getModule("thirdparty/lodash");
    var AppInit = brackets.getModule("utils/AppInit");
    var StringUtils = brackets.getModule("utils/StringUtils");
    var Dialogs = brackets.getModule("widgets/Dialogs");
    var CommandManager = brackets.getModule("command/CommandManager");
    var KeyBindingManager = brackets.getModule("command/KeyBindingManager");
    var Menus = brackets.getModule("command/Menus");
    var EditorManager = brackets.getModule("editor/EditorManager");
    var MainViewManager = brackets.getModule("view/MainViewManager");

    // Include local modules (settings, localizations, UI elements)
    var Settings = require("settings");
    var Strings = require("i18n!nls/strings");
    var UIDialogOptions = require("ui/dialogOptions");

    /**
     * @private
     * Helper function for logging and displaying error messages.
     * @param {String} msg Error message
     */
    function errorMessage(msg) {
        console.error("[smarkovic.transliteration] " + Strings.CONSOLE_ERROR_LABEL + ": " + msg);
        Dialogs.showModalDialog(Dialogs.DIALOG_ID_ERROR, Strings.DIALOG_TITLE_ERROR, msg);
    }

    /**
     * Extends the String object with .translit() function
     * @param {Object} mappings Character mappings
     * @param {Boolean} [reverse=false] Reverse transliteration (default: false)
     * @returns {String} Transliterated string
     */
    String.prototype.translit = function (mappings, reverse) {
        if (typeof reverse !== "boolean") { reverse = false; }

        var str = this;
        var result = str;

        var rexp;
        _.forEach(mappings, function (chrTo, chrFrom) {
            if (!reverse) {
                rexp = new RegExp(chrFrom, "g");
                result = result.replace(rexp, chrTo);
            } else {
                rexp = new RegExp(chrTo, "g");
                result = result.replace(rexp, chrFrom);
            }
        });

        // If the string was all upper case, make the transliterated version all upper case
        if (str === str.toUpperCase()) { result.toUpperCase(); }

        return result;
    };

    /**
     * @private
     * Executes transliteration.
     * @param {{ "table": String, "reverse": Boolean }} selectedOptions Transliteration options selected by the user
     * @returns {Boolean} Transliteration success
     */
    function execTranslit(selectedOptions) {
        var editor = EditorManager.getActiveEditor();
        if (!editor) { return false; }

        // Get character mappings of the selected transliteration table
        var mappings = _.result(_.find(Settings.tables, { "name": selectedOptions.table }), "mappings");
        if (mappings === "undefined") {
            errorMessage(StringUtils.format(Strings.ERROR_MAPPINGS_NOT_FOUND, selectedOptions.table));
            return false;
        }

        // Get current selection from the editor
        var currentSelection = editor.getSelectedText();

        // If nothing is selected, select the entire document first
        if (currentSelection === "") {
            editor.selectAllNoScroll();
            currentSelection = editor.getSelectedText();
        }

        // Transliterate the selection word-by-word
        var translitSelection = currentSelection.match(/\S+\s*/g).map(function (word) {
            return word.translit(mappings, selectedOptions.reverse);
        }).join("");

        // Replace the current selection with the trasnliterated text
        editor._codeMirror.replaceSelection(translitSelection);
        MainViewManager.focusActivePane();

        return true;
    }

    /**
     * @private
     * Opens the Options dialog and executes transliteration with the selected options.
     */
    function handleDialogOptions() {
        UIDialogOptions.showDialog().done(function (selectedOptions) {
            if (!selectedOptions.isEmptyObject) {
                execTranslit(selectedOptions);
            }
        });
    }

    /**
     * Execute when Brackets is ready.
     */
    AppInit.appReady(function () {
        // Register default command and add it to the Edit menu
        var defaultCommand = {
            "id": "smarkovic.transliteration.dialog",
            "title": Strings.MENU_OPTION_TITLE,
            "key" : "Ctrl-Shift-T"
        };
        CommandManager.register(defaultCommand.title, defaultCommand.id, handleDialogOptions);
        var editMenu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
        editMenu.addMenuItem(defaultCommand.id, defaultCommand.key);

        // Register custom commands and key bindings from settings.js
        _.forEach(Settings.shortcuts, function (shortcut, shortcuts) {
            var selectedOptions = {
                "table" : shortcut.table,
                "reverse": shortcut.reverse
            };
            CommandManager.register(shortcut.title, shortcut.id, function () { execTranslit(selectedOptions); });
            KeyBindingManager.addBinding(shortcut.id, shortcut.key);
        });
    });
});
