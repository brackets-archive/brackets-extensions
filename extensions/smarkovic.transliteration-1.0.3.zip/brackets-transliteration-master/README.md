# Transliteration for Brackets

This extension provides text transliteration for [Brackets](http://brackets.io).

The extension currently comes with support for:

* Serbian Cyrillic to Serbian Latin (including reverse transliteration)
* Serbian Cyrillic to US ASCII
* Serbian Latin to US ASCII

## Installation

To install this extension, please use the built-in Brackets Extension Manager (File → Extension Manager...), which will download the extension from the [Extension Registry](https://brackets-registry.aboutweb.com/).

## Features

* Transliterate a selection or the entire document
* Support for two-way (reverse) transliteration
* Add custom transliteration tables and key bindings

## Keyboard shortcuts

The following are the default keyboard shortcuts:

Windows        | Mac           | Associated Command
:------        | :--           | :-----------------
`Ctrl-Shift-T` | `Cmd-Shift-T` | Displays transliteration options dialog
`Ctrl-Shift-I` | `Cmd-Shift-I` | Serbian Cyrillic to Serbian Latin
`Ctrl-Shift-N` | `Cmd-Shift-N` | Serbian Latin to Serbian Cyrillic
`Ctrl-Shift-A` | `Cmd-Shift-A` | Serbian Cyrillic to US ASCII

If any of the shortcut keys conflict with your keyboard or you would prefer to use another shortcut key, you can [override the keys as described here](https://github.com/adobe/brackets/wiki/User-Key-Bindings) or customize the [`settings.js`](settings.js) file.

## Customization

You can add new transliteration tables and keyboard shortcuts by editing the [`settings.js`](settings.js) file.

Here's a sample transliteration table from the `"tables"` array of the [`settings.js`](settings.js) file:

```js
{
    "name": "sr-sr@latin",
    "description": Strings.SETTINGS_TABLE_CYR2LAT,
    "reverse": true,
    "mappings": {
        "А": "A",
        "Б": "B",
           ...
        "Ш": "Š"
    }
}
```

Field         | Description
:----         | :----------
*name*        | Internal name of the table
*description* | Localized user-friendly name of the table (see [`nls/{locale}/strings.js`](nls/root/strings.js))
*reverse*     | Is reverse transliteration possible? (`true`/`false`)
*mappings*    | Character mappings

Here's a sample keyboard shortcut entry from the `"shortcuts"` array of the [`settings.js`](settings.js) file:

```js
{
    "id": "smarkovic.transliterate.cyr2lat",
    "title": Strings.SETTINGS_TABLE_CYR2LAT,
    "key": "Ctrl-Shift-I",
    "table": "sr-sr@latin",
    "reverse": false
}
```

Field     | Description
:----     | :----------
*id*      | Internal command ID (**must** start with "`smarkovic.transliterate.`")
*title*   | Localized user-friendly name of the shortcut (see [`nls/{locale}/strings.js`](nls/root/strings.js))
*key*     | Keyboard shortcut
*table*   | Transliteration table to be used
*reverse* | Is this a reverse transliteration? (`true`/`false`)

### License

This extension is licensed under the [MIT License](LICENSE.md).
