This extension uses bits and pieces from the following projects:

[**WP Translit**](https://wordpress.org/plugins/wp-translit/developers/)
Copyright (C) 2008-2015 Aleksandar Urošević ([urke.kg@gmail.com](mailto:urke.kg@gmail.com))
