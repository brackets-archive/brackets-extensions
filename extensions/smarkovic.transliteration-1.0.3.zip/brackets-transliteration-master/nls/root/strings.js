/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */

/*global define */

define({
    // settings.js
    "SETTINGS_TABLE_CYR2LAT"          : "Serbian Cyrillic to Serbian Latin",
    "SETTINGS_TABLE_CYR2ASCII"        : "Serbian Cyrillic to US ASCII",
    "SETTINGS_TABLE_LAT2CYR"          : "Serbian Latin to Serbian Cyrillic",
    "SETTINGS_TABLE_LAT2ASCII"        : "Serbian Latin to US ASCII",

    // main.js
    "MENU_OPTION_TITLE"               : "Transliterate",
    "CONSOLE_ERROR_LABEL"             : "ERROR",
    "DIALOG_TITLE_ERROR"              : "Transliteration Extension Error",
    "ERROR_MAPPINGS_NOT_FOUND"        : "Character mappings for table '{0}' are not available in settings.js!",

    // ui/dialogОptions.js
    "REVERSE_DISABLED_TOOLTIP"        : "Reverse transliteration is not available for the selected table",

    // ui/dialogОptions.tpl
    "DIALOG_OPTIONS_TITLE"            : "Transliteration options",
    "DIALOG_OPTIONS_SELECT_TABLE"     : "Transliteration table",
    "DIALOG_OPTIONS_CHECKBOX_REVERSE" : "Reverse transliteration",
    "BUTTON_OK"                       : "OK",
    "BUTTON_CANCEL"                   : "Cancel"
});
