/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */

/*global define */

define(function (require, exports, module) {
    "use strict";

    // Available localizations
    module.exports = {
        root: true,     // English
        "sr": true      // Serbian (Cyrillic)
    };
});
