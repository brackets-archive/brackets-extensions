/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */

/*global define */

define({
    // settings.js
    "SETTINGS_TABLE_CYR2LAT"          : "Ћирилица у латиницу",
    "SETTINGS_TABLE_CYR2ASCII"        : "Ћирилица у US ASCII",
    "SETTINGS_TABLE_LAT2CYR"          : "Латиница у ћирилицу",
    "SETTINGS_TABLE_LAT2ASCII"        : "Латиница у US ASCII",

    // main.js
    "MENU_OPTION_TITLE"               : "Транслитерација",
    "CONSOLE_ERROR_LABEL"             : "ГРЕШКА",
    "DIALOG_TITLE_ERROR"              : "Додатак за транслитерацију - грешка!",
    "ERROR_MAPPINGS_NOT_FOUND"        : "Мапирања знакова за табелу '{0}' нису доступна у settings.js!",

    // ui/dialogОptions.js
    "REVERSE_DISABLED_TOOLTIP"        : "Реверзна транслитерација није доступна за изабрану табелу",

    // ui/dialogОptions.tpl
    "DIALOG_OPTIONS_TITLE"            : "Транслитерација",
    "DIALOG_OPTIONS_SELECT_TABLE"     : "Табела за транслитерацију",
    "DIALOG_OPTIONS_CHECKBOX_REVERSE" : "Реверзна транслитерација",
    "BUTTON_OK"                       : "У реду",
    "BUTTON_CANCEL"                   : "Поништи"
});
