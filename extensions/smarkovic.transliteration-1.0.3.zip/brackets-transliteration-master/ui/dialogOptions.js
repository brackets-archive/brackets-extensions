/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */

/*global define, $, brackets, Mustache */

define(function (require, exports, module) {
    "use strict";

    // Include Brackets modules
    var _ = brackets.getModule("thirdparty/lodash");
    var ExtensionUtils = brackets.getModule("utils/ExtensionUtils");
    var Dialogs = brackets.getModule("widgets/Dialogs");

    // Include local modules (extension settings, translations)
    var Settings = require("settings");
    var Strings = require("i18n!nls/strings");

    // Local variables
    var dialog, $dialog;

    /**
     * @private
     * Initialize the dialog and set event listeners.
     */
    function initializeDialog() {

        // If the selected table does not support reverse transliteration, uncheck and disable related checkbox
        var checkReverse = function () {
            var reverseAvailable = ($dialog.find("#select-table option:selected").attr("reverse").toLowerCase() === "true");
            var reverseChecked = $dialog.find("#select-reverse input:checkbox").is(":checked");
            if (reverseAvailable) {
                $dialog.find("#select-reverse input:checkbox").prop("disabled", false);
                $dialog.find("#select-reverse input:checkbox, #select-reverse label").removeAttr("title");
            } else {
                $dialog.find("#select-reverse input:checkbox").prop("disabled", true);
                $dialog.find("#select-reverse input:checkbox, #select-reverse label").prop("title", Strings.REVERSE_DISABLED_TOOLTIP);
                if (reverseChecked) {
                    $dialog.find("#select-reverse input:checkbox").prop("checked", false);
                }
            }
        };
        checkReverse();

        // checkReverse() every time the value in the select box changes
        $dialog.find("#select-table").on("change", checkReverse);
    }

    /**
     * @public
     * Displays the Options dialog and returns the selected options.
     * @returns {$.Promise} A jQuery promise resolved with a selectedOptions object
     */
    function showDialog() {
        var result = new $.Deferred();

        // Prepare options array for the template
        var translitOptions = { "tables": [] };
        _.forEach(Settings.tables, function (table, tables) {
            translitOptions.tables.push({
                "name": table.name,
                "description": table.description,
                "reverse": table.reverse,
                "defaultOption": (table.name === Settings.defaultTable)
            });
        });

        // Load CSS, provide template with the options and localized labels, and display the dialog
        ExtensionUtils.loadStyleSheet(module, "dialogOptions.css");
        var template = Mustache.render(
            require("text!ui/dialogOptions.html"),
            { "Options" : translitOptions, "Strings": Strings }
        );
        dialog = Dialogs.showModalDialogUsingTemplate(template);

        $dialog = dialog.getElement();

        // Initialize the dialog
        initializeDialog();

        // When dialog is dismissed, return the selected options
        dialog.done(function (buttonID) {
            if (buttonID === "OK") {
                var selectedOptions = {
                    "table": $dialog.find("#select-table option:selected").val(),
                    "reverse": $dialog.find("#select-reverse input:checkbox").is(":checked")
                };
                return result.resolve(selectedOptions);
            }
        });

        return result.promise();
    }

    // Expose public methods
    exports.showDialog = showDialog;

});
