# Brackets Blue
### Code editor and UI theme for Brackets.

![Screenshot 1](@screenshot1.png?raw=true "Screenshot 1")

![Screenshot 2](@screenshot2.png?raw=true "Screenshot 2")


This theme was created based on the following version of Brackets - **Release 1.13 build 1.13.0-17696** -

As you download this theme with a later Brackets build, and something went wrong with, I apolozige beforehand.

I will try to maintain this theme as long as I continue to use Brackets.

For the theme work as intended use the following extensions:

- [Custom Work](https://github.com/DH3ALEJANDRO/custom-work-for-brackets)

- [Brackets CSS Color Preview](https://github.com/cmgddd/Brackets-css-color-preview)

- [Brackets Tree Icons](https://github.com/wolffe/brackets-tree-icons)

- [Brackets UI Theming Enabler](https://github.com/notasz/brackets-uitheming)
___

#### In case you gonna create or modified a theme based on this one, take some notes:

- I did not want to use *!important*, but I could not find a way around for some CSS rules to work how I want.

- If something comes out of the stabilsh style of this theme, it will be of two reasons:

  - I forget or miss a element to be styled.
  - I have never seen the element highlighted in the editor to then apply the theme style.

- The comments are set to use the 'Share Tech Mono' font. You can find it in google fonts website. Otherwise declared what font you like or delete the declaration and the font will go with what is set in Brackets. Find the declaration with *'CTRL+F' and type -> .cm-comment*

___

#### For the development of this theme I have use, as references, the following themes.

- [Brackets-Stripper](https://github.com/visualbam/Brackets-Stripper)

- [Brackets-Stripper-Redo](http://brackets.dnbard.com/extension/brackets-stripper-redo)

- [Monokai Dark Soda](https://github.com/rainje/Monokai-Dark-Soda)

- [Dracula Theme](https://draculatheme.com/brackets/)
___

### LICENSE
Brackets Blue is licensed under the [MIT license](https://opensource.org/licenses/MIT).
___

### Thank you for using it.
