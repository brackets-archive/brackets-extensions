# robcaa dark theme to Brackets
[Robert Girhiny](http://robertgirhiny.com)  
robcaa@gmail.com  
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 

  > Clearly visible theme to brackest


### Screenshots
  ![screenshot](/screenshots/1.jpg?raw=true)