quickLib 1.0.3
==========

 Brackets extension that adds simple access to all those essential resources on Google Hosted Libraries for fast snippet insertion.
 ( https://developers.google.com/speed/libraries/ )

 ( https://developers.google.com/speed/libraries/ )
