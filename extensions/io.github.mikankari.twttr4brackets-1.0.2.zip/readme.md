# Twitter for Brackets
Twitter client on Adobe Brackets

Extension for [Brackets](https://github.com/adobe/brackets/).

![Screenshot](screenshot.png?raw=true)

## Installation

1. Open the **Extensions Manager**
2. Search for "twitter for brackets"
3. Click the **Install** button

## How to Use

1. Click "Twitter" icon in the toolbar

on first startup,

1. Click the **Login** button in the panal
2. Log in to Twitter and click **Authorize app** button in opened browser window
