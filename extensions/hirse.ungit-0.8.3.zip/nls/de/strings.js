define({
    TOOLBAR_ICON_TOOLTIP: "Ungit Ansicht umschalten",
    CLOSE_VIEWER_TOOLTIP: "Ungit Ansicht schließen",
    TOOLBAR_ICON_TOOLTIP_INSTALLING: "Installiere Ungit",
    OPEN_UNGIT_CMD: "Ungit Ansicht öffnen",
    KILL_UNGIT_CMD: "Ungit beenden",
    INSTALL_DIALOG_PROGRESS_TITLE: "Installiere Ungit…",
    INSTALL_DIALOG_FINISHED_TITLE: "Installiere Ungit … Fertig!",
    INSTALL_DIALOG_FINISHED_CONTENT: "Brackets Ungit is jetzt zur Verwendung bereit. Für Installationsdetails, siehe Log unten.",
    INSTALL_DIALOG_ERROR_TITLE: "Fehler bei der Installation von Ungit",
    INSTALL_DIALOG_ERROR_CONTENT: "Brackets Ungit setzt eine globale Installation von node.js und npm vorraus. Für Fehlerdetails, siehe Log unten.",
    INSTALL_DIALOG_BUTTON_HIDE: "Ausblenden",
    INSTALL_DIALOG_BUTTON_OK: "OK",
    INSTALL_DIALOG_BUTTON_CLOSE: "Schließen"
});
