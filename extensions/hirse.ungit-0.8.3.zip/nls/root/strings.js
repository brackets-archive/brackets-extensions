define({
    TOOLBAR_ICON_TOOLTIP: "Toggle Ungit View",
    CLOSE_VIEWER_TOOLTIP: "Close Ungit View",
    TOOLBAR_ICON_TOOLTIP_INSTALLING: "Installing Ungit",
    OPEN_UNGIT_CMD: "Open Ungit View",
    KILL_UNGIT_CMD: "Stop Ungit",
    INSTALL_DIALOG_PROGRESS_TITLE: "Installing Ungit…",
    INSTALL_DIALOG_FINISHED_TITLE: "Installing Ungit … Finished!",
    INSTALL_DIALOG_FINISHED_CONTENT: "You can now start using Brackets Ungit. See log below for installation details.",
    INSTALL_DIALOG_ERROR_TITLE: "Error installing Ungit",
    INSTALL_DIALOG_ERROR_CONTENT: "Do you have node.js and npm installed and globally available? See log below for details.",
    INSTALL_DIALOG_BUTTON_HIDE: "Hide",
    INSTALL_DIALOG_BUTTON_OK: "OK",
    INSTALL_DIALOG_BUTTON_CLOSE: "Close"
});
