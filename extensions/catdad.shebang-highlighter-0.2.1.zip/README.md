# brackets-shebang-highligher

Detect code language based on the shebang comment at the top of your code (e.g. `#!/usr/bin/env node`).

This project is still a work-in-progress, and I welcome any pull requests or [issues](https://github.com/catdad/brackets-shebang-highligher/issues/new) you may have.
