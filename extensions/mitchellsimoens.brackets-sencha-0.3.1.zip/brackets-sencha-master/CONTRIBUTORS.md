# Contributors

* [Mitchell Simoens](https://github.com/mitchellsimoens) [https://www.mitchellsimoens.com](https://www.mitchellsimoens.com)
* [Joel Watson](https://github.com/joelwatson) [http://existdissolve.com/](http://existdissolve.com/)
