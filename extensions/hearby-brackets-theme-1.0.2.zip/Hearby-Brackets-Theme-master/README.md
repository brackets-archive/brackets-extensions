Hearby Theme for Brackets
=============================

A theme for Professional Programmers. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/imbhavin95/Hearby-Brackets-Theme/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/imbhavin95/Hearby-Brackets-Theme/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/imbhavin95/Hearby-Brackets-Theme/blob/master/screenshots/Javascript.png)
