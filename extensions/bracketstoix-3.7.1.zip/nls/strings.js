'use strict';
// uuid: 3b4b3629-873e-4f41-8955-dc1687b4bec3

// ------------------------------------------------------------------------
// Copyright (c) 2016-2019 Alexandre Bento Freire. All rights reserved.
// Licensed under the MIT License+uuid License. See License.txt for details
// ------------------------------------------------------------------------

define(function (require, exports, module) {
  module.exports = {
    root: true,
    "pt": true,
    "de": true,
    "zh-tw": true,
    "zh": true
  };
});
