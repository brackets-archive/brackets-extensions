# flatlandish
Brackets Theme based roughly off of the ST3 flatland color scheme by <a href="https://github.com/thinkpixellab/flatland">thinkpixellab</a>

<h4>CSS</h4>
![CSS Sample](/images/css.jpg?raw=true "CSS")

<h4>PHP</h4>
![PHP Sample](/images/php.jpg?raw=true "CSS")


<h4>Plugin Support</h4>
<h6>Show Whitespace <a href="https://github.com/DennisKehrig/brackets-show-whitespace">https://github.com/DennisKehrig/brackets-show-whitespace)</a></h6>
<h6>Code Folding <a href="https://github.com/thehogfather/brackets-code-folding">https://github.com/thehogfather/brackets-code-folding</a></h6>
<h6>brackets documents toolbar<a href="https://github.com/dnbard/brackets-documents-toolbar">https://github.com/dnbard/brackets-documents-toolbar</a></h6>
