# CHANGELOG Flatlandish

v 0.3.0

* Initial Beta Release


v 0.4.0

* Updated scrollbar styling


V 0.5.0

* Fixed Scrollbar issue

V 0.5.1

* Added min version to JSON file to allow updates
* Support for Code Folding (https://github.com/thehogfather/brackets-code-folding)

V 0.6.0

* Updated Quick editor styles
* Updated matching tag highlights

V 0.6.5

* Added support for code folding plugin
* Show Whitespace (https://github.com/DennisKehrig/brackets-show-whitespace)

V 0.7.0

* Changed matching bracket styles
* Changed error highlighting styles
* Added Changlog

V 0.7.2

* minor adjustment to make the text not squished up next to line border.
* added 3rd tire color for sudo classes
* support for brackets documents-toolbar (https://github.com/dnbard/brackets-documents-toolbar)

