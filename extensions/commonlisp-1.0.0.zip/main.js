define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("commonlisp", {"name":"Common Lisp","mode":"commonlisp","fileExtensions":["clisp","lisp"],"lineComment":[";",";;"]});
});