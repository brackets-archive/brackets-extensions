# Subtly Light

A subtly colored light theme for Brackets by [Jay Boucher](http:jayboucher.com). Designed for legibility, quick reference and comfort.

## HTML
![HTML Screenshot](html.jpg)

## CSS
![CSS Screenshot](css.jpg)

## Copyright and License
Copyright (c) 2015 [Jay Boucher](http:jayboucher.com). Released under the [MIT License](LICENSE).
