Base 16 Pop Light Theme for Brackets
============================

Attempting to be as close to [Pop Light](http://chriskempson.github.io/base16/#pop) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
