Base 16 Atelierdune Light Theme for Brackets
============================

Attempting to be as close to [Atelierdune Light](http://chriskempson.github.io/base16/#atelierdune) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
