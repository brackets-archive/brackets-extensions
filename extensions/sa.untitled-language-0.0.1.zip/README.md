## Untitled language

Enable language highlighting for new unsaved files