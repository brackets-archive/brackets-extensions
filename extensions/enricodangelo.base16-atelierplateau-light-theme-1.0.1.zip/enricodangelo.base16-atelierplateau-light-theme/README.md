Base 16 Atelierplateau Light Theme for Brackets
============================

Attempting to be as close to [Atelierplateau Light](http://chriskempson.github.io/base16/#atelierplateau) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
