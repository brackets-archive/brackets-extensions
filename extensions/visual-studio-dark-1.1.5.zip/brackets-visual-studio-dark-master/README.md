Visual Studio Dark theme for Brackets
===========================

Based on Visual Studio 2013 Dark theme. Uses `"addModeClass" = true;` to make Brackets/CodeMirror add classes for the current language to allow fine grain styling. (e.g. different colors for html, css/less/sass, js/coffee etc)

Screenshot <br />![Visual Studio Dark theme](https://raw.githubusercontent.com/fergaldoyle/brackets-visual-studio-dark/master/screenshot.png) 
