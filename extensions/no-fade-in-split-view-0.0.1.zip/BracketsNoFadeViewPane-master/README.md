# BracketsNoFadeViewPane
Disables fading of inactive view pane in Brackets.
