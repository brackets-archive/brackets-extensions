// Uninitialize.
        uninitialize : function () {
            $(this.domNode).off();
            $(this.domNode).html('');
        },