// Setup widget.
        _setupWidget : function () {

            // Set class for domNode
            $(this.domNode).addClass('mx-reminder-notes-container');

        },