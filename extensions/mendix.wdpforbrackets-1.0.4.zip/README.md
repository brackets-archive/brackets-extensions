# Widget Development Plugin For Brackets

This plugin creates an IDE for creating custom widgets.

## Contributing

For more information on contributing to this repository visit [Contributing to a GitHub repository](https://world.mendix.com/display/howto50/Contributing+to+a+GitHub+repository)!

## Typical usage scenario

Use this within Brackets to get the right toolset to develop custom mendix widgets fast.

## More information?
Check out the [Wiki page] (https://github.com/mendix/WDPForBrackets/wiki)
