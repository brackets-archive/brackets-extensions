Brackets-dark-statusbar
=======================

Makes the bottom status bar dark.
It matches the default colors of the Brackets sidebbar.


**Change Log**


2014/8/13 - removed a style for a third-party extention and added the MIT licence.

