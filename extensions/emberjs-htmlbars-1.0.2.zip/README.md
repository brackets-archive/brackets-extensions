Ember HTMLBars highlighter for Brackets
===============================

A syntax highlighting plugin for [Ember HtmlBars templates](http://www.emberjs.com/) in the [Brackets editor](http://brackets.io/).

![HTMLBars Syntax highlighting](http://www.apyx.fr/medias/ember-js-htmlbars-brackets.png)

Installing
----------

The easiest way to install this extension is to use the [Extension Manager](github.com/adobe/brackets/wiki/Brackets-Extensions) in Brackets.

If you want the cutting-edge version you can always clone this repo and manually install it into the brackets extension folder (you can find it in your system by going to Help > Show Extensions Folder in Brackets).

History
------------

This project is a fork of brackets-handlebars-templates from [Karl-Johan Sjögren](https://github.com/karl-sjogren)
