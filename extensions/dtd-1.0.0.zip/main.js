define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("dtd", {"name":"DTD","mode":"dtd","fileExtensions":["dtd"],"blockComment":["<!--","-->"]});
});