Brackets New HTML5 document
===============

When double-clicked, a sidebar or toolbar to create a new Html5 document.


Run

    File -> 'New Html5...'
    or
    Sidebar double-click
    or 
    Toolbar double-click


![Bracekt html5](http://i62.tinypic.com/1564fow.png)

Yasin Kuyu - [Insya](http://insya.com)

License
MIT
