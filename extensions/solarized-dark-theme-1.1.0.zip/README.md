# Solarized Dark Theme for Brackets
A Solarized Dark theme for [Brackets](http://brackets.io/)

![alt text][logo]

[logo]: screenshot.png "Solarized Dark"