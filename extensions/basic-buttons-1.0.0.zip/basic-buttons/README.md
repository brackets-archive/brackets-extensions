## Instructions
Simply adds Save All, Undo/Redo, and optional Custom button to the toolbar.
Right-click for alternate actions, specify any command for third button.

## History
 - 1.0.0 Sept 2016
