/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window */

/** Simple extension that adds a "File > Hello World" menu item */
define(function (require, exports, module) {
    "use strict";

    //vars
    var CommandManager = brackets.getModule("command/CommandManager"),
        EditorManager = brackets.getModule("editor/EditorManager"),
        DocumentManager = brackets.getModule("document/DocumentManager"),
        Menus = brackets.getModule("command/Menus"),
        Commands = brackets.getModule("command/Commands"),
        AppInit = brackets.getModule("utils/AppInit"),
        KeyEvent = brackets.getModule("utils/KeyEvent"),
        KeyBindingManager = brackets.getModule("command/KeyBindingManager");

	
	
	
	function clear(text, editor, start, end) {
		 var tablica = text.split('\n');
		 var editor = EditorManager.getFocusedEditor();
		 var cursorPosition = editor.getCursorPos();
		 var Txt = editor.document.getLine(cursorPosition.line);
		var line = editor.document.getLine(cursorPosition.line);
		var word = line.substring(0, cursorPosition.ch);
		
		var cursorEnd = {
                        line: cursorPosition.line,
                        ch: line.length
                    };
		
		var startTxt = {
                        line: cursorPosition.line,
                        ch: cursorPosition.ch - word.length
                    };
		
			for (var i = 0, len = tablica.length; i < len; i++) {
			 if (tablica[i].indexOf("!important;") < 0) {
				 tablica[i] = tablica[i].replace(';', '!important;');
			 }	
		 }
		
		editor.document.replaceRange(tablica, start, end);
		
		if (tablica.length == 1) {
			if (Txt.indexOf("!important;") < 0) {
				 Txt = Txt.replace(';', '!important;');
			 }
			editor.document.replaceRange(Txt, startTxt, cursorEnd);
		}
        
				
    }
	
	
	
	function containsChar(word) {
        var erg;
        if (word.indexOf(";") > -1) {
            erg = true;
        }  else {
            erg = false;
        }
        return erg;
    }
	
	
	
	

	
	var parseLine = function (line, cursorColumn) {
        var words;
        line = line.substring(0, cursorColumn);
        words = line.split(" ");
        return words[words.length - 1];
    };
	
	
	
	
	var keyEventHandler = function ($event, editor, event) {
        var cursorPosition,
            line,
            word,
            start;
        var activedocument = DocumentManager.getCurrentDocument();
        var language = activedocument.getLanguage();
        var commmand = CommandManager.get("specialchars.scselect");
        if (commmand.getChecked()) {
            if (((event.type === "keydown") && (event.keyCode === KeyEvent.DOM_VK_SPACE)) || ((event.type === "keydown") && (event.keyCode === KeyEvent.DOM_VK_ENTER)) || ((event.type === "keydown") && (event.keyCode === KeyEvent.DOM_VK_RIGHT))) {
                if (language.getId() === "css") {
                    cursorPosition = editor.getCursorPos();
                    line = editor.document.getLine(cursorPosition.line);
                    word = parseLine(line, cursorPosition.ch);
                    start = {
                        line: cursorPosition.line,
                        ch: cursorPosition.ch - word.length
                    };
                    if (containsChar(word) && commmand.getChecked()) {
                        clear(word, editor, start, cursorPosition);
                    }
                }
            }
        }
    };
	
	
	
	 var activeEditorChangeHandler = function ($event, focusedEditor, lostEditor) {
        if (lostEditor) {
            $(lostEditor).off("keyEvent", keyEventHandler);
        }
        if (focusedEditor) {
            $(focusedEditor).on("keyEvent", keyEventHandler);
        }
    };
    
    function scSelect() {
        var commmand = CommandManager.get("specialchars.scselect");
        commmand.setChecked(!commmand.getChecked());
    }
	
	function select() {
        var editor = EditorManager.getFocusedEditor();
        editor.document.batchOperation(function () {
            var text;
            var selects = editor.getSelections();
            var selectionsCount = selects.length;
            if (selectionsCount > 1) {
                var text1 = editor.getSelectedText(true).split("\n").split(" ");
                var i;
                for (i = 0; i < selectionsCount; i++) {
                    text = clear(text1[i], editor, selects[i].start, selects[i].end);
                }
            } else {
                text = clear(editor.getSelectedText(true), editor, editor.getSelection().start, editor.getSelection().end);
            }
        });
    }
	
	 AppInit.appReady(function () {
        CommandManager.register("Important CSS", "specialchars.scselect", scSelect);
        var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
        menu.addMenuItem("specialchars.scselect");
        var newCommand = CommandManager.register("Important CSS", "specialchars.scselect2", select);
		 // Tu zmieniamy skrot klawiszowy
        KeyBindingManager.addBinding(newCommand, { "key": "Ctrl-Shift-Z" });
        var currentEditor = EditorManager.getCurrentFullEditor();
        $(currentEditor).on('keyEvent', keyEventHandler);
        $(EditorManager).on('activeEditorChange', activeEditorChangeHandler);
    });
	
});