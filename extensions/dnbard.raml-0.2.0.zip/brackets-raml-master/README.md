# Brackets RAML API Console
[RAML](http://raml.org/) API Console extension for Brackets.


## About
This extension are based on [API Console from Mulesoft](https://github.com/mulesoft/api-console). 

## How to use

- Open RAML file
- Click on *View RAML* indicator in the bottom of the screen:

![View RAML](http://content.screencast.com/users/dnbard/folders/Jing/media/f31730b4-ae0d-420a-8c60-942f7ad4e794/2015-11-01_2021.png)

- View the RAML API Console:

![example](http://content.screencast.com/users/dnbard/folders/Jing/media/4911be9b-7f41-4c67-b4d6-3f2ceedde0fc/2015-11-01_2023.png)