# Brackets-Dilbert

> Author: Brian Christopher Tomlinson <brian.tomlinson@linux.com>


## Description

> A "Daily Dilbert" viewer for the Open Source Brackets IDE developed by Adobe.

> Images are provided via the RSS feed located at [this link](http://rss.latunyi.com/dilbert.rss).


## Screenshots

> See [this page](https://github.com/darthlukan/brackets-dilbert/wiki/Screenshots)


## License

> MIT, see LICENSE file.
