SQF Syntax Highlighting for Brackets
============
Features
 * Syntax highlighting for all keywords used in SQF.
 * Auto complete and suggestions as you type

Todo
============
  * make auto complete more robust.
  * Add an easy way to auto open bohemia wiki for keywords
  * add the wiki contents to the quick doc menu of brackets. (gonna have to scrape alot of web to make that happen)

if you would like to support this open source project a few bucks goes a long way :).
paypal donation link: http://goo.gl/B7aYzx (shortened donation button cause its 3x this line)
