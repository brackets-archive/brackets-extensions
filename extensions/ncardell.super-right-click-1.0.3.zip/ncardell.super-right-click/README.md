------------------------------------------------------------------
Brackets Super Right Click
------------------------------------------------------------------

A Brackets extension that adds cut, copy, paste, delete, undo/redo, save/save all/live preview,
as well as other useful commands to right-click menu. This works on Windows 10!

Written by Nicholas Cardell, based on "Additional Right Click Menu" by Deddy Lasmono Putro.
