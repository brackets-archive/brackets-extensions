# lucee 
lucee is an extension for [Brackets](http://brackets.io/). It is designed to add support for the ColdFusion Markup Language (CFML) and the Lucee language.**Currently code hinting for cfml tags and attributes are working.**

##Usage
**Brackets before Lucee plugin installation**
<img src="https://github.com/DannyCork/images/blob/master/lucee/without.gif">

**Brackets AFTER Lucee plugin installation**
<img src="https://github.com/DannyCork/images/blob/master/lucee/with.gif">

##Forked
This is forked from raeberli's cfbrackets plugin. Forked from http://cfbrackets.org/dl.cfm?dict=railo4

## Install
Install this plugin via the Brackets Extension Manager using the _File > Extension Manager..._ menu item. 

## Compatibility
This extension has been tested and confirmed to work on Brackets versions 1.0 and later. 
