# CHANGELOG Nature to Ciclon

v 0.0.1

* CHANGE
* New animation for Matching Brackets and Tags
* New color palette
* New design for .CodeMirror-foldgutter-folded::after

* CHANGE IN
* .CodeMirror-focused .CodeMirror-activeline .CodeMirror-gutter-elt
* .CodeMirror-activeline-background
* .CodeMirror-selected
* .CodeMirror-linenumber