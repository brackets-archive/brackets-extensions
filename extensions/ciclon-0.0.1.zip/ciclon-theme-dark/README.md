# Ciclon Theme

* Ciclon is one copy of the nature dark theme for Brackets!

# How to install

Visit http://brackets-themes.github.io/ to see the latest install instructions.

# Troubleshooting

1. Things look "weird"
	1. Try hitting F5 (Save changes before doing so!).

# Contributing

* Please see [`CONTRIBUTING.md`](CONTRIBUTING.md) if you would like to help.

# License

* Theme under MIT license [`LICENSE`](LICENSE)

