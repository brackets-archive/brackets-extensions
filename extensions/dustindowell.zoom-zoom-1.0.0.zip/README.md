Zoom Zoom Brackets Extension 1.0.0
=========

Zoom zoom the sidebar 150%.

## Why zoom zoom the sidebar?

I have a 4k monitor and it's nice to have 6 browsers open at the same time, but I'd still like to read the file tree.
