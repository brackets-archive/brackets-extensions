 brackets-schema-preview (WIP)
==============================
Preview your HTML Schema.

To use, select the text in which you want to check the schema.

This extension uses semantic-schema-parser. 
Currently you can show the bottom panel with the schema preview by performing a keyboard shortcut: _Ctrl-Alt-Q_ on Windows or _CMD-Alt-Q_ on Mac. 
You can also open it from _File > Show Schema_

### Feel free to contribute!

### License
MIT-licensed -- see `main.js` for details.
