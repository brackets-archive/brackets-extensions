define(function(require, exports, module) {
	'use strict';
	
	module.exports = require( 'i18n!../nls/Strings' );
	
} );