# codepen-brackets-theme
A theme for Brackets that replicates the default theme on http://codepen.io.

Now with Less!

![Codepen Brackets Theme Screenshot](https://raw.githubusercontent.com/trvswgnr/codepen-brackets-theme/master/screenshot.png "Codepen Brackets Theme Screenshot")
