brackets-db Manager
====================

A brackets extension to querying a database server, now only support SQL server.

Now it's only offer basic functionality, like browse databases, tables, views, show table fields, show table data in a paging table, run query (all text in a document or just a selection of it).

How to connect to a database
====================
Add connection first
input your connection information into the specified fields and save it.
Then choose your connetion in connection list, and click connect.

To run a query, please select the database first and then run your query.


It is actually a modified of https://github.com/Azakur4/brackets-database because I need some functionality that's not available on it, then I have some idea to develop it to something more than just a modified version of Azakur4's plugin.

To do
====================
- [x] Show list of view
- [ ] Show and edit view
- [ ] Show list of function
- [ ] Show and edit function
- [ ] Show table trigger
- [ ] Edit table fields
- [ ] Edit table data
- [ ] Add mysql support
- [ ] Add postgresql support

PLease report/info me about bug, issue and idea, so I can fix and improve this addon, thanks.