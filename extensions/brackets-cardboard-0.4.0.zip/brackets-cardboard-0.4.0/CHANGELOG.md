# 0.3.0
- Add initial error handling and messages
- Focus on search box when cardboard is opened
- Add SEARCH_URL to managers
- Add install package by URI from search box

# 0.2.0
- Add npm manager
- Add [documentation](http://khornberg.github.io/brackets-cardboard)

# 0.1.0
- Add bower manager
- Removed show installed button temporarily