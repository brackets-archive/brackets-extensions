define(function (require, exports, module) {
	"use strict";
	
	var ExtensionUtils = brackets.getModule("utils/ExtensionUtils");
	
	ExtensionUtils.loadStyleSheet(module, "main.css");
});