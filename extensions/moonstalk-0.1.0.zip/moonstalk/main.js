define(function (require, exports, module) {
    "use strict";
    
    var LanguageManager = brackets.getModule("language/LanguageManager"),
        CodeMirror      = brackets.getModule("thirdparty/CodeMirror2/lib/codemirror"),
		//lua 			= LanguageManager.getLanguage("lua");

	// enable lua <? code blocks ?>
	CodeMirror.defineMode("moonstalk", function(config) {
	  return CodeMirror.multiplexingMode(
	    CodeMirror.getMode(config, "text/html"),
	    {open: "<?", close: "?>",
	     mode: CodeMirror.getMode(config, "lua"),
	     delimStyle: "delimit"}
	  );
	});

	LanguageManager.defineLanguage("moonstalk", {
	    name: "Moonstalk HTML",
	    mode: "moonstalk",
	    // we don't specify fileExtensions with html extension here as it could be shared, instead we can add it to a project-specific .brackets.json: { "language.fileExtensions":{"html":"moonstalk"} }
	    // in future we could associate our own dedicated extension e.g. .mhtml
	});

	// TDOD: enable ?(macros)
	//CodeMirror.defineMode("moonstalk", function(config, parserConfig) {
	//  var moonstalkOverlay = {
	//    token: function(stream, state) {
	//      var ch,;
	//      if (stream.match("?(")) {
	//        while ((ch = stream.next()) != null)
	//        	if (ch=="(") {count=count+1}
	//          if (ch == "}" && stream.next() == "}") {
	//            stream.eat("}");
	//            return "lua";
	//          }
	//      }
	//      while (stream.next() != null && !stream.match("{{", false)) {}
	//      return null;
	//    }
	//  };
	//  return CodeMirror.overlayMode(CodeMirror.getMode(config, parserConfig.backdrop || "text/html"), moonstalkOverlay);
	//});

});

