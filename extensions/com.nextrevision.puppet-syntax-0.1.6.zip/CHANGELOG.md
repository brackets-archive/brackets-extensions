## 2014-12-09 Release 0.1.6
### Summary

Fix deprecation warning for CodeMirror

## 2014-12-09 Release 0.1.5
### Summary

Bug Fixes

####Bugfixes

- Fix Issue #2 where adding a capital letter would cause an endless loop,
  effectively breaking the syntax highlighting

## 2014-07-13 Release 0.1.3
###Summary

Bug fixes in regex highlighting

####Bugfixes

- Fixed a bug in regex matching where any '/' following a valid match would be
  included incorrectly, breaking syntax highlighting.

