# Puppet syntax highlighting for Brackets

This is an extension to the code editor [Brackets][1], and adds syntax highlighting for Puppet manifests with the extension `.pp`.

## Install from URL

1. Open the the Extension Manager from the File menu.
2. Search for `puppet` and press install.

  [1]: http://brackets.io/ "Brackets — Open source code editor built with the web for the web"
