# flotsam
A brackets theme for otters.

## HTML
![HTML Screenshot](flotsam-html.png)

## CSS
![CSS Screenshot](flotsam-css.png)

## Copyright and License
Copyright (c) 2015 [Otterpus]. Released under the [MIT License].