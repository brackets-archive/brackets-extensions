[Brackets](http://brackets.io) - PHPLinter
============================

PHLinter is an extension for Brackets.

It works using the 'php -l' command, that's why 'php' is required to be in system path

Licence: MIT
