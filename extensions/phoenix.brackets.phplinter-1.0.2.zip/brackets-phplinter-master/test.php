<?php

function test() {
    echo "Hello World!!!";
}

?>