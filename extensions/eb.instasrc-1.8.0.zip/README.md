Instasrc-for-brackets
=================

Add a instasrc.com icon in Brackets, this allows for a random 'instagram' image tag to be generated and inserted into the editor.

Credit: http://instasrc.com