# brackets_zw
Increase / Decrease Font Size with the Mouse Wheel for Brackets

- Increase font size (Ctrl + Mouse Wheel Up)
- Decrease font size (Ctrl + Mouse Wheel Down)

PS 
tested on Windows not Mac
