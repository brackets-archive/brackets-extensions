Obsidian Theme by cforf
=======================

Elegant and easy for reading theme.This theme is based on Obsidian theme for Flash Develop (by Sebastien Benard, deepnight.net) & Delkos Dark Theme.

HTML
![screenshot](https://raw.githubusercontent.com/cforf/obsidiantheme_brackets/master/html.png)

CSS
![screenshot](https://raw.githubusercontent.com/cforf/obsidiantheme_brackets/master/css.png)

JS
![screenshot](https://raw.githubusercontent.com/cforf/obsidiantheme_brackets/master/js.png)

Install

1. Open Brackets.

2. Open the Extension Manager.

3. Switch to Themes tab.

4. Search for Obsidian Theme.

5. Click Install.

6. View -> Themes... -> Obsidian Theme.