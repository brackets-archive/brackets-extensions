Star Platinum Light Theme for Brackets
======================================

Inspired by the Stand of Jotaro Kujo; ORAORAORA. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/StarPlatinumLight/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/StarPlatinumLight/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/StarPlatinumLight/blob/master/screenshots/js.png)
