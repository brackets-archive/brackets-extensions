# Neon Sign theme for Brackets
Lights up your code as a neon sign.

## JS
![JS Screenshot](https://github.com/remonbonbon/brackets-theme-neon/blob/master/screenshots/js.png)

## HTML
![HTML Screenshot](https://github.com/remonbonbon/brackets-theme-neon/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/remonbonbon/brackets-theme-neon/blob/master/screenshots/css.png)
