Blueprint
=========

A simple Brackets theme to make coding easier with emphasis in color blue.
# HTML
![HTML Screenshot](https://github.com/600F1/simple-blue-theme/blob/master/screenshots/html.png)

# CSS
![CSS Screenshot](https://github.com/600F1/simple-blue-theme/blob/master/screenshots/css.png)

# JS
![JS Screenshot](https://github.com/600F1/simple-blue-theme/blob/master/screenshots/js.png)
