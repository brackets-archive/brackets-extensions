'use strict';

define(function (require, exports, module) {
    module.exports = {
        root: true,
        'de': true,
        'ru': true
    };

});
