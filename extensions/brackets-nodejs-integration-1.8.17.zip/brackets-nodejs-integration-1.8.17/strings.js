'use strict';

define(function (require, exports, module) {
    module.exports = require('i18n!nls/strings');
});
