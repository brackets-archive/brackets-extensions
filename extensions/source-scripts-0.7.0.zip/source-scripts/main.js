/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, document, brackets, Mustache */

define(function (require, exports, module) {
    "use strict";

	// 
    var NodeDomain         = brackets.getModule("utils/NodeDomain"),
        ExtensionUtils 	   = brackets.getModule("utils/ExtensionUtils"),
        CommandManager     = brackets.getModule("command/CommandManager"),
        Commands           = brackets.getModule("command/Commands"),
        Menus              = brackets.getModule("command/Menus"),
        Dialogs            = brackets.getModule("widgets/Dialogs"),
		DocumentManager    = brackets.getModule("document/DocumentManager"),
        PreferencesManager = brackets.getModule("preferences/PreferencesManager"),
        prefs              = PreferencesManager.getExtensionPrefs("scourcescripts"),
		COMMAND_ID         = "sourcescripts.open",
        DIALOG_ID          = "sourcescripts.pref",
		GRAMMARS_ID        = "sourcescripts.grammar_file",
		scrp               = prefs.get("script"),
		PanelTemplate      = require("text!panel.html"),
		FileUtils          = brackets.getModule("file/FileUtils"),
		grammar_file       = FileUtils.getNativeModuleDirectoryPath(module) + "/grammar.json";

	var builder = new NodeDomain("runScript", ExtensionUtils.getModulePath(module, "builder"));
    var builders = JSON.parse(require('text!grammar.json'));

    /* var hasPref = function () {
        if (!scrp) {
            setScript();
        }
    };
    var setPreferences = function () {
        var script = $('#scriptToRun').val();

        prefs.set("script", script);
        prefs.save();
        CommandManager.execute(Commands.APP_RELOAD);
    };
    var setScript = function () {
        var localizedTemplate = Mustache.render(PanelTemplate);
        Dialogs.showModalDialogUsingTemplate(localizedTemplate);
        if (prefs.get('script')) {
            $('#scriptToRun').val(scrp);
        }

        $('#submitScriptToRun').on('click', setPreferences);
    }; */
	
	var dPath, dFile, dLang, dName, dRawName, cmd;
	
    var runCmd = function () {
        CommandManager.execute("file.saveAll")
		
		dPath  = DocumentManager.getCurrentDocument().file._parentPath;
        dFile = DocumentManager.getCurrentDocument().file._path;
        dLang = DocumentManager.getCurrentDocument().language._name;
		dName = DocumentManager.getCurrentDocument().file._path.replace(dPath, "");
		dRawName = dName.replace(".java", "").replace(".py", "").replace(".js", "").replace(".rb", "");
		
		builders.forEach(function (el) {
            if (el.name.toLowerCase() === dLang.toLowerCase())
                cmd = el.cmd;
        });
			
		if(cmd == null) {
			console.error("Script not found");
			alert("Script not found");
			return true;
		}
        cmd = cmd.replace(/\$FILE/g, "\"" + dFile + "\"");
		cmd = cmd.replace(/\$NAME/g, "\"" + dName + "\"");
		cmd = cmd.replace(/\$RAW/g, "\"" + dRawName + "\"");
		builder.exec("runCMD", dPath, dFile, cmd)
		.done(function () {
			console.log("Running " + dLang + " with file " + dFile);
        })
        .fail(function (err) {
			console.error("Error while building " + dLang + ", error: " + err);
			alert("Error while building cmd. See console for more information.")
        });

    };

	// Registering Extension
	
	var openGrammarFile = function() {
	    Dialogs.showModalDialog('', 'Source Scripts', 'You must restart Brackets after changing this file.');
        DocumentManager.getDocumentForPath(grammar_file).done(
			function (doc) {
                DocumentManager.setCurrentDocument(doc);
			}
        );
	}
	
	CommandManager.register("Edit Grammar File", GRAMMARS_ID, openGrammarFile);
	
    CommandManager.register("Run script", COMMAND_ID, runCmd);
    //CommandManager.register("Set script", DIALOG_ID, setScript);

    var menu1 = Menus.getContextMenu(Menus.ContextMenuIds.PROJECT_MENU);
    menu1.addMenuItem(COMMAND_ID);
    var menu2 = Menus.getContextMenu(Menus.ContextMenuIds.WORKING_SET_CONTEXT_MENU);
    menu2.addMenuItem(COMMAND_ID);

    var menu3 = Menus.getMenu(Menus.AppMenuBar.VIEW_MENU);
    menu3.addMenuDivider();
    //menu3.addMenuItem(DIALOG_ID);
	menu3.addMenuItem(COMMAND_ID, "Ctrl-F5")
	menu3.addMenuItem(GRAMMARS_ID)

    // Creating Extension Icon
    ExtensionUtils.loadStyleSheet(module, "styles.css");
    $(document.createElement("a"))
        .attr("id", "run-script")
        .attr("href", "#")
        .attr("title", "Run Script")
        .on("click", runCmd)
        .appendTo($("#main-toolbar .buttons"));

});
