/*global require, exports*/

(function () {
    "use strict";

    var process = require("child_process"),
        exec = process.exec,
        spawn = process.spawn;

    function runScript(dir, file, command) {
		var cmd = "start \"Brackets Build\" /D \"" + dir + "\" \"cmd /k " + command + " && PAUSE && exit \"";
		exec(cmd);
        return true;
    }

	exports.init = function (DomainManager) {
		var paramsArray = [
				{
					name: "dir",
					type: "string"
				},
				{
					name: "file",
					type: "string"
				},
				{
					name: "command",
					type: "string"
				}
			];
		
		if (!DomainManager.hasDomain("runScript")) {
			DomainManager.registerDomain("runScript", {
				major: 0,
				minor: 1
			});
		}	
		DomainManager.registerCommand("runScript", "runCMD", runScript, false, "Starts linux, mac or windows terminal", paramsArray, []);
		console.log("Domain Loaded");
    };

}());
