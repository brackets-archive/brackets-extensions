Source Scripts
================
Use this extension to run different types of scripts. Currently supports: Java, JavaScript, CoffeeScript, Python, PHP, Perl and Ruby.

Github: https://github.com/SaiintBrisson/source-scripts

**Notes:** Only works with Windows.

**How to use:**
* Use the left Code icon or use 'CTRL+F5'.
* To change grammars go: View > Edit Grammar File

**Todo:**
* Add Linux/Mac support.
* Add step-by-step debugging support.
* Add outliner
* Add linter
