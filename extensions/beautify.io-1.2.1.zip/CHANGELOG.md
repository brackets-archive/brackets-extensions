# Change Log

## 1.2.0 - 2015-08-11
### Changed

Updated js-beautify to version 1.5.10
