Novo HTML ou CSS

Basta selecionar

Template>Novo HTML

ou

Template>Novo CSS
