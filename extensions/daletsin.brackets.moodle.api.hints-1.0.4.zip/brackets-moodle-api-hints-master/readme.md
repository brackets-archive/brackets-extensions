Extension para el editor adobe Brackets, permite el autocompletado de funciones de moodle

instalación y modo de uso

http://www.youtube.com/watch?v=obiPm17qvEs