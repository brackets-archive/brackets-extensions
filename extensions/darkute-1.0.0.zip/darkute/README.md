# Darkute

A dark theme (for Brackets) with pink/purple shades