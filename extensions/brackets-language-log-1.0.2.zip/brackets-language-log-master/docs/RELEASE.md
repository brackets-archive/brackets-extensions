#Brackets language log

###Release history

##1.0.2
``2016-12-12``
- apache code success 200/300, error 400/500
- emails
- caracters into <>
- update screenshot

##1.0.1
``2016-12-07``
- fix typing error
- had synthax highlighting ``char into suqare brace`` (alternative regexp date)
- update screenshot

##1.0.0
``2016-12-05``
- Initial commit
