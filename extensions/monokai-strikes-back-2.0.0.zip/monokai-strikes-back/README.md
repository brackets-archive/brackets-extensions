# Monokai-Strikes-Back
This is a Brackets theme which is a fork of [Monokai Darkness Reborn](https://github.com/anandisrocking007/Monokai-Darkness-Reborn) by Anand Arokianathan. It is made mainly with HTML / CSS / JS / PHP in mind.

Installation
---

This extension requires Brackets 1.3 or newer.

1. Open Brackets
2. Open the Extension Manager
3. Click on the Themes tab
4. Search for ‘Monokai Strikes Back’
5. Click on the Install button

License
---

The MIT License. Read [LICENSE](LICENSE) for further information.
