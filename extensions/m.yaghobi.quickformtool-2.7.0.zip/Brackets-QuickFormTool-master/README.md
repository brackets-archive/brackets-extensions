# QuickFormTool # ver 2.7

An extension for Adobe Brackets to insert form elements into editor quickly.<br>
This extension now available for download.<br>
![Alt text](/screenshot/shot1.png?raw=true "ScreenShot")

## Installation ##

A:
<br>

1. Run Brackets.<br>
2. Select _File > Extension Manager_<br>
3. Enter `quickformtool` as _SearchBox_.<br>
4. Click on _Install_ to begin downloading and installing the extension.<br>
<br>
<b>OR</b>

B:
<br>

1. Run Brackets.<br>
2. Select _File > Install Manager_<br>
3. Click on _Install from URL..._.
4. Enter `https://github.com/pgrammer/Brackets-QuickFormTool` as _Extension URL_.<br>
5. Click on _Install_ to begin downloading and installing the extension.<br>
<br>
<b>OR</b>

C:
<br>

1. Click on `Download ZIP`.<br>
2. Run Brackets.<br>
3. Select _Help > Show Extension Folder_ then go to _/user_ folder<br>
4. Now extract downloaded file there.
