define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("erlang", {"name":"Erlang","mode":"erlang","fileExtensions":["erl","escript"],"lineComment":["%%"]});
});