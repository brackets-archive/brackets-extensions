Neon Brackets Theme - 1.1.8
=========

A cool, bright and sleek theme.

Check out my new theme [Neon Morning!](https://github.com/dustindowell22/neon-morning-brackets-theme) It's like Neon, but more upbeat and happy.

## HTML
![HTML](https://github.com/dustindowell22/neon-brackets-theme/blob/master/preview/neon-html.png)

## CSS
![CSS](https://github.com/dustindowell22/neon-brackets-theme/blob/master/preview/neon-css.png)

## JavaScript
![JavaScript](https://github.com/dustindowell22/neon-brackets-theme/blob/master/preview/neon-js.png)

## Themed Extensions
+ [Code Folding by thehogfather](https://github.com/thehogfather/brackets-code-folding) (Now integrated into Brackets)
+ [CSS Color Preview by cmgddd](https://github.com/cmgddd/Brackets-css-color-preview)
