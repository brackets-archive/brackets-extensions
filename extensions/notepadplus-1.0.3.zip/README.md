Notepad++ theme for Brackets 
==========================

How to Install
==============
Go to Last Edit is an extension for [Brackets](https://github.com/adobe/brackets/), a new open-source code editor for the web.

To install extensions:

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for this extension
3. Click _Install_!

### HTML
![HTML Screenshot](https://github.com/EssamManzilak/NotepadPlusThemeForBrackets/blob/master/screenshot.png)

 
### Compatibility
Brackets Sprint 16 or newer (or Adobe Edge Code Preview 2 or newer).

#Changelog

### 1.0.3
- Bug fixing.

