# Go-Highlighter
Go language highligter for adobe brackets.io

Some languages are not included in brackets.io
you can use extensions to add them, it is very
easy as long as they are supported by CodeMirror.
List of the languages can be found here:
http://codemirror.net/mode/index.html

The link below provides information on language
support in brackets.io
https://github.com/adobe/brackets/wiki/Language-Support#defining-a-new-language

Here you cand find information about writing extensions
for brackets.io
https://github.com/adobe/brackets/wiki/How-to-write-extensions