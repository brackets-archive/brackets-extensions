The Hamptons Theme for Brackets
========================

Inspired by coconuts, this theme helps you relax. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/TheHamptons/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/TheHamptons/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/TheHamptons/blob/master/screenshots/js.png)
