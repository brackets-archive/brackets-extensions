HTMLEscaper Extension
=================

This extension simply provides a web-safe version of the current document. I use it
for blog entries.

History
=======
10/8/2014: Fixes for new layout stuff
10/2/2013: Merged in updates by Jason Dean (improvements to escape tool and unit tests)
10/1/2013: Genesis

