Brackets-MaterialAngularJS-CodeHints
============================

Extend Brackets HTML code hints and [collif](https://github.com/coliff)'s [Brackets-HTML5CodeHints](https://github.com/coliff/Brackets-HTML5CodeHints) with AngularJS elements like ng-include, ng-view and attributes such as ng-class, ng-controller, ng-app.

Extended code from the guys above with MaterialDesign Elements and Attributes - see: https://material.angularjs.org

Feel free to fork this repo and add more attributes, Create Pull Requests or Issues on this Repo

Thanks [collif](https://github.com/coliff) for inspiration