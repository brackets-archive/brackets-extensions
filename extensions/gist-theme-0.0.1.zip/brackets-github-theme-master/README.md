Brackets Github Theme
=====================
Light Github-like theme for [Brackets](http://brackets.io) editor. 

Forked from georapbox and tweaked to my liking. Screenshots are currently from the original. Once i'm all set with the tweaks i'll update.

### HTML
![HTML Screenshot](https://github.com/georapbox/brackets-github-theme/blob/master/screenshots/html.png)

### CSS
![HTML Screenshot](https://github.com/georapbox/brackets-github-theme/blob/master/screenshots/css.png)

### Javascript
![HTML Screenshot](https://github.com/georapbox/brackets-github-theme/blob/master/screenshots/javascript.png)
