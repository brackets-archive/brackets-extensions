# brackets-factor
[Factor](http://factorcode.org/) language highlight mode for [Brackets](http://brackets.io/)
