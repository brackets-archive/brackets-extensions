Neon Morning Brackets Theme - 1.1.0
=========

Like [Neon](https://github.com/dustindowell22/neon-brackets-theme), but more upbeat and happy.

## CSS
![CSS](https://github.com/dustindowell22/neon-morning-brackets-theme/blob/master/preview/css.png)

## Themed Extensions
+ [Code Folding by thehogfather](https://github.com/thehogfather/brackets-code-folding) (Now integrated into Brackets)
+ [CSS Color Preview by cmgddd](https://github.com/cmgddd/Brackets-css-color-preview)
