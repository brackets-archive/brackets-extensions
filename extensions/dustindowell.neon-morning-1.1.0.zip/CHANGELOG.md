Changelog
=========

**September 20, 2015**
+ 1.1.0
  + Redid all the colors but the feel remains the same

**June 18, 2015**
+ 1.0.1
  + Changed the background color slightly

+ 1.0.0
  + Committed Project
