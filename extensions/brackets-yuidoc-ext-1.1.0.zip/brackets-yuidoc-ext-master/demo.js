/**
* Description for init
* @private
* @method init
* @param {Object} params
* @return {Object} description
*/
function init(params) {

}









/**
* Description for init 
* @private
* @method init 
* @param {Object} params
* @return {Object} description
*/
init = function (params) {

}
















/**
* Description for init 
* @private
* @method init 
* @param {Object} params
* @return {Object} description
*/
this.init = function (params) {

}














/**
* Description for init
* @private
* @method init
* @param {Object} params
* @return {Object} description
*/
this.init: function (params) {

}














