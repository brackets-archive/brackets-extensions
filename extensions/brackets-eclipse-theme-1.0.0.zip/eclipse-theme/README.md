
# Eclipse theme

This is a effort to port the Eclipse's theme to Brackets

https://github.com/floatinghotpot/brackets-eclipse-theme

