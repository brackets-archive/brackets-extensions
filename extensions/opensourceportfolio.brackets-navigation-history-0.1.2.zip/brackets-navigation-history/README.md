brackets-navigation-history
===========================================

4/30/2014
Changed shortcut to be ctrl-alt instead of ctrl-shift

This extension adds the ability to ctrl-alt-right and
ctrl-alt-left to navigate back and forward in your 
source code. It remember the last 100 points which were
visited in each document.
