# brackets-epochhelper

Shows the value of any selected UNIX epoch timestamp (in micro, milli or whole seconds, hex or decimal) as an ISO datetime in the status bar.

Mad props to the awesome website [epochconverter.com](https://www.epochconverter.com/), where a decent chunk of the code in this extension is from.

![epochhelper in action](https://i.imgur.com/IEmPjna.gif "epochhelper in action")
