brackets-ant
============

A Brackets Extension to launch ant builds

![Screenshot](https://raw.github.com/jbalsas/brackets-ant/master/assets/screenshot.png)