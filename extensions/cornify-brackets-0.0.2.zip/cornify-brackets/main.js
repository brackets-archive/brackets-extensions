/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window, Mustache */

define(function (require, exports, module) {
    "use strict";

    var AppInit = brackets.getModule('utils/AppInit'),
        CommandManager = brackets.getModule("command/CommandManager"),
        Menus  = brackets.getModule("command/Menus"),
        CORNIFY_CMD_ID = "artoale.cornify";


    var cornify = require('lib/cornify');


    AppInit.appReady(function () {
        var helpMenu = Menus.getMenu(Menus.AppMenuBar.HELP_MENU);

        CommandManager.register("Gimme some love", CORNIFY_CMD_ID, cornify.add.bind(cornify));
        helpMenu.addMenuItem(CORNIFY_CMD_ID);
    });
});

