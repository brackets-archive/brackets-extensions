Brackets extension to show the git branch next to the project name

Release notes:<br>
- 1.0.7 - work around for a brackets issue where "manually" created files are not picked up by file watchers.
- 1.0.6 - switch to new FileSystem API
- 1.0.5 - do not fix width for dropdown
- 1.0.4 - better title for extension registry
- 1.0.3 - fix layout issue
- 1.0.2 - do not just clip long project title but use ellipsis instead
- 1.0.1 - enabled refresh on app focus. You can go to the terminal and change the branch. When you go back to Brackets / EC the branch name will reflect the change.
<br>
