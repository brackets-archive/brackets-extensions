Sidebar Reloaded Brackets Extension - 1.0.0
=========

This extension doesn't change much. This mostly serves as a base for future modifications.

Biggest changes:
+ Font size from 13px to 14px
+ Larger project files button
+ Replaced arrow sprite sheet with unicode arrow
+ Animated arrow rotation
+ Everything is, more or less, on a grid


## Before After Preview
![Before After Preview](https://github.com/dustindowell22/sidebar-reloaded-brackets-extension/blob/master/before-after-preview.gif)

## Arrow Rotation
![Arrow Rotation](https://github.com/dustindowell22/sidebar-reloaded-brackets-extension/blob/master/arrow-rotation-preview.gif)
