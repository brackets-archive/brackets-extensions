brackets-preferences-viewer
===========================

Brackets Extension to View Local Storage in bottom panel.
This was formerly called the "Preferences" Viewer, but Brackets preferences are now stored in JSON files.

## Overview

This is an Extension for [Brackets](https://github.com/adobe/brackets). 

## Features

This extension is accessed using: View > Show Local Storage Viewer

Click on the key of any [Object] to expand it.

Use breadcrumbs at top to get back to any parent.

## License

MIT-licensed -- see _main.js_ for details.
