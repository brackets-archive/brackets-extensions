brackets-oncopy
===============

[![Build Status](https://travis-ci.org/timoweiss/brackets-oncopy.svg?branch=master)](https://travis-ci.org/timoweiss/brackets-oncopy)

*brackets-oncopy* is a small, lightweight extension for Adobe Brackets.
It shows you a little message about the amount of characters you copied to the clipboard.

Thats it.
