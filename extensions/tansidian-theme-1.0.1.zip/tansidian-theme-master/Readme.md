# Tansidian color theme for Brackets
Inspired by Tango and Obsidian color themes.

![screenshot.png](screenshot.png)
