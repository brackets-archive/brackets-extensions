# Greentown
theme for Brackets. Greentown like a Duotone.
# Screenshot
<img src="https://raw.githubusercontent.com/vvaka1122/greentown/master/greentown-screenshot.jpg">
