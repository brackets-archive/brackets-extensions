Brackets togist extension
===

A simple brackets extension to easily create a Github Gist from the current text selection. To install, place the ```togist``` folder inside the ```brackets/src/extensions/user``` folder, and reload Brackets.

This extenstion was primarily created to learn how to create an extension for Brackets. As such, it is very experimental and should be used with caution -  even though it will most likely not harm your code.

**Compatible with Brackets Sprint10**

Usage
=====
Select some text, and then select "Create Gist" from the Edit menu.
An alert window should shortly appear with the Gist URL. Closing the alert will open the gist page in a new window.

Known issues
=====
No description can be given to the gist, nor can the file name be renamed.
Also, the gist page opens in a new Brackets window rather than in a browser window.