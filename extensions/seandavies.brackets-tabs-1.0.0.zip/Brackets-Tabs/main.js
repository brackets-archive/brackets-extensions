/*
 * Copyright (c) 2013 Sean Davies - http://seans.co
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, brackets, window, $, document */

var KeyBindingManager   = brackets.getModule("command/KeyBindingManager"),
    CommandManager      = brackets.getModule("command/CommandManager"),
    Commands            = brackets.getModule("command/Commands"),
    Menus               = brackets.getModule("command/Menus"),
    FileViewController  = brackets.getModule("project/FileViewController"),
    SidebarView         = brackets.getModule("project/SidebarView"),
    DocumentManager     = brackets.getModule("document/DocumentManager"),
    EditorManager       = brackets.getModule("editor/EditorManager"),
    ViewUtils           = brackets.getModule("utils/ViewUtils"),
    Resizer             = brackets.getModule("utils/Resizer"),
    Strings             = brackets.getModule("strings");

define(function (require, exports, module) {
    
    "use strict";
    
    
    var link = require.toUrl("tabs.less");
    var style = document.createElement("link");
    style.type = "stylesheet/less";
    style.rel = "stylesheet";
    style.href = link;
    document.querySelector("head").appendChild(style);
	
	 var elem = document.getElementById('working-set-header');
    elem.parentNode.removeChild(elem);
    return false;

    
});