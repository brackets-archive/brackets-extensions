define({
  // Generic.
  OK: 'Сохранить',
  CANCEL: 'Отмена',
  RESET: 'Сбросить',

  // Menu.
  MENU_ON_SAVE: 'Добавлять префиксы при сохранении файла',
  MENU_ON_CHANGE: 'Добавлять префиксы при изменении файла',
  MENU_SELECTION: 'Добавить префикс для выделенного фрагмента',
  MENU_SETTINGS: 'Настроить Autoprefixer...',

  // Settings dialog.
  SETTINGS_TITLE: 'Параметры Autoprefixer',
  SETTINGS_VISUAL_CASCADE: 'Каскадные отступы',
  SETTINGS_BROWSERS: 'Браузеры'
});
