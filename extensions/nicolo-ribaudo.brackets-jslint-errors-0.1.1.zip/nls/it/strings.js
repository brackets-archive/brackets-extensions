define({
    NOT_FOUND_TITLE: "Spiegazione non trovata",
    NOT_FOUND_ERROR: "La spiegazione dell'errore <code>{0}</code> non è stata trovata su <a href='http://jslinterrors.com'>jslinterrors.com</a>.<br/>" +
        "Se invece riesci a trovarla manualmente, perfavore <a href='https://github.com/nicolo-ribaudo/brackets-jslint-erors/issues/new'>segnalalo</a> su GitHub.",
    WRITTEN_BY: "Scritto da {0}"
});