define({
    NOT_FOUND_TITLE: "Explanation not found",
    NOT_FOUND_ERROR: "The error <code>{0}</code> hasn't be found on <a href='http://jslinterrors.com'>jslinterrors.com</a>.<br/>" +
        "If you can found it manually, please <a href='https://github.com/nicolo-ribaudo/brackets-jslint-erors/issues/new'>report an issue</a> on GitHub.",
    WRITTEN_BY: "Written by {0}"
});