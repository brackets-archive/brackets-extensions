# Change Log
All notable changes to this project will be documented in this file.

## Unreleased
### Added
- Explanations are cached to reduce the number of requests.

## 0.1.0 - 2015-03-10
### Added
- Support for JSLint, JSHint and ESLint.