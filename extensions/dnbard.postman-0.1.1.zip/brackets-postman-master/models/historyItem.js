define(function(require, exports, module){
    module.exports = {
        create: function(options){
            return options;
        }
    };
});
