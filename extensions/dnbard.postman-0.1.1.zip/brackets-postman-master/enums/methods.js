define(function(require, exports, module){
    module.exports = [ 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'COPY', 'HEAD', 'OPTIONS', 'PURGE' ];
});
