Golang Syntax Highlighting for Brackets
=======================================

Golang Syntax Higlightng

How to Install
==============

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for this extension
3. Click _Install_!


Todo
====

- Auto Completion
- Golang Integration 
    - Test
    - Build
    - etc
    
### License
MIT-licensed -- see `LICENSE` for details.