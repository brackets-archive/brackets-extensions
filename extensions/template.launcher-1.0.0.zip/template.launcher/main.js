define(function (require, exports, module) {
    "use strict";

    var CommandManager = brackets.getModule("command/CommandManager"),
        EditorManager = brackets.getModule("editor/EditorManager"),
        Menus = brackets.getModule("command/Menus");

    function loadHTMLTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var temphtml = '<!DOCTYPE html>\n<html>\n\t<head>\n\t\t<meta charset="utf-8">\n\t\t<meta description="">\n\t\t<meta keywords="">\n\t\t<title>Your title here</title>\n\t</head>\n\t<body>\n\t\t\n\t</body>\n</html>';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(temphtml, insertionPos);
        }
    }

    function loadCSSTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var tempcss = 'h1 {\n\t\n}\n\np {\n\t\n}\n\na {\n\t\n}\n\n.header {\n\t\n}\n\n.footer {\n\t\n}\n\nhr {\n\t\n}\n\nbutton {\n\t\n}\n\nimg {\n\t\n}\n\n';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(tempcss, insertionPos);
        }
    }

    function loadJSFunctionTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var tempjsf = 'function name() {\n\tconsole.log("Hello, world!");\n}\n\n';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(tempjsf, insertionPos)
        }
    }

    function loadJSDiscordTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var tempjsd = 'const Discord = require(\'discord.js\');\nconst client = new Discord.Client();\nconst config = require(\'config.json\'); // Optionnal\n\nconst prefix = config.prefix; // Or your prefix\nconst token = config.token; // Or your token\n\nclient.on(\'ready\', () => {\n\t\n});\n\nclient.on(\'guildMemberAdd\', member => {\n\t\n});\n\nclient.on(\'guildMemberRemove\', member => {\n\t\n});\n\nclient.on(\'message\', message => {\n\t\n});\n\nclient.login(token);';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(tempjsd, insertionPos)
        }
    }

    function loadJSONDiscordTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var tempjsond = '{\n\t"prefix": "", // Your prefix \n\t"token": "" // Your token\n}';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(tempjsond, insertionPos)
        }
    }

    function loadPythonConfigTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var temppyc = '#coding:utf-8\n\nfrom random import *\nfrom tkinter import *\nimport time\nimport pickle\nimport cgi\nimport webbrowser\nimport tkinter.messagebox\nimport sys\nimport os';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(temppyc, insertionPos)
        }
    }

    function loadPythonWindowTkinterTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var temppywt = 'def window():\n\n\twindow = Tk()\n\n\twindow.title("")\n\twindow.geometry("")\n\twindow.minsize()\n\twindow.maxsize()\n\twindow.iconbitmap("")\n\twindow.config(background="")\n\n\twindow.mainloop()\n\n';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(temppywt, insertionPos)
        }
    }
    
    function loadPugHTMLTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var temppughtml = 'doctype html\nhtml\n\thead\n\t\tmeta (charset="utf-8")\n\t\tmeta (keywords="")\n\t\tmeta (description="")\n\t\ttitle Your title here\n\tbody\n\t\t\n';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(temppughtml, insertionPos)
        }
    }
    
    function loadJSExtensionTemplate() {
        var editor = EditorManager.getFocusedEditor();
        if (editor) {

            var tempjsext = 'define(function(require, exports, module) {\n\t"use strict";\n\n\tvar CommandManager = brackets.getModule("command/CommandManager"),\n\t\tEditorManager = brackets.getModule("editor/EditorManager"),\n\t\tAppInit = brackets.getModule("utils/AppInit"),\n\t\tDocumentManager = brackets.getModule("document/DocumentManager"),\n\t\tExtensionUtils = brackets.getModule("utils/ExtensionUtils"),\n\t\tFileSystem = brackets.getModule("filesystem/FileSystem"),\n\t\tFileUtils = brackets.getModule("file/FileUtils"),\n\t\tDialogs = brackets.getModule("widgets/Dialogs"),\n\t\tDefaultDialogs = brackets.getModule("widgets/DefaultDialogs"),\n\t\tMenus = brackets.getModule("command/Menus");\n\n\tAppInit.appReady(function(){\n\t\tconsole.log("Hello, world!")\n\t});\n\n});';

            var insertionPos = editor.getCursorPos();
            editor.document.replaceRange(tempjsext, insertionPos)
        }
    }
    
    function aboutTheEXT() {
        
    }
    

    var COMMAND1_ID = "template.writehtml";
    CommandManager.register("Load HTML template", COMMAND1_ID, loadHTMLTemplate);
    var COMMAND2_ID = "template.writecss";
    CommandManager.register("Load CSS template", COMMAND2_ID, loadCSSTemplate);
    var COMMAND3_ID = "template.writejsfunction";
    CommandManager.register("Load JS template [Function]", COMMAND3_ID, loadJSFunctionTemplate);
    var COMMAND4_ID = "template.writejsdiscord";
    CommandManager.register("Load JS template [Discord]", COMMAND4_ID, loadJSDiscordTemplate);
    var COMMAND5_ID = "template.writejsondiscord";
    CommandManager.register("Load JSON template [Discord]", COMMAND5_ID, loadJSONDiscordTemplate);
    var COMMAND6_ID = "template.writepythonconfig";
    CommandManager.register("Load Python template [Config]", COMMAND6_ID, loadPythonConfigTemplate);
    var COMMAND7_ID = "template.writepythonwindowtkinter";
    CommandManager.register("Load Python template [Tkinter Window]", COMMAND7_ID, loadPythonWindowTkinterTemplate);
    var COMMAND8_ID = "template.writepughtml";
    CommandManager.register("Load HTML template [Pug]", COMMAND8_ID, loadPugHTMLTemplate);
    var COMMAND9_ID = "template.writejs";
    CommandManager.register("Load JS template [Brackets Extension]", COMMAND9_ID, loadJSExtensionTemplate);
    var COMMAND10_ID = "template.about";
    CommandManager.register("About the extension", COMMAND10_ID, aboutTheEXT);

    Menus.addMenu('Templates', 'hytemplatesw.main');
    var menu = Menus.getMenu('hytemplatesw.main');
    menu.addMenuItem(COMMAND1_ID);
    menu.addMenuItem(COMMAND8_ID);
    menu.addMenuItem(COMMAND2_ID);
    menu.addMenuItem(COMMAND3_ID);
    menu.addMenuItem(COMMAND4_ID);
    menu.addMenuItem(COMMAND9_ID);
    menu.addMenuItem(COMMAND5_ID);
    menu.addMenuItem(COMMAND6_ID);
    menu.addMenuItem(COMMAND7_ID);
    menu.addMenuDivider();
    menu.addMenuItem(COMMAND10_ID);
    
});
