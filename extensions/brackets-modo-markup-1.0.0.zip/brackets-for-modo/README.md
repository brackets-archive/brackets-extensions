brackets-modo-markup
==========================

Brackets MODO language extension.

Adds support for MODO file extensions.

##License
[MIT](http://opensource.org/licenses/MIT)