de.richter.brackets.jsonlint
============================

JSONLint Extension for Brackets

TODO:
# use jasmine 2.x for unit tests
# convince node-jasmine to use requireJS

### External Libraries
https://github.com/zaach/jsonlint
