Son Of Obsidian Brackets theme
=======

Customised Son Of Obsidian Theme.
Based on http://eclipsecolorthemes.org/?view=theme&id=1495

## HTML
![HTML Screenshot](/Screenshots/html.png)

## CSS
![CSS Screenshot](/Screenshots/css.png)

## JS
![JS Screenshot](/Screenshots/js.png)

## PHP
![PHP Screenshot](/Screenshots/php.png)

## XML
![XML Screenshot](/Screenshots/xml.png)

## LESS
![LESS Screenshot](/Screenshots/less.png)