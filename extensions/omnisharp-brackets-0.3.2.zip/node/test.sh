echo $PATH
