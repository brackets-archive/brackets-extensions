define(function (require, exports, module) {
  "use strict";
  var LanguageManager = brackets.getModule("language/LanguageManager");
  LanguageManager.defineLanguage("mirc", {"name":"mIRC","mode":"mirc","fileExtensions":["mrc"],"lineComment":[";"]});
});