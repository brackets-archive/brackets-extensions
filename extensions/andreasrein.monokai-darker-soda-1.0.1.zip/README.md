# Monokai Darker Soda
Brackets monokai theme with deeper colors for your late night coding sessions.

## Screenshot

![alt tag](https://github.com/kleinrein/Monokai-Darker-Soda/blob/master/Screenshots/monokai_darker_soda.png?raw=true)
