# UnoCSS

An extension for the Brackets Text Editor for displaying CSS files, their classes, and their properties in a bottom panel within Brackets. 


### Installation
##### Mac/OSX
Clone this repository in Users/<your username>/Library/Application Support/Brackets/extension/user
Reload brackets with extension using CMD+R
The Menu option is located in View -> Open UnoCSS or use the keyboard shortcut CMD+SHIFT+U

##### Windows

##### Linux
