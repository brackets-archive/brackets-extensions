Milk Oolong theme for Brackets
===========================
### Light sunny theme for harmony web coding.
### Using color palette of fresh joyful morning with cup of flavorous green tea.

## HTML
![HTML Screenshot](https://github.com/roicos/milkoolong/blob/master/image/html.png)

## CSS, LESS
![HTML Screenshot](https://github.com/roicos/milkoolong/blob/master/image/less.png)

## JavaScript
![HTML Screenshot](https://github.com/roicos/milkoolong/blob/master/image/javascript.png)

## JQuery
![HTML Screenshot](https://github.com/roicos/milkoolong/blob/master/image/jquery.png)

## PHP
![HTML Screenshot](https://github.com/roicos/milkoolong/blob/master/image/php.png)

## Java
![HTML Screenshot](https://github.com/roicos/milkoolong/blob/master/image/java.png)