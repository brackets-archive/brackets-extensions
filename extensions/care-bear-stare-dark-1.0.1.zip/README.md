Care Bear Stare Theme for Brackets
=============================

For kids that aren't afraid to code in the dark; ages 10–170. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/CareBearStareDark/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/CareBearStareDark/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/CareBearStareDark/blob/master/screenshots/js.png)
