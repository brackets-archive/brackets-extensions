Esquire Theme for Brackets
===========================

Esquire features a restrained palette of dark, WCAG-compliant colors on a white (active line only) or light gray background, and comments in a subtle gray. This clear visual hierarchy focuses the user on the active line without sacrificing readability elsewhere in the code.

## HTML
![HTML Screenshot](https://github.com/davidjamesknight/brackets/blob/master/djk-esquire/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/davidjamesknight/brackets/blob/master/djk-esquire/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/davidjamesknight/brackets/blob/master/djk-esquire/screenshots/js.png)