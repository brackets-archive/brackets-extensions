# Changelog

## 0.4.0 (15/08/2017)
* fixed select box not displaying correctly by [TechGladiator](https://github.com/TechGladiator)

## 0.4.0 (24/09/2017)
* updated libs.json, available libraries change from 3018 to 3160

## 0.5.1 (24/09/2017)
* updated version to 0.5.11 and made available on Brackets Extension Registry  
