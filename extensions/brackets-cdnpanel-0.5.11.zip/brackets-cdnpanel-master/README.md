![CDN PANEL](https://github.com/kopitar/brackets-cdnpanel/blob/master/ui/css/images/logo_cdnjs.png)
==========

 Brackets extension that gives you instant access to over 3000 Javascript libraries, plugins, CSS frameworks, fonts etc.
 Either select what you're looking for directly from a list or simply type in it's name or a keywords and get instant access to any file hosted on cdnjs.com.
 
 

