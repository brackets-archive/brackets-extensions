LightTable Theme for Adobe Brackets
=================

Dark and pleasant theme for Adobe Brackets, based on LightTable default colors.


### HTML
![HTML](https://raw.githubusercontent.com/brunnopleffken/light-table-theme/master/screenshots/html.png)

### CSS/SASS
![CSS/SASS](https://raw.githubusercontent.com/brunnopleffken/light-table-theme/master/screenshots/sass.png)

### Javascript
![Javascript](https://raw.githubusercontent.com/brunnopleffken/light-table-theme/master/screenshots/javascript.png)

### PHP
![PHP](https://raw.githubusercontent.com/brunnopleffken/light-table-theme/master/screenshots/php.png)
