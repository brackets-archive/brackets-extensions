#Brackets Theme - Solarized Light

The excellent [Solarized Light](http://ethanschoonover.com/solarized) theme for [Brackets](http://brackets.io/).

<hr>

![Solarized Light Brackets Theme](screenshot.png)
