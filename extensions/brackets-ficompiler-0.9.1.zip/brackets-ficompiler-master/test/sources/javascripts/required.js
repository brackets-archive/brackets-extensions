/*jslint node :true */

(function () {
    'use strict';
    
    exports.name = "I was required!";
}());