/*jslint node: true */

(function () {
    'use strict';

    var hello = "Hello",
        req = require('./required');
}());