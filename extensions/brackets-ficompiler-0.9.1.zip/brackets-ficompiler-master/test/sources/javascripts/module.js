(function () {
    'use strict';

    var miModuleVar = 'My module var value';
}());