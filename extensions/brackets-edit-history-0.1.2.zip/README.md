Brackets Edit History
=====================

A Brackets extension to navigate forward and backward among historical edit positions within a file.