#Gemstones Theme Light

After having some trouble with Gemstones in the sun, I decided to turn it into a light theme.
This is the result.

###Installation
* Open Brackets
* Open the Extension Manager
* Switch to "Themes" tab
* Search for "Gemstones Theme Light"
* Click "Install"

##Screenshots

### HTML
[![HTML](https://raw.githubusercontent.com/mynimi/gemstones-light-brackets-theme/master/screenshots/html.png)](https://raw.githubusercontent.com/mynimi/gemstones-light-brackets-theme/master/screenshots/html.png)
### SCSS
[![SCSS](https://raw.githubusercontent.com/mynimi/gemstones-light-brackets-theme/master/screenshots/scss.png)](https://raw.githubusercontent.com/mynimi/gemstones-light-brackets-theme/master/screenshots/scss.png)
### JavaScript
[![JS](https://raw.githubusercontent.com/mynimi/gemstones-light-brackets-theme/master/screenshots/js.png)](https://raw.githubusercontent.com/mynimi/gemstones-light-brackets-theme/master/screenshots/js.png)
