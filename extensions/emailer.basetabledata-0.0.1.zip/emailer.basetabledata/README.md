# emailer.basetabledata #

An [Adobe Brackets](http://brackets.io) Automatically create a basic table line that includes cellpadding='0' cellspacing='0' border='0' by using ctrl + shift + T.

# Installation #

1. Open the Brackets Extension Manager and search for "Table".

# Updates #

* 2/04/2014 - Initial release

# License #

[The MIT License](LICENSE.md)
