# Hannah-brackets-theme

Hannah for Brackets has a purple background, with a mix of colors such as green, white, gold, and light blue. It's inspired from my daughter Hannah.

## Screenshot

![screen shot](hannah_screenshot.png)

## Installation

The easiest and quickest way to install the Hannah theme is to download and install directly through the Brackets extension manager. The alternative is to download this repo by clicking Download ZIP in Github and install the zip file manually through the extension manager.
