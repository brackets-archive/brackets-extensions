# bracketstheme-obsidian2
Theme for Brackets code editor bºased on Obsidian for Seam and change highlight colours

## HTML
Obsidian original
![HTML Screenshot](/screenshot/obsidian.html.png)
Obsidian 2
![HTML Screenshot](/screenshot/obsidian2.html.png)

## CSS
Obsidian original
![CSS Screenshot](/screenshot/obsidian.css.png)
Obsidian 2
![CSS Screenshot](/screenshot/obsidian2.css.png)

## JS
Obsidian original
![JS Screenshot](/screenshot/obsidian.js.png)
Obsidian 2
![JS Screenshot](/screenshot/obsidian2.js.png)

## PHP
Obsidian original
![PHP Screenshot](/screenshot/obsidian.php.png)
Obsidian 2
![PHP Screenshot](/screenshot/obsidian2.php.png)
