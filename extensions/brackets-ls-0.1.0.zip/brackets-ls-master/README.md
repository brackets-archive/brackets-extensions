LiveScript Syntax Highlighting for Brackets
===========================================

LiveScript Syntax Higlightng

How to Install
==============

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for this extension
3. Click _Install_!


### License
MIT-licensed -- see `LICENSE` for details.