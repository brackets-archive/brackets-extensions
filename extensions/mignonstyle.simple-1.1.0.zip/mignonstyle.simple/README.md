# Simple Brackets Theme
Simple Light theme for [Brackets](http://brackets.io/).

## HTML
![HTML Screenshot](preview/html.png)

## CSS
![CSS Screenshot](preview/css.png)

## JavaScript
![JavaScript Screenshot](preview/javascript.png)

## PHP
![PHP Screenshot](preview/php.png)

## Changelog
* Ver 1.1.0 Change the color of the variables etc.
* Ver 1.0.0 Initial release.

## Copyright and License
Copyright (c) 2015 [Mignon Style](http://mignonstyle.com/). Released under the [MIT License](LICENSE).