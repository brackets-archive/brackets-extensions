<?PHP
include 'test1_inc.php';
echo $fruit;
echo "\n";

for($i = 0; $i < 11; $i++) {
   echo "this message has echoed $i times <br> \n";
   echo "";
}
echo "foo © bar ≠ baz 𝌆 qux é";
?>
