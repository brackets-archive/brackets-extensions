Solarized
=========

Solarized Theme

![Solarized ss](https://github.com/brackets-themes/solarized/raw/master/screenshot.png)
