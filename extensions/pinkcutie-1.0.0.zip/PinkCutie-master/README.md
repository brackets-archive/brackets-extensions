PinkCutie Theme for Brackets
=================================

Based on Snagglepanther - https://github.com/Brackets-Themes/Snagglepanther

However I do not care for light backgrounds, so I modified it to be darker.

## HTML
![HTML Screenshot](https://github.com/JDViz/PinkCutie/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/JDViz/PinkCutie/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/JDViz/PinkCutie/blob/master/screenshots/js.png)
