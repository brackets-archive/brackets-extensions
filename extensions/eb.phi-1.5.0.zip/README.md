Placeholdit-for-brackets
=================

Add a placehold.it icon in Brackets, this allows for a random 'placehold.it' image tag to be generated and inserted into the editor.

Credit: http://placehold.it