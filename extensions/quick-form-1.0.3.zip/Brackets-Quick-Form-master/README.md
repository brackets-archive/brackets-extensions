# Brackets Quick Form

An extension for Adobe Brackets to insert form elements into editor quickly.<br>
This project is base on [Brackets QuickFormTool](https://github.com/myaghobi/Brackets-QuickFormTool).
![Alt text](screenshot/shot1.png?raw=true "ScreenShot Brackets-Quick-Form")
