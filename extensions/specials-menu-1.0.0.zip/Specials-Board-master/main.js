//Why does a theme require a JS file?
