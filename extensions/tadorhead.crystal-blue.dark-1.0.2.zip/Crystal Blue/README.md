Crystal-Blue
============

Crystal Blue is a great syntax theme that is easy on your eyes. It consist various blues. 

![Screen Shot](Crystal.png)

Version: 1.0.0 - 1.0.1

I've changed a few things to improve the syntax theme. 

![Screen Shot](Crystal-V2.png)

Version: 1.0.2

>The red trapaziod in the picture should not appear in your Brackets IDE.