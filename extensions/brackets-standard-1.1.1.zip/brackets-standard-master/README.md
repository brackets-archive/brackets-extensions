# Brackets-Standard

This is the brackets extension for the [standard] code style.

## Installation

Use the Brackets extension manager. Make sure you have `standard` installed globally!

[standard]: https://github.com/feross/standard/
