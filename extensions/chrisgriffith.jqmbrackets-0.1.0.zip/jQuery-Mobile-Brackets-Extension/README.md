jQuery-Mobile-Brackets-Extension
================================

Extension for Brackets (http://brackets.io) that adds support for jQuery Mobile code hinting. 
