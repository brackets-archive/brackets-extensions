# Open In Browser
Open in Browser is a Brackets extension which allows you to save then open a file in the Working Files pane in the default browser or application using a context menu or the keyboard shortcut CMD-2/CTRL-2.


If you like my work then let's work together, I'm looking for a Software Engineering position. Here's my [Resume](https://u.nu/2w8t) and my [LinkedIn.](https://www.linkedin.com/in/justin-strong-a68b72119/)


## Version History
Version 1.1.0
* Open in Browser now saves your file before opening it so you can view your latest changes.
* Adds a preference to turn off saving before opening.

Version 1.0.0
* Allows you to open a file in the browser or default application using the working files context menu or the keyboard shortcut CMD-2/CTRL-2.
