define
   ({
	// Extension
	EXTENSION_NAME			:  "cv.console",
	   
	// Console actions
	CONSOLE_SHOW			:  "Afficher",
	CONSOLE_SHOW_HELP		:  "Affiche la console",
	CONSOLE_HIDE 			:  "Masquer",
	CONSOLE_HIDE_HELP		:  "Masque la console",
	CONSOLE_CLEAR 			:  "Effacer",
	CONSOLE_CLEAR_HELP		:  "Effacer la console"
     }) ;