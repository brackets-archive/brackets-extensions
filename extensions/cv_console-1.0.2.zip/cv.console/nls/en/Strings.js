define
   ({
	// Extension
	EXTENSION_NAME			:  "cv.console",
	   
	// Console actions
	CONSOLE_SHOW			:  "Show",
	CONSOLE_SHOW_HELP		:  "Shows the console",
	CONSOLE_HIDE 			:  "Hide",
	CONSOLE_HIDE_HELP		:  "Hides the console",
	CONSOLE_CLEAR 			:  "Clear",
	CONSOLE_CLEAR_HELP		:  "Clears the console"
     }) ;