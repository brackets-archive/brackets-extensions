cv.console
==========

Shows log, error, debug and dir console information in a Brackets panel, without developer tools.

