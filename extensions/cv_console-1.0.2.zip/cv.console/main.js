/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, console, brackets, $, Mustache */

/**************************************************************************************************

    NAME
    	cv.console/main.js
	
    DESCRIPTION
    	Overloads the log(), error(), debug() and dir() methods of the standard Console object to
	be able to log in the $('#editor-console') panel in addition to the developr's tools console
	window.
	
    AUTHOR 
    	Christian Vigh, 2014.
	
    LICENSE
    	GPL V3 (see the LICENSE file).
	
     CREDITS
     	This extension has been largely inspired by the brackets-console extension written by
	Alexadru Ghiura (ghalex@gmail.com).
	
     HISTORY
     [Version : 1.0.2]	[Date : 2014-02-16]	[Author : CV]
     	Initial version.
    	
 **************************************************************************************************/
define
   (
	function  ( require, exports, module ) 
	   {
    		"use strict" ;

		   
		// Brackets objects
		var 	AppInit       		=  brackets. getModule ( "utils/AppInit" ),
			Resizer       		=  brackets. getModule ( "utils/Resizer" ),
		        PanelManager 		=  brackets. getModule ( "view/PanelManager" ),
			ConsoleTemplate   	=  require ( "text!html/console.html" ) ;
    
		// Localization
		var	Strings 		=  require ( 'modules/Strings' ) ;
		   
		// Rendering of console template
		var 	ConsoleVariables 	=  
		   { 
			"SHOWHIDE" 	: __showhide, 
			"CLEAR" 	: Strings. CONSOLE_CLEAR 
		    } ;
		var 	ConsoleHTML ;

		// Internal settings
		var 	initialized 		=  false ;
		var 	$console,
			$showhide,
			$clear ;
		var 	logged_records		=  0 ;
		  

		/**
		 * Converts a message to HTML.
		 *
		 * @param message
		 *	Message to be converted.
		 */
		function  __tohtml ( message, message_class ) 
		   {
			var 	text 		=  ( message ) ?  message. replace ( /\n/g, "<br/>" ) : message ;
			var 	text_class	=  ( logged_records % 2 ) ?  "odd" : "even" ;
			   
			
			message_class	=  message_class  ||  "log" ;
			text 		=  "<div><div class='log-message " + message_class + " " + text_class + "'>" + text + "</div></div><br/>" ;
			logged_records ++ ;
			   
			return ( text ) ;
		    }

		/**
		 * Returns the appropriate Show or Hide string depending on the console visibility status.
		 *
		 */
		function  __showhide ( )
		   {
			return ( ( $($console). is ( ":visible" ) ) ?  Strings. CONSOLE_HIDE :  Strings. CONSOLE_SHOW ) ;
		    }
			
		   
		/**
		 * Logs a message to the console.
		 *
		 * @param message
		 *	Message to be logged.
		 */
		var 	__console_log 	=  console. log ;
		   
		console. log 	=  function  ( )
		   {
			var 	message 	=  Array. prototype. slice. call ( arguments ). join ( '' ) ;
			var 	text 		=  __tohtml ( message, "log" ) ;
			   
			$console. append ( text ) ;
			$console. animate ( { scrollTop: $console [0]. scrollHeight }, 10 ) ;
		
			__console_log. apply ( console, arguments ) ;
			return ( console ) ;
		    }
		   
		
		/**
		 * Logs an error message to the console.
		 *
		 * @param message
		 *	Message to be logged.
		 */
		var 	__console_error 	=  console. error ;
		   
		console. error 	=  function  ( )
		   {
			var 	message 	=  Array. prototype. slice. call ( arguments ). join ( '' ) ;
			var 	text 		=  __tohtml ( message, "error" ) ;
			   
			$console. append ( text ) ;
			$console. animate ( { scrollTop: $console [0]. scrollHeight }, 10 ) ;
		
			__console_error. apply ( console, arguments ) ;
			return ( console ) ;
		    }
		   
		
		/**
		 * Logs a debug message to the console.
		 *
		 * @param message
		 *	Message to be logged.
		 */
		var 	__console_debug 	=  console. debug ;
		   
		console. debug 	=  function  ( )
		   {
			var 	message 	=  Array. prototype. slice. call ( arguments ). join ( '' ) ;
			var 	text 		=  __tohtml ( message, "debug" ) ;
			   
			$console. append ( text ) ;
			$console. animate ( { scrollTop: $console [0]. scrollHeight }, 10 ) ;
		
			__console_debug. apply ( console, arguments ) ;
			return ( console ) ;
		    }
		   
		
		/**
		 * Dumps an object to the console.
		 *
		 * @param object
		 *	object to be dumped.
		 */
		var 	__console_dump	 	=  console. dir ;
		   
		// Returns the real type of an object
		function  __typeof ( object )
		   {
			var 	type	=  typeof  ( object ) ;
			   
			if  ( object  ===  null )			// Null object 
				return ( 'null' ) ;
			else if  ( type  ===  'undefined' )		// Undefined
				return ( type ) ;
			else if  ( type  ===  'string' )		// String type
				return ( type ) ;
			else if  ( type  ===  'boolean' )		// Boolean type
				return ( type ) ;
			else if  ( type  ===  'number' )		// Either integer or float
			   {
				if  ( Math. floor ( object )  ===  object )
					return ( 'integer' ) ;
				else
					return  ( 'float' ) ;
			    }
			else if  ( type  !==  'object' )		// Paranoia
				return ( type ) ;
			else						// object
			   {
				// Null value
				if  ( object  ===  null )
					return ( "null" ) ;

				// Treat "object" as an object and obtain its class name from its string representation ("[object something]")
				var	realclass	=  Object. prototype. toString. call ( object ). match ( /^\[object\s(.*)\]$/ ) [1]  ||  'Object' ;

				// Some structures may implement a toString() member function like in the following example :
				//	var  s = { field : 1, toString : function ( ) { return ( "structure" ) ; } }
				// When converted to a string, the "structure" string is returned.
				// However, when calling object. prototype. toString. call(), the string "[object object]" is returned.
				// In this case, we want to return what the toString() implementation returns.
				if  ( object. toString )
				   {
					if  ( realclass  ===  'object' )
						return ( object. toString ( ) ) ;
				    }

				// Other cases : we have an object class name to return
				return ( realclass ) ;
			    }
		    }
		   
		// Returns the formatted value of an object
		function  __valueof ( object, type )
		   {
			var 	text 	=  object ;
			
			   
			if  ( type  ===  'undefined' ) 
				text 	=  type ;
			else if  ( object  ===  null )
				text 	=  "null" ;
			else if  ( type  ===  'Array' )
				text 	=  "[ " + object. join ( ', ' ) + " ]" ;
			else if  ( type  ===  'string' )
				text 	=  '"' + text. replace ( '"', '\\"' ) + '"' ;
			else if  ( type  ===  'Object' )
			   {
				var  	items 	=  [] ;
				   
				for  ( var  item  in  object )
				   {
					var 	item_type	=  __typeof ( item ) ;
					var 	item_value 	=  __valueof ( object [ item ], item_type ) ;
					   
					items. push ( item. toString ( ) + ": "  + item_value + " [" + item_type + "]" ) ;
				    }
				   
				text 	=  "{ " + items. join ( ', ' ) + " }" ;
			    }
			   
			return ( text ) ;
		    }
		   
		console. dump	=  function ( object )
		   {
			var 	type	=  __typeof ( object ) ;
			var   	value 	=  __valueof ( object, type ) ;
			var 	html 	=  "<div class='type'>" +
			   		   type +
			    		   "</div>" +
			    		   "<div class='value' >" +
			    		   value +
			    		   "</div><br/>" ;
			var 	text 	=  __tohtml ( html, "dump dir" ) ;
			
			$console. append ( text ) ;
			$console. animate ( { scrollTop: $console [0]. scrollHeight }, 10 ) ;
			__console_dump. apply ( console, arguments ) ;
			
			return ( console ) ;
		    }
		   
		console. dir 	=  console. dump ;
		   
		   
		/**
		 * Clears the console.
		 *
		 */
		function  clear ( )
		   {
			$console. html ( "" ) ;
			logged_records	=  0 ;
			   
			return ( console ) ;
		    }
		   
		   
		// Console extension initialization
		initialized 	=  true ;
		ConsoleHTML 	=  Mustache. render ( ConsoleTemplate, ConsoleVariables ) ;

		$('.content'). append ( ConsoleHTML ) ;

		$console 	=  $('#editor-console') ;
		$showhide	=  $('#editor-console-toolbar > #show-hide') ;
		$clear 		=  $('#editor-console-toolbar > #clear') ;

		// Integrate console panel
		PanelManager.createBottomPanel ( 'cv.console.toolbar', $(ConsoleHTML) ) ;
		$showhide. html ( __showhide ( ) ) ;

		// Show/hide console link
		$showhide. click
		   (
			function  ( )
			   {
				Resizer. toggle ( $console ) ;
				$showhide. html ( __showhide ( ) ) ;
			    }
		    ) ;

		// Clear console link
		$clear. click
		   (
			function  ( ) 
			   {
				clear ( ) ;
			    }
		    ) ;
		   
		// No exports since we're simply overridding console methods
		alert ( "console" ) ;
	   }
    ) ;
