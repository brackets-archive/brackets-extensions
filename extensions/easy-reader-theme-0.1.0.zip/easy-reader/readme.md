Easy Reader Theme for Brackets
===

About
---
I created this theme as I couldn't find a theme that I liked that was dark, dimmed and had pleasing colours to my eyes. 

Initially I used [Midnight Glow Theme for Brackets](https://github.com/notasz/Brackets-Midnightglow) by [notasz](https://github.com/notasz) as the base for my theme,
mainly for the structure of the code, but modified most things in the end. I was originally using Atom but decided to swap so ported over my personal theme,
so the syntax is largely a mish mash of [Seti Syntax for Atom](https://github.com/jesseweed/seti-syntax) and [Gruvbox for Atom](https://github.com/kmfk/atom-gruvbox-dark) with many modifications.

To get the full theme, such as the sidebar colouring, you need to include [Custom UI Theme Enabler](https://github.com/notasz/brackets-uitheming), which will enable all the other small changes I've made.

Note that currently I'm learning CSS, HTML and Javascript so other languages won't be as refined in the meantime.

Examples
---

### HTML
![HTML](screenshots/html.png)

### SASS
![HTML](screenshots/sass.png)

To Do
---
Currently only HTML and SASS have been completed, Javascript is looking quite messy at the moment so I will be working on it.