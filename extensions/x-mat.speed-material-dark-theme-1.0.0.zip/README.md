# Fast Material Dark Theme
It's an easy and readable them for brakets

# HTML
![Html](/screenshot/html.png)

#JS
![Js](/screenshot/js.png)

#PHP
![L'ho](/screenshot/php.png)

#CSS
![Css](/screenshot/css.png)

