## Breathable Hacker theme for Brackets :D
An easier to read hacker theme. 

Work in progress...
