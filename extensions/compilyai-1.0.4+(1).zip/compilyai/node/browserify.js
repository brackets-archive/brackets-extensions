(function(){

////////////////////////////////////////////////////////////////////////////////

var fs;
var path;

fs = require('fs');
path = require('path');

////////////////////////////////////////////////////////////////////////////////

exports.init = function(manager){
    if (!manager.hasDomain('compilyai'))
        manager.registerDomain('compilyai', {
            major: 1,
            minor: 0
        });

    manager.registerCommand('compilyai', 'browserify', browserify, true);
};

////////////////////////////////////////////////////////////////////////////////

function browserify(filename, compress, cb){
    filename = path.normalize(filename);

    require('browserify')([filename]).
    bundle({debug: !compress}, function(err, data){
        if (err) return cb(err.toString());

        if (compress)
            data = require('uglify-js').minify(data, {
                fromString: true
            }).code;

        fs.writeFile(filename.replace('.js', '.min.js'), data, 'utf-8', function(err){
            if (err) return cb(err);
        });
    });
}

////////////////////////////////////////////////////////////////////////////////

}());
