(function(){

////////////////////////////////////////////////////////////////////////////////

var fs;
var path;

fs = require('fs');
path = require('path');

////////////////////////////////////////////////////////////////////////////////

exports.init = function(manager){
    if (!manager.hasDomain('compilyai'))
        manager.registerDomain('compilyai', {
            major: 1,
            minor: 0
        });

    manager.registerCommand('compilyai', 'lessify', lessify, true);
};

////////////////////////////////////////////////////////////////////////////////

function lessify(filename, compress, cb){
    var parser;

    filename = path.normalize(filename);
    parser = new require('less').Parser({
        paths: path.dirname(filename),
        filename: filename
    });

    fs.readFile(filename, 'utf-8', function(err, data){
        if (err)
            return cb(err);

        parser.parse(data, function(err, data){
            if (err) return cb(err);

            data = data.toCSS({
                compress: compress
            });

            fs.writeFile(filename.replace('.less', '.min.css'), data, 'utf-8', function(err){
                if (err) return cb(err);
            });
        });
    });
}

////////////////////////////////////////////////////////////////////////////////

}());
