define(function(require, exports, module){

////////////////////////////////////////////////////////////////////////////////

var app, project;
var panel;

app = brackets.getModule('utils/AppInit');
project = brackets.getModule('project/ProjectManager');

panel = brackets.getModule('view/PanelManager').
createBottomPanel('compilyai', $(require('text!bottom-panel.html')));

////////////////////////////////////////////////////////////////////////////////

app.appReady(function(){
    $(brackets.getModule('document/DocumentManager')).on('documentSaved', onDocumentSaved);

    $('#compilyai-panel .close').on('click', function(){
        panel.hide();
    });
});

////////////////////////////////////////////////////////////////////////////////

function onDocumentSaved(event, document){
    var dir, ext;

    if (document.file.isDirty)
        return;

    dir = project.getProjectRoot().fullPath;
    ext = document.file.fullPath.split('.').pop().toLowerCase();

    $('#compilyai-panel tbody tr').remove();

    $.ajax(dir + '.brackets.json', {dataType: 'json'}).
    done(function(data){
        if (!data.compilyai)
            return;

        compilyai(function(){
            var config = data.compilyai;

            if (config.less && ext == 'less')
                this.lessify(dir + config.less, config.compress).
                fail(log.bind(null, 'LESS'));

            if (config.js && ext == 'js')
                this.browserify(dir + config.js, config.compress).
                fail(log.bind(null, 'Browserify'));
        });
    });
}

////////////////////////////////////////////////////////////////////////////////

function log(from, err){
    var tr;

    panel.show();

    if (typeof(err) == 'string')
        err = {message: err};

    tr = $('<tr />').appendTo('#compilyai-panel tbody');

    $('<td />').text(from).appendTo(tr);
    $('<td />').text(err.message).appendTo(tr);
    $('<td />').text(err.filename).appendTo(tr);
}

////////////////////////////////////////////////////////////////////////////////

function compilyai(cb){
    var node = new (brackets.getModule('utils/NodeConnection'));

    if (node.domains.compilyai)
        return cb.call(node.domains.compilyai);

    node.connect(true).done(function(){
        var utils, path;

        utils = brackets.getModule('utils/ExtensionUtils');
        path = [];

        path.push(utils.getModulePath(module, 'node/lessify'));
        path.push(utils.getModulePath(module, 'node/browserify'));

        node.loadDomains(path, true).done(function(){
            cb.call(node.domains.compilyai);
        });
    });
}

////////////////////////////////////////////////////////////////////////////////

});
