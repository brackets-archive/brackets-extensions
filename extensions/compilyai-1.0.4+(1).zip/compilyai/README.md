COMPILYAI
=========

Compile [LESS] and JS ([Browserify] & [UglifyJS]) on fly for [Adobe Brackets].

[Adobe Brackets]: https://github.com/adobe/brackets

[LESS]: http://lesscss.org
[Browserify]: http://browserify.org
[UglifyJS]: https://github.com/mishoo/UglifyJS

USAGE
-----

Add section to `.brackets.json`:

```json
"compilyai": {
    "less": "src/main.less",
    "js": "src/main.js",
    "compress": false
}
```

And when you save `JS` or `LESS` Compilyai compile files.

LICENSE
-------

The MIT License (MIT)

Copyright (c) 2013 Лёха zloy и красивый <lexazloy@gmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
