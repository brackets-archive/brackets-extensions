exports.world = function(){
    return 'Чё-как?';
};
