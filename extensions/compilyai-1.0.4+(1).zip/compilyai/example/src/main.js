var hello;

hello = require('./hello.js');

console.log(hello);
