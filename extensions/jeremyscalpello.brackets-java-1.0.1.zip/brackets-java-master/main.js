define(function (require, exports, module) {

  'use strict';

  var CommandManager = brackets.getModule('command/CommandManager');
  var ProjectManager = brackets.getModule('project/ProjectManager');
  var Menus = brackets.getModule('command/Menus');
  var Utils = require('./utils');
  var menu = Menus.addMenu('Java', 'JAVA_MENU');

  var ctrls = {
    execute: require('./execute').execute
  };

  //Execute function
  CommandManager.register('Execute', 'java.execute', ctrls.execute);
  menu.addMenuItem('java.execute', 'Ctrl-Shift-e');

});
