define(function (require, exports, module) {

  'use strict';

  var Utils = require('./utils');
  var NodeDomain = brackets.getModule("utils/NodeDomain");
  var ExtensionUtils = brackets.getModule("utils/ExtensionUtils");

  var Java = new NodeDomain('java', ExtensionUtils.getModulePath(module, 'node/main'));

  exports.execute = function () {
    var path = Utils.getActiveFilePath();
    var file = Utils.getActiveFile();
    if (!path || !file) return Utils.alert('Error', 'No file is open in the editor');
    var ext = file.split('.')[file.split('.').length - 1];
    if (!ext || ext != 'java') return Utils.alert('Error', 'The selected file is not a Java file');
    var compiling = Utils.interstitial('Compiling', 'Please wait while the class compiles')
    Java.exec('execute', file, path)
      .done(function (out) {
        compiling.close();
        Utils.alert('Success', out);
      }).fail(function (err) {
        compiling.close();
        Utils.alert('Error', err);
      });
  };

});
