define(function (require, exports, module) {

  'use strict';

  var CommandManager = brackets.getModule('command/CommandManager');
  var ProjectManager = brackets.getModule('project/ProjectManager');
  var DocumentManager = brackets.getModule('document/DocumentManager');
  var Dialogs = brackets.getModule("widgets/Dialogs");

  exports.getActiveFile = function () {
    var doc = DocumentManager.getCurrentDocument();
    if (!doc) return null;
    return doc.file.name;
  };

  exports.getActiveFilePath = function () {
    var doc = DocumentManager.getCurrentDocument();
    if (!doc) return null;
    return doc.file.parentPath;
  };

  exports.alert = function (title, text) {
    Dialogs.showModalDialog(title, title, text);
  };

  exports.interstitial = function (title, text) {
    return Dialogs.showModalDialog(title, title, text, []);
  };

});
