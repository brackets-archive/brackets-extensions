# brackets-java
Brackets extension to compile and execute the currently open Java file. I wrote this because my programming lecturer refused to allow us to use a proper IDE.
