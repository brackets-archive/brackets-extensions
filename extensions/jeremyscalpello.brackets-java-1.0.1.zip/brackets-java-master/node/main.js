var ctrls = {
  execute: require('./execute').execute
};

function init(domainManager) {
  if (!domainManager.hasDomain('java')) {
    domainManager.registerDomain('java', {
      major: 0,
      minor: 1
    });
  }
  domainManager.registerCommand(
    'java',
    'execute',
    ctrls.execute,
    true,
    'Compile and execute Java file ', [
      {
        name: 'path',
        type: 'string',
        description: 'Java file path'
      },
      {
        name: 'output',
        type: 'string',
        description: 'Class file output directory'
      }
    ]
  );
};

exports.init = init;
