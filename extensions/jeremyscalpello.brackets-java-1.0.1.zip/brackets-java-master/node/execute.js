var exec = require('child_process').execFile;
var join = require('path').join;
var fs = require('fs');

function compile(file, path, callback) {
  var buildPath = join(path, 'build');
  fs.mkdir(buildPath, function (err) {
    if (err && err.code != 'EEXIST') return callback(displayOutput(err.toString()));
    else {
      exec('javac', ['-d', buildPath, '-sourcepath', '.', file], {
        cwd: path
      }, (err, stdout, stderr) => {
        if (err || stderr) return callback(displayOutput(stderr || err.toString()));
        else {
          var filenameParts = file.split('.');
          var mainClass = filenameParts.slice(0, filenameParts.length - 1).join('.');
          exec('java', [mainClass], {
            cwd: buildPath
          }, (err, stdout, stderr) => {
            if(err || stderr) return callback(displayOutput(stderr || err.toString()));
            else return callback(null, displayOutput(stdout))
          });
        }
      });
    }
  });
};

function displayOutput(text) {
  return text
    .split(' ').join('&nbsp;')
    .split('\n').join('<br />')
};

exports.execute = compile;
