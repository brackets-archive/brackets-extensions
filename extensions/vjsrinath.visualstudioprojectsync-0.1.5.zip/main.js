define(function (require, exports, module) {
    "use strict";

    var ProjectManager = brackets.getModule("project/ProjectManager"),
        Menus = brackets.getModule("command/Menus"),
        CommandManager = brackets.getModule("command/CommandManager"),
        DocumentManager = brackets.getModule("document/DocumentManager"),
        ExtensionUtils = brackets.getModule("utils/ExtensionUtils"),
        NodeConnection = brackets.getModule("utils/NodeConnection"),
        FileSystem = brackets.getModule("filesystem/FileSystem"),
        FileUtils = brackets.getModule("file/FileUtils"),
        PreferencesManager = brackets.getModule("preferences/PreferencesManager"),
        preferences = PreferencesManager.getExtensionPrefs("vjsrinath.VisualStudioProjectSync"),
        ADD_SHORTCUT = 'Ctrl-Shift-A',
        REM_SHORTCUT = 'Ctrl-Shift-R',
        // Then create a menu item bound to the command
        // The label of the menu item is the name we gave the command (see above)
        menu = Menus.getMenu(Menus.AppMenuBar.FILE_MENU);



    // default preferences
    $.extend(preferences, {
        "settingsPath": "vsproject.json"
    });

    var _getVsProjectPath,
        vsProjectPath,
        //Gets visual studio project file
        getVsProjectPath = function (refresh) {
            var projectPath = ProjectManager.getProjectRoot().fullPath,
                configFile = FileSystem.getFileForPath(projectPath + preferences.settingsPath);
            _getVsProjectPath = (refresh || (!_getVsProjectPath)) ? $.Deferred() : _getVsProjectPath;
            if (_getVsProjectPath.state() == "pending") { // read the config file
                FileUtils.readAsText(configFile).then(function (text) {
                    var err;
                    try {
                        // try to parse it
                        vsProjectPath = JSON.parse(text).projectFile;
                        _getVsProjectPath.resolve(vsProjectPath);
                    } catch (e) {
                        err = e;
                    }
                    if (err) {
                        // reject with error if not parsable
                        _getVsProjectPath.reject(new Error("Invalid configuration file (compile.json): " + err.message));
                    }
                });
            }
            return _getVsProjectPath.promise();
        };

    var _readProjectsXml,
        readProjectsXml = function (refresh) {
            _readProjectsXml = (refresh || (!_readProjectsXml)) ? $.Deferred() : _readProjectsXml;
            if (_readProjectsXml.state() == "pending") {

                getVsProjectPath().done(function (path) {
                    var projectPath = ProjectManager.getProjectRoot().fullPath,
                        fullProjPath = projectPath + path,
                        projectFile = FileSystem.getFileForPath(fullProjPath);
                    FileUtils.readAsText(projectFile).then(function (text) {
                        var $projectXml,
                            err;
                        try {
                            // try to parse it
                            _readProjectsXml.resolve({
                                path: fullProjPath,
                                $xml: $($.parseXML(text))
                            });
                        } catch (e) {
                            err = e;
                        }
                        if (err) {
                            // reject with error if not parsable
                            _readProjectsXml.reject(new Error("Invalid Project file : " + path + " " + err.message));
                        }
                    });
                });
            }
            return _readProjectsXml.promise();
        };

    var addFileToProj = function (path) {
            var relPath = FileUtils.getRelativeFilename(ProjectManager.getProjectRoot().fullPath, path);
            relPath = relPath.replace(/\//g, '\\');
            readProjectsXml().done(function (result) {

                var $project = result.$xml,
                    $elt = $project.find('Content[Include="' + relPath + '"]');
                if ($elt.length)
                    return;
                $project.find('Content[Include$=' + FileUtils.getFileExtension(relPath) + ']')
                    .parents('ItemGroup')
                    .append($.parseXML('<Content Include="' + relPath + '"/>\n').documentElement);
                return saveProjectFile(result.path, $project);
            });
        },
        removeFileFromProj = function (path) {
            readProjectsXml().done(function (result) {

                var $project = result.$xml,
                    $elt = $project.find('Content[Include="' + path + '"]')
                if (!$elt.length)
                    return;
                $elt.remove();
                return saveProjectFile(result.path, $project);
            });
        };

    var getXmlString = function ($xml) {
            var xmlData = $xml[0],
                xmlString;

            try {
                xmlString = (new XMLSerializer()).serializeToString(xmlData);
            } catch (e) {
                xmlString = '';
            }
            return xmlString;

        },
        saveProjectFile = function (path, $project) {

            var file = FileSystem.getFileForPath(path);
            var xml = getXmlString($project);
            return (xml && FileUtils.writeText(file, xml)) || $.Deferred();
        };

    //Bind event handlers
    $(DocumentManager).on('documentSaved documentRefreshed', function (e, path) {

        try {
            switch (path) {
            case preferences.settingsPath:
                getVsProjectPath(true);
                break;
            case vsProjectPath:
                _readProjectsXml = null;
                break;
            }
        } catch (e) {}
    }).on('pathDeleted', function (e, path) {
        removeFileFromProj(path);
    });

    // First, register a command - a UI-less object associating an id to a handler
    // package-style naming to avoid collisions
    var ADD_CURR_TO_PROJ = 'vjsrinath.VisualStudioProjectSync.addCurrentFileToProject',
        REM_CURR_FROM_PROJ = 'vjsrinath.VisualStudioProjectSync.removeCurrentFileFromProject';
    CommandManager.register("Add to VS project", ADD_CURR_TO_PROJ, function () {

        var doc = DocumentManager.getCurrentDocument();
        if (doc && doc.file && doc.file.fullPath)
            addFileToProj(doc.file.fullPath);
    });

    CommandManager.register("Remove from VS project", REM_CURR_FROM_PROJ, function () {

        var doc = DocumentManager.getCurrentDocument();
        (doc && doc.file && doc.file.fullPath) && removeFileFromProj(doc.file.fullPath);
    });




    console.log('VisualStudioSync initalized.');
    console.info('Press ' + ADD_SHORTCUT + ' to add the current file to the visual studio project');
    console.info('Press ' + REM_SHORTCUT + ' to remove the current file to the visual studio project');

    menu.addMenuItem(ADD_CURR_TO_PROJ, ADD_SHORTCUT);
    menu.addMenuItem(REM_CURR_FROM_PROJ, REM_SHORTCUT);

});