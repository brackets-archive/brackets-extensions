# Pretty Light Theme for Brackets

A pretty light theme for [Brackets](http://brackets.io/), by [MMK Jony](https://github.com/mmkjony). This theme is designed with some pretty color-scheme to make your code-editor much eye-friendly and readable.

## HTML
![HTML Screenshot](http://i.imgur.com/9HR0nwG.png)

## CSS
![CSS Screenshot](http://i.imgur.com/2QSq5Zt.png)

## JavaScript
![JavaScript Screenshot](http://i.imgur.com/10n4E4R.png)

## PHP
![JavaScript Screenshot](http://i.imgur.com/dsAmaq6.png)

## Copyright and License
Copyright (c) 2015 [MMK Jony](https://github.com/mmkjony). Released under the [MIT License](LICENSE).
