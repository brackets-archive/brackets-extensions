No Highlight
------------
Brackets IDE Theme *without* syntax highlight support.


Currently there is over 9000 themes with color highlighting and just this one without it.

![screenshot](https://github.com/dnbard/no-highlight/blob/master/screenshots/screenshot.png?raw=true)