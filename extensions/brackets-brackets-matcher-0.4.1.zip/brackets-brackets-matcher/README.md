Brackets Matcher
==========

**Extension for [Adobe Brackets](http://brackets.io)**

Select code between "", '', ``, [], (), and {} when will automatically close brackets

##Disabling

Disable the extension for a specific project by adding the `"brackets-brackets-matcher.enabled": false`
key/value to a `.brackets.json` JSON file at the root of your project. Changing this may require
you to restart Brackets.

##Install

1. Open the Extension Manager
2. Search for "Brackets Matcher"
3. Click "install"
