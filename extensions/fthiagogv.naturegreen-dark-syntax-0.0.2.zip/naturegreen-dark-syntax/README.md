## Nature Green Dark Syntax theme

Made as from of a fork of One-dark-syntax theme.

![naturegreen](https://cloud.githubusercontent.com/assets/6399202/8463830/098df8c8-2014-11e5-80a4-0024ae6b083b.png)
