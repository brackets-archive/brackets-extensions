<?php
  public function name($something, $other) {

  }
?>
