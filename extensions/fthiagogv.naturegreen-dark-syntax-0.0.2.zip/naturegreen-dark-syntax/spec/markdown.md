# hello world
## hello world
### hello world
#### hello world
##### hello world
###### hello world

you can write text [with links](http://example.com) inline or [link references][1].

* one _thing_ has *em* phasis
* two __things__ are **bold**

[1]: http://example.com

---

hello world
===========

```html
<div class="main"></div>
```

> markdown is so cool

    so are code segments

1. one thing (yeah!)
2. two thing `i can write code`, and `more` wipee!
