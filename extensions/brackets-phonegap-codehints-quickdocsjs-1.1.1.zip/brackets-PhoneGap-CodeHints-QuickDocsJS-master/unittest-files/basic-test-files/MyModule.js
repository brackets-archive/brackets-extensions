/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, $ */
define(function (require, exports, module) {
    "use strict";
    exports.a = function (a, b) {};
    exports.b = function () {
        return "a string";
    };
    exports.j = "hi";
    

    function c() {
    }
    
    exports.c = 
        c;
});