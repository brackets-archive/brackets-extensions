define(function() {
  return {b: "b"};
});
