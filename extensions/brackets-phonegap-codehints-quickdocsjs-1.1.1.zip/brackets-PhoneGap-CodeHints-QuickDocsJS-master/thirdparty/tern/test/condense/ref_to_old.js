var myElement = new Date();
