var foo = {
  x: 10,
  y: 20
};
