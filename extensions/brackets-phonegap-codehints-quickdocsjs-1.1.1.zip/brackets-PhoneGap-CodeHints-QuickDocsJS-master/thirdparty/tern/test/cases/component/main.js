// plugin=component

require('./localfile').hey; //: fn() -> string
require('tern').hello; //: fn() -> number