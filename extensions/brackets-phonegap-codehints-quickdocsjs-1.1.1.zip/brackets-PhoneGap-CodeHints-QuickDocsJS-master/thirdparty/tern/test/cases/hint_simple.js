"x". //+ charAt, concat, ...
"x".ch //+ charAt, charCodeAt

(10).to //+ toFixed, toString, toLocaleString, toString

var a = [1];
a = 10;
a. //+ forEach, toFixed, ...

Object.crea //+ create @8
