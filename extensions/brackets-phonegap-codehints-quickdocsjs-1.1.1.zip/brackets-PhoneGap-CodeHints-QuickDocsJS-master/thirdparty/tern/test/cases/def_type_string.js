// environment=string

foo; //: string
