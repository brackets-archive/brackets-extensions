# Brackets Toggle Working Files Panel

To install, search for "Toggle Working Files" on Brackets Extention Manager, then click Install.

To toggle Working Files panel, go to View > Toggle Working Files.

Have fun coding ;-)
