#CopyCase

A brackets plugin to enable developers to copy the text while toggling the case of the content. This plugin currently enable converting `snake-case` to `CamelCase` and vice-versa.

This is particularly useful for Angular developers who might have to search for the toggled case content in the project.
