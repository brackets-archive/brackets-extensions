The Weaver Theme for Brackets
=============================

"Nature uses only the longest threads to weave her patterns, so that each small piece of her fabric reveals the organization of the entire tapestry." —Richard Feynman 

A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/TheWeaver/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/TheWeaver/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/TheWeaver/blob/master/screenshots/js.png)
