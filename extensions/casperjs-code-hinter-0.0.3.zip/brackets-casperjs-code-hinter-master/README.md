brackets-casperjs-code-hinter
===========================

Bracktes extensions.
