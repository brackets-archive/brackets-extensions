define(function(require, exports, module) {
  'use strict';

  const PREFIX = 'sizuhiko.brackets';

  module.exports = PREFIX;
});
