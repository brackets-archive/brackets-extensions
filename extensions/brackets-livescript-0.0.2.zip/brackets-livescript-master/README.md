Livescript Syntax Highlighting for Brackets
===========================================

Livescript Syntax Higlightng

How to Install
==============

1. Choose _File > Extension Manager_ and select the _Available_ tab
2. Search for this extension
3. Click _Install_!


Todo
====

- Auto Completion
- Livescript Integration 
    - Build
    - etc
    
### License
MIT-licensed -- see `LICENSE` for details.