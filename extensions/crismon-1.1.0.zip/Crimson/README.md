Crismon Theme
==============================================
Simple theme for brackets


### Supported Languages:
- **HTML,XML**
- **CSS, SCSS, SASS**
- **JavaScript**

Installation
---

1. Open Brackets
2. Open the Extension Manager
3. Switch to "Themes" tab
4. Search for "Monokai"
5. Click "Install"

## Screenshot
![alt text](https://github.com/hosein2398/Crimson/blob/master/screenshot/Screen.JPG)



