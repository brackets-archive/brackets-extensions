Brackets Pixlr
==============

Support of Pixlr image editor inside of Brackets IDE

![example](http://content.screencast.com/users/dnbard/folders/Jing/media/8323c77b-8ea0-41b0-99c8-0518c7a5c657/2014-08-07_1930.png)

Fully functional professional photo and image editing software inside Brackets IDE.

Warning: Flash Player should be installed!
