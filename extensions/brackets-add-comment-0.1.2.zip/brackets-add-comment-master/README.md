## Add Comments
If the cursor is in line of code is _/**_,press _Enter_. the comments auto generate
```javascript
/**
 * 
 * @param {Type} name
 * @param {Type} age
 * @param {Type} address
 */
function testFun(name, age, address){
    ...
}
```
