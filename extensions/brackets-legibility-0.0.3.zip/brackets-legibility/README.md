# brackets-legibility

Compatible with Sprint 45 and above

Increase the legibility (font-sizes, line-heights, heights, etc) of the following UI elements:

* Sidebar *including increasing the max-height on Working Files*
* Code Hints
* Dropdown Menus
* Status Bar
* Vertical Toolbar
* Modal Bar
* Bottom Panel
* Extension Modal