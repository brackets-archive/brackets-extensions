brackets-vagrant-extension
==========================

Brackets.io extension for vagrant
