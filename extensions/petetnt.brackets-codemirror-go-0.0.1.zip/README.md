# Brackets CodeMirror Go
## Go Programming Language syntax highlighter
Brings support for Go from CodeMirror to Brackets.
