brackets-roy
============

Code highlighting for Roy lang in Brackets.

Provides primitive highlighting for [Roy Lang](http://roy.brianmckenna.org/).

This extension is nothing more than wrapper of [Brian McKenna](https://github.com/puffnfresh/)'s [codemirror-roy-mode](https://github.com/puffnfresh/roy/tree/master/site/codemirror2/mode/roy).

## License

[MIT](http://opensource.org/licenses/mit)
