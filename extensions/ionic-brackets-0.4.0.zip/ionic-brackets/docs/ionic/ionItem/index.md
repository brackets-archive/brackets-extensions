














  
<h2 id="usage">Usage</h2>
  
```html
<ion-list>
  <ion-item>Hello!</ion-item>
  <ion-item href="#/detail">
    Link to detail page
  </ion-item>
</ion-list>
```
  
  

  





