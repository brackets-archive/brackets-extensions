














  
<h2 id="usage">Usage</h2>
  
```html
<ion-list show-delete="shouldShowDelete">
  <ion-item>
    <ion-delete-button class="ion-minus-circled"></ion-delete-button>
    Hello, list item!
  </ion-item>
</ion-list>
<ion-toggle ng-model="shouldShowDelete">
  Show Delete?
</ion-toggle>
```
  
  

  





