





Touch stays at the same location for 500ms. Similar to long touch events available for AngularJS and jQuery.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-hold="onHold()" class="button">Test</button>
```
  
  

  





