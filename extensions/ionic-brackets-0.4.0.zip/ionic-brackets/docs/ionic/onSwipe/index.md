





Called when a moving touch has a high velocity in any direction.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-swipe="onSwipe()" class="button">Test</button>
```
  
  

  





