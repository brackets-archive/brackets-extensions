





A simple container that fits content, with no side effects.  Adds the 'pane' class to the element.








  
<h2 id="usage">Usage</h2>
  
    

  ```html
  <ion-pane>
  ...
  </ion-pane>
  ```
    
  

  





