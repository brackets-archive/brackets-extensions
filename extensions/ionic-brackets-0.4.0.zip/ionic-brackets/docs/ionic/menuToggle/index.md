





Toggle a side menu on the given side.








  
<h2 id="usage">Usage</h2>
  
Below is an example of a link within a nav bar. Tapping this button
would open the given side menu, and tapping it again would close it.

```html
<ion-nav-bar>
  <ion-nav-buttons side="left">
   <button menu-toggle="left" class="button button-icon icon ion-navicon"></button>
  </ion-nav-buttons>
</ion-nav-bar>
```

### Button Hidden On Child Views
By default, the menu toggle button will only appear on a root level side-menu page.
Navigating in to child views will hide the menu-toggle button. They can be made visible
on child pages by setting the enable-menu-with-back-views attribute of the 
<a href="/docs/api/directive/ionSideMenus/"><code>ionSideMenus</code></a> directive to true.
  
  

  





