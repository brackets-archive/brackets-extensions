





Called when a moving touch has a high velocity moving up.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-swipe-up="onSwipeUp()" class="button">Test</button>
```
  
  

  





