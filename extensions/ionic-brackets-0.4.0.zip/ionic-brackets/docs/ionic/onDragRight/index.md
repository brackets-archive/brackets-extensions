





Called when the element is dragged to the right.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-drag-right="onDragRight()" class="button">Test</button>
```
  
  

  





