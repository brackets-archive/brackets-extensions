





Called when the user ends a touch.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-release="onRelease()" class="button">Test</button>
```
  
  

  





