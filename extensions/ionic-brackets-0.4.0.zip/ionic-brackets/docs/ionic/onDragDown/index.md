





Called when the element is dragged down.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-drag-down="onDragDown()" class="button">Test</button>
```
  
  

  





