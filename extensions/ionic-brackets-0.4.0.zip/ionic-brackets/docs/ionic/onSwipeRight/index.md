





Called when a moving touch has a high velocity moving to the right.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-swipe-right="onSwipeRight()" class="button">Test</button>
```
  
  

  





