





Called when a moving touch has a high velocity moving to the left.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-swipe-left="onSwipeLeft()" class="button">Test</button>
```
  
  

  





