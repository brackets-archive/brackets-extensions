





The transition type which the nav view transition should use when it animates.
Current, options are `ios`, `android`, and `none`. More options coming soon.








  
<h2 id="usage">Usage</h2>
  
```html
<a nav-transition="none" href="#/home">Home</a>
```
  
  

  





