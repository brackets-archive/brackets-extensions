





Called immediately when the user first begins a touch. This
gesture does not wait for a touchend/mouseup.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-touch="onTouch()" class="button">Test</button>
```
  
  

  





