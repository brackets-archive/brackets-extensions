





Called when a moving touch has a high velocity moving down.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-swipe-down="onSwipeDown()" class="button">Test</button>
```
  
  

  





