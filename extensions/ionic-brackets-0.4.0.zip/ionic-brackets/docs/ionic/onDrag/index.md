





Move with one touch around on the page. Blocking the scrolling when
moving left and right is a good practice. When all the drag events are
blocking you disable scrolling on that area.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-drag="onDrag()" class="button">Test</button>
```
  
  

  





