





Set the default options to be passed to the <a href="/docs/api/service/$ionicLoading/"><code>$ionicLoading</code></a> service.









## Usage
```js
var app = angular.module('myApp', ['ionic'])
app.constant('$ionicLoadingConfig', {
  template: 'Default Loading Template...'
});
app.controller('AppCtrl', function($scope, $ionicLoading) {
  $scope.showLoading = function() {
    $ionicLoading.show(); //options default to values in $ionicLoadingConfig
  };
});
```


  

  
  
  






