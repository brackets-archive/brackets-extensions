





keyboard-attach is an attribute directive which will cause an element to float above
the keyboard when the keyboard shows. Currently only supports the
[ion-footer-bar]({{ page.versionHref }}/api/directive/ionFooterBar/) directive.

### Notes
- This directive requires the
[Ionic Keyboard Plugin](https://github.com/driftyco/ionic-plugins-keyboard).
- On Android not in fullscreen mode, i.e. you have
  `<preference name="Fullscreen" value="false" />` or no preference in your `config.xml` file,
  this directive is unnecessary since it is the default behavior.
- On iOS, if there is an input in your footer, you will need to set
  `cordova.plugins.Keyboard.disableScroll(true)`.








  
<h2 id="usage">Usage</h2>
  
```html
 <ion-footer-bar align-title="left" keyboard-attach class="bar-assertive">
   <h1 class="title">Title!</h1>
 </ion-footer-bar>
```
  
  

  





