





The direction which the nav view transition should animate. Available options
are: `forward`, `back`, `enter`, `exit`, `swap`.








  
<h2 id="usage">Usage</h2>
  
```html
<a nav-direction="forward" href="#/home">Home</a>
```
  
  

  





