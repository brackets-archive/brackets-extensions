





Displays a slide inside of a slidebox.

For more complete examples, see <a href="/docs/nightly/api/directive/ionSlideBox/"><code>ionSlideBox</code></a>.








  
<h2 id="usage">Usage</h2>
  
```html
<ion-slide-box>
  <ion-slide>1</ion-slide>
  <ion-slide>2</ion-slide>
</ion-slide-box>
```
  
  

  





