





The nav title directive replaces an <a href="/docs/api/directive/ionNavBar/"><code>ionNavBar</code></a> title text with
custom HTML from within an <a href="/docs/api/directive/ionView/"><code>ionView</code></a> template. This gives each
view the ability to specify its own custom title element, such as an image or any HTML,
rather than being text-only. Alternatively, text-only titles can be updated using the
`view-title` <a href="/docs/api/directive/ionView/"><code>ionView</code></a> attribute.

Note that `ion-nav-title` must be an immediate descendant of the `ion-view` or
`ion-nav-bar` element (basically don't wrap it in another div).








  
<h2 id="usage">Usage</h2>
  
```html
<ion-nav-bar>
</ion-nav-bar>
<ion-nav-view>
  <ion-view>
    <ion-nav-title>
      <img src="logo.svg">
    </ion-nav-title>
    <ion-content>
      Some super content here!
    </ion-content>
  </ion-view>
</ion-nav-view>
```
  
  

  





