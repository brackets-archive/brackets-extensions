





Called when the element is dragged up.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-drag-up="onDragUp()" class="button">Test</button>
```
  
  

  





