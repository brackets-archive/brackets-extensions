





Called when the element is dragged to the left.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-drag-left="onDragLeft()" class="button">Test</button>
```
  
  

  





