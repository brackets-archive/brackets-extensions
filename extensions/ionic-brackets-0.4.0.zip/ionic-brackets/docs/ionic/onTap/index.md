





Quick touch at a location. If the duration of the touch goes
longer than 250ms it is no longer a tap gesture.








  
<h2 id="usage">Usage</h2>
  
```html
<button on-tap="onTap()" class="button">Test</button>
```
  
  

  





