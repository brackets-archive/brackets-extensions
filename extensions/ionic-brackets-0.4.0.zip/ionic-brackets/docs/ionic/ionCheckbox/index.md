







The checkbox is no different than the HTML checkbox input, except it's styled differently.

The checkbox behaves like any [AngularJS checkbox](http://docs.angularjs.org/api/ng/input/input[checkbox]).








  
<h2 id="usage">Usage</h2>
  
```html
<ion-checkbox ng-model="isChecked">Checkbox Label</ion-checkbox>
```
  
  

  





