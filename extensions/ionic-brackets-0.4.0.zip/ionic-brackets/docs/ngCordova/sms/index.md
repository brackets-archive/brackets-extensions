

Easily send SMS natively in iOS or Android SMS app

```
cordova plugin add https://github.com/aharris88/phonegap-sms-plugin.git
```


#### Example

```javascript
module.controller('ThisCtrl', function($cordovaSMS) {


});
```
