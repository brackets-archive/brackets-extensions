

The [BatteryStatus](https://github.com/apache/cordova-plugin-battery-status) plugin provides an API for the current battery status.

```bash
cordova plugin add org.apache.cordova.battery-status
```


```javascript

module.controller('MyCtrl', function($scope, $cordovaBatteryStatus) {

  $cordovaBatteryStatus.$on('batterystatus', function (result) {
    var batteryLevel = result.level;       // (0 - 100)
    var isPluggedIn  = result.isPlugged;   // bool
  });

  $cordovaBatteryStatus.$on('batterycritical', function (result) {
    var batteryLevel = result.level;       // (0 - 100)
    var isPluggedIn  = result.isPlugged;   // bool
  });

  $cordovaBatteryStatus.$on('batterylow', function (result) {
    var batteryLevel = result.level;       // (0 - 100)
    var isPluggedIn  = result.isPlugged;   // bool
  });

});

```