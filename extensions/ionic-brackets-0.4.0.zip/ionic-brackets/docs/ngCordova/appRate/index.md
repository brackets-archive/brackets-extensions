

The [AppRate](https://github.com/pushandplay/cordova-plugin-apprate) plugin makes it easy to prompt the user to rate your app, either no or later, or never.


```bash
cordova plugin add https://github.com/pushandplay/cordova-plugin-apprate.git
```


```javascript

module.controller('MyCtrl', function($scope, $cordovaAppRate) {

  $cordovaAppRate.promptForRating(true).then(function (result) {
    // success
  });
});
```
