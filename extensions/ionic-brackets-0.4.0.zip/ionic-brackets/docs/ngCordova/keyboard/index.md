

Accessing the Keyboard of iOS from cordova

```
cordova plugin add https://github.com/driftyco/ionic-plugins-keyboard.git
```


```javascript
module.controller('MyCtrl', function($scope, $cordovaKeyboard) {

  $cordovaKeyboard.hideAccessoryBar(true)

  $cordovaKeyboard.disableScroll(true)

  $cordovaKeyboard.close()

  var isVisible = $cordovaKeyboard.isVisible()

});
```

