


Unzip a file.

```
cordova plugin add https://github.com/MobileChromeApps/zip.git
```

```javascript
module.controller('MyCtrl', function($scope, $cordovaZip) {

  $cordovaZip
    .unzip(
      src, // https://github.com/MobileChromeApps/zip/blob/master/tests/tests.js#L32
      dest // https://github.com/MobileChromeApps/zip/blob/master/tests/tests.js#L45
    ).then(function () {
      console.log('success');
    }, function () {
      console.log('error');
    }, function (progressEvent) {
      // https://github.com/MobileChromeApps/zip#usage
      console.log(progressEvent);
    });
});
```