

The [AdMob](https://github.com/floatinghotpot/cordova-admob-pro) plugin presents AdMob Ads in Mobile App/Games natively from JavaScript.


```bash
cordova plugin add com.google.cordova.admob
```


```javascript

module.controller('AdMobCtrl', function($scope, $cordovaAdMob) {
    // AdMob implementation here
    // coming soon...
});
```