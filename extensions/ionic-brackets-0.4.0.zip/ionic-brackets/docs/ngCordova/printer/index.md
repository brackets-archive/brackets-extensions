

Printer plugin

```
cordova plugin add https://github.com/katzer/cordova-plugin-printer.git
```

```javascript
module.controller('MyCtrl', function($scope, $cordovaPrinter) {

  var printerAvail = $cordovaPrinter.isAvailable()

  var doc = "<html> ... </html>";
  $cordovaPrinter.print(doc)
});
```
