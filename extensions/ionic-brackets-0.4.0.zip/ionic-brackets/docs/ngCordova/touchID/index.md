

Cordova Plugin to leverage the iOS local authentication framework to allow in-app user authentication using Touch ID.

```
cordova plugin add uk.co.ilee.touchid
```

```javascript
module.controller('MyCtrl', function($cordovaTouchID) {

  $cordovaTouchID.checkSupport().then(function() {
    // success, TouchID supported
  }, function (error) {
    alert(error); // TouchID not supported
  });

  $cordovaTouchID.authenticate("text").then(function() {
    // success
  }, function () {
    // error
  });

});
```
