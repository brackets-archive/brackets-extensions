

A dialog with a spinner wheel.

```
cordova plugin add https://github.com/Paldom/SpinnerDialog.git
```

#### Methods

##### `show(title, message, persistent)`


| Param        | Type           | Detail  |
| ------------ |----------------| --------|
| title        | `String`       | Title of the spinner dialog. Leave blank for no title |
| message      | `String`       | Message of the spinner dialog. Leave blank for no message |
| persistent   | `Boolean`      | `true` to stop the user from dismissing the dialog with touch. `false` to allow touch to dismiss dialog.|


##### `hide()`

Hides the spinner dialog, which is currently in the view.


#### Example

```javascript
module.controller('MyCtrl', function($scope, $cordovaSpinnerDialog) {

  $cordovaSpinnerDialog.show("title","message", true);

  $cordovaSpinnerDialog.hide();
});
```


