

Reads the version of your app from the target build settings.

```bash
cordova plugin add https://github.com/whiteoctober/cordova-plugin-app-version.git
```

#### Methods

##### `getAppVersion()`

Get the version of the current app running.

**Returns**  `String`, with the app-version


#### Example

```javascript

module.controller('myCtrl', function($scope, $cordovaAppVersion) {

  $cordovaAppVersion.getAppVersion().then(function (version) {
    var appVersion = version;
  });
});
```