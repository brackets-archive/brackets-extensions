# somethingBlue
A blueprint theme for Brackets


# Install
1. Open Brackets
2. Open the Extension Manager
3. Navigate to the "Themes" tab
4. Search, "somethingBlue"
5. Click install on the theme titled, "somethingBlue"
6. Go to View > Themes and select the somethingBlue.

# Preview
<a href="http://i.imgur.com/iJRarGF.png"><img src="http://i.imgur.com/iJRarGF.png" title="somethingBlue Preview" /></a>