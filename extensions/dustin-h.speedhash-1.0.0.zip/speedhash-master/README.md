Speed Hash
=========

Speed Hash is a simple Brackes Extension which hashes oninput the current file. So you can easily compare documents.

(c) 2014 by Dustin Hoffner

MIT Licence
