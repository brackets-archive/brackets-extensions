/*jslint vars: true, plusplus: true, nomen: true, indent: 4 */
/*global define, brackets, $ */

define(function (require, exports, module) {

    "use strict";

    // Brackets modules
    var AppInit             = brackets.getModule("utils/AppInit"),
        EditorManager       = brackets.getModule("editor/EditorManager"),
        DocumentManager     = brackets.getModule("document/DocumentManager"),
        Menus               = brackets.getModule("command/Menus"),
        PreferencesManager  = brackets.getModule("preferences/PreferencesManager"),
        KeyEvent            = brackets.getModule("utils/KeyEvent"),
        CommandManager      = brackets.getModule("command/CommandManager");

    var EXTENSION_ID        = "winek.brackets-chain-indents",
        prefs               = PreferencesManager.getExtensionPrefs(EXTENSION_ID),
        enabled             = true;

    function _createIndentation(editor) {
        if (editor._codeMirror.getOption("indentWithTabs")) {
            return "\t";
        } else {
            var indent = "";
            for (var i = 0, spaceUnits = editor._codeMirror.getOption("indentUnit"); i < spaceUnits; i += 1) {
                indent += " ";
            }
            return indent;
        }
    }

    // Function to handle pressed keys
    function _handleKey($event, editor, event) {
        if (!enabled) {
            return;
        }

        if (event.type === "keydown" && event.keyCode === KeyEvent.DOM_VK_PERIOD) {
            if (DocumentManager.getCurrentDocument().getLanguage()._id === "javascript") {
                var cursorPos = editor.getCursorPos();
                var ch = cursorPos.ch;
                var line = editor.document.getLine(cursorPos.line);

                // If the line is empty or just whitespace
                if (/^[\s\t]*$/.test(line)) {
                    var start = {
                        line: cursorPos.line,
                        ch: cursorPos.ch
                    },
                        indent = _createIndentation(editor);

                    editor.document.replaceRange(indent, start, cursorPos);
                }
            }
        }
    }

    var _activeEditorChangeHandler = function ($event, focusedEditor, lostEditor) {
        if (lostEditor) {
            $(lostEditor).off("keyEvent", _handleKey);
        }
        if (focusedEditor) {
            $(focusedEditor).on("keyEvent", _handleKey);
        }
    };

    AppInit.appReady(function () {
        var currentEditor = EditorManager.getCurrentFullEditor();
        $(currentEditor).on("keyEvent", _handleKey);
        $(EditorManager).on("activeEditorChange", _activeEditorChangeHandler);
    });

    var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU),
        COMMAND_ID = EXTENSION_ID + ".enabled",
        _setEnabled = function () {
            var en = !this.getChecked();
            prefs.set("enabled", en);
            prefs.save();
        },
        command = CommandManager.register("Chain Indents", COMMAND_ID, _setEnabled);

    prefs.definePreference("enabled", "boolean", "true").on("change", function () {
        enabled = prefs.get("enabled");
        console.log(enabled);
        command.setChecked(enabled);
    });

    command.setChecked(enabled);

    menu.addMenuDivider();
    menu.addMenuItem(COMMAND_ID);

});
