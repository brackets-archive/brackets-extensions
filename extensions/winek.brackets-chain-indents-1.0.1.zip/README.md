# Brackets Chain Indents

If you enjoy jQuery-like method chaining, and use additional indentation level for chained API calls,
but you are annoyed when Brackets continuously returns to the previous indentation level on each call,
then this extension is for you.

Basically, when it sees a dot at the beginning of line in a JavaScript file, it adds a level of indentation
(so you even don't have to delete tabs).

## Contribution

All issues and pull requests are welcome!

## License

The extension is licensed [WTFPL](http://wtfpl.net/about) - you just do what you want to.
