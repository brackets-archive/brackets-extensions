# Changelog

## 1.3.10 (07/22/2017)
* Polish translation by [Michał Korczak](https://github.com/MajkelKorczak)

## 1.3.9 (04/23/2017)
* Swedish translation by [Mikael Jorhult](https://github.com/mikaeljorhult)

## 1.3.8 (04/22/2017)
* German translation by [FW](https://github.com/tweakimp)

## 1.3.7 (04/08/2017)
* Add support for multiple languages

## 1.3.6 (04/07/2017)
* Added screenshots
* Added Change Log
