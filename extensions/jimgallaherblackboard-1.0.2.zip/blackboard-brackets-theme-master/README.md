# Blackboard-bracket-theme

Blackboard for Brackets is based on Sublime Text's Blackboard theme.

Author: Jim Gallaher

![screen shot](blackboard_screenshot.png)