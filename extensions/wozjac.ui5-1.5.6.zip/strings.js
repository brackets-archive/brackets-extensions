define((require, exports, module) => {
    "use strict";

    module.exports = require("nls/root/strings");
});
