flat-theme
==========
A flat theme for brackets. Use with care.
![Flat theme](https://raw.githubusercontent.com/reginbald/flat-theme/master/img/screenshot.png "Flat theme")

