# W3Schools


This is an extension created for [Brackets 1.0 or later](http://brackets.io/). 

It adds a link:

* In `Help` menu
[W3School](http://www.w3schools.com/), [Mozilla Developer Network (MDN)](https://developer.mozilla.org/), [Developer List on Google Groups](https://groups.google.com/forum/#!forum/brackets-dev), [Trello](https://trello.com/b/LCDud1Nd/brackets), [Waffle](https://waffle.io/adobe/brackets)
* In `View` menu
[Brackets Themes (WEB site)](http://brackets-themes.github.io/)

###### Languages supported (English and Italian).
Please help me to translate it in other languages!

# Extension installation

### Installing into Brackets

1. Choose **File > Extension Manager...**
2. Search for "Tutorials"
3. Click the `Install` button

# License

* Theme under MIT license [`LICENSE`](LICENSE)
