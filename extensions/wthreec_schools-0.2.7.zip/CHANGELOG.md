CHANGELOG
=========

V 0.1.2

* Fix issue https://github.com/Denisov21/W3Schools/issues/1
* Fix link (http://www.w3schools.com/)
* Update ReadMe.md

V 0.1.3

* Fix issue https://github.com/Denisov21/W3Schools/issues/2
* Add link (https://developer.mozilla.org)
* Update ReadMe.md
* Add divisor in Help menu

V 0.1.4

* Fix issue https://github.com/Denisov21/W3Schools/issues/3

V 0.2.0

* Fix error in Help menu.
* Add link Brackets-Dev

v 0.2.1

* Add link Brackets Themes
* Rename Brackets-Dev

v 0.2.2

* Rename many items
* Add Trello Web site

v 0.2.4

* Rename many items
* Add Multilanguage (EN)
* Add Waffle Web site
* Update ReadME.md

v 0.2.6

* Fix any errors

v 0.2.7

* Add Brackets Wiki
