Important: There is not much to fork here, but if it will help you, feel free to use the code.

Brackets-Silverstripe
=====================

Silverstripe for Brackets is an extensions which adds Silverstripe specific features to Brackets language modes.

####Installation
Run Brackets, go to Extension Manager (on the right) and search for "bracket-silverstripe" in Available tab.  

####Changelog & To-Do

0.0.2  
-released to extension manager with fixed data

0.0.1  
-extends html mode to support Silverstripe files  
-uses <%-- --%> for block comment  


To Do:  
-move from HTML extension to overlay or multiplex ?? (syntax highlighting, coming after sprint 34)  
-accept EchoData and EchoDataEscape coloring  
-improved comment support  
-add text-based tagging

