function funcExt() {
    return "funcExt called";
}
