function func1() {
    return "func1 called";
}

/*
 * function comment
 */
var func2 = function() {
    return "func2 called";
}
