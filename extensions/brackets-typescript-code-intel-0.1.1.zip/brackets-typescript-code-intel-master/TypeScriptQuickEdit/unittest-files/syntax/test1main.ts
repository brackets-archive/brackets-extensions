///<reference path='test1inline.ts'/>

{{31}}function func3() {
    // comment
}

var a = {{10}}func1();
var b = fun{{20}}c2();
var c = func3{{30}}();

// instance doc
{{41}}var greeter = new {{50}}Greeter("world");

{{40}}greeter.{{60}}greeting = "brackets";

greeter.{{70}}sayHello();
