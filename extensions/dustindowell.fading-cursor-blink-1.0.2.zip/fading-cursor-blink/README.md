Fading Cursor Blink - 1.0.2
=========


## Gif
![Gif](https://github.com/dustindowell22/fading-cursor-blink-brackets-extension/blob/master/preview.gif)
