Changelog
=========

**February 8, 2015**
+ 1.0.2
  + Animated `.CodeMirror-cursors` instead of `.CodeMirror-cursor` which prevents a double blink after typing

**February 6, 2015**
+ 1.0.1
  + Completely removed CodeMirror blinking

+ 1.0.0
  + Commited Project
