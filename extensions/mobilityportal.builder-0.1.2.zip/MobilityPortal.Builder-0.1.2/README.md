# Mobility Portal Builder

This extension for the [Brackets](http://brackets.io) Editor allows to immediately preview [Mobility Portal](http://www.mobilityportal.com) apps.

The extension adds also code hinting for [Polymer](https://www.polymer-project.org) iron and paper [elements](https://elements.polymer-project.org/) as well as adenin Tangere elements.

## Screenshot
![Mobile Preview](https://raw.githubusercontent.com/MobilityPortal/MobilityPortal.Builder/master/screenshots/MobilePreview.png)  
*Mobile Preview*
