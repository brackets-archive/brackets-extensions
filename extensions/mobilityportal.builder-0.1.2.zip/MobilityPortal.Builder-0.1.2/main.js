define(function (require, exports, module) {
	"use strict";

	var CommmandManager = brackets.getModule("command/CommandManager");
	var Menus = brackets.getModule("command/Menus");
	var DocumentManager = brackets.getModule("document/DocumentManager");
	var EditorManager = brackets.getModule("editor/EditorManager");
	var Resizer = brackets.getModule("utils/Resizer");
	var AppInit = brackets.getModule("utils/AppInit");
	var ExtensionUtils = brackets.getModule("utils/ExtensionUtils");
	var NativeApp = brackets.getModule('utils/NativeApp');
	var _ = brackets.getModule("thirdparty/lodash");
	var PreferencesDialogs = brackets.getModule("preferences/PreferencesDialogs");
	var ProjectManager = brackets.getModule("project/ProjectManager");
	var CodeHintManager = brackets.getModule("editor/CodeHintManager");
	var HTMLUtils = brackets.getModule("language/HTMLUtils");
	var HTMLTags = require("text!src/HtmlTags.json");
	var HTMLAttributes = require("text!src/HtmlAttributes.json");
	var Strings = require("strings");
	var prefs = require("src/Preferences");
	var BuilderTemplate = require("text!templates/preview.html");

	var tags, attributes;

	ExtensionUtils.loadStyleSheet(module, "styles/styles.css");

	var prefix = "tangere.preview";

	function getPreview() {
		var $preview = Mustache.render(BuilderTemplate, {
			Strings: Strings
		});
		$preview = $($preview);

		$preview.on("click", "#preview-close", toggleEnabled);
		return $preview;
	}

	function goToLine(event) {
		var currentEditor = EditorManager.getActiveEditor();
		currentEditor.setCursorPos(event.data.line, event.data.ch, true);
		currentEditor.focus();
	}

	function getDocUrl() {

		var url = "";
		var component = "";
		var containsComponentFolder = false;
		var root = ProjectManager.getProjectRoot()._contents;

		for (var i = 0; i < root.length; i++) {
			if (root[i].name.toLowerCase() == "components" || root[i].name.toLowerCase() == "bower_components") {
				containsComponentFolder = root[i].isDirectory;
			}
		}

		var doc = DocumentManager.getCurrentDocument();
		var baseUrl = ProjectManager.getBaseUrl();

		// prompt for baseUrl if not yet provided
		if (!baseUrl) {
			PreferencesDialogs.showProjectPreferencesDialog("", Strings.LIVE_DEV_NEED_BASEURL_MESSAGE);
			baseUrl = ProjectManager.getBaseUrl();
			if (!baseUrl) {
				disablePreview(); // hide preview when no baseUrl is provided
				return "";
			}
		}

		if (doc) {
			var fname = doc.file.name;

			if (containsComponentFolder) {
				var fsegs = doc.file.parentPath.split("/");
				for (var i = 0; i < fsegs.length; i++) {
					if (fsegs[i].toLowerCase() == "components" || fsegs[i].toLowerCase() == "bower_components") {
						component = fsegs[i + 1];
						break;
					}
				}

				url = "components/" + component + "/" + fname;

				// check if the file is a component 
				// a) .html file
				// b) dash in file name
				// c) no <html in the file
				if (fname.indexOf("-") > 0 && fname.indexOf(".html") > 0) {
					// if filename is a component-name.html then url = app url
					if (doc.getText().indexOf("<html") == -1) {
						url = "App#!" + component + "/" + fname.replace(".html", "");
					}
				}
			}
		}

		url = baseUrl + url;
		return url;
	}


	function updatePreview() {

		var url = getDocUrl();

		if (!url) {
			disablePreview(); // hide preview when no baseUrl is provided
			return;
		}

		console.log("update preview " + url);
		updateTheme();
		showPreview(url);

	}

	function updateTheme() {
		var dark = prefs.get("dark");
		var frame = $("#device-frame");

		if (frame.length == 1) {
			frame = frame[0];
			frame.className = "marvel-device iphone5s " + (dark ? "silver" : "black");
		}

		$("#preview").attr('class', "preview-main quiet-scrollbars " + (prefs.get("dark") ? "theme-dark" : "theme-light"));
	}

	function onResize() {
		var toolbarPx = $("#main-toolbar:visible").width() || 0;
		$(".content").css("right", ($("#preview").width() || 0) + toolbarPx + "px");
	}

	function showPreview(url) {
		var iframe = $("#device-iframe");

		// iframe exists already -- just refresh
		if (iframe.length == 1) {
			iframe = iframe[0];
			iframe.src = "about:blank"; // clear current page to force refresh

			setTimeout(function () {
				iframe.src = url;
			}, 100);

			return;
		}
		var $preview = getPreview();

		var toolbarPx = $("#main-toolbar:visible").width() || 0;
		$(".main-view").append($preview);
		$("#preview").css("right", toolbarPx + "px");
		$("#preview").attr('class', "preview-main quiet-scrollbars " + (prefs.get("dark") ? "theme-dark" : "theme-light"));

		iframe = $("#device-iframe")[0];
		iframe.src = url;

		Resizer.makeResizable($preview, "horz", "left", 150);
		$preview.on("panelResizeUpdate", onResize);
		onResize();

		Menus.ContextMenu.assignContextMenuToSelector("#preview-settings", settingsMenu);
	}

	function hidePreview(onHideCompleted) {
		$("#preview").remove();
		onResize();
		if (onHideCompleted) {
			onHideCompleted();
		}
		prefs.togglePref("enabled", false); // force enabled to false
	}

	function enablePreview() {
		$("#preview-toolbar-icon").addClass("enabled");
		EditorManager.on("activeEditorChange", updatePreview);
		DocumentManager.on("documentSaved", updatePreview);
		updatePreview();
	}

	function disablePreview() {
		hidePreview();
		$("#preview-toolbar-icon").removeClass("enabled");
		EditorManager.off("activeEditorChange", updatePreview);
		DocumentManager.off("documentSaved", updatePreview);
	}

	function toggleEnabled() {
		if (prefs.togglePref("enabled")) {
			enablePreview();
		} else {
			disablePreview();
		}
	}

	function openInBrowser() {
		var url = getDocUrl();
		if (url) {
			NativeApp.openURLInDefaultBrowser('"' + url + '"');
		}
	}


	/* Create Settings Context Menu */
	var settingsMenu = Menus.registerContextMenu("hirse-preview-context-menu");
	_.each(prefs.getSettings(), function (status, key) {
		var commandName = prefix + "." + key;
		var commandString = Strings["COMMAND_" + key.toUpperCase()];
		var command = CommmandManager.register(commandString, commandName, function () {
			var checked = prefs.togglePref(commandName.split(".")[2]);
			command.setChecked(checked);
			updatePreview();
		});
		command.setChecked(status);
		settingsMenu.addMenuItem(command);
	});

	/* Create Toolbar Icons */
	$(document.createElement("a"))
		.attr("id", "preview-toolbar-icon")
		.attr("href", "#")
		.attr("title", Strings.TOOLBAR_ICON_TOOLTIP)
		.on("click", toggleEnabled)
		.appendTo($("#main-toolbar .buttons"));


	$(document.createElement("a"))
		.attr("id", "oib-toolbar-icon")
		.attr("href", "#")
		.attr("title", Strings.TOOLBAR_OIB_TOOLTIP)
		.on("click", openInBrowser)
		.appendTo($("#main-toolbar .buttons"));


	AppInit.appReady(onResize);
	if (prefs.get("enabled")) {
		var baseUrl = ProjectManager.getBaseUrl();
		if (!baseUrl) {
			disablePreview(); // disable preview if no baseUrl is available
		} else {
			enablePreview();
		}

	}


	//--- Code Hints -----------------------------------------
	/**
	 * @constructor
	 */
	function TagHints() {
		this.exclusion = null;
	}

	/**
	 * Check whether the exclusion is still the same as text after the cursor. 
	 * If not, reset it to null.
	 */
	TagHints.prototype.updateExclusion = function () {
		var textAfterCursor;
		if (this.exclusion && this.tagInfo) {
			textAfterCursor = this.tagInfo.tagName.substr(this.tagInfo.position.offset);
			if (!CodeHintManager.hasValidExclusion(this.exclusion, textAfterCursor)) {
				this.exclusion = null;
			}
		}
	};

	/**
	 * Determines whether HTML tag hints are available in the current editor
	 * context.
	 * 
	 * @param {Editor} editor 
	 * A non-null editor object for the active window.
	 *
	 * @param {string} implicitChar 
	 * Either null, if the hinting request was explicit, or a single character
	 * that represents the last insertion and that indicates an implicit
	 * hinting request.
	 *
	 * @return {boolean} 
	 * Determines whether the current provider is able to provide hints for
	 * the given editor context and, in case implicitChar is non- null,
	 * whether it is appropriate to do so.
	 */
	TagHints.prototype.hasHints = function (editor, implicitChar) {
		var pos = editor.getCursorPos();

		this.tagInfo = HTMLUtils.getTagInfo(editor, pos);
		this.editor = editor;
		if (implicitChar === null) {
			if (this.tagInfo.position.tokenType === HTMLUtils.TAG_NAME) {
				if (this.tagInfo.position.offset >= 0) {
					if (this.tagInfo.position.offset === 0) {
						this.exclusion = this.tagInfo.tagName;
					} else {
						this.updateExclusion();
					}
					return true;
				}
			}
			return false;
		} else {
			if (implicitChar === "<") {
				this.exclusion = this.tagInfo.tagName;
				return true;
			}
			return false;
		}
	};

	/**
	 * Returns a list of availble HTML tag hints if possible for the current
	 * editor context. 
	 *
	 * @return {jQuery.Deferred|{
	 *              hints: Array.<string|jQueryObject>,
	 *              match: string,
	 *              selectInitial: boolean,
	 *              handleWideResults: boolean}}
	 * Null if the provider wishes to end the hinting session. Otherwise, a
	 * response object that provides:
	 * 1. a sorted array hints that consists of strings
	 * 2. a string match that is used by the manager to emphasize matching
	 *    substrings when rendering the hint list
	 * 3. a boolean that indicates whether the first result, if one exists,
	 *    should be selected by default in the hint list window.
	 * 4. handleWideResults, a boolean (or undefined) that indicates whether
	 *    to allow result string to stretch width of display.
	 */
	TagHints.prototype.getHints = function (implicitChar) {
		var query,
			result;

		this.tagInfo = HTMLUtils.getTagInfo(this.editor, this.editor.getCursorPos());
		if (this.tagInfo.position.tokenType === HTMLUtils.TAG_NAME) {
			if (this.tagInfo.position.offset >= 0) {
				this.updateExclusion();
				query = this.tagInfo.tagName.slice(0, this.tagInfo.position.offset);
				result = $.map(tags, function (value, key) {
					if (key.indexOf(query) === 0) {
						return key;
					}
				}).sort();

				return {
					hints: result,
					match: query,
					selectInitial: true,
					handleWideResults: false
				};
			}
		}

		return null;
	};

	/**
	 * Inserts a given HTML tag hint into the current editor context. 
	 * 
	 * @param {string} hint 
	 * The hint to be inserted into the editor context.
	 *
	 * @return {boolean} 
	 * Indicates whether the manager should follow hint insertion with an
	 * additional explicit hint request.
	 */
	TagHints.prototype.insertHint = function (completion) {
		var start = {
				line: -1,
				ch: -1
			},
			end = {
				line: -1,
				ch: -1
			},
			cursor = this.editor.getCursorPos(),
			charCount = 0;

		if (this.tagInfo.position.tokenType === HTMLUtils.TAG_NAME) {
			var textAfterCursor = this.tagInfo.tagName.substr(this.tagInfo.position.offset);
			if (CodeHintManager.hasValidExclusion(this.exclusion, textAfterCursor)) {
				charCount = this.tagInfo.position.offset;
			} else {
				charCount = this.tagInfo.tagName.length;
			}
		}

		end.line = start.line = cursor.line;
		start.ch = cursor.ch - this.tagInfo.position.offset;
		end.ch = start.ch + charCount;

		if (this.exclusion || completion !== this.tagInfo.tagName) {
			if (start.ch !== end.ch) {
				this.editor.document.replaceRange(completion, start, end);
			} else {
				this.editor.document.replaceRange(completion, start);
			}
			this.exclusion = null;
		}

		return false;
	};

	/**
	 * @constructor
	 */
	function AttrHints() {
		this.globalAttributes = this.readGlobalAttrHints();
		this.cachedHints = null;
		this.exclusion = "";
	}

	/**
	 * @private
	 * Parse the code hints from JSON data and extract all hints from property names.
	 * @return {!Array.<string>} An array of code hints read from the JSON data source.
	 */
	AttrHints.prototype.readGlobalAttrHints = function () {
		return $.map(attributes, function (value, key) {
			if (value.global === "true") {
				return key;
			}
		});
	};

	/**
	 * Helper function that determines the possible value hints for a given html tag/attribute name pair
	 * 
	 * @param {{queryStr: string}} query
	 * The current query
	 *
	 * @param {string} tagName 
	 * HTML tag name
	 *
	 * @param {string} attrName 
	 * HTML attribute name
	 *
	 * @return {{hints: Array.<string>|$.Deferred, sortFunc: ?Function}} 
	 * The (possibly deferred) hints and the sort function to use on thise hints.
	 */
	AttrHints.prototype._getValueHintsForAttr = function (query, tagName, attrName) {
		// We look up attribute values with tagName plus a slash and attrName first.  
		// If the lookup fails, then we fall back to look up with attrName only. Most 
		// of the attributes in JSON are using attribute name only as their properties, 
		// but in some cases like "type" attribute, we have different properties like 
		// "script/type", "link/type" and "button/type".
		var hints = [],
			sortFunc = null;

		var tagPlusAttr = tagName + "/" + attrName,
			attrInfo = attributes[tagPlusAttr] || attributes[attrName];

		if (attrInfo) {
			if (attrInfo.type === "boolean") {
				hints = ["false", "true"];
			} else if (attrInfo.attribOption) {
				hints = attrInfo.attribOption;
			}
		}

		return {
			hints: hints,
			sortFunc: sortFunc
		};
	};

	/**
	 * Check whether the exclusion is still the same as text after the cursor. 
	 * If not, reset it to null.
	 *
	 * @param {boolean} attrNameOnly
	 * true to indicate that we update the exclusion only if the cursor is inside an attribute name context.
	 * Otherwise, we also update exclusion for attribute value context.
	 */
	AttrHints.prototype.updateExclusion = function (attrNameOnly) {
		if (this.exclusion && this.tagInfo) {
			var tokenType = this.tagInfo.position.tokenType,
				offset = this.tagInfo.position.offset,
				textAfterCursor;

			if (tokenType === HTMLUtils.ATTR_NAME) {
				textAfterCursor = this.tagInfo.attr.name.substr(offset);
			} else if (!attrNameOnly && tokenType === HTMLUtils.ATTR_VALUE) {
				textAfterCursor = this.tagInfo.attr.value.substr(offset);
			}
			if (!CodeHintManager.hasValidExclusion(this.exclusion, textAfterCursor)) {
				this.exclusion = null;
			}
		}
	};

	/**
	 * Determines whether HTML attribute hints are available in the current 
	 * editor context.
	 * 
	 * @param {Editor} editor 
	 * A non-null editor object for the active window.
	 *
	 * @param {string} implicitChar 
	 * Either null, if the hinting request was explicit, or a single character
	 * that represents the last insertion and that indicates an implicit
	 * hinting request.
	 *
	 * @return {boolean} 
	 * Determines whether the current provider is able to provide hints for
	 * the given editor context and, in case implicitChar is non-null,
	 * whether it is appropriate to do so.
	 */
	AttrHints.prototype.hasHints = function (editor, implicitChar) {
		var pos = editor.getCursorPos(),
			tokenType,
			offset,
			query;

		this.editor = editor;
		this.tagInfo = HTMLUtils.getTagInfo(editor, pos);
		tokenType = this.tagInfo.position.tokenType;
		offset = this.tagInfo.position.offset;
		if (implicitChar === null) {
			query = null;

			if (tokenType === HTMLUtils.ATTR_NAME) {
				if (offset >= 0) {
					query = this.tagInfo.attr.name.slice(0, offset);
				}
			} else if (tokenType === HTMLUtils.ATTR_VALUE) {
				if (this.tagInfo.position.offset >= 0) {
					query = this.tagInfo.attr.value.slice(0, offset);
				} else {
					// We get negative offset for a quoted attribute value with some leading whitespaces 
					// as in <a rel= "rtl" where the cursor is just to the right of the "=".
					// So just set the queryStr to an empty string. 
					query = "";
				}

				// If we're at an attribute value, check if it's an attribute name that has hintable values.
				if (this.tagInfo.attr.name) {
					var hintsAndSortFunc = this._getValueHintsForAttr({
							queryStr: query
						},
						this.tagInfo.tagName,
						this.tagInfo.attr.name);
					var hints = hintsAndSortFunc.hints;
					if (hints instanceof Array) {
						// If we got synchronous hints, check if we have something we'll actually use
						var i, foundPrefix = false;
						for (i = 0; i < hints.length; i++) {
							if (hints[i].indexOf(query) === 0) {
								foundPrefix = true;
								break;
							}
						}
						if (!foundPrefix) {
							query = null;
						}
					}
				}
			}

			if (offset >= 0) {
				if (tokenType === HTMLUtils.ATTR_NAME && offset === 0) {
					this.exclusion = this.tagInfo.attr.name;
				} else {
					this.updateExclusion(false);
				}
			}

			return query !== null;
		} else {
			if (implicitChar === " " || implicitChar === "'" ||
				implicitChar === "\"" || implicitChar === "=") {
				if (tokenType === HTMLUtils.ATTR_NAME) {
					this.exclusion = this.tagInfo.attr.name;
				}
				return true;
			}
			return false;
		}
	};

	/**
	 * Returns a list of availble HTML attribute hints if possible for the 
	 * current editor context. 
	 *
	 * @return {jQuery.Deferred|{
	 *              hints: Array.<string|jQueryObject>,
	 *              match: string,
	 *              selectInitial: boolean,
	 *              handleWideResults: boolean}}
	 * Null if the provider wishes to end the hinting session. Otherwise, a
	 * response object that provides:
	 * 1. a sorted array hints that consists of strings
	 * 2. a string match that is used by the manager to emphasize matching
	 *    substrings when rendering the hint list
	 * 3. a boolean that indicates whether the first result, if one exists,
	 *    should be selected by default in the hint list window.
	 * 4. handleWideResults, a boolean (or undefined) that indicates whether
	 *    to allow result string to stretch width of display.
	 */
	AttrHints.prototype.getHints = function (implicitChar) {
		var cursor = this.editor.getCursorPos(),
			query = {
				queryStr: null
			},
			tokenType,
			offset,
			result = [];

		this.tagInfo = HTMLUtils.getTagInfo(this.editor, cursor);
		tokenType = this.tagInfo.position.tokenType;
		offset = this.tagInfo.position.offset;
		if (tokenType === HTMLUtils.ATTR_NAME || tokenType === HTMLUtils.ATTR_VALUE) {
			query.tag = this.tagInfo.tagName;

			if (offset >= 0) {
				if (tokenType === HTMLUtils.ATTR_NAME) {
					query.queryStr = this.tagInfo.attr.name.slice(0, offset);
				} else {
					query.queryStr = this.tagInfo.attr.value.slice(0, offset);
					query.attrName = this.tagInfo.attr.name;
				}
				this.updateExclusion(false);
			} else if (tokenType === HTMLUtils.ATTR_VALUE) {
				// We get negative offset for a quoted attribute value with some leading whitespaces 
				// as in <a rel= "rtl" where the cursor is just to the right of the "=".
				// So just set the queryStr to an empty string. 
				query.queryStr = "";
				query.attrName = this.tagInfo.attr.name;
			}

			query.usedAttr = HTMLUtils.getTagAttributes(this.editor, cursor);
		}

		if (query.tag && query.queryStr !== null) {
			var tagName = query.tag,
				attrName = query.attrName,
				filter = query.queryStr,
				unfiltered = [],
				hints = [],
				sortFunc = null;

			if (attrName) {
				var hintsAndSortFunc = this._getValueHintsForAttr(query, tagName, attrName);
				hints = hintsAndSortFunc.hints;
				sortFunc = hintsAndSortFunc.sortFunc;

			} else if (tags && tags[tagName] && tags[tagName].attributes) {
				unfiltered = tags[tagName].attributes.concat(this.globalAttributes);
				hints = $.grep(unfiltered, function (attr, i) {
					return $.inArray(attr, query.usedAttr) < 0;
				});
			}

			if (hints instanceof Array && hints.length) {
				console.assert(!result.length);
				result = $.map(hints, function (item) {
					if (item.indexOf(filter) === 0) {
						return item;
					}
				}).sort(sortFunc);
				return {
					hints: result,
					match: query.queryStr,
					selectInitial: true,
					handleWideResults: false
				};
			} else if (hints instanceof Object && hints.hasOwnProperty("done")) { // Deferred hints
				var deferred = $.Deferred();
				hints.done(function (asyncHints) {
					deferred.resolveWith(this, [{
						hints: asyncHints,
						match: query.queryStr,
						selectInitial: true,
						handleWideResults: false
                    }]);
				});
				return deferred;
			} else {
				return null;
			}
		}


	};

	/**
	 * Inserts a given HTML attribute hint into the current editor context.
	 * 
	 * @param {string} hint 
	 * The hint to be inserted into the editor context.
	 * 
	 * @return {boolean} 
	 * Indicates whether the manager should follow hint insertion with an
	 * additional explicit hint request.
	 */
	AttrHints.prototype.insertHint = function (completion) {
		var cursor = this.editor.getCursorPos(),
			start = {
				line: -1,
				ch: -1
			},
			end = {
				line: -1,
				ch: -1
			},
			tokenType = this.tagInfo.position.tokenType,
			offset = this.tagInfo.position.offset,
			charCount = 0,
			insertedName = false,
			replaceExistingOne = this.tagInfo.attr.valueAssigned,
			endQuote = "",
			shouldReplace = true,
			textAfterCursor;

		if (tokenType === HTMLUtils.ATTR_NAME) {
			textAfterCursor = this.tagInfo.attr.name.substr(offset);
			if (CodeHintManager.hasValidExclusion(this.exclusion, textAfterCursor)) {
				charCount = offset;
				replaceExistingOne = false;
			} else {
				charCount = this.tagInfo.attr.name.length;
			}
			// Append an equal sign and two double quotes if the current attr is not an empty attr
			// and then adjust cursor location before the last quote that we just inserted.
			if (!replaceExistingOne && attributes && attributes[completion] &&
				attributes[completion].type !== "flag") {
				completion += "=\"\"";
				insertedName = true;
			} else if (completion === this.tagInfo.attr.name) {
				shouldReplace = false;
			}
		} else if (tokenType === HTMLUtils.ATTR_VALUE) {
			textAfterCursor = this.tagInfo.attr.value.substr(offset);
			if (CodeHintManager.hasValidExclusion(this.exclusion, textAfterCursor)) {
				charCount = offset;
				// Set exclusion to null only after attribute value insertion,
				// not after attribute name insertion since we need to keep it 
				// for attribute value insertion.
				this.exclusion = null;
			} else {
				charCount = this.tagInfo.attr.value.length;
			}

			if (!this.tagInfo.attr.hasEndQuote) {
				endQuote = this.tagInfo.attr.quoteChar;
				if (endQuote) {
					completion += endQuote;
				} else if (offset === 0) {
					completion = "\"" + completion + "\"";
				}
			} else if (completion === this.tagInfo.attr.value) {
				shouldReplace = false;
			}
		}

		end.line = start.line = cursor.line;
		start.ch = cursor.ch - offset;
		end.ch = start.ch + charCount;

		if (shouldReplace) {
			if (start.ch !== end.ch) {
				this.editor.document.replaceRange(completion, start, end);
			} else {
				this.editor.document.replaceRange(completion, start);
			}
		}

		if (insertedName) {
			this.editor.setCursorPos(start.line, start.ch + completion.length - 1);

			// Since we're now inside the double-quotes we just inserted,
			// immediately pop up the attribute value hint.
			return true;
		} else if (tokenType === HTMLUtils.ATTR_VALUE && this.tagInfo.attr.hasEndQuote) {
			// Move the cursor to the right of the existing end quote after value insertion.
			this.editor.setCursorPos(start.line, start.ch + completion.length + 1);
		}

		return false;
	};


	AppInit.appReady(function () {
		// Parse JSON files
		tags = JSON.parse(HTMLTags);
		attributes = JSON.parse(HTMLAttributes);

		// Register code hint providers
		var tagHints = new TagHints();
		var attrHints = new AttrHints();
		CodeHintManager.registerHintProvider(tagHints, ["html"], 2);
		CodeHintManager.registerHintProvider(attrHints, ["html"], 2);

		// For unit testing
		exports.tagHintProvider = tagHints;
		exports.attrHintProvider = attrHints;
	});

});