define({
    HEADER_TITLE: "Mobility Portal Preview",

    TOOLBAR_ICON_TOOLTIP: "Mobile Preview",

    BUTTON_SETTINGS: "Configure Preview",    
    BUTTON_CLOSE: "Close Preview",

    COMMAND_DARK: "Dark Theme / White Phone",

    PREF_ENABLED_NAME: "Preview - Enabled",
    PREF_ENABLED_DESC: "Enable/disable Preview List",
    PREF_DARK_NAME: "Preview - Use Dark Theme / White Phone",
    PREF_DARK_DESC: "Use dark theme / white phone"
    
});
