define({
    HEADER_TITLE: "Mobility Portal Preview",

    TOOLBAR_ICON_TOOLTIP: "Mobile Vorschau",
	TOOLBAR_OIB_TOOLTIP: "im Browser öffnen",

    BUTTON_SETTINGS: "Preview konfigurieren",    
    BUTTON_CLOSE: "Preview schließen",

    COMMAND_DARK: "Dunkle Theme",

    PREF_ENABLED_NAME: "Preview - Aktiviert",
    PREF_ENABLED_DESC: "Aktiviert/deaktiviert die Preview Liste",
    PREF_DARK_NAME: "Dunkle Theme",
    PREF_DARK_DESC: "Dunkle Theme"
});
