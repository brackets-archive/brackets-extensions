Autosave all open files when switching away from the Brackets editor, in the style of PHPStorm/WebStorm.
