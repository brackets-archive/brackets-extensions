Frackets
========

A brackets editor theme based upon flat colors

<p>Frackets is a theme for the Brackets Editor. It's based around the concept of flat colours. The theme is still in development and will most likely be forever!</p>
<p>Frackets is compatible with brackets ```1.0```
