brackets-hoganjs-language
==========================

Brackets HoganJs language extension.

Adds support for hoganjs file extensions.

##License
[MIT](http://opensource.org/licenses/MIT)