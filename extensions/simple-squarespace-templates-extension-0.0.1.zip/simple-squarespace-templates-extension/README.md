Simple Squarespace Templates Extension
=====================
A simple Brackets extension that adds a simple extension that adds HTML-markup and html-highlight for *.block, *.region, *.list, *.item files of Squarespace templates.

