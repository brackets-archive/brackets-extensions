Delkos Dark Theme
=================

This is a Delkos (me) Dark Theme based (forked) from the theme boilerPlate from Miguel del Castillo.

This theme includes a serie of modificatios on syntax higlight and editor elements.
It also modifies some other extensions elements like git extension.

It's aimed to be clear, elegant, consistent, provide easy reading, and of course, to be dark ;-)

![screenshot](https://raw.githubusercontent.com/David5i6/wiki/master/themes/Delkos%20Dark%20Theme/delkos_dark_theme.png)