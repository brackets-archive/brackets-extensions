# brackets-TrueBlue

## sample screen shots
### HTML
![screenshot-html](/screenshots/Screen\ Shot\ HTML.png "HTML Screen Shot")

### CSS
![screenshot-css](/screenshots/Screen\ Shot\ CSS.png "CSS Screen Shot")
# TrueBlueBracketsTheme
