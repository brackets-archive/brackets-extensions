brackets-rubocop
===

Adds RuboCop support to Brackets. Uses the [new Brackets linting API](http://blog.brackets.io/2013/10/07/new-linting-api/).

Usage
===

Requires Ruby 2.0.0-p247 and (globally-available) RuboCop:

````
rvm install 2.0.0-p247
rvm @global do gem install rubocop
````
