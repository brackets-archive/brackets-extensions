Installation
------------

Create an account at [CodeShark](https://codeshark.live/).

1. `File` → `Extension Manager...`

2. Search for `CodeShark`, then `Install`.

3. Enter your [CodeShark API Key](https://app.codeshark.live/settings).

4. To search and insert code `Find` → `CodeShark: Search Code` then click the program
