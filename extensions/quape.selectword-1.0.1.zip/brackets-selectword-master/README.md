# Select Word
Use the shortcut `Ctrl-Y` to select the word at the current cursor position.
That's all :)
