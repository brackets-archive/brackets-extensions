# Brackets Auto Pairing

An extension for Brackets which automatically pairs quotations, apostrophes, parentheses, brackets and curly braces by adding the closing character when you press the opening character (e.g. quotation mark, opening bracket. It also allows you to make a selection and wrap the whole thing in one of the aforemention character pairs by pressing the opening character. 