brackets-toggle-toolbar
=======================

Brackets extension for allowing the toolbar to be toggled independent of the sidebar.
