[kaoscript/highlight-brackets](https://github.com/kaoscript/highlight-brackets)
===============================================================================

[![MIT License](http://img.shields.io/badge/license-MIT-blue.svg?style=flat)](./LICENSE)

Provides [kaoscript](https://github.com/kaoscript/kaoscript) syntax highlight via a [CodeMirror](http://codemirror.net/) mode for [Brackets](http://brackets.io/).

License
-------

Copyright &copy; 2016 Baptiste Augrain

Licensed under the [MIT license](http://www.opensource.org/licenses/mit-license.php).