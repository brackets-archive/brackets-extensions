Brackets Theme: Eggsecute Shutdown
===

A theme for Brackets that is based on nature (and really reminds me of the pokémon "Eggsecutor"). Based on the original Ambiance theme from CodeMirror.

<!--Screenshots UPDATE LATER
---

### HTML
![HTML](screenshots/firewatch-html.png)

### CSS
![HTML](screenshots/firewatch-css.png)

### JavaScript
![HTML](screenshots/firewatch-js.png)-->

Installation
---

This extension requires Brackets Release 1.0 or newer.

1. Open Brackets
2. Open the Extension Manager
3. Switch to "Themes" tab
4. Search for "Nature Be Scary"
5. Click "Install"

License
---

The MIT License. Read [LICENSE](LICENSE) for further information.