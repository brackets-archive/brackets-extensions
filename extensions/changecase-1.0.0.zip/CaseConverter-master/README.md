# CaseConverter
Convert between case on selection of a text in the code editor.

Convert Case menu option is added to the right click menu in the code editor. Select a text in the code editor and select the case from the options under Convert case menu option to convert the selected text inplace.

Converts string to camel case, constant case, dot case, header case, lower case, lower case first, no case, param case, pascal case, path case, sentence case, snake case, swap case, title case, upper case, upper case first.

This extension uses change-case npm module for case conversion.