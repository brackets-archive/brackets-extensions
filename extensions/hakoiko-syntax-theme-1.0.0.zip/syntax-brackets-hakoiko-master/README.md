#Hakoiko Theme for Brackets

Inspired from tumblr.com Html editor. and added some light effects. 

basicially, HTML shows you green + gray. JS is yellow + orange. CSS is combined with blue + gray + green + orange. so you can easilly know document type that you see now. even if you don't read the file name.

![Screenshot](https://raw.github.com/hakoiko/syntax-brackets-hakoiko/master/screenshot.gif)
