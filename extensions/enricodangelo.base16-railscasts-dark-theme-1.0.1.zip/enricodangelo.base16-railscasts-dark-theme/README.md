Base 16 Railscasts Dark Theme for Brackets
============================

Attempting to be as close to [Railscasts Dark](http://chriskempson.github.io/base16/#railscasts) as possible.

Brackets theme adapted from [John Molakvoæ](https://github.com/skjnldsv/default-dark).
Colorscheme copied from [Chris Kempson](http://chriskempson.com).
