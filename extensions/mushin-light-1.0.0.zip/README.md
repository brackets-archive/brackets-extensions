Mushin Light Theme for Brackets
===============================

Grayscale zen theme. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/MushinLight/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/MushinLight/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/MushinLight/blob/master/screenshots/js.png)
