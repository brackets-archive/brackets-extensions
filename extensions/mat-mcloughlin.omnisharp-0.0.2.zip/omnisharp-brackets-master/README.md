omnisharp-brackets
==================

Completed(ish)
==============

1. Code Fixes
2. Navigate to
3. Fix Usings
4. Format code
