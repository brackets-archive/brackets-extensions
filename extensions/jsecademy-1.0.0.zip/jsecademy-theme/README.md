[JSecademy](https://www.jsecademy.com/) Official Theme for Brackets
===========================

Flat minimalistic light theme for Brackets

## JavaScript
![JS Screenshot](https://github.com/Brackets-Themes/Coolwater/blob/master/screenshots/js.png)