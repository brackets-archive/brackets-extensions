class Light {
  constructor(state = false) {
    this._state = state;
  }
  on() {
    this._state = true;
    return this.state;
  }
  off() {
    this._state = false;
    return this.state;
  }
  get state(){
    return this._state;
  }
}

const myLight = new Light();
myLight.on();
console.log(myLight.state);