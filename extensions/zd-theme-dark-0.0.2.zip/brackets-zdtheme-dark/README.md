# brackets-zdtheme-dark
Homemade Brackets Editor theme

## Still in progression you can try it but take sunglasses it could burn your eyes

