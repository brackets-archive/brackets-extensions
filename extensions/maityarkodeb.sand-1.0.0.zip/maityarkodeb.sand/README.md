###Change log
* 1.0.3 - lightened theme for better visibility

* 1.0.2 - darkened the theme overall

* 1.0.1 - minor changes

##Subtle Colors (a Brackets theme)
***
###Installation
Search for 'Subtle Colors' in Themes section of Brackets extension manager or download zip and install manually to extensions/user folder.
