# codepen-brackets-theme
A theme for Brackets based on http://codepen.io's Panda theme.

![Codepen Brackets Theme Screenshot](https://raw.githubusercontent.com/trvswgnr/codepen-brackets-panda-theme/master/screenshot.png "Codepen Brackets Theme Screenshot")