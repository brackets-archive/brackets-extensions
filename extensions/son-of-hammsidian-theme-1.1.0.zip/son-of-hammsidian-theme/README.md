Son of Hammsidian Theme for Brackets
====================================
A variation of John Hamm's Hammsidian dark theme.

### HTML
![HTML Screenshot](https://github.com/georapbox/son-of-hammsidian-theme/blob/master/screenshots/html.png)

### CSS
![HTML Screenshot](https://github.com/georapbox/son-of-hammsidian-theme/blob/master/screenshots/CSS.png)

### Javascript
![HTML Screenshot](https://github.com/georapbox/son-of-hammsidian-theme/blob/master/screenshots/Javascript.png)
