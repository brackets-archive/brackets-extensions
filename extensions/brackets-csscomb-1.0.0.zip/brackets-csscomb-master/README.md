brackets-[csscomb](https://github.com/csscomb/csscomb.js)
============================

Compatible with Sprint 22 and above

Sorts css files with csscomb.js


Usage
===

Select css to sort and press `Ctrl + Shift + C` or select `Edit > Sort with CSScomb` in menu.


Installation
===

`File > Extension Manager > Install from URL`

Paste https://github.com/i-akhmadullin/brackets-csscomb into Extension URL field


Manual Installation
---
Download zip and extract into arbitrary directory (or clone source files), then move the folder to the extensions folder (you can open this folder by clicking "Help > Show Extensions Folder" menu).
