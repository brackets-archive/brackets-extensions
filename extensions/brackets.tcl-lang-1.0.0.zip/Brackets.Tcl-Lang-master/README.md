# Brackets.Tcl-Lang

_Version: 1.0.0_

### About
A very simple extension for [Brackets](http://brackets.io/) to allow Tcl syntax highlighting.

It will turn your coding into something readable, like so.

![Screenshot](./example.png)

I have included .tcl and .etcl files, as I use .etcl to distinguish that they are for Eggdrop.