# The Greyhound Companion

Feature-rich companion extension for **The Greyhound** theme, extending the theme capabilities to other areas of the IDE.

= 0.0.5 =

* FIX: Fixed sidebar resize

= 0.0.4 =

* FIX: Fixed extension compatibility with latest Adobe Brackets version
* PACKAGE: Tweaked package description

= 0.0.3 =

* UI: Fixed missing background colour
* UI: Tweaked several areas of the IDE, including bottom toolbars, font weights and buttons
