brackets-darkbar
================

Stupid extension to uniform the color of the main toolbar with the rest of Brackets.  

I know, I know... was a long and hard project but finally I did it.


![comparision](http://i.imgur.com/BrOhYCb.jpg)
