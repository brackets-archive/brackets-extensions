# Flat Dark
A Brackets theme based on two Kuler submissions:

[Flat Dark](https://color.adobe.com/Flat-Dark-UI-color-theme-2730708/) by user sampath_roots

[Dark Cartoon](https://color.adobe.com/Dark-cartoon-color-theme-2585004/) by user keith 