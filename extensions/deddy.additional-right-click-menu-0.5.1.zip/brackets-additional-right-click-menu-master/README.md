Brackets Additional Right Click Menu
================

A Brackets extension that add additional functionality to Brackets editor, like cut, copy, paste.

Works on windows 7!!! :)

Now support select all, Camel Case, fix code indentaion, UPPERCASE and lowercase and some functionality from edit menu. Now some menu items will be disabled if no text selected.

#Changelog
added a shortcuts to some menu items
Fixed some bugs with brackets 1.3 paste
added fix indentation
bug fix for uppercase, lowercase and camelcase selection behaviour and change it's short cut key