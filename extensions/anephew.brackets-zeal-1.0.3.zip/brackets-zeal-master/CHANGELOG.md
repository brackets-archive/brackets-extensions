# Changelog
All notable changes to this project will be documented in this file.

## 1.0.3 - 2017-03-15
### Fixed
- Dropped support for <code>--query</code> command line parameter. Users can invoke search by running <code>zeal &lt;query&gt;</code> instead. Support for <code>dash-plugin</code> URL scheme on the roadmap.

## 1.0.2 - 2016-04-16
### Fixed
- Quotes around search string

## 1.0.1 - 2014-11-03
### Added
- Modal bar for custom search (use <kbd>Ctrl+Shift+Z</kbd>)

## 1.0.0 - 2014-10-25
- Initial release.