These icons are taken from [Public Icons Project](https://github.com/davidmerfield/Public-Icons) and edited to match Brackets' UX.
Python logos are trademarks of the Python Software Foundation.