# Raspberry theme for Brackets
Raspberry – dark theme for [Brackets Editor](https://github.com/adobe/brackets) with soft colors.
# License
This theme is distributed under MIT license, see LICENSE.md .