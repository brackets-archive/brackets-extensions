## 0.1.1
* Added Gist Manager button into main toolbar (you can disbled it from preferences file) by [malas34](https://github.com/malas34)

## 0.1.0
* First stable release, fix of various critical bugs.

## 0.0.8
* Now is possible to delete gists.

## 0.0.7
* Added support for [GitHub authorization tokens](https://github.com/settings/applications).
* Auth tokens are saved locally and can be loaded writing the owner's username in the username field.

## 0.0.6
* Added option in menu to fastly create a Gist with the content of the current document.
* Gists are now listed showing the first 15 chars of the description (if provided).
* Added tool to filter gists by keywords.

## 0.0.5
* Added Gist creation support (anonymous, public, secret)

## 0.0.4
* Added support for localization.
* Now is possible load public gists, user's public gists and user's secret gists.
* Added buttons to download gist or open in browser
