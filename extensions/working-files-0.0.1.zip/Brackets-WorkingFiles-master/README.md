# Brackets-WorkingFiles
Reposition working files panel in Brackets below the file tree

<img src="https://raw.githubusercontent.com/MiguelCastillo/Brackets-WorkingFiles/master/img/working-files-panel.png" width="320px"/>
