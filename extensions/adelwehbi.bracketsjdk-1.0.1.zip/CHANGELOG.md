# Changelog

### 2018-02-07 Version 1.0.1
Patch for killing java process on Windows.

### 2018-02-07 Version 1.0.0
First Release.
