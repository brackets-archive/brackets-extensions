# brackets-theme-nightshade
NightShade Theme for Adobe Brackets IDE
Versão 1.0
