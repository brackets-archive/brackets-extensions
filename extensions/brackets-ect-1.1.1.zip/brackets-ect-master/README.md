# Brackets-ECT

Provides [ECT](http://ectjs.com/) Template Engine syntax highlighting. Highlighter uses a genuine coffeescript highlighter for the template code between the `<% %>`.

"ECT" stands for "Embedded CoffeeScript Ttemplates". It's a templating engine that allows you to embed coffescript logic in your markup.

## License

[MIT](http://opensource.org/licenses/MIT)

## Fork

Original repository [brackets-eco](https://github.com/SteveMcArthur/brackets-eco) by SteveMcArthur
