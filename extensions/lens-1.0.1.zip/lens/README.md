#Lens
> Provides [lens](http://help.koken.me/customer/portal/articles/828688-lens-templates) syntax highlighting for Brackets

## Getting Started
You can install this extension directly from within Brackets or [download it from the Brackets Extension Directory](https://brackets-registry.aboutweb.com/).

## Contributing
Feel free to help with the development of this extension! If you have any changes you would like made, please open an [issue](https://github.com/pburtchaell/lens/issues) and/or [make a pull request](https://github.com/pburtchaell/lens/pulls) with the changes.

Built with love in New Orleans  | Version: **1.0.0**

[Source files licensed under MIT](http://pb.mit-license.org/).
[All content copyright (c) 2014 Patrick Burtchaell](http://pburtchaell.com/legal/)

