# ocelots_theme
A brackets css theme

A theme created for tired eyes in the middle of an eight hour coding session


![preview](https://github.com/OcelotDive/ocelots_theme/blob/master/preview.PNG)
