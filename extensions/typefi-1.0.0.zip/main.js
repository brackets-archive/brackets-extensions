/*
 * Copyright © 2001-2017 Typéfi Systems. All rights reserved.
 *
 * Typefi Brackets extension
 *
 * jdebuse@typefi.com
 */

/* global define */
"use strict";

define(require => require('lib/ui-utils').initialiseUi());
