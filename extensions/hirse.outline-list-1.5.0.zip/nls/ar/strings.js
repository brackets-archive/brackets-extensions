define({
    HEADER_TITLE: "الأوت لاين",

    TOOLBAR_ICON_TOOLTIP: "علامة تبويب",

    BUTTON_SETTINGS: "الخصائص",
    BUTTON_MOVE: "تغيير الوضعية",
    BUTTON_CLOSE: "إغلاق",

    COMMAND_SORT: "قائمة قصيرة",
    COMMAND_UNNAMED: "إظهارالوظائف",
    COMMAND_ARGS: "إظهار الخصائص",
    COMMAND_INDENT: "بداية المدخلات",

    MESSAGE_SYNTAX_ERROR: "تصحيح اخطاء الاوسم داخل الملف في الاوت لاين",

    PREF_ENABLED_NAME: "الاوت لاين /تفعيل",
    PREF_ENABLED_DESC: "الاوت لاين/تعطيل القائمة",
    PREF_UNNAMED_NAME: "الاوت لاين/غير مسمى",
    PREF_UNNAMED_DESC: "إخفاء/إظهار الاوت لاين من القائمة",
    PREF_ARGS_NAME: "الاوت لاين-ارغيمون",
    PREF_ARGS_DESC: "إظهار / إخفاء معلمات الدالة",
    PREF_SIDEBAR_NAME: "الشريط الجانبي",
    PREF_SIDEBAR_DESC: "إظهار الشريط الجانبي اسفل شجرت الملفات",
    PREF_SORT_NAME: "الاوت لاين - فرز",
    PREF_SORT_DESC: "فرز الإدخالات في قائمة المخطط التفصيلي",
    PREF_INDENT_NAME: "المسافة البادئة",
    PREF_INDENT_DESC: "تلاشي الإدخال في قائمة المخطط التفصيلي"
});
