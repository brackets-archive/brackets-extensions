define(function (require, exports, module) {
    "use strict";

    module.exports = {
        root: true,
        de: true,
        es: true,
        fr: true,
        ja: true,
        pl: true
    };
});
