define({
    HEADER_TITLE: "アウトライン",

    TOOLBAR_ICON_TOOLTIP: "アウトライン表示",

    BUTTON_SETTINGS: "設定",
    BUTTON_MOVE: "表示位置の切り替え",
    BUTTON_CLOSE: "閉じる",

    COMMAND_SORT: "関数名でソートする",
    COMMAND_UNNAMED: "無名関数を表示",
    COMMAND_ARGS: "引数を表示"
});

/* Last translated for 339a8c473edd03187835046cde1b32dbcab441d1 */
