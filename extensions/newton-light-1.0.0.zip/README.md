Newton Light Theme for Brackets
===============================

Sophisticated spectral theme. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/NewtonLight/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/NewtonLight/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/NewtonLight/blob/master/screenshots/js.png)
