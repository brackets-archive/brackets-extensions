Flash Ruby Dark  Theme for Brackets
=====================================

A premium Dark Theme for Brackets. Inspired by Belo horizontes night Clubs A Brackets original.


<img src="https://cloud.githubusercontent.com/assets/17788476/17230178/37719f5c-54f1-11e6-9db0-e0e319cd712b.png" width="90%"></img>

<img src="https://cloud.githubusercontent.com/assets/17788476/17230179/378f0006-54f1-11e6-89cf-302ba37a44a3.png" width="90%"></img>

<img src="https://cloud.githubusercontent.com/assets/17788476/17230180/37a2e530-54f1-11e6-8182-03e127443608.png" width="90%"></img> 