# brackets-ink
Ink syntax highlighting extension for Adobe Brackets.

Provides rudimentary highlighting for Inkle's [Ink](https://github.com/inkle/ink) syntax.