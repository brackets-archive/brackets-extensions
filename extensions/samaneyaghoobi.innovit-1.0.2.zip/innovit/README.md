# Innovit Theme

##### To My Favorite Editor [Brackets](http://brackets.io/).

A _dark_ Syntax Theme that is really _Friend_ to the Eyes.


#### HTML
![HTML Screenshot](https://github.com/SamaneYaghoobi/Innovit/blob/master/ScreenShots/HTML.jpg)

#### CSS
![CSS Screenshot](https://github.com/SamaneYaghoobi/Innovit/blob/master/ScreenShots/CSS.jpg)

#### JavaScript
![JS Screenshot](https://github.com/SamaneYaghoobi/Innovit/blob/master/ScreenShots/JS.jpg)

