Brackets extension: International keyboards
================================

This extension fixes bugs with international letters. If AltGr is down then every shortcuts are disabled
