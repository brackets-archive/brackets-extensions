# Encode
A minimal theme for brackets.

It's candy, classy, and clean, all in one. 
Encode has distinct colors and a meticulously chosen palette to make programming more easy on the eyes.
![](http://the.x10.mx/images/encode.png)
