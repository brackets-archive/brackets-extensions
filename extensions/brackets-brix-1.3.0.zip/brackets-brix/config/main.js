/*global define, $, brackets */

/** Global Brix plugin assets */
define(function (require, exports, module) {
  'use strict';
  
  var _                   = brackets.getModule('thirdparty/lodash');
  var config              = require('text!./config.json');
  var configJSON          = JSON.parse(config);
  var CommandManager      = brackets.getModule('command/CommandManager');
  var Commands            = brackets.getModule('command/Commands');
  var PreferencesManager  = brackets.getModule('preferences/PreferencesManager');
  var ExtensionUtils      = brackets.getModule('utils/ExtensionUtils');
  var AppInit             = brackets.getModule('utils/AppInit');
  var Menus               = brackets.getModule('command/Menus');
  var prefs               = PreferencesManager.getExtensionPrefs('brix.brackets-brix');

  ExtensionUtils.loadStyleSheet(module, './css/main.css');
  
  var environment = prefs.get('environment') || 'production';
  
  if(environment == 'development'){
    $('<div />').appendTo('#main-toolbar').attr('id', 'devmode').html('development');
  }

  var prodCommand = CommandManager.register('Switch to PROD (default)', 'env.production', function(){
    environment = 'production';
    prefs.set('environment', environment);

    CommandManager.execute(Commands.APP_RELOAD);
  });

  var devCommand = CommandManager.register('Switch to DEV', 'env.development', function(){
    environment = 'development';
    prefs.set('environment', environment);

    CommandManager.execute(Commands.APP_RELOAD);
  });

  var devMenu = Menus.addMenu('DEV', 'dev-menu', Menus.AFTER, Menus.AppMenuBar.HELP_MENU);
  devMenu.addMenuItem(prodCommand, '', Menus.LAST);
  devMenu.addMenuItem(devCommand, '', Menus.LAST);
  

  // Export config
  config = _.extend(configJSON.global, configJSON[environment]);

  module.exports = config;
  window.environment = environment;
  window.config = config;

  AppInit.appReady(function () {
    if(environment == 'development'){
      console.log('================');
      console.log('=== DEV MODE ===');
      console.log('================');
      
      $('#main-toolbar').addClass('dev');
    }
  });
});