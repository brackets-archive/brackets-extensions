/*jslint indent: 2, maxerr: 50 */
/*global define, $, brackets, window, Mustache */

define(function (require, exports, module) {
  'use strict';

  var ProjectManager   = brackets.getModule('project/ProjectManager');
  var WorkspaceManager = brackets.getModule('view/WorkspaceManager');
  var ExtensionUtils   = brackets.getModule('utils/ExtensionUtils');
  var errorPanelTpl    = require('text!./html/brix-errors-panel.html');
  var errorRowTpl      = require('text!./html/brix-errors-row.html');
  var utils            = require('../../utils/main');
  var AppInit          = brackets.getModule('utils/AppInit');

  var sidebarBtn;
  var errorCount = 0;

  var rootFolder = 'contentPages/';
  var basePath;

  // Create bottom errors panel
  var errorPanel = WorkspaceManager.createBottomPanel('errors.panel', $(errorPanelTpl));

  // Get jQuery objects
  var $panel = errorPanel.$panel;
  var $list = $panel.find('.brix-errors-list');

  // load CSS
  ExtensionUtils.loadStyleSheet(module, './css/brix-errors.css');

  // Show errors in panel
  function showErrors(data){

    var errorCount = data && typeof data == 'object' ? Object.keys(data).length : 0;
    $list.empty();

    for(var file in data){

      var $row = utils.tpl(errorRowTpl, {file: file, errors: data[file]});

      $list.append($row);

      $row.find('[data-file]').click(function(){
        utils.open(basePath + $(this).data('file'));
      });
    }

    // Show number of errors in sidebar button
    sidebarBtn.html(errorCount)[errorCount ? 'addClass' : 'removeClass']('errors');
  }

  // Event handlers
  function bindEventHandlers(){
    $panel.on('click', '.brix-panel-close', function(){
      utils.togglePanel(errorPanel, sidebarBtn);
    });

    sidebarBtn.click(function(){
      utils.togglePanel(errorPanel, sidebarBtn);
    });
  }

  // App is ready
  AppInit.appReady(function () {

    basePath = ProjectManager.getProjectRoot()._path.split(rootFolder)[0] + rootFolder;

    // Create and add sidebar button
    sidebarBtn = utils.addSidebarButton({
      className: 'brix-errors-sidebar-btn',
      html: errorCount
    });

    bindEventHandlers();

    // Listen to error messages from potato
    utils.ws.on('preview.error', showErrors);
    utils.ws.emit('preview.requestErrors');
  });
})
