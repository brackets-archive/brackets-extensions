define(function (require, exports, module) {
  "use strict";
  var ExtensionUtils      = brackets.getModule('utils/ExtensionUtils');
  var notificationTpl     = require('text!./html/brix-notification.html');
  var utils               = require('../../utils/main');

    // load CSS
  ExtensionUtils.loadStyleSheet(module, './css/main.css');

  var $editorHolder = $('#editor-holder');
  var $notification = utils.create('div').prependTo($editorHolder);

  function notification(message, type, persistent){

    // Allow 2 arguments, map persistent to type
    if(arguments.length == 2) persistent = type;

    var deferred = new $.Deferred();

    $notification.html(Mustache.render(notificationTpl, {
      showDismiss: persistent,
      contents: message,
      type: type
    }));

    $notification.find('.close').click(function(){
      $notification.empty();
    });

    console.log('persistent', persistent);

    if(!persistent){
      setTimeout(function(){
        $notification.empty();
        deferred.resolve();
      }, 2000);
    } else {
      deferred.resolve();
    }

    return deferred.promise();
  }

  utils.ws.on('notify', function(data){
    notification(data.message, data.type, true);
  });

  module.exports = notification;
});
