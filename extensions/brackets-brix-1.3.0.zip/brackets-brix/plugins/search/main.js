/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets */

/** Simple extension that adds a 'File > Hello World' menu item. Inserts 'Hello, world!' at cursor pos. */
define(function (require, exports, module) {
  'use strict';

  var WorkspaceManager    = brackets.getModule('view/WorkspaceManager');
  var ExtensionUtils      = brackets.getModule('utils/ExtensionUtils');
  var AppInit             = brackets.getModule('utils/AppInit');
  var config              = require('../../config/main');

  ExtensionUtils.loadStyleSheet(module, './css/brix-search-main.css');
  ExtensionUtils.loadStyleSheet(module, './css/brix-search-content.css');
  ExtensionUtils.loadStyleSheet(module, './css/brix-search-results.css');

  var SEARCH_LABEL_SERVICE_URL = [config.serverPath, ':1617/labels/?method=files'].join('');
  
  /**
   * Templates
   */
  var searchPanelTpl = require('text!./html/brix-search-panel.html');
  var searchInfoTpl = require('text!./html/brix-search-info.html');
  var labelsSearchTpl = require('text!./html/brix-search-labels.html');

  var options = {};
  var searchLabelsQuery;
  var busy;
  var searchButtonLabels = {
    search: "Search",
    previewReplace: "Replace preview",
    saveToFile: "Save changes to disk",
    busy: "Busy..."
  }
  // var contentSearchTpl = require('text!./html/brix-search-content.html');
  

  /*
  var MODE_CONTENT = 'content';
  var MODE_LABELS = 'labels';

  var context = {
    mode: MODE_CONTENT,
    searchResults: null
  };
  */

  var panel = WorkspaceManager.createBottomPanel('brix.searchPanel', $(searchPanelTpl));
  var $resultsContainer = $('#brix-search-labels-results');

  function doSearch() {
    
    searchLabelsQuery = $('.search__query').val();

    options = {
      query           : searchLabelsQuery,
      replaceWith     : $('.search__replacewith').val(),
      replaceValue    : $('.option__wholevalue').is(':checked'),
      exact           : $('.option__exact').is(':checked'),
      caseInsensitive : $('.option__case').is(':checked'),
      saveToFile      : ($('.search__replacewith').val() && $('.option__savefile').is(':checked')),
      projects        : $('.filter__brands').val(),
      countries       : $('.filter__countries').val(),
      locales         : $('.filter__locales').val()
    };

    busy = true;
    updateSearchButton();

    $.ajax({
      url: SEARCH_LABEL_SERVICE_URL,
      type: 'POST',
      data: JSON.stringify(options),
      contentType: 'application/json; charset=utf-8',
      dataType: 'json',
      success: searchDone,
      fail: renderSearchError
    });
  }

  function updateSearchButton(e){

    var $searchBtn = $('#searchPanel .search__button');

    if(busy){
      $searchBtn.text(searchButtonLabels.busy)
        .prop('disabled', 'disabled')
        .removeClass('highlight');
      return;
    }

    if($('.search__query').val()){
      $searchBtn.prop('disabled', '');
    } else {
      $searchBtn.prop('disabled', 'disabled');
    }

    if($('.search__replacewith').val()){
      if($('.option__savefile').is(':checked')){
        $searchBtn.text(searchButtonLabels.saveToFile).addClass('highlight');
      } else {
        $searchBtn.text(searchButtonLabels.previewReplace).removeClass('highlight');
      }
    } else {
      $searchBtn.text(searchButtonLabels.search).removeClass('highlight');
    }

    // ENTER, search
    if(e && e.which == 13 && $('.search__query').val()){
      doSearch();
    };
  }

  function searchDone(data) {
    
    busy = false;

    // Uncheck saveToFile after saving
    if(options.saveToFile){
      $('.option__savefile').prop('checked', false);
    }
    updateSearchButton();
    renderSearchResults(data);
  }

  function renderSearchResults(data) {

    var infoHtml = Mustache.render(searchInfoTpl, {saved: options.saveToFile, matches: data.matches, files: data.fileCount});
    $('#searchPanel .search-form__info').html(infoHtml).removeClass('hidden');
    
    var searchQuery = options.replaceWith || options.query;
    var reFlags = options.caseInsensitive ? 'gi' : 'g';
    
    var pattern = new RegExp('>.*?(' + searchQuery + ').*?<\/div>', reFlags);
    var resultsHtml = Mustache.render(labelsSearchTpl, {results: data.results}).replace(pattern, function($1, $2){
      return $1.replace(new RegExp($2, reFlags), '<span class="search-result__highlight">' + $2 + '</span>');
    });

    $resultsContainer.html(resultsHtml);
  }

  function renderSearchError(err) {
    console.error(err);
  }

  function togglePanel(){
    if(panel.isVisible()){
      panel.hide();
      $('#brixSearchButton').removeClass('active');
    } else {
      panel.show();
      $('#brixSearchButton').addClass('active');
    }
  }

  function bindEvents(){
    $('#brixSearchButton').click(togglePanel);

    $('#searchPanel .search__filter').keyup(function(e){
      if(e.which == 13 && $('.search__query').val()){
        doSearch();
      }
    });
    $('#searchPanel .search__query').keyup(updateSearchButton);
    $('#searchPanel .search__replacewith').keyup(updateSearchButton);
    $('#searchPanel .option__savefile').change(updateSearchButton);
    $('#searchPanel .search__button').click(doSearch);
  }

  $('#main-toolbar .buttons').append($(document.createElement('a')).attr('id', 'brixSearchButton'));

  // App is ready
  AppInit.appReady(function () {
    bindEvents();
  });
})
