/*global define, $, brackets */

define(function (require, exports, module) {
    "use strict";

    // var CommandManager   = brackets.getModule("command/CommandManager");
    var EditorManager    = brackets.getModule("editor/EditorManager");
    var DocumentManager  = brackets.getModule('document/DocumentManager');

    var ProjectManager      = brackets.getModule('project/ProjectManager');
    var Commands         = brackets.getModule('command/Commands');
    var CommandManager   = brackets.getModule('command/CommandManager');

    var ExtensionUtils   = brackets.getModule('utils/ExtensionUtils');
    var AppInit          = brackets.getModule('utils/AppInit');

    var mainTpl          = require('text!./html/main.html');
    var resultsTpl       = require('text!./html/results.html');
    var utils            = require('../../utils/main');

    var $sidebar         = $('#sidebar');
    var $main;
    var $results;
    var $searchInput;
    var $resultsContainer;
    var $treeContainer;
    var $treeList;

    var files;
    var filesLength;
    var searchDelay;
    var oldQuery;
    var tree;

    // Settings
    var searchDelayTime = 250;
    var minCharacters   = 3;
    
    var rootFolder = navigator.platform.indexOf('Win') > -1 ? '/' : 'src/';
    var basePath;

    // load CSS
    ExtensionUtils.loadStyleSheet(module, './css/main.css');

    // Init
    function init(){
        
        $main = $(Mustache.render(mainTpl));
        $main.prependTo($sidebar);

        $searchInput = $('#quickfind_search_input');
        $resultsContainer = $('#quickfind_results_container');
        $treeContainer = $('#project-files-container');

        $treeList = $(document.createElement('ul'));
        $treeContainer.html($treeList);

        bindDomEvents();

        loadPaths();
        loadTree();
    }

    function loadPaths(){
        $.get('http://localhost:2626/paths', function(data){
            files = data;
            filesLength = data.length;
            unlockSearch();
        });
    }

    function loadTree(){
        $.get('http://localhost:2626/tree', function(data){
            tree = data;
            
            for(var i = 0; i < tree.children.length; i++){

                var node = tree.children[i];
                var $item = $(document.createElement('li'));
                $item.text(node.name);
                

                $treeList.append($item);
            }
        });
    }

    function unlockSearch(){
        $searchInput.attr('placeholder', 'Quick find files...');
        $searchInput.attr('disabled', false);
    }

    // Render table
    function renderResults(data){

        $results = $(Mustache.render(resultsTpl, {files: data}));

        $resultsContainer.html($results);
        bindResultsEvents();
    }

    // Clear table
    function clearResults(){
        $resultsContainer.empty();
    }

    var handlers = {
        searchFiles: function(e){

            var query = String($searchInput.val()).toLowerCase();

            if(oldQuery == query){
                return;
            }

            oldQuery = query;

            if(query.length < minCharacters){
                clearResults();
                return;
            }

            if(searchDelay) clearTimeout(searchDelay);

            searchDelay = setTimeout(function(){

                var results = [];
                for(var index = 0; index < filesLength; index++){

                    var item = files[index];

                    if(item.toLowerCase().indexOf(query) > -1){
                        results.push({
                            path: item,
                            displayName: item.split('/').slice(-3).join('/'),
                            fileName: item.substr(item.lastIndexOf('/') + 1)
                        });
                    }
                };

                if(results.length == 0){
                    clearResults();
                    return;
                }

                results.sort();

                renderResults(results);
                
            }, searchDelayTime);
        },
        openFile: function(e){
            basePath = ProjectManager.getProjectRoot()._path.split(rootFolder)[0] + rootFolder;
            var filePath = basePath + $(e.currentTarget).data('path');

            CommandManager.execute(Commands.CMD_OPEN, {fullPath: filePath});
        }
    }

    function bindDomEvents(){
        $searchInput.on('keyup', handlers.searchFiles);
    }

    function bindResultsEvents(){
        $results.find('> li').on('click', handlers.openFile);
    }

    // App is ready
    AppInit.appReady(init);
});