/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets */

/** Simple extension that adds a "File > Hello World" menu item. Inserts "Hello, world!" at cursor pos. */
define(function (require, exports, module) {
    "use strict";

    var CommandManager   = brackets.getModule("command/CommandManager"),
        EditorManager    = brackets.getModule("editor/EditorManager"),
        Menus            = brackets.getModule("command/Menus"),
        ProjectManager   = brackets.getModule("project/ProjectManager"),
        WorkspaceManager = brackets.getModule('view/WorkspaceManager'),
        ExtensionUtils   = brackets.getModule('utils/ExtensionUtils'),
        previewPanelTpl  = require('text!./html/brix-preview-panel.html'),
        AppInit          = brackets.getModule('utils/AppInit');

    // load CSS
    ExtensionUtils.loadStyleSheet(module, './css/brix-preview.css');

    var urlMap;
    // var baseUrl = navigator.platform.indexOf('Win') > -1 ? '/' : 'src/';
    var previewDomain = 'preview.travix.com/';
    var previewProtocol = 'http://';
    var panel = WorkspaceManager.createBottomPanel('preview.panel', $(previewPanelTpl));

    function openPreview(){
        var separator = '/';
        var baseUrl = ProjectManager.getProjectRoot()._path;
        var currentFile = ProjectManager.getSelectedItem().fullPath.split(baseUrl)[1];
        var brandPreviewDomain = previewProtocol;
        if(currentFile.indexOf('contentPages') !== -1) {
            currentFile = currentFile.replace('contentPages/', '');
            var path = currentFile.split('/');
            brandPreviewDomain += path[0].toLowerCase() + '.';
            brandPreviewDomain += path[1].toLowerCase() + '.';
        }
        brandPreviewDomain += previewDomain;
        var path = urlMap[currentFile];

        $('#previewUrl').attr('href', brandPreviewDomain + path).text(path);
        $('#brixPreviewFrame').removeClass('done').attr('src', brandPreviewDomain + path);
        panel.show();

        $("#brixPreviewButton").addClass("active");

        $('#brixPreviewFrame').on('load', function(){
            $(this).addClass('done');
        })
    }

    function closePreview(){
        panel.hide();

        $("#brixPreviewButton").removeClass("active");
    }

    function togglePreview(){
        if(panel.isVisible()){
            closePreview();
        } else {
            openPreview();
        }
    }

    function bindCloseBtn(){
        $("#previewClose").click(closePreview);
    }

    $.get('http://preview.travix.com/urlMap.json', function(data){
        urlMap = data;
    });



    // Add toolbar icon
    var btn = document.createElement('a');
    btn.id = 'brixPreviewButton';
    btn.href = '#';
    // btn.target = '_blank';
    btn.onclick = togglePreview;

    document.querySelector('#main-toolbar .buttons').appendChild(btn);

    // App is ready
    AppInit.appReady(function () {
        bindCloseBtn();
    });
});