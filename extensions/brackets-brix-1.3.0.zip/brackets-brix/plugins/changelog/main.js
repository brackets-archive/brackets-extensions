/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets */

define(function (require, exports, module) {
  'use strict';

  var changelog           = require('text!../../CHANGELOG');
  var marked              = require('./thirdparty/marked.min');
  var utils               = require('../../utils/main');
  var Dialogs             = brackets.getModule('widgets/Dialogs');
  var PreferencesManager  = brackets.getModule("preferences/PreferencesManager");
  var prefs               = PreferencesManager.getExtensionPrefs("brix");

  var methods = {
    showAfterUpdate: function(){
      prefs.set('brackets-brix.showChangeLog', true);
    },

    showChangelog: function(){
      Dialogs.showModalDialog('dialogs.git.changelog', 'Brix is updated to the latest version!', marked(changelog));
    }
  };

  // Check if showChangelog is set
  if(prefs.get('brackets-brix.showChangeLog')){
    
    // Uncheck showChangelog
    prefs.set('brackets-brix.showChangeLog', false);

    // Show the changelog
    methods.showChangelog();
  }

  module.exports = methods;
});