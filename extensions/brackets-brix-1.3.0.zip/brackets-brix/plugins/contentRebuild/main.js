/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window */

/** Extension to check rebuild status */
define(function (require, exports, module) {
    'use strict';

    var ExtensionUtils   = brackets.getModule('utils/ExtensionUtils');
    var WorkspaceManager = brackets.getModule('view/WorkspaceManager');
    var Menus = brackets.getModule('command/Menus');
    var CommandManager = brackets.getModule('command/CommandManager');
    var contentMessageTpl  = require('text!./html/main.html');
    var utils = require('../../utils/main');

    var SHOW_RESULT_TIMEOUT = 2000;
    var BASE_CLASS = 'content-rebuild-info';
    var RESULT_CLASS = 'rebuild-result-message';
    var DEFAULT_HEIGHT = 260;
    var startDone = false;
    var messageTimeout;

    ExtensionUtils.loadStyleSheet(module, './css/main.css');

    var loadingPanel = WorkspaceManager.createBottomPanel('contentRebuild.panel', $(contentMessageTpl), DEFAULT_HEIGHT);
    var $panel = loadingPanel.$panel;

    var showTimer = setTimeout(function(){
        loadingPanel.show();
        togglePanel();
    }, 500);

    var $content        = $panel.find('.' + BASE_CLASS + '__content').eq(0);
    var $header         = $panel.find('.' + BASE_CLASS + '__header').eq(0);
    var $headerToggle   = $panel.find('.' + BASE_CLASS + '__toggle').eq(0);
    var $headerClose    = $panel.find('.' + BASE_CLASS + '__close').eq(0);
    var $headerTitle    = $panel.find('.' + BASE_CLASS + '__header-message').eq(0);

    var lastChanges = {
        directories: [],
        files: [],
    };

    var lastChange = '';

    utils.ws.on('content.rebuild.start',    startRebuildContent );
    utils.ws.on('content.rebuild.complete', stopRebuildContent  );
    utils.ws.on('content.rebuild.error',    errorRebuildContent );

    $headerToggle.on('click', togglePanel);
    $headerClose.on('click', closePanel);

    function startRebuildContent(data) {
        if(messageTimeout) {
            clearTimeout(messageTimeout);
            setBaseMessageStatus();
        }



        if(Array.isArray(data)) {
            data.forEach(function(item) {
                if(item.file) {
                    lastChanges.files.push(item.file);
                    lastChange = item.file;
                }
                else if(item.dir) {
                    lastChanges.directories.push(item.dir);
                    lastChange = item.dir;
                }
            });
        }

        headerMessage('Building | ' + lastChange);

        $content.append(showMessage('Start rebuild'));
        $panel.addClass(BASE_CLASS + '--start');

        if(!$panel.hasClass(BASE_CLASS + '--shown') && !startDone) {
            $panel.addClass(BASE_CLASS + '--shown');
            loadingPanel.show();
            startDone = true;
        }
    }

    function stopRebuildContent() {
        $panel.addClass(BASE_CLASS + '--success').removeClass(BASE_CLASS + '--start');
        $content.append('<div><p class="' + RESULT_CLASS + ' ' + RESULT_CLASS + '--success">Success rebuilding</p></div>');
        messageTimeout = setTimeout(setBaseMessageStatus, SHOW_RESULT_TIMEOUT);

        headerMessage('Done | ' + lastChange);
    }

    function errorRebuildContent() {
        $panel.addClass(BASE_CLASS + '--error').removeClass(BASE_CLASS + '--start');
        $content.append('<div><p class="' + RESULT_CLASS + ' ' + RESULT_CLASS + '--error">Rebuild failed</p></div>');
        messageTimeout = setTimeout(setBaseMessageStatus, SHOW_RESULT_TIMEOUT);

        headerMessage('Error | ' + lastChange);
    }

    function setBaseMessageStatus() {
        $panel.removeClass(BASE_CLASS + '--success' + ' ' + BASE_CLASS + '--error' + ' ' + BASE_CLASS + '--start');
        lastChanges = {
            directories: [],
            files: [],
        };

        headerMessage('Idle');
    }

    function headerMessage(message){
        $headerTitle.text(message);
    }

    function showMessage(header) {
        var date = getDate();

        var message = '<div class="content-rebuild-item"><header class="content-rebuild-item__header">' + 
            '<div class="content-rebuild-item__header-message"><h4>' + header + ' according to changes in:</h4></div>' +
            '<div class="content-rebuild-item__date"><p>' + date + '</p></div></header><div class="content-rebuild-item__body"><ul>';

        lastChanges.directories.forEach(function(item) {
            message += '<li>' + item + '</li>';
        });

        lastChanges.files.forEach(function(item) {
            message += '<li>' + item + '</li>';
        });

        return message + '</ul></div></div>';
    }

    function togglePanel() {
        if($panel.hasClass(BASE_CLASS + '--toggle')) {
            $panel.height(DEFAULT_HEIGHT);
            $content.height(DEFAULT_HEIGHT - $header.outerHeight());
        }
        else {
            $panel.height($header.outerHeight());
            $content.height(0);
        }
        loadingPanel.hide();
        loadingPanel.show();
        $panel.toggleClass(BASE_CLASS + '--toggle');
    }

    function closePanel() {
        $panel.removeClass(BASE_CLASS + '--shown');
        loadingPanel.hide();
    }

    function openPanel() {
        loadingPanel.show();
    }

    function getDate(value) {

        if(!value) {
            value = Date.now();
        }

        var date = new Date(value);
        var day = date.getDate();
        if(day < 10) {
            day = '0' + day;
        }
        var month = date.getMonth() + 1;
        if(month < 10) {
            month = '0' + month;
        }
        var hours = date.getHours();
        if(hours < 10) {
            hours = '0' + hours;
        }
        var minutes = date.getMinutes();
        if(minutes < 10) {
            minutes = '0' + minutes;
        }
        var seconds = date.getSeconds();
        if(seconds < 10) {
            seconds = '0' + seconds;
        }
        return day + '.' + month + '.' + date.getFullYear() + ' ' +
            hours + ':' + minutes + ':' + seconds;
    }

    var MY_COMMAND_ID = 'content.rebuild.info';
    CommandManager.register('Show content rebuilding info', MY_COMMAND_ID, openPanel);

    var menu = Menus.getMenu(Menus.AppMenuBar.VIEW_MENU);
    menu.addMenuItem(MY_COMMAND_ID);

});