/*global define, $, brackets */

define(function (require, exports, module) {
    "use strict";

    // var CommandManager   = brackets.getModule("command/CommandManager");
    var EditorManager    = brackets.getModule("editor/EditorManager");
    var DocumentManager  = brackets.getModule('document/DocumentManager');

    var ExtensionUtils   = brackets.getModule('utils/ExtensionUtils');
    var AppInit          = brackets.getModule('utils/AppInit');

    var mainTpl          = require('text!./html/main.html');
    var tableTpl         = require('text!./html/table.html');
    var utils            = require('../../utils/main');

    var $editorWindow    = $('.pane-content');
    var $main;
    var $searchInput;
    var $showNewOnly;
    var $labelsStatus;
    var $tableContainer;
    var $table;

    var currentDocument;
    var labels;
    var displayLabels;
    var searchDelay;
    var oldQuery;
    var oldLabelValue;

    // Settings
    var searchDelayTime = 500;
    var maxResults      = 200;
    var minCharacters   = 1;
    var showNewLabels   = false;
    var labelsStatus    = {
        busy          : 'Busy...',
        ready         : 'Found {labelCount} labels',
        readyAndCut   : 'Found {labelCount} labels, showing {maxResults}',
        toShort       : 'Type at least {minCharacters} character(s)',
        noResults     : 'No labels found.'
    }

    // load CSS
    ExtensionUtils.loadStyleSheet(module, './css/main.css');

    // Init
    function getCurrentFileContents(){
        currentDocument = DocumentManager.getCurrentDocument();
        if($main) $main.remove();
        
        // Cancel if not [a-z]-[A-Z].json filename
        if(!currentDocument || !/[a-z]{2}\-[A-Z]{2}\.json/.test(currentDocument.file._name)){
            return;
        }

        // Original labels object
        labels = JSON.parse(currentDocument.getText());

        // This will create a copy of the labels to manipulate
        displayLabels = JSON.parse(JSON.stringify(labels));

        $main = $(Mustache.render(mainTpl, {filename: currentDocument.file._name.split('.')[0]}));
        $main.prependTo($editorWindow);

        $searchInput = $('#labelsSearchInput');
        $showNewOnly = $('#labelsShowNewOnly');
        $labelsStatus = $('#labelsStatus');
        $tableContainer = $('#tableContainer');

        bindDomEvents();
    }

    // Render table
    function renderTable(data){

        $table = $(Mustache.render(tableTpl, {labels: data}));

        $tableContainer.html($table);
        $main.find('.table-container').removeClass('hidden');
        bindTableEvents();
    }

    // Clear table
    function clearTable(){
        $main.find('.table-container').addClass('hidden');
        $tableContainer.empty();
    }

    // Display status
    function showStatus(status, vars){

        var statusText = labelsStatus[status];
        for(var key in vars){
            statusText = statusText.replace('{' + key + '}', vars[key]);
        }
        $labelsStatus.text(statusText);
    }

    var handlers = {
        searchLabel: function(e){
            
            var query = String($searchInput.val()).toLowerCase();

            // If the value is the same, don't search 
            if(oldQuery == query){
                return;
            }

            // Buffer the query for comparison
            oldQuery = query;

            if(searchDelay) clearTimeout(searchDelay);
            showStatus('busy');

            searchDelay = setTimeout(function(){

                if(!showNewLabels && query.length < minCharacters){
                    showStatus('toShort', {minCharacters: minCharacters});
                    clearTable();
                    return;
                }

                var results = [];
                for(var index = 0; index < displayLabels.length; index++){

                    var item = displayLabels[index];
                    item.index = index;

                    if(
                        (
                            showNewLabels
                            && item.value == ''
                            && item.key.toLowerCase().indexOf(query) > -1
                        )
                        ||
                        (
                            !showNewLabels
                            && (
                                item.key.toLowerCase().indexOf(query) > -1 ||
                                item.value.toLowerCase().indexOf(query) > -1
                            )
                        )
                    ){
                        results.push(item);
                    }
                };

                if(results.length == 0){
                    showStatus('noResults');
                    clearTable();
                    return;
                }

                results.sort(function(a, b){
                    return Date.parse(b.timestamp) - Date.parse(a.timestamp);
                });

                if(results.length > maxResults){
                    showStatus('readyAndCut', {labelCount: results.length, maxResults: maxResults});
                    results = results.slice(0, maxResults);
                } else {
                    showStatus('ready', {labelCount: results.length});
                }

                renderTable(results);
                
            }, searchDelayTime);
        },
        updateLabel: function(e){
            
            var currentInput = $(e.currentTarget);
            var currentIndex = currentInput.data('index');
            var newValue = currentInput.val();

            // Cancel if there's no change
            if(oldLabelValue == newValue){
                return;
            }

            // Buffer label value for comparison
            oldLabelValue = newValue;

            labels[currentIndex].value = newValue;
            displayLabels[currentIndex].value = newValue;

            currentDocument.setText(JSON.stringify(labels, null, 2));

        },
        toggleNewOnly: function(){
            showNewLabels = !showNewLabels;

            $showNewOnly[showNewLabels ? 'addClass' : 'removeClass']('active');
            handlers.searchLabel();
        },
        activeEditorChangeHandler: function(){
            getCurrentFileContents();
        },
        beforeSaved: function(){
            currentDocument.setText(JSON.stringify(labels, null, 2));

            console.log('saving...');
        },
        documentSaved: function(){

            console.log('saved!');
            
        },
        documentChanged: function(){
            console.log('doc changed');
        }
    }

    function bindEvents(){
        EditorManager.on('activeEditorChange', handlers.activeEditorChangeHandler);
        DocumentManager.on('documentSaved', handlers.documentSaved);
        DocumentManager.on('fileNameChange', handlers.documentChanged);
        DocumentManager.on('pathDeleted', handlers.documentChanged);
    }

    function bindDomEvents(){
        $searchInput.on('keyup', handlers.searchLabel);
        $showNewOnly.on('click', handlers.toggleNewOnly);
    }

    function bindTableEvents(){
        $table.find('.labels-value-input').on('keyup', handlers.updateLabel);
    }

    // App is ready
    AppInit.appReady(function () {
        bindEvents();
    });
});