/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets */

/** Simple extension that adds a 'File > Hello World' menu item. Inserts 'Hello, world!' at cursor pos. */
define(function (require, exports, module) {
  'use strict';

  var Commands            = brackets.getModule('command/Commands');
  var CommandManager      = brackets.getModule('command/CommandManager');
  var EditorManager       = brackets.getModule('editor/EditorManager');
  var DocumentManager     = brackets.getModule('document/DocumentManager');
  var Menus               = brackets.getModule('command/Menus');
  var ProjectManager      = brackets.getModule('project/ProjectManager');
  var WorkspaceManager    = brackets.getModule('view/WorkspaceManager');
  var ExtensionUtils      = brackets.getModule('utils/ExtensionUtils');
  var gitPanelTpl         = require('text!./html/brix-git-panel.html');
  var gitDialogTpl        = require('text!./html/brix-git-dialog-username.html');
  var AppInit             = brackets.getModule('utils/AppInit');
  var utils               = require('../../utils/main');
  var Dialogs             = brackets.getModule('widgets/Dialogs');
  var PreferencesManager  = brackets.getModule("preferences/PreferencesManager");
  var prefs               = PreferencesManager.getExtensionPrefs("brix");

  // load CSS
  ExtensionUtils.loadStyleSheet(module, './css/brix-git.css');

  var serverDomain = 'http://preview.travix.com:1616/';
  var panel = WorkspaceManager.createBottomPanel('git.panel',$(gitPanelTpl));
  var rootFolder = navigator.platform.indexOf('Win') > -1 ? '/' : 'src/';

  var username, basePath, msgTimer, fileList, filterTimeout;

  fileList = [];
  username = prefs.get('brackets-brix.username');

  if(!username) showUsernameDialog();

  function showUsernameDialog(){
    var dialog = Dialogs.showModalDialog('dialogs.git.username', 'Please enter your username', gitDialogTpl);
    var dialogElem = dialog.getElement();
    var dialogPromise = dialog.getPromise();
    var dialogBtn = dialogElem.find('.dialog-button');
    var userNameInput = dialogElem.find('#brix-git-username');

    dialogBtn.attr('disabled', 'disabled');

    userNameInput.keyup(function(){
      if(this.value.length > 0) dialogBtn.removeAttr('disabled');
      else dialogBtn.attr('disabled', 'disabled');
    });

    dialogPromise.done(function(){
      username = userNameInput[0].value;

      prefs.set('brackets-brix.username', username);
    })
  }

  function openPanel(){
    panel.show();
    getGitStatus();

    $('#brixGitButton').addClass('active');
  }

  function closePanel(){
    panel.hide();

    $('#brixGitButton').removeClass('active');
  }

  function togglePanel(){

    if(panel.isVisible()){
      closePanel();
    } else {
      openPanel();
    }
  }

  function filterResults(){
    var contents = $('#gitPanel .panel-contents');
    var val = $('#gitPanel .gitFilter').val();

    if(filterTimeout) clearTimeout(filterTimeout);

    filterTimeout = setTimeout(function(){
      var results = contents.find('.row').hide().filter(function(index, elem){
        return elem.innerHTML.toLowerCase().indexOf(val) > -1;
      });

      results.show();

      $('#gitResultCount').text(results.length);
    }, 250);
  }

  function gitPush(){

    var msg;
    var contentPanel = $('#gitPanel .panel-contents');

    modal('Pushing the files...', true);
    $('#gitPanel .confirmPush').prop('checked', false);

    $.ajax({
      type: 'POST',
      url: serverDomain + 'push?username=' + username,
      data: { files: fileList },
      timeout: 20000
    }).done(function (result) {
      modal('All files have been pushed succesfully.', false, function(){
        getGitStatus();
      });
    }).fail(function (err, status) {
      if (status == 'timeout') {
        msg = 'Request timeout. <br /><br /> Looks like somebody is pushing changes right now. Please, try again later<br />';
      } else {
        msg = 'Something went wrong. <br/><br/>Git message: <br/>';
        msg += '<p style="text-align:left">' + err.responseText + '<br/></p>';
      }

      modal(msg, true, function(){
        getGitStatus();
      });
    });
  }

  function togglePushLock(event){

    if(event && fileList.length == 0){
      $(event.currentTarget).prop('checked', false);
      modal('Select 1 or more files first.');
      return;
    }

    if(event && event.currentTarget.checked){
      $('.confirmLock').addClass('unlocked');
      $('.gitPush').removeAttr('disabled');
    } else {
      $('.confirmLock').removeClass('unlocked');
      $('.gitPush').attr('disabled', 'disabled');
    }
  };

  function toggleCheckAllFiles(event){
    fileList = [];

    $('#gitPanel .panel-contents ul > li:visible input.selectFile')
      .prop('checked', event.currentTarget.checked)
      .trigger('change');
  }

  function modal(msg, persistent, callback){
    if(msgTimer) clearInterval(msgTimer);
    if(!callback) callback = null;

    if(msg){
      if(!persistent) msgTimer = setTimeout(modal, 2000, callback);

      $('#gitPanel .panel-contents').addClass('blur');
      $('#gitPanel .modal').show().html(msg);
    } else {
      $('#gitPanel .panel-contents').removeClass('blur');
      $('#gitPanel .modal').hide(200, callback);
    }
  }

  function getGitStatus(){
    var contents = $('#gitPanel .panel-contents');
    var list = '';
    fileList = [];
    showFileCount();
    contents.empty();
    togglePushLock();

    $('#gitPanel .checkAllFiles').prop('checked', false);

    modal('Loading...', true);

    $.get(serverDomain + 'status', function(data){

      $('#gitResultCount').text(data.length);

      if(data.length == 0){
        modal('No changes found, everything is up to date.');
        return;
      }

      data.forEach(function(item, index){

        list += '<li class="row ' + (item.status ? item.status.toLowerCase() : '') + '">';
        list += '<span class="checkbox"><input type="checkbox" class="selectFile" value="' + item.file + '"/></span>';
        list += '<span class="file">' + item.file + '</span>';
        list += '<span class="status">' + (item.status || '') + '</span>';
      });

      contents.html('<ul class="list">' + list + '</ul>');
      bindListEvents();
      modal();

      filterResults();
    }).fail(function (err) {
        
      modal(err.responseText, true, function(){
        getGitStatus();
      });
    });
  }

  function showFileCount(){
    var btnText = 'Push selected files';

    if(fileList.length > 0) btnText += ' (' + fileList.length + ')';

    $('.gitPush').val(btnText);
  }

  function bindEvents(){
    $('#brixGitButton').click(togglePanel);
    $('#gitPanel .panelClose').click(closePanel);
    $('#gitPanel .gitRefresh').click(getGitStatus);
    $('#gitPanel .gitPush').click(gitPush);
    $('#gitPanel .gitFilter').keyup(filterResults);
    $('#gitPanel .confirmPush').change(togglePushLock);
    $('#gitPanel .checkAllFiles').change(toggleCheckAllFiles);
    $('#gitPanel .modal').click(function(){modal()});

    DocumentManager.on('documentSaved', getGitStatus);
    DocumentManager.on('fileNameChange', getGitStatus);
    DocumentManager.on('pathDeleted', getGitStatus);
  }

  function bindListEvents(){

    $('#gitPanel .panel-contents ul > li:visible input.selectFile').change(function(){

      var val = $(this).val();

      if($(this).is(':checked')){
        fileList.push(val);
      }
      else {
        fileList.splice(fileList.indexOf(val), 1);
      }

      showFileCount();
    });

    $('#gitPanel .panel-contents li.row:not(.deleted) .file').click(function(){

      basePath = ProjectManager.getProjectRoot()._path.split(rootFolder)[0] + rootFolder;

      var filePath = basePath + $(this).text();
      console.log(filePath);

      CommandManager.execute(Commands.CMD_OPEN, {fullPath: filePath});
    });
  }

  utils.ws.on('preview.error', function(data){

    var errorCount = data && typeof data == 'object' ? Object.keys(data).length : 0;
    $('#gitPanel .confirmLock, #gitPanel .gitPush')[errorCount ? 'addClass' : 'removeClass']('error');
  });

  $('#main-toolbar .buttons').append($(document.createElement('a')).attr('id', 'brixGitButton'));

  // App is ready
  AppInit.appReady(function () {
    bindEvents();
  });
})