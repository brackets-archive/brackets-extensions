/*global define, $, brackets */

/** Brix plugin loader */
define(function (require, exports, module) {
  'use strict';

  /* Modules */
  var ExtensionManager  = brackets.getModule('extensibility/ExtensionManager');
  var ExtensionUtils    = brackets.getModule('utils/ExtensionUtils');


  var labels            = require('./plugins/labels/main');
  var git               = require('./plugins/git/main');
  var highlight         = require('./plugins/highlight/main');
  var snippets          = require('./plugins/snippets/main');
  var preview           = require('./plugins/preview/main');
  var errors            = require('./plugins/errors/main');
  var notify            = require('./plugins/notify/main');
  var changelog         = require('./plugins/changelog/main');
  var searchAndReplace  = require('./plugins/search/main');
  var contentRebuild    = require('./plugins/contentRebuild/main');
  
  // In POC status, adds a quick find input to the file tree browser
  // var quickfind         = require('./plugins/quickfind/main');

  /* Load global styles */
  ExtensionUtils.loadStyleSheet(module, './css/brix-global.css');

  /* Check for updates */
  ExtensionManager.downloadRegistry()
    .then(function(){

      var availableUpdates = ExtensionManager.getAvailableUpdates();
      var brixInfo;

      // cancel if no updates are available
      if(availableUpdates.length == 0){
        return;
      }

      // Extract Brix update if available
      availableUpdates.forEach(function(extensionInfo){
        if(extensionInfo.id = 'brackets-brix'){
          brixInfo = extensionInfo;
        }
      });

      // Update found for Brix
      if(brixInfo){

        var updateMessage = [
            'Update for Brix available ('
          , brixInfo.installVersion
          , ' --> '
          , brixInfo.registryVersion
          , '). Please update Brix from the extension manager to the right.'
        ].join('');

        // Mark display changelog after update
        changelog.showAfterUpdate();
        
        // Show update notification
        notify(updateMessage, true);

        // Nothing else to do here
        return;
      }
    });
});