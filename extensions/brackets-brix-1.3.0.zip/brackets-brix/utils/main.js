/*global define, $, brackets */

/** Global Brix plugin assets */
define(function (require, exports, module) {
  'use strict';

  var _                       = brackets.getModule('thirdparty/lodash');
  var CommandManager          = brackets.getModule('command/CommandManager');
  var Commands                = brackets.getModule('command/Commands');
  var Handlebars              = require('./js/vendor/handlebars-v3.0.3');
  var Marked                  = require('./js/vendor/marked');
  var config                  = require('../config/main');
  var io                      = require('./js/vendor/socket.io');

  Handlebars.registerHelper('convertNewlines', function(str) {
    return str ? str.replace(/\n/g, '<br/>') : '';
  });

  /**
   * Set up connection with websocket server
   * @method webSocket
   * @param  {Object}   options Extend default settings
   * @param  {Function} cb      Callback on receiving message
   */

  // Connect to preview
  this.ws = io.connect(config.webSocketPath, { reconnect: true });


  /**
   * Show/hide panel and set active class on sidebar button
   * @method togglePanel
   * @param  {Object}    panel      Brackets panel object (WorkspaceManager.createBottomPanel)
   * @param  {Object}    sidebarBtn jQuery node object $('#button')
   * @return {Promise}              Returns promise with new visibility of panel
   */
  this.togglePanel = function(panel, sidebarBtn){

    var promise = $.Deferred();
    var isVisible = panel.isVisible();

    panel[isVisible ? 'hide' : 'show']();
    sidebarBtn[isVisible ? 'removeClass' : 'addClass']('active');

    return promise.resolve(!isVisible);
  }

  /**
   * Shortcut for creating new jQuery element
   * @method create
   * @param  {String} elem Name of new element to create (div, span etc)
   * @return {Object}      Returns jQuery node object
   */
  this.create = function(elem){
    return $(document.createElement(elem));
  }

  /**
   * Shortcut for opening a file in Brackets
   * @method open
   * @param  {String} filePath Absolute path to the file (/Users/Name/path)
   */
  this.open = function(filePath){
    CommandManager.execute(Commands.CMD_OPEN, {fullPath: filePath});
  }

  /**
   * Create and add new sidebar button
   * @method addSidebarButton
   * @param  {Object}         options Extend default settings
   * @return {Object}                 Returns jQuery node object of the new button
   */
  this.addSidebarButton = function(options){

    var settings = _.extend({
      classNames: ['brix-sidebar-btn'],
      href: '#',
      html: '',
      container: '#main-toolbar .buttons'
    }, options);

    if(options.className) settings.classNames.push(options.className);

    var btn = $(document.createElement('a'))
                .addClass(settings.classNames.join(' '))
                .attr('href', settings.href)
                .html(settings.html)
                .appendTo(settings.container);

    return btn;
  }

  /**
   * Parse raw HTML string with data
   * @method tpl
   * @param  {String} str    Raw HTML string with placeholders to convert to tpl
   * @param  {Object} tokens Dynamic data for replacing placeholders in tpl
   * @return {Object}        jQuery HTML object
   */
  this.tpl = function(str, tokens){

    var template = Handlebars.compile(str);
    return $(template(tokens));
  }

  this.parseMarkdown = function(str){

    return Marked(str);
  }

  /**
   * Dispatch custom event
   * @method trigger
   * @param  {String} eventName Event name to dispatch
   * @param  {Object} details   Object with additional information to pass
   */
  this.trigger = function(eventName, details){
    var event = new CustomEvent(eventName, {detail: details || {}});
    document.dispatchEvent(event);
  }

  /**
   * Show only elements that contain the query string
   * @method filter
   * @param  {jQuery} target [jQuery HTML Node object]
   * @param  {String} query  [String to filter]
   */
  this.filter = function(target, query){
    target.hide().filter(function(){
      return $(this).html().toLowerCase().indexOf(query) > -1;
    }).show();
  }

});
