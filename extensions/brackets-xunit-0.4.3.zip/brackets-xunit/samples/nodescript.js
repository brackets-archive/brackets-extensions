#!/usr/bin/env node
/* brackets-xunit: args=one,two,three */

console.log("running a node script");
console.log("args: "+process.argv);
