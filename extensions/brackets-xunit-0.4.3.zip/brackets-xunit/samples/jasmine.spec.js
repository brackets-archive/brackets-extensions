describe("The first suite", function () {
    it("1st testcase should be green", function () {
        expect(true).toBe(true);
    });
    it("2nd testcase the top should appear as (green) o o o o,(green) Passing 4 specs", function () {
        expect(true).toBe(true);
    });
});
describe("The second suite", function () {
    it("1st testcase", function () {
        expect(true).toBe(true);
    });
});
describe("The third suite", function () {
    it("2nd testcase", function () {
        expect(true).toBe(true);
    });
});
describe("The fourth suite", function () {
    it("3rd testcase", function () {
        expect(true).toBe(true);
    });
});