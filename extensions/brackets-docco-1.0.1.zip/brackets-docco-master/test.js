/*jslint sloppy: true */

// ## This is H2 ##
// This function is for test only
var myF = function () {
};