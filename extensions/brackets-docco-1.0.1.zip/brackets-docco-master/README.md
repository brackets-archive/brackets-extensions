## brackets-docco

A [Brackets](https://github.com/adobe/brackets) extension to use [Docco](http://jashkenas.github.io/docco/)

### How To Use

Before use you need to Install Docco:

    sudo npm install -g docco
    
After you have install Docco, just right click on a js file and click "Run Docco".
For more info please visit [Docco](http://jashkenas.github.io/docco/) website.

Some examples of Docco documentation:
* http://pivotal.github.io/jasmine/
* http://underscorejs.org/docs/underscore.html

