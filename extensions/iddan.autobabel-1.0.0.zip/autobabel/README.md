# autobabel
Transform ES6 and JSX files into ES5 automatically using Babel
