brackets-wdminimap
==================

A minimap extension for the <a href="http://www.brackets.io">Brackets</a> open-source code editor.

![minimap](https://raw.github.com/websiteduck/brackets-wdminimap/master/brackets-wdminimap.png)

To show or hide the minimap, in the top menu click View > Show Minimap.

To switch between plain text or CodeMirror (syntax highlighting), use the right-click context menu of the minimap.
