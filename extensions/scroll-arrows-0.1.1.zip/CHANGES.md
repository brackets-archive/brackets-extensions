# Changelog

## 0.1.1 (27.07.2016)
* On Brackets Release 1.8 and above, scroll track markers that show Find results are positioned correctly
* Added grunt tasks to automate linting and zip creation

## 0.1.0 (17.03.2015)
* Scroll arrows for Windows (dark and light themes)
