define(function (require, exports, module) {
    var ExtensionUtils      = brackets.getModule("utils/ExtensionUtils"),
        ScrollTrackMarkers  = brackets.getModule("search/ScrollTrackMarkers");

    if (ScrollTrackMarkers.setScrollbarTrackOffset) {
        ScrollTrackMarkers.setScrollbarTrackOffset(15);
    }
    ExtensionUtils.loadStyleSheet(module, "styles/scrollbars.less");
});
