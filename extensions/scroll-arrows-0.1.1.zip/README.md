# Brackets Scroll Arrows [![devDependency Status](https://david-dm.org/MarcelGerber/brackets-scroll-arrows/dev-status.svg)](https://david-dm.org/MarcelGerber/brackets-scroll-arrows#info=devDependencies)
Adds scroll arrows to [Brackets](http://brackets.io)' scrollbars. Windows only.

## Screenshots
With Dark theme on Windows ([Lion](https://github.com/Brackets-Themes/Lion)):
![Screenshot with dark theme](img/screenshot-win-dark.png)

With Light theme on Windows (Brackets Light, preinstalled):
![Screenshot with light theme](img/screenshot-win-light.png)
