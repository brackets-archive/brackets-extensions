tornado-brackets
================

Tornado templates highlighter for Brackets

Important
================
Please, since i am a bad programmer, i need an update to make it work independently, so you have to do an extra step to make it work, this way, you will make think that Brackets is shipped with a special edition of CodeMirror:

 1. Download this [folder][1]
 2. Locate your {original installation}\Brackets\www\thirdparty\CodeMirror2\mode (windows, mac i dont know, sorry).
 3. Add the folder as a name *tornado* and copy the contents you downloaded from (1).
 4. Your extension should work now :)

I am sorry again for the workaround, i need some serious javascript courses :D

[1]: https://github.com/abdelouahabb/CodeMirror/tree/master/mode/tornado
