
# glayzzle/php-parser

This is a pretty cleaned up copy from [glayzzle/php-parser](https://github.com/glayzzle/php-parser).
