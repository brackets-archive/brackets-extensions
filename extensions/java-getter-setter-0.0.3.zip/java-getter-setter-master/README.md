# Brackets getter/setter generator
[Brackets][Brackets] Extension that generate Java getter/setter based on selected text.

## Usage
Brackets getter/setter generator need to be run manually on a selection with the command `Ctrl-Shift-Q` (Windows/Linux) and `Cmd-Shift-Q` (Mac).

## License
Brackets getter/setter generator is licensed under the [MIT license][MIT].

[Brackets]: http://brackets.io
[MIT]: http://opensource.org/licenses/MIT