/*
 * The MIT License (MIT)
 * Copyright (c) 2016 Mattia Della Mina. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 */

/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window, Mustache */

define(function(require, exports, module) {

    var CommandManager = brackets.getModule("command/CommandManager"),
        Menus = brackets.getModule("command/Menus"),
        EditorManager = brackets.getModule("editor/EditorManager"),
        AppInit = brackets.getModule("utils/AppInit"),
		indentChar = "\t",
		getMethodText = indentChar + "public {type} get{camel}(){\n" + indentChar + indentChar + "return {field};\n" + indentChar + "}\n",
		setMethodText = indentChar + "public void set{camel}( {type} value ){\n" + indentChar + indentChar + "{field} = value;\n" + indentChar + "}\n";
		

    AppInit.appReady(function () {

        var JAVA_GETTER_SETTER = "java-getter-setter.execute";
        CommandManager.register("Java Getter Setter Generator", JAVA_GETTER_SETTER, getterSetterGenerator);

        var editMenu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
        editMenu.addMenuItem(JAVA_GETTER_SETTER, "Ctrl-Shift-Q");

    });

    var getterSetterGenerator = function() {
        var selectionForEdit = EditorManager.getActiveEditor().convertToLineSelections( EditorManager.getActiveEditor().getSelections() )[0].selectionForEdit;
        EditorManager.getActiveEditor().setSelection( selectionForEdit.start, selectionForEdit.end );
        var _input = EditorManager.getActiveEditor().getSelectedText(),
            _output = "",
            rowArray = _input.split( /\n/ );
        rowArray.forEach(function( value, index ){
            _output += _generateGetterSetter( value );
        });
        if( _output.length > 0 ){
            _output = "\n" + _output;
        } else {
            _log( "Error generating getter and setter :`(" );
        }
        var cursorPosition = EditorManager.getActiveEditor().getCursorPos( false, "end" );
        EditorManager.getActiveEditor().document.replaceRange( _output, cursorPosition, cursorPosition );

    }
    
    function _generateGetterSetter(s) {
        var _words = s.split( /\W/ ),
            _result = new Array(),
            _text = "";
        _words.forEach(function( value, index ){
            value = _trim( value );
            if( value.length > 0 ){
                _result.push( value );
            }
        });
        if( _result.length != 3 ) {
            return "";
        }
        _text += _generateGetterText( _result );
        _text += _generateSetterText( _result );
        
        return _text;
    }
    
    function _log(s){
        console.log("[Getter/Setter] "+s);
    }
    
    function _generateGetterText(obj){
	    return _formatText( getMethodText, { type: obj[1], field: obj[2], camel: _firstCamel( obj[2] ) } );
    }
    
    function _generateSetterText(obj){
	    return _formatText( setMethodText, { type: obj[1], field: obj[2], camel: _firstCamel( obj[2] ) } );
    }
    
    function _firstCamel(s){
        return s.charAt(0).toUpperCase() + s.slice(1);
    }
    
    function _trim(s){
        return s.replace( /^\s\s*/, '' ).replace( /\s\s*$/, '' );
    }
    
    function _formatText( str, obj ) {
        for( var key in obj ) {
            var regexp = new RegExp( '\\{' + key + '\\}', 'gi' );
            str = str.replace( regexp, obj[key] );
        }
        return str;
    }

});