CHANGELOG
=========

##1.0.5
- [CHANGE] Update matching tag and bracket colors

##1.0.4
- [CHANGE] Update matching tag and bracket colors

##1.0.3
- [NEW] Add support for code-folding (https://github.com/thehogfather/brackets-code-folding)
- [NEW] Add CHANGELOG
- [DOCS] Update README
- [CHANGE] Require Brackets 1.0.0 or higher
- [CHANGE] Update matching tags color

##1.0.2
- [CHANGE] Change white space color to be be more subtle

##1.0.1
- [NEW] Add support for white-space (https://github.com/DennisKehrig/brackets-show-whitespace)
- [CHANGE] Update and re-organize less varables

##1.0.0
- [NEW] Initital Release