(function($) {
  // My code goes here.
  // linter should not throw random exceptions because the file starts with
  // an open paren. Regression test for bug 2966755.
})(jQuery);
