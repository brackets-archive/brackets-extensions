#!/usr/bin/env python

"""Package indicator for closure_linter and glfags."""
