#FOCUS
###A CUSTOM THEME FOR ADOBE BRACKETS

![Screenshot of the Focus theme in action](screenshot.png)

>"A really dark theme with vibrant colors that make sense, so that you won't miss anything. It'll help you focus at coding."

</br>

###Changelog
 ---
 **July 15, 2016 - Version 1.0**
 * Initial release.
 
 <br/>

###Description
---

This theme follows the original template for Brackets Default Theme.<br/>
Be sure to check it's [documentation](https://github.com/adobe/brackets/wiki/Creating-Themes) if you wish to make any changes to it.

You can find some examples of the classes at [Codemirror's Website](http://codemirror.net)

If you have any suggestions or wish to contribute, hit me at [github](http://github.com/brucecantarim).

Cheers!

 -Bruce
 
 </br>
 
