# Simply-Unique
My very own created Brackets editor theme.
<br>
I have made this theme with a lot of love so please use it and if you use my files to create your own theme then please credit me with a simple mention. :)

<h3>Screenshots</h3>
![alt text](Screenshot (59).png "Tag matching")
![alt text](Screenshot (60).png "Bracket matching")
![alt text](Screenshot (62).png "Text selection")
![alt text](Screenshot (58).png "A unique CSS look and feel")
![alt text](Screenshot (56).png)
<h3>Contributions and Issues</h3>
Please fork this repository and help improve this theme

<h3>License</h3>
MIT
