/* global $, define, brackets */
/* jshint browser: true */
define(function (require, exports, module) {
    "use strict";

    var CommandManager      = brackets.getModule("command/CommandManager"),
        Menus               = brackets.getModule("command/Menus"),
        Resizer             = brackets.getModule("utils/Resizer"),
        StatusBar           = brackets.getModule("widgets/StatusBar"),
        AppInit             = brackets.getModule("utils/AppInit"),
        WorkspaceManager    = brackets.getModule("view/WorkspaceManager"),
		PreferencesManager  = brackets.getModule("preferences/PreferencesManager"),
        prefs               = PreferencesManager.getExtensionPrefs("gtTodo"),
        stateManager        = PreferencesManager.stateManager.getPrefixedSystem("gtTodo"),
        ExtensionUtils      = brackets.getModule("utils/ExtensionUtils");
	
	var items = localStorage.getItem('gtTodoItems');
	prefs.definePreference("showTodoPanel", "boolean", false);
	
	if(items === null){
		// First run (probably)
		localStorage.setItem('gtTodoItems', []);
		items = [];
	}
	
	/**
	 * Builds a JSON object and saves it to local storage
	 */
	function saveItems(){
		var items = [];
		var itemCount = 0;
		
		$('.gtTodo-items tr.item').each(function(index, value){
			if($(this).hasClass('clone')){ return; }
			if(!$(this).find('input[type=text]').val()){ return; }
			
			items.push({
				'description': $(this).find('input[type=text]').val(),
				'completed': $(this).find('input[type=text]').prop('disabled')
			});
			
			if(!$(this).find('input[type=text]').prop('disabled')){ itemCount++; }
		});
		
		$('.gtTodo-indicator .taskCount').text(itemCount);
		
		var itemsToSave = JSON.stringify(items);
		localStorage.setItem('gtTodoItems', itemsToSave);
	}
	
	/**
	 * Clones an empty row and adds it to the table
	 */
    function addItem(){
        var $newRow = $('.gtTodo-items .clone').clone(); 
        $newRow.insertAfter($('.gtTodo-items tr.clone')).removeClass('clone').show();
        $('input[type=text]', $newRow).focus();
    }

    AppInit.appReady(function(){
        var gtTodo = $("<div class='gtTodo-indicator'>Outstanding Tasks: <span class='taskCount'>0</span></div>");
        var statusBar = StatusBar.addIndicator("gtTodo", gtTodo);
        var gtTodoPanel = require('text!bottom-panel.html');
        var panel = WorkspaceManager.createBottomPanel('gtTodoPanel', $(gtTodoPanel), 200);
		
		$('.gtTodo-items').height($('#gtTodo').height() - 20);
		
		if(items){
			var jsonItems = $.parseJSON(items);
			var itemCount = 0;

			$.each(jsonItems, function(index, value){
				var $newRow = $('.gtTodo-items .clone').clone(); 
				$newRow.find('input[type=text]').val(value.description);
				$newRow.find('input[type=text]').prop('disabled', value.completed);
				$newRow.find('input[type=checkbox]').prop('checked', value.completed);
				$newRow.insertBefore($('#gtTodo tr.addRow')).removeClass('clone');
				
				if(!value.completed){ itemCount++; }
			});
			
			$('.gtTodo-indicator .taskCount').text(itemCount);
		}
		
		$('#gtTodo').on('panelResizeUpdate', function(e){
			$('.gtTodo-items').height($(this).height() - 20);
		});

        ExtensionUtils.loadStyleSheet(module, "main.less");
		
		// Toggles the panel, updates show preferences
        $('.gtTodo-indicator').show().click(function(){
            if(Resizer.isVisible($('#gtTodo'))){
                Resizer.hide($('#gtTodo'));
				prefs.set("showTodoPanel", false);
            }else{
                Resizer.show($('#gtTodo'));
				prefs.set("showTodoPanel", true);
            }
        });
		
		// Hides the panel
		$('#gtTodo a.close').click(function(){
			Resizer.hide($('#gtTodo'));
			prefs.set("showTodoPanel", false);
		});
		
		// Completes/uncompletes a to-do list item
        $(document).on('click', '.gtTodo-items input[type=checkbox]', function(){
            var $input = $(this).parent().next().find('input');

            if($(this).is(':checked')){
                $input.prop('disabled', true);
            }else{
                $input.prop('disabled', false);
            }
			
			saveItems();
        });
		
		// Removes to-do list item rows
        $(document).on('click', '.gtTodo-items .remove', function(){
            var $tr = $(this).parent();
            $tr.remove();
			saveItems();
        });
        
		// Checks for enter press, adds new item
        $(document).on('keyup', '.gtTodo-items input[type=text]', function(e){
            if(e.keyCode == 13){
                addItem();
            }
			
			// Run the save routine after 250ms (time to add more info)
			setTimeout(saveItems, 250);
        });
		
		// Adds a new to-do list item
        $('.gtTodo-add').click(function(){
            addItem();
        });
		
		// Checks if the to-do list was open, if so re-opens on load
		if(prefs.get('showTodoPanel')){
			Resizer.show($('#gtTodo'));	
		}

    });

});