Brackets Tasks
===================

Brackets plugin that enables a basic task list in the editor
