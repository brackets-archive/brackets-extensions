# material-dark-brackets

Material dark inspired by Mattia Astorino's [SublimeText theme](https://github.com/equinusocio/material-theme) for brackets

![](http://i.imgur.com/RF238rR.png)
