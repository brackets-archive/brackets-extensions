define(function(require, exports, module){
    return {
        SINGLE_QUOTE: "SINGLE_QUOTE",
        DOUBLE_QUOTE: "DOUBLE_QUOTE"
    };
});