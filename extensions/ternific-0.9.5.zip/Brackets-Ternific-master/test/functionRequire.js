define(function(require, exports, module) {

    function functionRequire() {
    }

    functionRequire.prototype.test = function() {
    };

    return functionRequire;
});
