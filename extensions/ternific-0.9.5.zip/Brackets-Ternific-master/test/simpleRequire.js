define(function (require, exports, module) {

    var goodRequire = require("goodRequire");
    var badRequire = require("badRequire");


    // Should return a function as the type
    var functionRequire = require("functionRequire");

});
