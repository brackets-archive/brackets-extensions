define(function (require, exports, module) {
    "use strict";
    var jsMode = "javascript";
  jsMode.


});