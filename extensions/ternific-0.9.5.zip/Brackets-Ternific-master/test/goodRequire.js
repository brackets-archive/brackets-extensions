define(function(require, exports, module){
    $.extend(exports, {
        SINGLE_QUOTE: "SINGLE_QUOTE",
        DOUBLE_QUOTE: "DOUBLE_QUOTE"
    });

    return exports;
});