asciitoentity
=============

ASCII to Unicode and HTML Entity modal dialog
