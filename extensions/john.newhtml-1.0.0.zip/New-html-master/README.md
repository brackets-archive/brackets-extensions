New html
=======

This only let you create a Html skeleton with 2 simple click.

Html>New html

feel free to edit html-template.html for your personal use !
