Copyright (c) 2014 John Barry
