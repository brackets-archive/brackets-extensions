Based on Pantone's [Spring 2017 Color Report](https://www.pantone.com/fashion-color-report-spring-2017).

HTML:

![html preview](https://i.imgur.com/OR9tEOg.jpg)

JS:

![js preview](https://i.imgur.com/mbNBg1w.jpg)

JSON: 

![json preview](https://i.imgur.com/IZ16Ult.jpg)

CSS (Less):

![less preview](https://i.imgur.com/n9QOl41.jpg)

Ruby:

![rb preview](https://i.imgur.com/8vfv75B.jpg)
