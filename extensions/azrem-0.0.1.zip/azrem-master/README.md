azrem
=====

This is a simple theme i customized to use with Python and espetially with Django/Tornado Templates.

Azrem means Snake in Kabyle (People living in north africa), the name is about Python :D

azrem
=====
The original theme, is called Easy-Dark, forked from [Theme EasyDark Copyright (c) 2014 Miguel Castillo.][1], it is beautiful, but when i tried to use it with Tornado templates/Python, i found that i have to customize it a little bit.

![Here is some](https://cloud.githubusercontent.com/assets/2527234/4639059/5a77a800-5405-11e4-9c58-703441d977ea.jpg)

[1]:https://github.com/Brackets-Themes/EasyDark
