   
   A CLEAN SYNTAX THEME FOR BRACKETS

   https://github.com/lipeprado/Brazil-Clean-Theme.git
   
    Clean Brazil
    
    Um tema elegante para o Brackets, 
    simples de entender e facilita no diferenciamento na hora de codificar,
    ajustavél para todas as linguagens.
    
    Versão:
       Clean_v1
    Autor:
       LipePrado
      
    License: 
      MIT


    
    
     [https://raw.githubusercontent.com/lipeprado/Brazil-Clean-Theme/master/Html.jpg](Versão HTML)
    
   

     [https://github.com/lipeprado/Brazil-Clean-Theme/blob/master/css.jpg](Versão CSS)
