# Liquid

Liquid theme for [Brackets](https://github.com/adobe/brackets).

## Screenshots

### HTML

![HTML Screenshot](https://raw.githubusercontent.com/LAron/Liquid/master/screenshot/html.png)

### LESS / CSS

![LESS / CSS Screenshot](https://raw.githubusercontent.com/LAron/Liquid/master/screenshot/less.png)

### JavaScript

![JavaScript Screenshot](https://raw.githubusercontent.com/LAron/Liquid/master/screenshot/javaScript.png)

### PHP

![PHP Screenshot](https://raw.githubusercontent.com/LAron/Liquid/master/screenshot/php.png)


### JSON

![JSON Screenshot](https://raw.githubusercontent.com/LAron/Liquid/master/screenshot/json.png)

### LUA

![LUA Screenshot](https://raw.githubusercontent.com/LAron/Liquid/master/screenshot/lua.png)

### C++

![C++ Screenshot](https://raw.githubusercontent.com/LAron/Liquid/master/screenshot/c++.png)

------------------------------------------------------------
## License
Released under the MIT license.

