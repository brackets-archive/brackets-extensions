Brackets VW Calculator
=================

This is an extension for Adobe Brackets for fast insertion of vw values.


### Usage
Edit->Calculator or Ctrl-Alt-V
