ViewCalc
=================

Viewport calculator extension for Adobe Brackets.


### Usage
Right Toolbar Button, View->ViewCalc or Ctrl-Alt-V