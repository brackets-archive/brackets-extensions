#After8
After8 is a Brackets theme based on my custom jEdit theme, with cool minty green, dark tones.

#Supported extensions
html, css, java, js, jsp, c, cpp, py, rb, properties, and more! 

#Screenshots
screenshots/java.png

#Installation
This extension requires Brackets 1.0 or newer.

- Open Brackets
- File -> extension manager
- Click the Themes tab
- Search for ‘After8’
- Click install

#Todo
Better colors for other languages

#License
Licensed under MIT
