# brackets-moonscript

Moonscript language support for the [Brackets editor](http://brackets.io/) (.moon files).

## Installation

Search for 'moonscript' in Brackets' Extension Manager, hit Install, you're done.

## Authors

  * Leaf Corcoran [@leafo](https://github.com/leafo) - CodeMirror mode
  * Amos Wenger aka [@nddrylliog](https://github.com/nddrylliog) - Brackets extension

## Links

  * [Moonscript language](http://moonscript.org/)
  * [Original CodeMirror mode](https://github.com/leafo/moonscript-javascript/tree/master/codemirror2/mode/moonscript)
  * [Brackets text editor](http://brackets.io)

## License

MIT

