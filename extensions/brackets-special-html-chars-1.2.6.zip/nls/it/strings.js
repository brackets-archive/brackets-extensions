// Italian - strings

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    SPECIAL_HTML_CHARACTER                      : 'Caratteri HTML speciali',
    MORE                                        : 'di più...',
    CLICK_THE_CHARACTER_YOU_WISH_TO_INSERT      : 'Clicca sul carattere che tu vuoi inserire',
    CANCEL                                      : 'Cancella'
});
