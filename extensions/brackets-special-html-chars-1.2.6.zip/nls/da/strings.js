// Danish - strings

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    SPECIAL_HTML_CHARACTER                      : 'Specialtegn HTML',
    MORE                                        : 'mere...',
    CLICK_THE_CHARACTER_YOU_WISH_TO_INSERT      : 'Klik på tegnet du ønsker at indsætte',
    CANCEL                                      : 'Afbryd'
});
