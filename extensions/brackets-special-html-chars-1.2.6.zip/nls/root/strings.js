// English - root strings

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    SPECIAL_HTML_CHARACTER                      : 'Special HTML Character',
    MORE                                        : 'more...',
    CLICK_THE_CHARACTER_YOU_WISH_TO_INSERT      : 'Click the character you wish to insert',
    CANCEL                                      : 'Cancel'
});
