// German - strings

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    SPECIAL_HTML_CHARACTER                      : 'HTML Sonderzeichen',
    MORE                                        : 'mehr...',
    CLICK_THE_CHARACTER_YOU_WISH_TO_INSERT      : 'Klicke auf das Zeichen, das du einfügen möchtest.',
    CANCEL                                      : 'Abbrechen'
});
