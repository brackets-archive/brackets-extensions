// Croatian - strings

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    SPECIAL_HTML_CHARACTER                      : 'specijalni HTML znakovi',
    MORE                                        : 'više...',
    CLICK_THE_CHARACTER_YOU_WISH_TO_INSERT      : 'stisnite znak koji želite umetnuti',
    CANCEL                                      : 'odustani'
});
