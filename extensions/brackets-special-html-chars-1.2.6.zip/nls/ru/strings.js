// Russian - strings

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    SPECIAL_HTML_CHARACTER                      : 'Специальный символ HTML',
    MORE                                        : 'Еще...',
    CLICK_THE_CHARACTER_YOU_WISH_TO_INSERT      : 'Нажмите на символ, который Вы желаете вставить',
    CANCEL                                      : 'Отмена'
});
