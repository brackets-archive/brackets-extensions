// Dutch - strings

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50 */
/*global define */

define({
    SPECIAL_HTML_CHARACTER                      : 'Speciaal HTML teken',
    MORE                                        : 'Meer...',
    CLICK_THE_CHARACTER_YOU_WISH_TO_INSERT      : 'Klik op het teken dat je wil invoegen',
    CANCEL                                      : 'Annuleren'
});
