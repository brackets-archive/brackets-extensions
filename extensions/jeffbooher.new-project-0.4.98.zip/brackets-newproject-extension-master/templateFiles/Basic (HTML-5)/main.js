/*
 * Auto-generated content from the Brackets New Project extension.  Enjoy!
 */