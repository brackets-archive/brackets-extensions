brackets-aspnet
===============

Brackets ASP.NET provides syntax highlighting for ASP.NET MVC View Master Pages.
