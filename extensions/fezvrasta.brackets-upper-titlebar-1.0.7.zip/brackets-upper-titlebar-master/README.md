# Brackets Upper Titlebar

This (stupid) extension just moves the not-native titlebar of Brackets for Linux on top of the window, making it looks like how it looks on Windows.

![preview](preview.png)