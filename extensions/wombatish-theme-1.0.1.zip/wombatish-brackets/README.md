wombatish-brackets
==================

Brackets color scheme based [Wombatish](https://github.com/vlad-saling/wombatish), which is in turn based on original Vim theme [Wombat](http://dengmao.wordpress.com/2007/01/22/vim-color-scheme-wombat/)


Optimized mainly for HTML, CSS, SCSS, LESS, JS, JSON. 
See examples below.


Changelog
---------

v 1.0.1: matching bracket/tag highlight update
 

## HTML
![html](https://dl.dropboxusercontent.com/u/33040431/brackets-html.png)

## CSS
![css](https://dl.dropboxusercontent.com/u/33040431/brackets-css.png)

## SCSS
![scss](https://dl.dropboxusercontent.com/u/33040431/brackets-scss.png)

## JS
![js](https://dl.dropboxusercontent.com/u/33040431/brackets-js.png)