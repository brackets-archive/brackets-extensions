custom-placeholdit-for-brackets
=================

Add option to help menu and icon in toolbar for insert a custom placehold.it image tag in document.
Fork from 'placeholdit-for-brackets' by Enton Biba.

Credits: http://placehold.it/ & http://www.entonbiba.com/