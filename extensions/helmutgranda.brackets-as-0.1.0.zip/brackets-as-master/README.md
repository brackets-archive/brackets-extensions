<img src="http://img.shields.io/badge/version-0.2.0-green.svg?style=flat-square">
[<img src="http://img.shields.io/badge/brackets-up--to--date-green.svg">](http://brackets.io/)
[<img src="http://img.shields.io/badge/Brackets-code editor-blue.svg?style=flat-square">](http://brackets.io/)

Brackets ActionScript
=============
Syntax highlighting and Code Hints for [*Brackets code editor*](http://brackets.io/).

##Supports:
Syntax Highlight for:

* Statements
* Attribute Keywords
* Definition Keywords
* Directives (partial)
* Namespaces (soon)
* Primary expression keywords
* Comments: **//**
* Long Comments: **/*  */**

###**Current State**
Syntax highlighting and Code Hints for ActionScript, Roy lang package was used as guide.

![Sample](https://raw.githubusercontent.com/helmutgranda/brackets-as/master/assample.png)
