
define(function (require, exports, module) {
	'use strict';	
	
	var ActionScriptSyntaxHighligh = require('src/actionscriptsyntaxhighligh');
	var ActionScriptCodeHint		 = require('src/actionscriptcodehint');

	ActionScriptSyntaxHighligh;
	ActionScriptCodeHint;

});
