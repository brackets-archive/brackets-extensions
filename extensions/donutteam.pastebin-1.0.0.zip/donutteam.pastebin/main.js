define(function (require, exports, module) {
    var PreferencesManager = brackets.getModule("preferences/PreferencesManager"),
        CommandManager = brackets.getModule("command/CommandManager"),
        Dialogs = brackets.getModule("widgets/Dialogs"),
        DefaultDialogs = brackets.getModule("widgets/DefaultDialogs"),
        EditorManager = brackets.getModule("editor/EditorManager"),
        DocumentManager = brackets.getModule("document/DocumentManager"),
        Menus = brackets.getModule("command/Menus");
    
    /* Preferences */
    prefs = PreferencesManager.getExtensionPrefs("dtpastebin");
    if(prefs.get("def_expire_time") === null){
        prefs.definePreference("def_expire_time", "string", "1W");
    }
    if(prefs.get("privacy") === null){
        prefs.definePreference("privacy", "string", "0");
    }
    
    /* Functions */
    function pasteResponse(data){
            if(data.substr(0,7) == 'http://'){
                Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_INFO, "Pastebin Successful", "<h2 style='text-align: center;'>Copy the link:</h2><p>Your code was successfully shared to Pastebin. It will remain there until the time you set when sharing or in your preferences expires.</p><input type='text' value='"+data+"' onClick='$(this).focus().select();' style='border: 0px; background: none; outline: none; text-align: center; width: 100%; box-sizing: border-box; box-shadow: none;'><p style='text-align: center;'>Because of limitations, you must copy this to your clipboard yourself. Just click on it and press Control+C / Command+C</p>");
                //window.open(data); - Doesn't do what I want it to do.
            } else {
                Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_INFO, "Pastebin Unsuccessful", data);
            }
    }
    
    function pastebin_qui(){
        $.post("http://pastebin.com/api/api_post.php",{ "api_dev_key": "c9f13ec91efadaa2c658b5168757892d","api_option":"paste","api_paste_code":DocumentManager.getCurrentDocument().getText(),"api_paste_expire_date":prefs.get('def_expire_time'),"api_paste_private":prefs.get('privacy') },function(data){ pasteResponse(data); });
    }
    
    function pastebin (){
        var pasteshare = '',
            share_expireDate = prefs.get('def_expire_time'),
            share_privacy = prefs.get('privacy'),
            share_onlyShareSelc = null;
        pasteshare += '<b>Default Expire Date</b><br />'; 
            pasteshare += '<select id="expireDate">';
                pasteshare += '<option value="1W"';
                    if(prefs.get('def_expire_time') == "1W"){ pasteshare += 'SELECTED'; }
                pasteshare += '>7 Days</option>';

                pasteshare += '<option value="10M"'
                    if(prefs.get('def_expire_time') == "10M"){ pasteshare += 'SELECTED'; }
                pasteshare += '>10 Minutes</option>';

                pasteshare += '<option value="N"';
                    if(prefs.get('def_expire_time') == 'N'){ pasteshare += 'SELECTED'; }
                pasteshare += '>Never</option>';
            pasteshare += '</select><br />';
        
        $('#expireDate').on('change',function(){
            share_expireDate = $(this).val();
        });
        
        pasteshare += '<b>Privacy</b><br />';
            pasteshare += '<select id="privacy">';
                pasteshare += '<option value="0"';
                    if(prefs.get('privacy') == 0){ pasteshare += 'SELECTED'; }
                pasteshare += '>Public</option>';

                pasteshare += '<option value="1"';
                    if(prefs.get('privacy') == 1){ pasteshare += 'SELECTED'; }
                pasteshare += '>Unlisted</option>';
	       pasteshare += '</select><br />';
        
        $('#privacy').on('change',function(){
            share_privacy = $(this).val();
        });
        
        pasteshare += '<b>Only Share Selected Code:</b><br />';
            pasteshare += '<input type="checkbox" name="onlyShareSelction"';
            if(EditorManager.getCurrentFullEditor().getSelectedText() == ""){
                pasteshare += 'DISABLED>';
                share_onlyShareSelc = 0;
            } else {
                pasteshare += 'CHECKED>';
                share_onlyShareSelc = 1;
                $('#onlyShareSelection').on('change',function(){
                    if($(this).is(':checked')){
                        share_onlyShareSelc = 1;
                    } else {
                        share_onlyShareSelc = 0;   
                    }
                });
            }
        Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_INFO, "Share to Pastebin", pasteshare,[
                    {
                        className : Dialogs.DIALOG_BTN_CLASS_PRIMARY,
                        id        : Dialogs.DIALOG_BTN_OK,
                        text      : "Share"
                    },
                    {
                        className : Dialogs.DIALOG_BTN_CLASS_NORMAL,
                        id        : Dialogs.DIALOG_BTN_CANCEL,
                        text      : "Cancel"
                    }
                ]).done(function (id) {
                    if (id === Dialogs.DIALOG_BTN_OK) {
                        var share_SharingContent;
                        if(share_onlyShareSelc == 0){
                            share_SharingContent = DocumentManager.getCurrentDocument().getText();    
                        } else {
                            share_SharingContent = EditorManager.getCurrentFullEditor().getSelectedText();
                        }
                        $.post("http://pastebin.com/api/api_post.php",{ "api_dev_key": "c9f13ec91efadaa2c658b5168757892d","api_option":"paste","api_paste_code":share_SharingContent,"api_paste_expire_date":share_expireDate,"api_paste_private":share_privacy },function(data){ pasteResponse(data); });
                    } else {
                        //nothing   
                    }
                });
    }
    
    function pastebin_opt_dis (){
        var prefshow;
        prefshow = '<p>Pastebin.com is a website where you can store text for a certain period of time. The website is mainly used by programmers to store pieces of sources code or configuration information, but anyone is more than welcome to paste any type of text. The idea behind the site is to make it more convenient for people to share large amounts of text online. This extension allows you to have a one click sharing to pastebin and pulling code from Pastebin to a document.</p>';
        prefshow += '<b>Default Expire Date</b><br />';
        prefshow += '<select id="expireDate">';
            prefshow += '<option value="1W"';
                if(prefs.get('def_expire_time') == "1W"){ prefshow += 'SELECTED'; }
            prefshow += '>7 Days</option>';
        
            prefshow += '<option value="10M"'
                if(prefs.get('def_expire_time') == "10M"){ prefshow += 'SELECTED'; }
            prefshow += '>10 Minutes</option>';
        
            prefshow += '<option value="N"';
                if(prefs.get('def_expire_time') == 'N'){ prefshow += 'SELECTED'; }
            prefshow += '>Never</option>';
        prefshow += '</select><br />';
        
        prefshow += '<b>Privacy</b><br />';
        prefshow += '<select id="privacy">';
            prefshow += '<option value="0"';
                if(prefs.get('privacy') == 0){ prefshow += 'SELECTED'; }
            prefshow += '>Public</option>';
        
            prefshow += '<option value="1"';
                if(prefs.get('privacy') == 1){ prefshow += 'SELECTED'; }
            prefshow += '>Unlisted</option>';
        prefshow += '</select>';
        
		Dialogs.showModalDialog(DefaultDialogs.DIALOG_ID_INFO, "Pastebin Preferences", prefshow);
        $('#privacy').on('change',function(){
            prefs.set('privacy',$(this).val());
            prefs.save();
        });
        $('#expireDate').on('change',function(){
            prefs.set('def_expire_time',$(this).val());
            prefs.save();
        });
	}
	
	
    CommandManager.register("Quick Share to Pastebin", "pastebin_qui", pastebin_qui);
    CommandManager.register("Share to Pastebin...", "pastebin", pastebin);
    CommandManager.register("Pastebin Preferences...", "pastebin_opt", pastebin_opt_dis);
    var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
    menu.addMenuDivider();
    menu.addMenuItem("pastebin_qui");
    menu.addMenuItem("pastebin");
    menu.addMenuItem("pastebin_opt");
});