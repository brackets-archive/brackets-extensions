Brackets-宋体
=============

"Brackets-宋体"可以使Brackets代码编辑器窗口选择"宋体"显示。
本扩展借鉴于“https://github.com/TyGoss”，感谢TyGoss。
