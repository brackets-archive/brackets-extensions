brackets-wrapper
================

Extension for [Brackets Code Editor](http://brackets.io/ "Brackets"). <br /> 
Autoclose braces, curly-braces, parentheses, quotes and double quotes just like Sublime Text does. <br />
If there is selected text, extension will wrap selection with pressed symbol ('text' becomes '{text}', '[text]' and so forth).
You can edit which symbols process.
