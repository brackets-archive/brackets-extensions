# open-app

A brackets extension to allow you to open apps from the side bar.

