Color Highlighter
================

Color highlighter for CSS, LESS, SCSS, SASS and Stylus

![](/images/example.png)