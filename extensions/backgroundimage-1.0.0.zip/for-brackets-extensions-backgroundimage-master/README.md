# for-brackets-extensions-backgroundimage

#### use
directory 「assets/ini.png」 set your favorite photo