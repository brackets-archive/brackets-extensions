# SOY-brackets
brackets extension: soy syntax highlighter and quick edit functionality for soy templates

## how to install
- open Brackets
- go to extension manager under file menu
- click on the Avaliable tab
- find SOY for Brackets extension
- check your soy files syntax highlighting

## Quick Edit functionality
- cursor should be somewhere at {call} template.name {/call}
- command: ctrl/cmd+E
- inline editor open with the approprate template definition (if its avaliable in the project files)
