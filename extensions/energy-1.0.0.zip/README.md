Energy Theme for Brackets
=========================

Dark and minimal, inspired by that stuff they drink in Tron. A Brackets original.

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/Energy/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/Energy/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/Energy/blob/master/screenshots/js.png)
