# Changelog

## 1.0.6
#### Fixed
- Unexpected behavior of the "Tab" key for MAC users. MAC users should use "Cmd (⌘) + ]" keys.

## 1.0.5
#### Fixed
- Unexpected behavior of the "Tab" key for MAC users. MAC users should use "Cmd (⌘) + ]" keys.

## 1.0.4
#### Fixed
- Unexpected behavior of the "Tab" key

## 1.0.3
#### Fixed
- Key Binding where document type not HTML

## 1.0.2
#### Added 
- Ability to expand the abbreviation with the "Tab" key
#### Changed
- The HTML template was moved from the main.js

## 1.0.1
#### Added 
- Toolbar button.

## 1.0.0
- Initial release.
