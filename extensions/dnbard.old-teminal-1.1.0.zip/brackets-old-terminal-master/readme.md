#Vintage Terminal
Visual extension for *any* dark Brackets theme.

Features:
* Stylize Brackets editor with the charm of Vintage Terminal
![example](https://raw.githubusercontent.com/dnbard/brackets-old-terminal/master/shots/shot00.png)

* Works with any dark Brackets theme. Choose any theme you want!
![example](https://raw.githubusercontent.com/dnbard/brackets-old-terminal/master/shots/shot04.png)

* Support any fancy color rules from original theme
![example](https://raw.githubusercontent.com/dnbard/brackets-old-terminal/master/shots/shot03.png)

Changes:
* Added a menu item to View Menu to toggle the effect