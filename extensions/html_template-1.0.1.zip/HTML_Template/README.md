New html
=======

This only let you create a Html skeleton. 

`Html > Template`
