# brackets-oz
Oz Syntax Highlighting for the Brackets editor.
