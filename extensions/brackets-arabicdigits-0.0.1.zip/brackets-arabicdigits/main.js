/* Brackets extension that adds simple and fast acces to all those essential libraries  */
define(function (require, exports, module) {
    "use strict";
      
var Commands        = brackets.getModule("command/Commands"),
    CommandManager  = brackets.getModule("command/CommandManager"),
    Menus           = brackets.getModule("command/Menus"),
    EditorManager   = brackets.getModule("editor/EditorManager");

function replaceNumbers() {
	var string = EditorManager.getCurrentFullEditor().getSelectedText(true);
	
	console.log(string);
	string = string.replace(/0/g, '٠');
	string = string.replace(/1/g, '١');
	string = string.replace(/2/g, '٢');
	string = string.replace(/3/g, '٣');
	string = string.replace(/4/g, '٤');
	string = string.replace(/5/g, '٥');
	string = string.replace(/6/g, '٦');
	string = string.replace(/7/g, '٧');
	string = string.replace(/8/g, '٨');
	string = string.replace(/9/g, '٩');
	
	console.log(string);
	EditorManager.getActiveEditor()._codeMirror.replaceSelection(string);
}

CommandManager.register('Replace Selection with Arabic Numbers', 'arabicdigits.replaceNumbers', replaceNumbers);

Menus.getMenu(Menus.AppMenuBar.EDIT_MENU).addMenuItem('arabicdigits.replaceNumbers');

});