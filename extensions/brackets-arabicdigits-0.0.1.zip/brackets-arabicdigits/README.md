Arabic Digits 
================

A brackets extension that allows you to replace normal digits to Arabic/Persian ones (Actually from Arabic to Indian)