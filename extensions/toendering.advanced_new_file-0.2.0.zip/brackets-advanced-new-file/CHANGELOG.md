## 0.2.0 (2014-08-12)

* Change default shortcut to Ctrl-Shift-N.
* Add menu item to file menu
* Add preferences:
  * ```brackets-advanced-new-file.shortcut```
  * ```brackets-advanced-new-file.hideMenuItem```

## 0.1.0 (2014-08-07)

Initial release.
