Brackets Light Theme
# Kindfeeling-light

画像を表示するために起動が少し遅くなります。(Base64デコード処理のためです。)  
Startup is slightly slower to display the image. (This is for Base64 decoding.)  

CSS
![css](https://user-images.githubusercontent.com/54123288/74589072-7f7bb280-5045-11ea-93b4-16254f48eb82.png)
HTML
![html](https://user-images.githubusercontent.com/54123288/74589073-80acdf80-5045-11ea-9be4-9499f052fe30.png)
JS
![js](https://user-images.githubusercontent.com/54123288/74589074-81457600-5045-11ea-8004-b565896c887e.png)

[ダークテーマもあります。There is also a dark theme.](https://github.com/Aromatibus/Brackets-Kindfeeling-dark)
![html](https://user-images.githubusercontent.com/54123288/74583795-35c3a580-500e-11ea-8f86-3b7a1a8b6714.png)
