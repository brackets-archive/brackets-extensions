# Special B theme
Special B dark theme for Brackets by linoa1

## Installation
* Open Brackets
* Open the Extension Manager
* Switch to "Themes" tab
* Search for "Special B"
* Click "Install"

## Screenshot
![Brackets editor screenshot](screenshot.png)


## Copyright and License
Copyright (c) 2016 [Luisiany Inoa](https://github.com/linoa1). Released under the [MIT License](LICENSE).

