/** My extension for add Halfspace for Perisan and Arabic language in Brackets 1.7 */
define(function (require, exports, module) {
    "use strict";

    var CommandManager = brackets.getModule("command/CommandManager"),
        EditorManager  = brackets.getModule("editor/EditorManager"),
        KeyBindingManager  = brackets.getModule("command/KeyBindingManager"),
        Menus          = brackets.getModule("command/Menus");


    // Function to run when the menu item is clicked
    function handleHalfSpace() {
        var editor=EditorManager.getFocusedEditor();
        
        if(editor)
        {
            var insertaionPos=editor.getCursorPos();
            //editor.document.replaceRange(String.fromCharCode("8201"),insertaionPos);
            editor.document.replaceRange("‌",insertaionPos);
        }
    }


    
    var MY_COMMAND_ID = "abp-half-space.addChar";
    CommandManager.register("Add HalfSpace", MY_COMMAND_ID, handleHalfSpace);

    KeyBindingManager.removeBinding("Ctrl-Shift-2");
    
    var menu = Menus.getMenu(Menus.AppMenuBar.EDIT_MENU);
    menu.addMenuItem(MY_COMMAND_ID,"Ctrl-Shift-2");
});