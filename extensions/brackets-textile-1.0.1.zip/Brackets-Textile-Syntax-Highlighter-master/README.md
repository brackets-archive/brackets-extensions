#Textile Syntax Highlighting for Brackets

Provides textile syntax highlight via a CodeMirror mode for Brackets.

##Install from URL

1. Open the the Extension Manager from the File menu
2. Copy paste the URL of the github repo or zip file

##Install from file system

1. Download this extension using the ZIP button above and unzip it.
2. Copy it in Brackets' `/extensions/user` folder by selecting `Help > Show Extension Folder` in the menu. 
3. Reload Brackets.

##Instructions

This extension is useful only if you use RedCloth/Jekyll to convert textile files to html.  See  [RedCloth.org/Textile](http://redcloth.org/textile "RedCloth Textile") for more info.

Submit issues on the github if you'd like additions or more functionality. Styles were arbitrarily chosen by me. 

##Special Thanks

This was created by using the .jade syntax highlighter by Drew Bratcher as reference.