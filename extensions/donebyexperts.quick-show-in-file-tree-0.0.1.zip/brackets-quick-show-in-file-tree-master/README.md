Brackets Quick Show In File Tree
================================

Adobe Brackets Extention:  Creates context menu and shortcut to quickly show a file in project tree.

![Image of screenshot](screenshot.jpg)

Change Log
----------
first releast - version 0.0.1


Future
------

Automatically show in file tree when switching editing documents