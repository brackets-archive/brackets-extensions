define({
    "CMD_STATIC_PREVIEW": "Statische Vorschau",
    "CMD_STATIC_PREVIEW_SETTINGS": "Statische Vorschau konfigurieren\u2026",
    "RESTART": "Server neustarten",
    "DIALOG_RESTART_TITLE": "Einstellungen übernehmen",
    "DIALOG_RESTART_TEXT": "Um die geänderten Einstellungen zu übernehmen, muss Static Preview neugestartet werden.",
    "DIALOG_SETTINGS_TITLE": "Statische Vorschau konfigurieren",
    "SETTING_HOSTNAME": "Hostname",
    "SETTING_PORT": "Port",
    "TOOLBAR_LABEL_STOP": "Statische Vorschau beenden",
    "TOOLBAR_LABEL_START": "Statische Vorschau starten"
});
