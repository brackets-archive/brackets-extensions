define({
    "CMD_STATIC_PREVIEW": "Anteprima Statica",
    "CMD_STATIC_PREVIEW_SETTINGS": "Impostazioni Anteprima Statica\u2026",
    "RESTART" : "Riavvia Server",
    "DIALOG_RESTART_TITLE" : "Applica impostazioni",
    "DIALOG_RESTART_TEXT" : "Per applicare le impostazioni modificate, Anteprima Statica sarà necessario riavviare.",
    "DIALOG_SETTINGS_TITLE" : "Impostazioni Anteprima Statica",
    "SETTING_HOSTNAME" : "Hostname",
    "SETTING_LIVERELOADPORT": "Porta Livereload",
    "SETTING_PORT" : "Porta",
    "TOOLBAR_LABEL_STOP": "Stop Anteprima Statica",
    "TOOLBAR_LABEL_START": "Avvia Anteprima Statica"
});
