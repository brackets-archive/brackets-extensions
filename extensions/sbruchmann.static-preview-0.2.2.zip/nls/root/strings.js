define({
    "CMD_STATIC_PREVIEW": "Static Preview",
    "CMD_STATIC_PREVIEW_SETTINGS": "Static Preview Settings\u2026",
    "RESTART": "Restart Server",
    "DIALOG_RESTART_TITLE": "Apply Settings",
    "DIALOG_RESTART_TEXT": "In order to apply changed settings, Static Preview will need to restart.",
    "DIALOG_SETTINGS_TITLE": "Static Preview Settings",
    "SETTING_BASEPATH": "Root Directory",
    "SETTING_HOSTNAME": "Hostname",
    "SETTING_LIVERELOADPORT": "Livereload Port",
    "SETTING_PORT": "Port",
    "TOOLBAR_LABEL_STOP": "Stop Static Preview",
    "TOOLBAR_LABEL_START": "Start Static Preview"
});
