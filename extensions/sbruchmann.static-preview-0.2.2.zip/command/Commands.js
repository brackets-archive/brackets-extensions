define({
    STATIC_PREVIEW:          "sbruchmann.static-preview.toggle",
    STATIC_PREVIEW_SETTINGS: "sbruchmann.static-preview.settings"
});
