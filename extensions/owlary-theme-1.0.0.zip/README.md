Owlary Theme for Brackets
=========================

Dark theme inspired by [Waher](http://waher.net/) Notepad++ theme by Kristo Vaher.

Brackets theme adapted from [Base16 Tomorrow Dark Theme](https://github.com/enricodangelo/brackets-themes/tree/master/enricodangelo.base16-tomorrow-dark-theme)

![Owlary Theme for Brackets](https://github.com/mpegyna/owlary-theme/blob/master/screenshot.jpg)

Created by mpegyna. 
