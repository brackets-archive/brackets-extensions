# CoffeeLint [![Build Status](https://travis-ci.org/zaggino/brackets-coffeelint.svg?branch=master)](https://travis-ci.org/zaggino/brackets-coffeelint)

Brackets extension which provides file linting with CoffeeLint.

Uses CoffeeLint from [https://www.npmjs.com/package/coffeelint](https://www.npmjs.com/package/coffeelint)

## How to install

Use [brackets-npm-registry](https://github.com/zaggino/brackets-npm-registry)

## How to configure

Use standard `coffeelint.json` file
