/* eslint no-sync:0 */
const MyClass = {
	
	MyMethod: function () {
		return "something"
	}
	
};