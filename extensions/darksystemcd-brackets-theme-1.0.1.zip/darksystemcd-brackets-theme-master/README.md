<h2>DarkSystemCD® | Brackets Theme 1.0.1</h2>

provide the productivity quality production from DarkSystemCD programming as WDS_Styles color scheme.

<h3>brackets .less file</h3>

![DarkSystemCD® | Brackets Theme](http://i.imgur.com/6DEyKCy.png)

<h3>style .css file</h3>

![DarkSystemCD® | Brackets Theme](http://i.imgur.com/J9UUTlN.png)

<h3>logic .js file</h3>

![DarkSystemCD® | Brackets Theme](http://i.imgur.com/mS157e2.png)


<h3>document .html file</h3>

![DarkSystemCD® | Brackets Theme](http://i.imgur.com/74JyXDe.png)

---

**DarkSystemCD&#174;** used to identify, meet, work and publish<br />
logics and programming design, software, games and music<br />
on interfaces and electronic, digital and virtual media.<br />

**WDS_Styles** is a layout personality scheme<br />
created for the presentation of WDS.DarkBrain&#174; Productions.<br /><br />

DIGITAL MONITOR DISPLAY SETTINGS

[D a r k R o o m]
backlight: 0; contrast: 20; brightness: 40; sharpness: 10; color: 20; tint: 0; color temp.: 0;<br>
[L i g h t R o o m]
backlight: 10; contrast: 20; brightness: 40; sharpness: 10; color: 25; tint: 0; color temp.: 0;<br>

---

> available as sample usage from the original production of DarkSystemCD quality<br />
in which as far it provides has being created from BloodArt logo(art and literature).<br />
references should restrict moral violence from any purpose where `try - catch - finnaly` would affect this availability before whatever statement.

thanks for choosing DarkSystemCD,
