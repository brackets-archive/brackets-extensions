80's Baby Theme for Brackets
============================

Inspired by Silkie's 80's Baby. A Brackets original.

This theme is very bad for your eyes :+1:

## HTML
![HTML Screenshot](https://github.com/Brackets-Themes/80sBaby/blob/master/screenshots/html.png)

## CSS
![CSS Screenshot](https://github.com/Brackets-Themes/80sBaby/blob/master/screenshots/css.png)

## JS
![JS Screenshot](https://github.com/Brackets-Themes/80sBaby/blob/master/screenshots/js.png)
