#### dark-proton-theme

This is a port of the [Dark Proton theme for Brackets](https://github.com/shohan4556/dark-proton), which was
created by [shohan4556](https://github.com/shohan4556).

###Installation

- Open Brackets
- Open the Extension Manager
- Switch to "Themes" tab
- Search for "Dark Proton Theme"
- Click "Install"


## JS
![JS Screenshot](https://github.com/shohan4556/dark-proton/blob/master/screenshots/js.jpg)


## HTML
![HTML Screenshot](https://github.com/shohan4556/dark-proton/blob/master/screenshots/html.jpg)
