#Brackets Epic Green Theme
A very nice and pretty green dark Brackets theme that is easy on the eyes.
#Install
1. Open Brackets
2. Open the Extension Manager
3. Navigate to the "Themes" tab
4. Search, "Epic Green"
5. Click install on the theme titled, "Epic Green"
6. Go to View > Themes and select the Epic Green theme.

#HTML
<a href="http://imgur.com/MvhJnjp"><img src="http://i.imgur.com/MvhJnjp.png" title="source: imgur.com" /></a>
#CSS
<a href="http://imgur.com/83u4V0v"><img src="http://i.imgur.com/83u4V0v.png" title="source: imgur.com" /></a>
#JavaScript
<a href="http://imgur.com/5Qom3g4"><img src="http://i.imgur.com/5Qom3g4.png" title="source: imgur.com" /></a>
