django-brackets
===============

This is a simple extension to add syntaxe highlighter for Django templates to Brackets

Thanks for [lh brackets syntax highlighter jinja2] for the help, that was so easy to make this extension after i saw his example, since the extension will just bring back what [already exists ;) ].

Road Map
--------------
The main idea was to use [Tornado] templates, since it is like the Django one, the trick it to use that extension, now, the second step, is trying to add [the code folding] support.






[lh brackets syntax highlighter jinja2]: https://github.com/Leif7/lh.brackets.syntax-highlighter-jinja2
[already exists ;) ]: http://codemirror.net/mode/django/index.html
[Tornado]: http://www.tornadoweb.org/en/stable/
[the code folding]: https://github.com/thehogfather/brackets-code-folding
