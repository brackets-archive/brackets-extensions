BracketsExtensionManagerShortkey
================================

A plug-in developed for the open source text editor Brackets that enables quick access to the Brackets Extension Manager using the command Alt+Shift+O
