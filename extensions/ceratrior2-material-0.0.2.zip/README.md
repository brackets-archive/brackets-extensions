# Ceratrior II (inspired by Material design)
Brackets material design dark theme(beta).

![Alt text](https://raw.githubusercontent.com/Voronar/ceratrior2-material/master/pic1.png "Example") 