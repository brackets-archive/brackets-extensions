# brackets-gnu-assembler-syntax-highlighter

GNU Assembler Syntax Highlighter for Brackets Editor
