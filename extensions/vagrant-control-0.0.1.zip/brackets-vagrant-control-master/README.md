brackets-vagrant-control
========================

Vagrant control

  This extension allows to start, suspend and halt a vagrant virtual machine located in the project path
