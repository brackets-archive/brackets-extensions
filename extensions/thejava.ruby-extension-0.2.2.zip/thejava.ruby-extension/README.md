Simple Ruby Extension
=====================

A simple Brackets extension that adds:
* comments to Ruby files, 
* syntax highlight for specific Rails files (Gemfile, Rakefile),
* html highlight for ERB and HAML files

