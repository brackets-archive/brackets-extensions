(function() {
    var util = require('util'),
        child_process = require('child_process'),
        exec = child_process.exec,
        spawn = child_process.spawn,
        child;
    
    var irb, ruby;
    
    require('../src/utils');
    
    /* Recieves a command like ruby PATH_TO_FILE */
    var executeRubyCommand = function(params/*, win Optional? */) {
        ruby = spawn('ruby', params);
        _setRubyHandlers();
        // Use some type of $ event
    }
    
    var _setRubyHandlers = function() {
        ruby.stdout.on('data', function(data) {
            console.log('RUBY EXEC stdout: ' + data);
        });
        ruby.stderr.on('data', function(data) {
            console.log('RUBY EXEC stderr: ' + data);
        });
        ruby.on('close', function(code) {
            console.log('RUBY EXEC child process exited with code ' + code);
        });
    }
    
    /*
    var _execHandler = function(error, stdout, stderr) {
        output = stdout;
        console.log(stdout);
        console.log('stderr: ' + stderr);
        if (error !== null) {
          console.error('exec error: ' + error);
        }
        var toReturn = stdout || stderr || error;
        $(window).trigger('rb-build-done', toReturn);
        return toReturn;
    }
    */
    
    var startIrb = function(params) {
        irb = spawn('irb', params);
    };
    
    var _setIrbHandlers = function() {
        irb.stdout.on('data', function(data) {
            console.log('IRB EXEC stdout: ' + data);
        });
        irb.stderr.on('data', function(data) {
            console.log('IRB EXEC stderr: ' + data);
        });
        irb.on('close', function(code) {
            console.log('IRB EXEC child process exited with code ' + code);
        });
    }
    
    function init(DomainManager) {
        if (!DomainManager.hasDomain("ruby")) {
            DomainManager.registerDomain("ruby", {major: 0, minor: 2});
        }
        DomainManager.registerCommand(
            "ruby",         // domain name
            "exec",         // command name
            executeRubyCommand, // command handler function
            false,          // this command is synchronous
            "Runs a ruby command in context",
            []             // no parameters
            //[{name: "memory",
            //    type: "{total: number, free: number}",
            //    description: "amount of total and free memory in bytes"}]
        );
        // For the future.....
        DomainManager.registerCommand(
            "ruby",
            "irb",
            startIrb,
            true, // asynchronous
            "Starts an irb window",
            []
        );
    }
    
    exports.init = init;
        
})();