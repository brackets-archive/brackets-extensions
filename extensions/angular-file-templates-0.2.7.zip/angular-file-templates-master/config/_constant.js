/**
 * @author {{{author}}}
 * @since {{{date}}}
 */

(function () {
    'use strict';

    angular
        .module('{{{moduleName}}}')
        .constant('{{{elementName}}}',
        // Add your values here
        );
    });
})();
