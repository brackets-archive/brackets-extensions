/**
 * @author {{{author}}}
 * @since {{{date}}}
 */

(function () {
    'use strict';

    angular
        .module('{{{moduleName}}}')
        .value('{{{elementName}}}',
        // Add your values here
        );
    });
})();
