# jasmine-autocompleter-bracketsio
Simple Jasmine autocompleter to make easier your day by day testing
