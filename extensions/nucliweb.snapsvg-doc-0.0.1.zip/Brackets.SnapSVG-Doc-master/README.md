## Brackets SnapSVG-Doc

Access to API Reference of SnapSVG

![alt tag](https://raw.githubusercontent.com/nucliweb/Brackets.SnapSVG-Doc/master/media/SnapSVG-Screenshot.png)

## Credits

* [Adobe Web Platform](https://github.com/adobe-webplatform/) for this awesome library.