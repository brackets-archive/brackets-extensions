# DarkBlue4Brackets

Dark Blue theme is inspired by one of most fascinating themes I've encountered, 
and that is [Bartelme](http://www.bartelme.at)'s Dark Blue theme for WordPress.

His color scheme was so bold and different than others, that I swore to myself 
- one day I'll make a coding theme out of it. (Silly me.) And here it is. 
I hope you'll like it.

![screenshot](https://raw.githubusercontent.com/diomed/DarkBlue4Brackets/master/screenshot/screenshot.png)

##  How to Use
1. Open Brackets.
2. Open the `Extension Manager`.
3. Switch to `Themes` tab.
4. Search for `Dark Blue`.
5. Click `Install`.
6. `View` -> `Themes...` -> `Dark Blue`.
7. Enjoy! :)