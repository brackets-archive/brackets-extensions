define(function (require, exports, module) {
    var simple = require("simple");

simple
    function noop(){
    }
});