define(function(require, exports, module){
    function functionRequire(){
    }

    return functionRequire;
});