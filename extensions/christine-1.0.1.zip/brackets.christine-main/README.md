# brackets.christine
Christine language support extension for Brackets editor
