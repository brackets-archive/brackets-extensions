Resonant Light
===

Adobe Brackets light theme, with dark UI elements. It uses the SourceSansPro typeface (variable width) for comments. Font smoothing is set to sub-pixel for better rendering on Mac OSX.

Screenshot
---

![HTML](images/screenshot-011.png)

Version History
---
####0.1.0

- Initial Commit & Submission

####0.1.1

- Support for CSS Color Preview (https://github.com/cmgddd/Brackets-css-color-preview)
- Padding fix to gutters/line numbers
- Moved and rearranged repository

License
---

The MIT License. Read [LICENSE](LICENSE) for further information.
