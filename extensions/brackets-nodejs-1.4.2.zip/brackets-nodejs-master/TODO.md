* ~~Add coloring to Brackets' console~~
* ~~Start process with arguments~~
* Multiple process at once on Brackets' side
* Support for Coffescript and Typescript