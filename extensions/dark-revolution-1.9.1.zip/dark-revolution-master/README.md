# Dark-Revolution

[![Downloads](https://badges.ml/dark-revolution/total.svg)](https://brackets-extension-badges.github.io#dark-revolution)
[![Downloads](https://badges.ml/dark-revolution/last-version.svg)](https://brackets-extension-badges.github.io#dark-revolution)
[![Downloads](https://badges.ml/dark-revolution/week.svg)](https://brackets-extension-badges.github.io#dark-revolution)
[![Downloads](https://badges.ml/dark-revolution/day.svg)](https://brackets-extension-badges.github.io#dark-revolution)
[![Version](https://badges.ml/dark-revolution/version.svg)](https://brackets-extension-badges.github.io#dark-revolution)

![Alt text](https://github.com/af009/dark-revolution/blob/master/assets/dark-logo.png?raw=true "Logo")

A dark theme based on Brackets Dark.  

# Vue
![Alt text](https://github.com/af009/dark-revolution/blob/master/assets/vue.png?raw=true "Vue")

# React/JSX
![Alt text](https://github.com/af009/dark-revolution/blob/master/assets/react.png?raw=true "React")

# PHP/HTML
![Alt text](https://github.com/af009/dark-revolution/blob/master/assets/php.png?raw=true "PHP")

# JS
![Alt text](https://github.com/af009/dark-revolution/blob/master/assets/js.png?raw=true "JS")

# CSS
![Alt text](https://github.com/af009/dark-revolution/blob/master/assets/css.png?raw=true "CSS")

Enjoy!
