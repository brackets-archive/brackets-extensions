# BracketsStarterTemplate
This is an extension for Brackets. This extension creates a starter HTML5 Template page by adding a command to the Edit Menu.
This is an [Adobe Brackets](http://brackets.io) extension.
