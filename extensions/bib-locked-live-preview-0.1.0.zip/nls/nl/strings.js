/*global define */

// Dutch strings
define({
    'COMMAND_NAME': 'Vergrendelde Live Preview',

    /* ICON TITLES */
    "ICON_TITLE_BASE": "Vergrendel huidige pagina in live preview\n-Vergrendelde Live Preview-",
	"ICON_TITLE_UNLOCK": "Schakel vergendelde live preview uit\nvan '{0}'\n-Vergrendelde Live Preview-",
	"ICON_TITLE_LOCK": "Open '{0}'\nin vergrendelde live preview\n-Vergrendelde Live Preview-",
	"ICON_TITLE_SWITCH_LOCK": "Ga naar '{0}'\nin vergrendelde live preview\n-Vergrendelde Live Preview-",
	"ICON_TITLE_NODOC": "Open eerst een pagina in the editor\n-Vergrendelde Live Preview-"
});