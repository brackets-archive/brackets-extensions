/*global define */

// English - root strings
define({
    "COMMAND_NAME": "Locked Live Preview",

    /* ICON TITLES */
    "ICON_TITLE_BASE": "Lock current page in live preview\n-Locked Live Preview-",
	"ICON_TITLE_UNLOCK": "Deactivate locked live preview\nof '{0}'\n-Locked Live Preview-",
	"ICON_TITLE_LOCK": "Open '{0}'\nin locked live preview\n-Locked Live Preview-",
	"ICON_TITLE_SWITCH_LOCK": "Switch to '{0}'\n in locked live preview\n-Locked Live Preview-",
	"ICON_TITLE_NODOC": "First open a page in the editor\n-Locked Live Preview-"
});