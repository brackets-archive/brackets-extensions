
define(function (require, exports, module) {
	'use strict';

	//Require
	var BladeSyntaxHighlight  = require('src/bladesyntaxhighlight');
	var BladeCodeHint		 = require('src/bladecodehint');

	//Call
	BladeSyntaxHighlight;
	BladeCodeHint;

});
