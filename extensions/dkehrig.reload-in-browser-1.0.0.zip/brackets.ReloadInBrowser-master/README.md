Brackets: Reload in Browser
===========================

Adds a toolbar button and shortcut to reload the page in the browser.

Installation
------------

Clone the repository into extensions/user

	git clone https://github.com/DennisKehrig/brackets.ReloadInBrowser.git brackets/src/extensions/user/ReloadInBrowser