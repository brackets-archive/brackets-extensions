# New One Dark Theme for Brackets

Inspired by One Dark Theme for Atom Editor.

## Installation

* Open the Extension Manager in Brackets
* Switch to "Themes" tab
* Search for "New One Dark Theme"
* Click "Install"

## Javascript
![JS Screenshot](https://github.com/moritzw1/one-dark-theme-for-brackets/blob/master/screenshot/js_screenshot.png)
## HTML
![HTML Screenshot](https://github.com/moritzw1/one-dark-theme-for-brackets/blob/master/screenshot/html_screenshot.png)
## PHP
![PHP Screenshot](https://github.com/moritzw1/one-dark-theme-for-brackets/blob/master/screenshot/php_screenshot.png)
## CSS
![CSS Screenshot](https://github.com/moritzw1/one-dark-theme-for-brackets/blob/master/screenshot/css_screenshot.png)