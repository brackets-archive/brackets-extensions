Bracket-InspectEditor
================

Quick toggle to enable/disable the ability to inspect the Editor's DOM in Developer Tools.  Make sure to use this only while you need to enable inspection, as pop up menus will misbehave a bit.

![Enable](https://raw.github.com/wiki/MiguelCastillo/Brackets-InspectEditor/images/screenshot.png)
