# Switch-camelCase-or-snake_case
An extension of Brackets. Switch between snake case and camel case for the selected area or the entire text.
