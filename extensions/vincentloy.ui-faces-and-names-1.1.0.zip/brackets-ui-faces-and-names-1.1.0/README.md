Brackets UI Faces & Names
====================

Generate random images & names from over 6K+ pictures & 1M+ available names. You can choose names from 40+ countries and specify the gender

The extension use [uinames.com](http://uinames.com/) & [uifaces.com](http://uifaces.com/)'s APIs to generate random pictures & names.


### ScreenShot : 

![UI Faces & Names for Brackets](https://farm8.staticflickr.com/7545/16238346352_3f788c47bc_c.jpg)
