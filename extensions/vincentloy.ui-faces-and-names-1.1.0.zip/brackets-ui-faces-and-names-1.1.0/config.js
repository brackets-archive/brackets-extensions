define(function(require, exports, module){
    exports.path = module.uri.replace('config.js', '');
});
