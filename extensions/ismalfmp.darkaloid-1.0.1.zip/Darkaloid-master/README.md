# DARKALOID

A dark theme for brackets!

Cold colour palette with a focus colouring and decolouring effect! 
While you keep the mouse over the code area it will be coloured, move your mouse to another place and the color is gone!

# LICENSE 
Licensed under MIT.

# Screenshots
## HTML
### Full colour
![HTMLfullcolor](https://github.com/Ismalf/Darkaloid/blob/master/Screenshots/HTMLFC.PNG)
### No colour
![HTMLfullcolor](https://github.com/Ismalf/Darkaloid/blob/master/Screenshots/HTMLNC.PNG)
## CSS
### Full colour
![HTMLfullcolor](https://github.com/Ismalf/Darkaloid/blob/master/Screenshots/CSSFC.PNG)
### No colour
![HTMLfullcolor](https://github.com/Ismalf/Darkaloid/blob/master/Screenshots/CSSNC.PNG)
## JS
### Full colour
![HTMLfullcolor](https://github.com/Ismalf/Darkaloid/blob/master/Screenshots/JSFC.PNG)
### No colour
![HTMLfullcolor](https://github.com/Ismalf/Darkaloid/blob/master/Screenshots/JSNC.PNG)
