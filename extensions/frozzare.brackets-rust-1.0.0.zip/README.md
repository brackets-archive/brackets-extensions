brackets-rust
=============

Adds support for Rust language via CodeMirror to Brackets
