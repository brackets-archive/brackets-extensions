[Brackets](http://brackets.io) - PHPLint
============================

PHPLint Extension for Brackets, using the `php -l` command

Requires `php` to be available in system path

Licence: MIT
