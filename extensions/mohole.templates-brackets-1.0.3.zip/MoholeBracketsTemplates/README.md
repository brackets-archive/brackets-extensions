Template HTML Mohole
====================

Questa estensione per l'editor open source [Brackets](http://brackets.io/) (di Adobe) permette di creare rapidamente nuovi file con la marcatura necessaria per gran parte dei corsi presso la scuola [Mohole](http://scuola.mohole.it/).

Non ci sono copyright o diritti applicati su questa estensione.