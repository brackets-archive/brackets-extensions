# pre-written-codes
My expandable collection codes (JS, PHP, CSS ...)

This Extension provides a platform for creating new projects for [Brackets](https://github.com/adobe/brackets).

To use this extension, simply install it then select `Saját kódok > Új kód` 
This command will present a dialog from which you can specify the name of the code.
Quickly Add any Snippets.
This extension has support for a user codes folder.
My goal is to see any code snippet should be invited.
