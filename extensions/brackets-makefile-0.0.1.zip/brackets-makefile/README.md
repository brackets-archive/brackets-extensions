brackets-makefile
=================

Run make, make install and make clean from within brackets. Useful when using Brackets to develop c programs.

Shortcut keys:

* Ctrl(Cmd)-Alt-M - run 'make'
* Ctrl(Cmd)-Alt-I - run 'make install'
* Ctrl(Cmd)-Alt-C - run 'make clean'
