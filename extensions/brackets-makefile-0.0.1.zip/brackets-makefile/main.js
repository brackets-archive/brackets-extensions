/**
	(c) by Brian Schau

	This extension is heavily based on the excellent brackets-builder
	extension.    However, I am the only one to blame for mistakes in
	this extension ...
*/
define(function (require, exports, module) {
	'use strict';

	var AppInit = brackets.getModule('utils/AppInit');
        var CommandManager = brackets.getModule('command/CommandManager');
        var DocumentManager = brackets.getModule('document/DocumentManager');
        var ExtensionUtils = brackets.getModule('utils/ExtensionUtils');
	var FileSystem = brackets.getModule('filesystem/FileSystem');
	var KeyBindingManager = brackets.getModule('command/KeyBindingManager');
	var Menus = brackets.getModule('command/Menus');
        var NodeConnection = brackets.getModule('utils/NodeConnection');
        var PanelManager = brackets.getModule('view/PanelManager');
	var domainName = 'makefile.execute';
	var domainPath = ExtensionUtils.getModulePath(module) + 'domain';
        var panelHtml = require('text!makefile-panel.html');
        var panelIsVisible = false;
        var panel;
    	var currentDirectory;
	var currentFile;

	function makeCommand() {
		findMakefile('');
	}

	function makeInstallCommand() {
		findMakefile('install');
	}

	function makeCleanCommand() {
		findMakefile('clean');
	}

	function findMakefile(target) {
        	var currentDirectory = DocumentManager.getCurrentDocument().file._parentPath;
		FileSystem.resolve(currentDirectory + '/Makefile', function (error, item) {
			if (error) {
				FileSystem.resolve(currentDirectory + '/makefile', function (error, item) {
					if (error) {
						window.alert('Cannot find Makefile or makefile');
						return;
					}

					runMake(currentDirectory, 'makefile', target);
				});
			} else {
				runMake(currentDirectory, 'Makefile', target);
			}
		});
	} 

	function getOutput(data) {
		data = JSON.stringify(data);
		data = data.replace(/\\n/g, '<br />').replace(/\"/g, '').replace(/\\t/g, '');
		return data;
	}

	function runMake(currentDirectory, makefile, target) {
        	var nodeConnection = new NodeConnection();
		var cmd = 'make -f ' + makefile + ' ' + target + ' 2>&1';

		nodeConnection.connect(true).fail(function (error) {
			console.error('[Brackets Makefile] Cannot connect to node: ', error);
		}).then(function () {
			return nodeConnection.loadDomains([domainPath], true).fail(function (error) {
				console.error('[Brackets Makefile] Cannot register domain: ', error);
				});
		}).then(function () {
			nodeConnection.domains[domainName].exec(currentDirectory, cmd)
				.fail(function (err) {
					$('#makefile-panel .makefile-content').html(getOutput(err));
					panel.show();
			}).then(function (data) {
				$('#makefile-panel .makefile-content').html(getOutput(data));
				panel.show();
			});
        	}).done();
	}

	AppInit.appReady(function () {
		var MAKE_CLEAN_COMMAND = 'makefile.clean';
		var MAKE_COMMAND = 'makefile.make';
		var MAKE_INSTALL_COMMAND = 'makefile.install'
		CommandManager.register('Make', MAKE_COMMAND, makeCommand);
		CommandManager.register('Install', MAKE_INSTALL_COMMAND, makeInstallCommand);
		CommandManager.register('Clean', MAKE_CLEAN_COMMAND, makeCleanCommand);

		var menu = Menus.addMenu('Makefile', 'brianschau.makefile.makefile');
		menu.addMenuItem(MAKE_COMMAND);
		KeyBindingManager.addBinding(MAKE_COMMAND, 'Ctrl-Alt-M');
		menu.addMenuItem(MAKE_INSTALL_COMMAND);
		KeyBindingManager.addBinding(MAKE_INSTALL_COMMAND, 'Ctrl-Alt-I');
		menu.addMenuItem(MAKE_CLEAN_COMMAND);
		KeyBindingManager.addBinding(MAKE_CLEAN_COMMAND, 'Ctrl-Alt-C');

		panel = PanelManager.createBottomPanel('makefile-panel', $(panelHtml), 100);
		$('#makefile-panel .close').on('click', function () {
			panel.hide();
		});
		ExtensionUtils.loadStyleSheet(module, 'makefile.css');
	});
});

