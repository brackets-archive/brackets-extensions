# brackets-expand-selection-to-quotes
use ctrl+' to expand selection to single/double quotes
