bracket-match-highlighter
=========================

This extension enables [Adobe Brackets](https://github.com/adobe/brackets) to highlight selected text.

To active/deactivate this addon, see Menu > View > Highlight Selection.

Install
=========================

Please place the extension folder under extensions folder. To locate it, see Help > Show Extensions Folder.

License
===============

Licensed under MIT
