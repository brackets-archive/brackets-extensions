# PSD Layer Viewer
PSD Layer Viewer is an extension for the code editor Brackets that allows to view PSD files, export layers, generate CSS code.

It is a very simple extension that shows panel with site [http://psd.keyangxiang.com/](http://psd.keyangxiang.com/) which is an awesome tool to work with PSD files.

The extension have one little issue: "Export PNG" button doesn't work, so you should use drag and drop for saving image above the button.

### Installation

PSD Layer Viewer is installed from the Brackets Extension Manager.

### Acknowledgements

Author of [Online PSD Viewer](http://psd.keyangxiang.com/): [Keyang Xiang](http://keyangxiang.com/)