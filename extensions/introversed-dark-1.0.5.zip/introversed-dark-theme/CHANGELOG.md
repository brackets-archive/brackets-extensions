CHANGELOG
=========
##1.0.0
- [NEW] Initial Release

##1.0.1
- [CHANGE] README update

##1.0.2
- [CHANGE] Minor update

##1.0.3
- [CHANGE] Minor updates to theme file

##1.0.4
- [CHANGE] Minor refactoring

##1.0.4
- [CHANGE] Minor fixes