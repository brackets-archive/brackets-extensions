#Cleaner for [Brackets.io](https://github.com/adobe/brackets)

Removes trailing spaces and tabs, adds newlines at the end of the file, and converts tabs to spaces if the user is using spaces.

Press Ctrl-Alt-C to activate.

## License

MIT
