"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

/* jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4,
maxerr: 50, node: true */

/* global */
define(function (require, exports, module) {
  'use strict';

  var CodeHintManager = brackets.getModule('editor/CodeHintManager');
  var DocumentManager = brackets.getModule('document/DocumentManager');
  var LanguageManager = brackets.getModule('language/LanguageManager');

  var _require = require('./jasmine-keywords')(),
      keyFunctions = _require.keyFunctions,
      keyMatchers = _require.keyMatchers;

  var _require2 = require('./jasmine-shared'),
      matchesSpecPattern = _require2.matchesSpecPattern;
  /**
   * Jasmine Hint Provider for brackets
   */


  var JasmineHintProvider = /*#__PURE__*/function () {
    /**
     * The constructor
     */
    function JasmineHintProvider() {
      _classCallCheck(this, JasmineHintProvider);

      this.editor = null;
    }
    /**
     * The method by which the provider indicates intent to provide hints for a given editor
     * @param {Editor} editor
     * @param {String} implicitChar - contains just the last character inserted into the editor's document and the request for hints is implicit
     * @return {Boolean}
     */


    _createClass(JasmineHintProvider, [{
      key: "hasHints",
      value: function hasHints(editor, implicitChar) {
        this.editor = editor;
        var doc = DocumentManager.getCurrentDocument();

        if (!doc || !matchesSpecPattern(doc.file.fullPath)) {
          return null;
        }

        if (implicitChar == null || !/[a-zA-Z().=>{'"]/.test(implicitChar)) {
          return null;
        }

        var cursor = this.editor.getCursorPos();
        var lineBeginning = {
          line: cursor.line,
          ch: 0
        };
        var textBeforeCursor = this.editor.document.getRange(lineBeginning, cursor);
        return this.matchHints(textBeforeCursor).length > 0;
      }
      /**
       * [description]
       * @param {String} implicitChar - contains just the last character inserted into the editor's document and the request for hints is implicit
       * @return {Object}
       */

    }, {
      key: "getHints",
      value: function getHints(implicitChar) {
        if (implicitChar == null || !/[a-zA-Z().=>{'"]/.test(implicitChar)) {
          return null;
        }

        var cursor = this.editor.getCursorPos();
        var lineBeginning = {
          line: cursor.line,
          ch: 0
        };
        var textBeforeCursor = this.editor.document.getRange(lineBeginning, cursor);
        var hints = this.matchHints(textBeforeCursor);
        return {
          hints: hints,
          match: null,
          selectInitial: true,
          handleWideResults: false
        };
      }
      /**
       * Finds and matches hints to the available keywords
       * @param {String} textBeforeCursor
       * @return {Array}
       */

    }, {
      key: "matchHints",
      value: function matchHints(textBeforeCursor) {
        var result; // match functions

        var confirmedMatches = [];
        var wordBeforeCursor = textBeforeCursor.match( // eslint-disable-next-line max-len
        /((\w+)(|(\("|\('|\()))$|((expect)(\()(.*)(\))(\.))$ |((expect)(\()(.*)(\))(\.)(.*))$/i);

        if (!wordBeforeCursor || wordBeforeCursor[0].length < 1) {
          return [];
        }

        keyFunctions.forEach(function (fnName) {
          if ("".concat(fnName.toLowerCase(), "(").startsWith(wordBeforeCursor[0].toLowerCase())) {
            confirmedMatches.push(fnName);
          }
        }); // match matchers

        if (/((expect)(\()(.*)(\))(\.))$/i.test(textBeforeCursor)) {
          result = confirmedMatches.concat(keyMatchers);
        } else {
          if (/((expect)(\()(.*)(\))(\.)(.*))$/i.test(textBeforeCursor)) {
            var lastInputChars = wordBeforeCursor[0].match(/\)\.(\w+)/);
            keyMatchers.forEach(function (matcher) {
              var startString = ").".concat(matcher.toLowerCase());

              if (startString.startsWith(lastInputChars[0].toLowerCase())) {
                confirmedMatches.push(matcher);
              }
            });
          }

          result = confirmedMatches;
        }

        return result;
      }
      /**
       * Inserts the selected hint
       * @param {String} hint
       * @return {Boolean}
       */

    }, {
      key: "insertHint",
      value: function insertHint(hint) {
        var cursorPos = this.editor.getCursorPos();
        var line = this.editor.document.getLine(cursorPos.line);
        var lineTextBeforeCursor = line.slice(0, cursorPos.ch);
        var wordBeforeCursor = lineTextBeforeCursor // eslint-disable-next-line max-len
        .match(/((\w+)(|(\("|\('|\()))$|((expect)(\()(.*)(\))(\.))$ |((expect)(\()(.*)(\))(\.)(.*))$/i);

        if (!wordBeforeCursor || wordBeforeCursor[0].length < 1) {
          return false;
        }

        var start = {
          line: cursorPos.line,
          ch: cursorPos.ch - wordBeforeCursor[0].length
        };
        var end = {
          line: cursorPos.line,
          ch: cursorPos.ch
        };
        /* autocomplete for:
        * ---------------------------------
        *     expect(<anything>).
        * ---------------------------------
        */

        if (/((expect)(\()(.*)(\))(\.))$/i.test(lineTextBeforeCursor)) {
          var filler = /((expect)(\()(.*)(\))(\.))/i.test(lineTextBeforeCursor) ? '' : ').';
          this.editor.document.replaceRange("".concat(wordBeforeCursor[0]).concat(filler).concat(hint, "()"), start, end);
          var pos = this.editor.getCursorPos();
          pos.ch -= 1;
          this.editor.setCursorPos(pos);
          return true;
        }
        /* autocomplete for:
        * ---------------------------------
        *     expect(<anything>).<anything>
        * ---------------------------------
        */


        if (/((expect)(\()(.*)(\))(\.)(.*))$/i.test(lineTextBeforeCursor)) {
          var lastInputChars = wordBeforeCursor[0].match(/\)\.(\w+)/);
          var targetText = wordBeforeCursor[0].slice(0, wordBeforeCursor[0].length - lastInputChars[0].length);
          this.editor.document.replaceRange("".concat(targetText, ").").concat(hint, "()"), start, end);

          var _pos = this.editor.getCursorPos();

          _pos.ch -= 1;
          this.editor.setCursorPos(_pos);
          return true;
        }
        /* autocomplete for functions like:
        * ---------------------------------
        *     describe
        * ---------------------------------
        */


        if (keyFunctions.includes(hint) && hint != 'expect') {
          var spaceBeforeContentMatch = lineTextBeforeCursor.match(/(^\s*)|^(\t)*/);
          var whitespaceBeforeContent = spaceBeforeContentMatch ? spaceBeforeContentMatch[0] : '';
          this.editor.document.replaceRange("".concat(hint, "('', () => {\n").concat(whitespaceBeforeContent, "\t\n").concat(whitespaceBeforeContent, "})"), start, end);

          var _pos2 = this.editor.getCursorPos();

          _pos2.line -= 2;
          _pos2.ch = start.ch + hint.length + 2;
          this.editor.setCursorPos(_pos2);
          return true;
        }

        if (hint == 'expect') {
          this.editor.document.replaceRange("".concat(hint, "()"), start, end);

          var _pos3 = this.editor.getCursorPos();

          _pos3.ch -= 1;
          this.editor.setCursorPos(_pos3);
          return true;
        }
        /* autocomplete for:
        * ---------------------------------
        *     <anything>
        * ---------------------------------
        */


        this.editor.document.replaceRange(hint, start, end);
        return true;
      }
    }]);

    return JasmineHintProvider;
  }();

  module.exports = function () {
    var langIds = ['js', 'ts'].map(function (extension) {
      var language = LanguageManager.getLanguageForExtension(extension);
      return language ? language.getId() : null;
    }).filter(function (x) {
      return x != null;
    });
    CodeHintManager.registerHintProvider(new JasmineHintProvider(), langIds, 1);
  };
});