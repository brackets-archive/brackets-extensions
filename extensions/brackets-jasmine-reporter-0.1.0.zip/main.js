"use strict";

/* jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4,
maxerr: 50, node: true */

/* global */
define(function (require, exports, module) {
  'use strict';

  var AppInit = brackets.getModule('utils/AppInit');
  var CodeInspection = brackets.getModule('language/CodeInspection');
  var ExtensionUtils = brackets.getModule('utils/ExtensionUtils');
  var NodeDomain = brackets.getModule('utils/NodeDomain');
  var FileSystem = brackets.getModule('filesystem/FileSystem');
  var ProjectManager = brackets.getModule('project/ProjectManager');
  var StatusBar = brackets.getModule('widgets/StatusBar');
  var DropdownButton = brackets.getModule('widgets/DropdownButton');

  var _require = require('./support/jasmine-shared'),
      getFeedbackLines = _require.getFeedbackLines,
      matchesSpecPattern = _require.matchesSpecPattern;
  /**
   * Unique name of this Brackets extension
   * @type {String}
   */


  var EXTENSION_UNIQUE_NAME = 'nadchif.BracketsJasmine';
  /**
   * Indicates whether the current workspace/project has a /spec/support/jasmine.json file.
   * @type {Boolean}
   */

  var hasJasmineConfig = false;
  /**
   * Path to the active jasmine.json config file
   * @type {String}
   */

  var configFilePath;
  /**
   * Array of code lines for the document that was linted
   * @type {Array}
   */

  var lintedCodeLines = [];
  /**
   * Indicates that Jasmine tests are currently running
   * @type {Boolean}
   */

  var isWorking = false;
  /**
   * Indicates that tests are running as a reattempt resulting from a possible Node failure
   * @type {Boolean}
   */

  var isReattemptRun = false;
  /**
   * The Node Domain that we will be using for this extension
   * @type {NodeDomain}
   */

  var bracketsJasmineDomain = new NodeDomain('bracketsJasmineTests', ExtensionUtils.getModulePath(module, 'node/domain'));
  /**
   * The status bar dropdown button that presents the options
   *  - Run Test
   *  - Enable/Disable
   */

  var statusDropDownBtn = new DropdownButton.DropdownButton('Jasmine Tests', [' Run Tests', 'Enable/Disable']);
  statusDropDownBtn.on('select', function (event, item, itemIndex) {
    switch (itemIndex) {
      case 1:
        // Enable/Disable automatic Jasmine Tests from running on save
        hasJasmineConfig = !hasJasmineConfig;
        updateStatus();
        break;

      case 0:
        // Request CodeInspection to lint current file, which in turn will trigger JasmineTests to lint
        CodeInspection.requestRun();
        break;
    }
  });
  /**
   * Generates CodeInspection ready reports
   *
   * @param   {Object}  rawResult   raw string of results from the node process
   * @param   {String}  fileName  fullpath to the file being linted
   * @param   {String}  text      The text being linted
   * @return  {Object<String, Object>}  two reports. one for the bottom panel, one for the gutters
   */

  var generateReport = function generateReport(rawResult, fileName, text) {
    lintedCodeLines = text.split('\n');
    var results;
    var reportData = {
      errors: []
    };
    var gutterReportData = {
      errors: []
    };

    try {
      results = JSON.parse(rawResult.split('---JASMINERESULT---')[1]);
    } catch (e) {
      console.error('Failed to parse', rawResult);
      var failureMessage = {
        pos: {
          line: 0,
          ch: 1
        },
        type: CodeInspection.Type.WARNING,
        message: 'Extension Failed to parse Jasmine results'
      };
      reportData.errors.push(failureMessage);
      gutterReportData.errors.push(failureMessage);
      return {
        reportData: reportData,
        gutterReportData: gutterReportData
      };
    }

    results.specs.forEach(function (spec) {
      var message;
      var feedbackLines = getFeedbackLines(spec, lintedCodeLines, fileName);

      if (spec.status == 'passed') {
        // eslint-disable-next-line no-irregular-whitespace
        message = "\u2705\u200F\u200F\u200E\u2000 [PASS] ".concat(spec.fullName);
        reportData.errors.push({
          pos: {
            line: feedbackLines.lines[0],
            ch: 1
          },
          type: CodeInspection.Type.META,
          message: message
        });
        gutterReportData.errors.push({
          pos: {
            line: feedbackLines.lines[0],
            ch: 1
          },
          type: spec.status == 'passed' ? CodeInspection.Type.META : CodeInspection.Type.ERROR,
          message: message
        });
      } else {
        spec.failedExpectations.forEach(function (failedExpect, index) {
          var details = spec.failedExpectations[index].message;
          reportData.errors.push({
            pos: {
              line: feedbackLines.lines[index],
              ch: 1
            },
            type: CodeInspection.Type.META,
            // eslint-disable-next-line no-irregular-whitespace
            message: "\u274C\u2000 [FAIL] ".concat(spec.fullName, " -- ").concat(details)
          });
          gutterReportData.errors.push({
            pos: {
              line: feedbackLines.lines[index],
              ch: 1
            },
            type: spec.status == 'passed' ? CodeInspection.Type.META : CodeInspection.Type.ERROR,
            // eslint-disable-next-line no-irregular-whitespace
            message: "\u274C\u2000 [FAIL] ".concat(details)
          });
        });
      }
    });
    return {
      reportData: reportData,
      gutterReportData: gutterReportData
    };
  };
  /**
   * Handles projects opening and refreshing
   * @param   {Event}  event          The event
   * @param   {any}  projectRoot  The active project root
   * @return  {void}
   */


  var handleProjectOpen = function handleProjectOpen(event, projectRoot) {
    // immediately set hasJasmineConfig to false
    hasJasmineConfig = false;
    isWorking = false; // check if the project path contains /spec/support/jasmine.json

    resolveConfigFile(projectRoot.fullPath);
  };
  /**
   * Handles scanFileAsync calls to lint the current file
   * @param   {String}  text      The text of the file going to be linted
   * @param   {String}  filePath  Full filepath of the file going to be linted
   * @return  {Promise}           a jQuery.Promise
   */


  var handleLinterAsync = function handleLinterAsync(text, filePath) {
    var def = new $.Deferred();

    if (!hasJasmineConfig || !matchesSpecPattern(filePath) || isWorking) {
      console.log('[JasmineTests] ignoring...', filePath);
      isWorking = false;
      updateStatus();
      def.resolve({
        errors: []
      });
      return def.promise();
    }

    console.log("[JasmineTests] ".concat(isReattemptRun ? 'Reattempting Test' : 'Testing', "..."), filePath);
    var params = {
      file: filePath,
      config: configFilePath
    };
    isWorking = true;
    updateStatus();
    bracketsJasmineDomain.exec('runTests', params).done(function (result) {
      isWorking = false;
      updateStatus();

      var _generateReport = generateReport(result, filePath, text),
          reportData = _generateReport.reportData,
          gutterReportData = _generateReport.gutterReportData;

      try {
        if (window.bracketsInspectionGutters) {
          window.bracketsInspectionGutters.set(EXTENSION_UNIQUE_NAME, filePath, gutterReportData, true);
        } else {
          console.error("No bracketsInspectionGutters found on window");
        }
      } catch (e) {
        console.error(e);
      }

      isReattemptRun = false;
      def.resolve(reportData);
    }).fail(function (err) {
      if (!isReattemptRun) {
        isReattemptRun = true;
        isWorking = false;
        new Promise(function (resolve) {
          return setTimeout(resolve, (Math.random() + 1) * 1000);
        }).then(function () {
          return CodeInspection.requestRun();
        });
        return;
      } else {
        isReattemptRun = false;
        isWorking = false; // StatusBar.hideBusyIndicator();

        updateStatus();
        def.resolve({
          errors: [{
            pos: {
              line: 0,
              ch: 1
            },
            type: CodeInspection.Type.WARNING,
            message: "[Jasmine error occurred] ".concat(err)
          }]
        });
      }
    });
    return def.promise();
  };
  /**
   * Updates the status bar to reflect the extensions current status: enabled, disabled or running
   */


  var updateStatus = function updateStatus() {
    var status = hasJasmineConfig ? isWorking ? '⚪ Running...' : '🔵 Enabled' : '🔴 Disabled';
    statusDropDownBtn.$button.text("Jasmine: ".concat(status));
  };
  /**
   * Resolves whether the project path includes a /spec/support/jasmine.json
   * @param   {String}  projectPath        path to Project
   * @param   {Boolean}  triggerInspection  triggers a CodeInspection run if the path resolves
   * @return  {void}
   */


  var resolveConfigFile = function resolveConfigFile(projectPath, triggerInspection) {
    FileSystem.resolve("".concat(projectPath, "/spec/support/jasmine.json"), function (err, file) {
      if (err) {
        hasJasmineConfig = false;
        updateStatus();
      } else {
        configFilePath = "".concat(projectPath, "/spec/support/jasmine.json");
        hasJasmineConfig = true;

        if (triggerInspection) {
          CodeInspection.requestRun();
        }

        updateStatus();
      }
    });
  }; // register linter


  CodeInspection.register('javascript', {
    name: 'JasmineTests',
    scanFileAsync: handleLinterAsync
  }); // add the Jasmine Tests button to the status bar

  StatusBar.addIndicator('jasmineTestsStatus', statusDropDownBtn.$button, true, 'btn btn-dropdown btn-status-bar', 'Jasmine Tests', 'status-overwrite');
  ProjectManager.on('projectOpen', handleProjectOpen);
  ProjectManager.on('projectRefresh', handleProjectOpen);
  AppInit.appReady(function () {
    resolveConfigFile(ProjectManager.getProjectRoot().fullPath, true);

    require('support/jasmine-hint-provider')();

    updateStatus();
  }); // exports for unit test purposes

  exports.updateStatus = updateStatus;
  exports.resolveConfigFile = resolveConfigFile;
  exports.getFeedbackLines = getFeedbackLines;
  exports.generateReport = generateReport;
  exports.handleLinterAsync = handleLinterAsync;
  exports.matchesSpecPattern = matchesSpecPattern;
});