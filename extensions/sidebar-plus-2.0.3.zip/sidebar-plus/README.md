[Brackets](https://github.com/adobe/brackets) is an open-source code editor built with the web for the web.

You can hide your sidebar using **View->Hide Sidebar** Or **Ctrl+Alt+H** (Brackets Feature). But it is little hard, if you want to access it immediatley. By using this extension, you can bring sidebar into view by clicking at the left corner and you can collapse it by clicking on editor area.

You can see this [youtube](http://youtu.be/T4X7YIrOBOo) video for demo.

Please post issues and feature changes/requests. I will try to improve this. 
