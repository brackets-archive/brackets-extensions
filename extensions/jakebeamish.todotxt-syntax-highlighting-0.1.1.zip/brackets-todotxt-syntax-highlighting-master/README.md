# Brackets-Todotxt-Syntax-Highlighting
A very basic syntax highlighter for viewing the [Todo.txt Format](https://github.com/ginatrapani/todo.txt-cli/wiki/The-Todo.txt-Format) in [Brackets](http://brackets.io) using [CodeMirror](http://codemirror.net) [Simple Mode](http://codemirror.net/demo/simplemode.html).
