CodeMirror.defineSimpleMode("todotxt", {
    start: [
        // date in YYYY-MM-DD format
        { regex: /[0-9]{4}-[0-9]{2}-[0-9]{2}/, token: "number" },
        // context as @string
        { regex: /\@\w+/, token: "keyword" },
        // project as +string
        { regex: /\+\w+/, token: "tag" },
        // priority as (A-Z)
        { regex: /\([A-Z]\)/, token: "def" }
        ]
});

var LanguageManager = brackets.getModule("language/LanguageManager");

LanguageManager.defineLanguage("todotxt", {
    name: "Todotxt",
    mode: "todotxt",
    fileExtensions: ["txt"],
});