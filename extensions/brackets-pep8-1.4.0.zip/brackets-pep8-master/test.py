class Test3(lol):
    leet = loot
    12er = 10
    def ____init(mab):
        return meb


    