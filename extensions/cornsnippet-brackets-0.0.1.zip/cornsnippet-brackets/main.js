/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window, Mustache */

define(function (require, exports, module) {
    "use strict";

    var AppInit = brackets.getModule("utils/AppInit"),
        EditorManager = brackets.getModule("editor/EditorManager"),
        KeyEvent = brackets.getModule("utils/KeyEvent");

    var snippets = require("lib/snippet");

    var parseLine = function (line, cursorPosition) {
        var words;
        line = line.substring(0, cursorPosition);
        //split the line in "words" made of alphanumeric char or underscores (a-zA-Z0-9 and _)
        words = line.split(/\W/);
        return words[words.length - 1];
    };

    var keyEventHandler = function ($event, editor, event) {
        var cursorPosition,
            line,
            snippetKey,
            start;
        if ((event.type === "keydown") && (event.keyCode === KeyEvent.DOM_VK_TAB)) {
            cursorPosition = editor.getCursorPos();
            line = editor.document.getLine(cursorPosition.line);
            snippetKey = parseLine(line, cursorPosition.ch);
            if (snippets[snippetKey]) {
                start = {
                    line: cursorPosition.line,
                    ch: cursorPosition.ch - snippetKey.length
                };
                editor.document.replaceRange(snippets[snippetKey], start, cursorPosition);
                event.preventDefault();
            }
        }
    };

    var activeEditorChangeHandler = function ($event, focusedEditor, lostEditor) {
        if (lostEditor) {
            $(lostEditor).off("keyEvent", keyEventHandler);
        }

        if (focusedEditor) {
            $(focusedEditor).on("keyEvent", keyEventHandler);
        }
    };

    AppInit.appReady(function () {
        var currentEditor = EditorManager.getCurrentFullEditor();
        $(currentEditor).on('keyEvent', keyEventHandler);
        $(EditorManager).on('activeEditorChange', activeEditorChangeHandler);
    });
});
