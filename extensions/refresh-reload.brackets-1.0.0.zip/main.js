/*global define, brackets, $, console*/
//multibyte
define(function(require, exports, module){
  "use strict";
  var Editor = brackets.getModule("editor/Editor"),
      EditorManager = brackets.getModule('editor/EditorManager'),
      ExtensionUtils = brackets.getModule('utils/ExtensionUtils'),
      WorkingSetView = brackets.getModule('project/WorkingSetView'),
      ProjectManager = brackets.getModule('project/ProjectManager'),
      CommandManager = brackets.getModule("command/CommandManager"),
      Commands = brackets.getModule("command/Commands"),
      DocumentManager = brackets.getModule('document/DocumentManager'),
      CodeMirror = brackets.getModule("thirdparty/CodeMirror2/lib/codemirror"),
      icon = $('<a href="#" title="Refresh Editor" id="refresh-editor-button"></a>').appendTo($('#main-toolbar .buttons'));
  ExtensionUtils.loadStyleSheet(module, 'styles.css');
  icon.on("click", function(){
    var document = DocumentManager.getCurrentDocument(),
        editor = EditorManager.getCurrentFullEditor(),
        codeMirror = editor._codeMirror;
    if(editor){
      editor.refresh();
    }
    if(codeMirror){
      codeMirror.refresh();
    }
    ProjectManager.rerenderTree();
    WorkingSetView.refresh(true);
    /*
        if (editor) {
            editor._codeMirror.on('gutterClick', action);
            $('.CodeMirror-gutters')
                .on('mouseenter', gutterEnter)
                .on('mouseleave', gutterLeave);
        }
    */
    /*
    var editor  = EditorManager.getCurrentFullEditor(),
            cm      = editor ? editor._codeMirror : null;
        
        // Update CodeMirror overlay if editor is available
        if (cm) {
            cm.removeOverlay(indentGuidesOverlay);
            if (enabled) {
                cm.addOverlay(indentGuidesOverlay);
                updateStyleRules();
            }
            cm.refresh();
        }
    */
  })
  .on("dblclick", function(){
    CommandManager.execute(Commands.APP_RELOAD);
  })
  .on("contextmenu", function(){
    CommandManager.execute(Commands.APP_RELOAD_WITHOUT_EXTS);
  });
});