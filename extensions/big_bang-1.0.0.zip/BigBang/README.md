BigBang Theme
==============================================
Crazy Brackets theme for you.


### Supported Languages:
- **HTML,XML**
- **CSS, SCSS, SASS**
- **JavaScript**
- **Php**

Installation
---

1. Open Brackets
2. Open the Extension Manager
3. Switch to "Themes" tab
4. Search for "Monokai"
5. Click "Install"

## Screenshot
1:
![alt text](https://raw.githubusercontent.com/hosein2398/BigBang/master/screenshots/1.JPG)
<br>
2:
![alt text](https://raw.githubusercontent.com/hosein2398/BigBang/master/screenshots/2.PNG)
<br>
3:
![alt text](https://raw.githubusercontent.com/hosein2398/BigBang/master/screenshots/3.PNG)


