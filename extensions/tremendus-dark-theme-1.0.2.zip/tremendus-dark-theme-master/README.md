Tremendus Dark Theme for Brackets
=========

Forked from Zenburn, a dark low contrast color themes originally designed for Vim then modified by Zenburn, and modified by me

Dark theme has subtle near-pastel colors for those long and late-night sessions. 

![Screenshot](https://github.com/tremendus/tremendus-dark-theme/blob/master/screen.png)

For more themes and install instructions see the [Brackets Themes website](http://brackets-themes.github.io/)
