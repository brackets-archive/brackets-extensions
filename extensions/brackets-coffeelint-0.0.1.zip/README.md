de.richter.brackets.coffeelint
==============================

CoffeeLint Extension for Brackets

### External Libraries
https://github.com/clutchski/coffeelint