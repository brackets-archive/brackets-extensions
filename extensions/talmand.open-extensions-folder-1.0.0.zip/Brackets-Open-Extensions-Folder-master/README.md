#Brackets Open Extensions Folder

>"I choose a lazy person to do a hard job. Because a lazy person will find an easy way to do it." ~ Bill Gates

Are you an extensions developer for Brackets? Do you have a working copy of your project inside the user extensions folder? Do you navigate through numerous strangely named folders to find your project when wishing to develop your next brilliant idea?

**Me too!**

*I admit my projects may not be so brilliant, but brilliance can be subjective...*

Well, have I got a tool for you!

*Actually, extension...*

Start up Brackets, click on File, and choose...

###Open Extensions Folder...

...and bask in the glory of accessing any of your extensions for development!

Assuming you've installed this extension before you read that last instruction. If not, install the extension and then go back up there where it starts to say "Start up Brackets" to try again. Then bask in the glory of accessing any of your extensions for development.

No worries if you somehow basked in the glory twice.

>Success is not achieved by early risers or hard workers but by Lazy People trying to find easy way to do the same job. -- Henry Ford

Really, I made this simply because I like to keep my extension project working copy inside the extensions folder and getting to it within Brackets can be annoying. I keep one Brackets open for coding and second window open for testing. I update my code, reload the testing window, and extension loads. No copying stuff from one folder to another or having a service running to copy it for me. If things go bad; kill the testing window, fix or step back code in coding window, open new testing window, and extension loads again.

#####Use at your own discretion. If this extension somehow wipes out your projects, fries your computer, or causes thermo-nuclear global warfare then such actions are your own responsibility to sort out.