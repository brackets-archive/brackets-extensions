this.fullName = ko.computed(function () {
    return "Yay!" + " Nice work!";
}, this);

var testFunction = function () {

};