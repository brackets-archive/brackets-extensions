[![Build Status](https://travis-ci.org/NexusTools/NexusFrameworkBrackets.svg)](https://travis-ci.org/NexusTools/NexusFrameworkBrackets) [![Apache License 2.0](http://img.shields.io/hexpm/l/plug.svg)](https://coveralls.io/r/NexusTools/NexusFrameworkBrackets) [![Coverage Status](https://img.shields.io/coveralls/NexusTools/NexusFrameworkBrackets.svg)](https://coveralls.io/r/NexusTools/NexusFrameworkBrackets) [![Gratipay Tips](http://img.shields.io/gratipay/NexusTools.svg)](https://gratipay.com/NexusTools/)

NexusFramework Brackets
----------------
NexusFramework Brackets is an extension for Brackets that adds NexusFramework support and functionality to [Brackets](http://brackets.io/).

Legal
-----
NexusFramework Brackets is licensed under [Apache License 2.0](LICENSE.md).
