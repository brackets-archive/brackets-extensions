Flat Zeedijk
=====================
Light theme for [Brackets](http://brackets.io) editor.

### HTML
![HTML Screenshot](https://github.com/fredserva/flat-zeedijk/blob/master/screenshots/html.png)

### CSS
![HTML Screenshot](https://github.com/fredserva/flat-zeedijk/blob/master/screenshots/css.png)

### Javascript
![HTML Screenshot](https://github.com/fredserva/flat-zeedijk/blob/master/screenshots/js.png)
