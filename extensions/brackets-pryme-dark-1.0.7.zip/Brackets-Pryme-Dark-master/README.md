# Brackets-Pryme-Dark
Brackets Dark Theme for Dark lovers
Brackets Pryme Dark Theme inspired by Solaris Dark Theme.

Brackets Pryme Dark Theme uses "Source Code Pro Light" free Google Font. To get the full beauty of this theme please download the font from here -> https://fonts.google.com/specimen/Source+Code+Pro?selection.family=Source+Code+Pro and install it in your pc.

Install it with Extension Manager in Bracktes.
or
Download the zip file from Git and drag-and-drop the zipped folder in the Extension Managaer.

Happy Brackets coding.
