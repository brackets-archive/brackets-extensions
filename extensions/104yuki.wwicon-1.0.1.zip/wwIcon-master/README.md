##Instructions
Displays the status of the word wrap in the toolbar , you can switch its state.

## histry
 - 1.0.0 July 23 2016
First edition

